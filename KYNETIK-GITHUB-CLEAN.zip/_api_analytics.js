import supabase from './db-client.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { event } = req.query;
      let q = supabase.from('analytics_events').select('*').order('id', { ascending: false }).limit(200);
      if (event) q = q.eq('event', event);
      const { data, error } = await q;
      if (error) throw error;
      return res.status(200).json(data);
    }
    if (req.method === 'POST') {
      const body = req.body || {};
      if (!body.event) return res.status(400).json({ error: 'event is required' });
      const ip =
        (req.headers['x-forwarded-for'] || '').toString().split(',')[0].trim() ||
        req.headers['x-real-ip'] ||
        '';
      const { data, error } = await supabase
        .from('analytics_events')
        .insert({
          event: body.event,
          path: body.path || '',
          meta: body.meta ? JSON.stringify(body.meta) : null,
          ip_address: ip,
          user_agent: req.headers['user-agent'] || '',
        })
        .select()
        .single();
      if (error) throw error;
      return res.status(201).json(data);
    }
    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('analytics API error:', err);
    res.status(500).json({ error: err.message });
  }
}

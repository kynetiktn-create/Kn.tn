import { copyFileSync, mkdirSync, existsSync, writeFileSync, chmodSync } from 'fs';
import { join } from 'path';
try {
  writeFileSync('api/quotes.js', await import('fs').then(fs => fs.readFileSync('_api_quotes.js','utf8')));
  console.log('copied quotes');
} catch (e) {
  console.error('copy failed', e.message);
  // try writing to a destination that deploy packages
}

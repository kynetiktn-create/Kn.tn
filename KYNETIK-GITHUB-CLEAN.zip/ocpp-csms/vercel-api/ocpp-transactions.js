import supabase from './db-client.js';

function cors(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-API-Key');
}

export default async function handler(req, res) {
  cors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();
  try {
    if (req.method === 'GET' && req.query.report === 'energy') {
      let q = supabase.from('ocpp_transactions').select('*').order('start_timestamp', { ascending: false }).limit(1000);
      if (req.query.charge_point_id) q = q.eq('charge_point_id', req.query.charge_point_id);
      const { data, error } = await q;
      if (error) throw error;
      const list = data || [];
      const completed = list.filter((r) => r.status === 'completed' || r.energy_kwh);
      const total_kwh = completed.reduce((s, r) => s + Number(r.energy_kwh || 0), 0);
      const total_cost = completed.reduce((s, r) => s + Number(r.cost || 0), 0);
      const by_station = {};
      for (const r of completed) {
        const k = r.charge_point_id || 'unknown';
        if (!by_station[k]) by_station[k] = { charge_point_id: k, sessions: 0, energy_kwh: 0, cost: 0 };
        by_station[k].sessions += 1;
        by_station[k].energy_kwh += Number(r.energy_kwh || 0);
        by_station[k].cost += Number(r.cost || 0);
      }
      return res.status(200).json({
        total_sessions: completed.length,
        total_kwh: Number(total_kwh.toFixed(3)),
        total_cost: Number(total_cost.toFixed(3)),
        currency: 'TND',
        by_station: Object.values(by_station),
        sessions: list.slice(0, 100),
      });
    }

    if (req.method === 'GET') {
      let q = supabase.from('ocpp_transactions').select('*').order('start_timestamp', { ascending: false }).limit(Number(req.query.limit || 100));
      if (req.query.charge_point_id) q = q.eq('charge_point_id', req.query.charge_point_id);
      if (req.query.status) q = q.eq('status', req.query.status);
      const { data, error } = await q;
      if (error) throw error;
      return res.status(200).json(data || []);
    }

    if (req.method === 'POST') {
      const body = req.body || {};
      const { data, error } = await supabase.from('ocpp_transactions').insert(body).select().single();
      if (error) throw error;
      return res.status(201).json(data);
    }

    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: err.message });
  }
}

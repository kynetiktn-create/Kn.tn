import supabase from './db-client.js';

function cors(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-API-Key');
}

export default async function handler(req, res) {
  cors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();
  const resource = req.query.resource || 'events';

  try {
    if (resource === 'health') {
      const { count } = await supabase.from('ocpp_stations').select('*', { count: 'exact', head: true });
      return res.status(200).json({
        ok: true,
        service: 'kynetik-ocpp-api',
        protocol: 'OCPP 1.6J JSON',
        stations: count || 0,
        csms_package: 'ocpp-csms/',
        websocket: 'ws(s)://<csms-host>/ocpp/{chargePointId}',
        time: new Date().toISOString(),
      });
    }

    const tableMap = {
      events: 'ocpp_event_logs',
      audit: 'ocpp_audit_logs',
      'id-tags': 'ocpp_id_tags',
      users: 'ocpp_users',
      reservations: 'ocpp_reservations',
      profiles: 'ocpp_charging_profiles',
      firmware: 'ocpp_firmware_jobs',
      diagnostics: 'ocpp_diagnostics',
      commands: 'ocpp_pending_commands',
      meters: 'ocpp_meter_values',
      connectors: 'ocpp_connectors',
    };
    const table = tableMap[resource];
    if (!table) return res.status(400).json({ error: 'Unknown resource' });

    if (req.method === 'GET') {
      let q = supabase.from(table).select('*').limit(Number(req.query.limit || 100));
      // order heuristics
      if (table.includes('log') || table.includes('event') || table.includes('audit') || table.includes('command') || table.includes('meter') || table.includes('transaction')) {
        q = q.order('created_at', { ascending: false });
      }
      if (req.query.charge_point_id) q = q.eq('charge_point_id', req.query.charge_point_id);
      const { data, error } = await q;
      if (error) throw error;
      return res.status(200).json(data || []);
    }

    if (req.method === 'POST') {
      const body = { ...(req.body || {}), created_at: new Date().toISOString() };
      const { data, error } = await supabase.from(table).insert(body).select().single();
      if (error) throw error;
      return res.status(201).json(data);
    }

    if (req.method === 'DELETE' && resource === 'id-tags' && req.body?.id_tag) {
      const { error } = await supabase.from('ocpp_id_tags').delete().eq('id_tag', req.body.id_tag);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }

    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: err.message });
  }
}

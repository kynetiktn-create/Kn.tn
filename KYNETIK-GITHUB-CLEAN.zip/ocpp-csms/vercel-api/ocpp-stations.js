import supabase from './db-client.js';

function cors(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, PATCH, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-API-Key');
}

export default async function handler(req, res) {
  cors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    const { id, action } = req.query;

    if (req.method === 'GET' && !id) {
      let q = supabase.from('ocpp_stations').select('*').order('charge_point_id');
      if (req.query.status) q = q.eq('status', req.query.status);
      if (req.query.connected === 'true') q = q.eq('connected', true);
      const { data, error } = await q;
      if (error) throw error;
      return res.status(200).json(data || []);
    }

    if (req.method === 'GET' && id) {
      const { data: st, error } = await supabase.from('ocpp_stations').select('*').eq('charge_point_id', id).maybeSingle();
      if (error) throw error;
      if (!st) return res.status(404).json({ error: 'Station not found' });
      const { data: connectors } = await supabase.from('ocpp_connectors').select('*').eq('charge_point_id', id).order('connector_id');
      return res.status(200).json({ ...st, connectors: connectors || [] });
    }

    if (req.method === 'POST' && !id) {
      const body = req.body || {};
      if (!body.charge_point_id) return res.status(400).json({ error: 'charge_point_id required' });
      const row = {
        charge_point_id: body.charge_point_id,
        vendor: body.vendor || 'KYNETIK',
        model: body.model || 'NOVA',
        serial_number: body.serial_number || null,
        firmware_version: body.firmware_version || '1.0.0',
        status: 'registered',
        registration_status: 'Accepted',
        protocol: 'ocpp1.6',
        auth_key: body.auth_key || null,
        site_name: body.site_name || null,
        city: body.city || null,
        latitude: body.latitude ?? null,
        longitude: body.longitude ?? null,
        heartbeat_interval: body.heartbeat_interval || 60,
        configuration: body.configuration || {
          HeartbeatInterval: '60',
          MeterValueSampleInterval: '60',
          AuthorizeRemoteTxRequests: 'true',
        },
        connected: false,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      };
      const { data, error } = await supabase.from('ocpp_stations').insert(row).select().single();
      if (error) throw error;
      const connectors = body.connectors || [1];
      for (const c of connectors) {
        await supabase.from('ocpp_connectors').insert({
          charge_point_id: body.charge_point_id,
          connector_id: Number(c),
          status: 'Available',
          error_code: 'NoError',
          availability: 'Operative',
          meter_wh: 0,
          power_kw: 0,
          updated_at: new Date().toISOString(),
        });
      }
      await supabase.from('ocpp_audit_logs').insert({
        actor: 'api',
        action: 'REGISTER_STATION',
        resource: 'ocpp_stations',
        resource_id: body.charge_point_id,
        details: body,
        created_at: new Date().toISOString(),
      });
      return res.status(201).json(data);
    }

    if ((req.method === 'POST' || req.method === 'PUT') && id && action) {
      const body = req.body || {};
      const command_id = `cmd_${Date.now()}`;
      const map = {
        'remote-start': 'RemoteStartTransaction',
        'remote-stop': 'RemoteStopTransaction',
        reset: 'Reset',
        unlock: 'UnlockConnector',
        'change-configuration': 'ChangeConfiguration',
        'change-availability': 'ChangeAvailability',
        firmware: 'UpdateFirmware',
        diagnostics: 'GetDiagnostics',
        reserve: 'ReserveNow',
        'cancel-reservation': 'CancelReservation',
        'charging-profile': 'SetChargingProfile',
        trigger: 'TriggerMessage',
        'data-transfer': 'DataTransfer',
      };
      const ocppAction = map[action] || action;
      const { data: cmd, error: cmdErr } = await supabase
        .from('ocpp_pending_commands')
        .insert({
          command_id,
          charge_point_id: id,
          action: ocppAction,
          payload: body,
          status: 'queued',
          requested_by: 'dashboard',
          created_at: new Date().toISOString(),
        })
        .select()
        .single();
      if (cmdErr) throw cmdErr;

      // Simulate acceptance for dashboard when CSMS WS node is separate
      let result = { status: 'Accepted', note: 'Queued for CSMS WebSocket node' };
      if (action === 'remote-start') {
        const txId = Math.floor(100000 + Math.random() * 800000);
        await supabase.from('ocpp_transactions').insert({
          transaction_id: txId,
          charge_point_id: id,
          connector_id: Number(body.connectorId || 1),
          id_tag: body.idTag || 'RFID-DEMO',
          meter_start: 0,
          start_timestamp: new Date().toISOString(),
          status: 'active',
          energy_kwh: 0,
          currency: 'TND',
          created_at: new Date().toISOString(),
        });
        await supabase
          .from('ocpp_connectors')
          .update({ status: 'Charging', current_transaction_id: txId, power_kw: 7.4, updated_at: new Date().toISOString() })
          .eq('charge_point_id', id)
          .eq('connector_id', Number(body.connectorId || 1));
        await supabase
          .from('ocpp_stations')
          .update({ status: 'charging', updated_at: new Date().toISOString() })
          .eq('charge_point_id', id);
        result = { status: 'Accepted', transactionId: txId };
      }
      if (action === 'remote-stop') {
        const txId = Number(body.transactionId);
        if (txId) {
          const { data: tx } = await supabase.from('ocpp_transactions').select('*').eq('transaction_id', txId).maybeSingle();
          const meterStop = Number(body.meterStop || (tx?.meter_start || 0) + 12000);
          const energy = Math.max(0, (meterStop - Number(tx?.meter_start || 0)) / 1000);
          await supabase
            .from('ocpp_transactions')
            .update({
              status: 'completed',
              meter_stop: meterStop,
              stop_timestamp: new Date().toISOString(),
              stop_reason: 'Remote',
              energy_kwh: energy,
              cost: Number((energy * 0.45).toFixed(3)),
            })
            .eq('transaction_id', txId);
        }
        await supabase
          .from('ocpp_connectors')
          .update({ status: 'Available', current_transaction_id: null, power_kw: 0, updated_at: new Date().toISOString() })
          .eq('charge_point_id', id);
        await supabase
          .from('ocpp_stations')
          .update({ status: 'online', updated_at: new Date().toISOString() })
          .eq('charge_point_id', id);
        result = { status: 'Accepted' };
      }
      if (action === 'reset') {
        await supabase
          .from('ocpp_stations')
          .update({ status: 'online', last_boot: new Date().toISOString(), updated_at: new Date().toISOString() })
          .eq('charge_point_id', id);
      }
      if (action === 'unlock') {
        result = { status: 'Unlocked' };
      }

      await supabase
        .from('ocpp_pending_commands')
        .update({ status: 'completed', result, completed_at: new Date().toISOString() })
        .eq('command_id', command_id);

      await supabase.from('ocpp_audit_logs').insert({
        actor: 'dashboard',
        action: ocppAction,
        resource: 'ocpp_stations',
        resource_id: id,
        details: { body, result },
        created_at: new Date().toISOString(),
      });

      await supabase.from('ocpp_event_logs').insert({
        charge_point_id: id,
        direction: 'out',
        action: ocppAction,
        message_id: command_id,
        message_type: 2,
        payload: body,
        created_at: new Date().toISOString(),
      });

      return res.status(200).json({ command_id, status: 'completed', result });
    }

    if (req.method === 'DELETE' && id) {
      await supabase.from('ocpp_connectors').delete().eq('charge_point_id', id);
      const { error } = await supabase.from('ocpp_stations').delete().eq('charge_point_id', id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }

    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: err.message });
  }
}

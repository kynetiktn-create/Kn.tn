import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { MessageType, RegistrationStatus, Roles } from '../src/models/types.js';

describe('OCPP types', () => {
  it('message types', () => {
    assert.equal(MessageType.CALL, 2);
    assert.equal(MessageType.CALLRESULT, 3);
    assert.equal(MessageType.CALLERROR, 4);
  });
  it('registration + roles', () => {
    assert.ok(RegistrationStatus.Accepted);
    assert.ok(Roles.admin);
  });
});

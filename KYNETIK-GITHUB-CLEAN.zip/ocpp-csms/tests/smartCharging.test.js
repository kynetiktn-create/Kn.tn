import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { buildTxProfile, buildTxDefaultProfile } from '../src/smartCharging/engine.js';

describe('smart charging engine', () => {
  it('builds TxDefaultProfile', () => {
    const p = buildTxDefaultProfile({ chargingProfileId: 1, limitA: 16 });
    assert.equal(p.chargingProfilePurpose, 'TxDefaultProfile');
    assert.equal(p.chargingSchedule.chargingSchedulePeriod[0].limit, 16);
  });

  it('builds TxProfile with periods', () => {
    const p = buildTxProfile({
      chargingProfileId: 2,
      transactionId: 99,
      periods: [{ startPeriod: 0, limit: 10 }, { startPeriod: 3600, limit: 32 }],
    });
    assert.equal(p.transactionId, 99);
    assert.equal(p.chargingSchedule.chargingSchedulePeriod.length, 2);
  });
});

import http from 'http';
import { WebSocketServer } from 'ws';
import { randomUUID } from 'crypto';
import config from '../config/index.js';
import logger from '../logging/logger.js';
import { MessageType } from '../models/types.js';
import connectionRegistry from '../services/connectionRegistry.js';
import cpHandlers from '../services/ocppHandlers.js';
import stationRepository from '../repositories/stationRepository.js';
import eventRepository from '../repositories/eventRepository.js';

function parseChargePointId(url) {
  // Expected: /ocpp/{chargePointId} or /ocpp1.6/{chargePointId}
  if (!url) return null;
  const path = url.split('?')[0];
  const parts = path.split('/').filter(Boolean);
  // ['ocpp', 'CP001'] or ['ocpp1.6', 'CP001']
  if (parts.length < 2) return null;
  return decodeURIComponent(parts[parts.length - 1]);
}

function parseAuth(req, url) {
  const header = req.headers.authorization || '';
  if (header.startsWith('Basic ')) {
    try {
      const decoded = Buffer.from(header.slice(6), 'base64').toString('utf8');
      const idx = decoded.indexOf(':');
      return { user: decoded.slice(0, idx), pass: decoded.slice(idx + 1) };
    } catch {
      return null;
    }
  }
  try {
    const u = new URL(url, 'http://localhost');
    const key = u.searchParams.get('key') || u.searchParams.get('authKey');
    if (key) return { user: null, pass: key };
  } catch {
    /* ignore */
  }
  return null;
}

async function authorizeConnection(chargePointId, req, url) {
  if (!config.requireCpAuth) return true;
  const st = await stationRepository.get(chargePointId);
  // Auto-register unknown stations (Accepted) for scale-onboarding; tighten in prod with pre-registration.
  if (!st) {
    if (process.env.OCPP_AUTO_REGISTER === 'false') return false;
    return true;
  }
  if (!st.auth_key) return true;
  const auth = parseAuth(req, url);
  if (!auth) return false;
  if (auth.pass && auth.pass === st.auth_key) return true;
  if (auth.user === chargePointId && auth.pass === st.auth_key) return true;
  return false;
}

function send(ws, msg) {
  if (ws.readyState === 1) ws.send(JSON.stringify(msg));
}

async function handleCall(ws, chargePointId, uniqueId, action, payload) {
  await eventRepository.logOcpp({
    chargePointId,
    direction: 'in',
    action,
    messageId: uniqueId,
    messageType: MessageType.CALL,
    payload,
  });

  const handler = cpHandlers[action];
  if (!handler) {
    const err = [
      MessageType.CALLERROR,
      uniqueId,
      'NotImplemented',
      `Action ${action} not implemented`,
      {},
    ];
    send(ws, err);
    await eventRepository.logOcpp({
      chargePointId,
      direction: 'out',
      action,
      messageId: uniqueId,
      messageType: MessageType.CALLERROR,
      errorCode: 'NotImplemented',
    });
    return;
  }

  try {
    const result = await handler(chargePointId, payload || {});
    const out = [MessageType.CALLRESULT, uniqueId, result || {}];
    send(ws, out);
    await eventRepository.logOcpp({
      chargePointId,
      direction: 'out',
      action,
      messageId: uniqueId,
      messageType: MessageType.CALLRESULT,
      payload: result,
    });
  } catch (e) {
    logger.error('handler failed', { chargePointId, action, error: e.message });
    send(ws, [
      MessageType.CALLERROR,
      uniqueId,
      'InternalError',
      e.message || 'Internal error',
      {},
    ]);
  }
}

function handleCallResult(chargePointId, uniqueId, payload) {
  eventRepository.logOcpp({
    chargePointId,
    direction: 'in',
    action: null,
    messageId: uniqueId,
    messageType: MessageType.CALLRESULT,
    payload,
  });
  connectionRegistry.resolvePending(chargePointId, uniqueId, payload);
}

function handleCallError(chargePointId, uniqueId, errorCode, errorDescription, errorDetails) {
  eventRepository.logOcpp({
    chargePointId,
    direction: 'in',
    messageId: uniqueId,
    messageType: MessageType.CALLERROR,
    errorCode,
    payload: { errorDescription, errorDetails },
  });
  connectionRegistry.rejectPending(
    chargePointId,
    uniqueId,
    Object.assign(new Error(errorDescription || errorCode), { code: errorCode, details: errorDetails })
  );
}

/**
 * Create OCPP WebSocket server.
 * Attach to existing HTTP(S) server or standalone.
 */
export function createOcppWebSocketServer(server) {
  const wss = new WebSocketServer({
    server,
    path: undefined, // accept and filter manually for flexible paths
    handleProtocols: (protocols) => {
      const list = [...protocols];
      if (list.includes(config.ocppSubprotocol)) return config.ocppSubprotocol;
      if (list.includes('ocpp1.6')) return 'ocpp1.6';
      // some stacks omit subprotocol in dev
      return list[0] || config.ocppSubprotocol;
    },
  });

  wss.on('connection', async (ws, req) => {
    const url = req.url || '';
    const chargePointId = parseChargePointId(url);
    if (!chargePointId) {
      ws.close(1008, 'Missing charge point id in path. Use /ocpp/{chargePointId}');
      return;
    }

    const ok = await authorizeConnection(chargePointId, req, url);
    if (!ok) {
      logger.warn('CP auth failed', { chargePointId });
      ws.close(1008, 'Unauthorized');
      return;
    }

    ws.chargePointId = chargePointId;
    ws.isAlive = true;
    connectionRegistry.set(chargePointId, ws);
    await stationRepository.setConnected(chargePointId, true);

    ws.on('pong', () => {
      ws.isAlive = true;
    });

    ws.on('message', async (data) => {
      let msg;
      try {
        msg = JSON.parse(data.toString());
      } catch {
        logger.warn('invalid JSON from CP', { chargePointId });
        return;
      }
      if (!Array.isArray(msg) || msg.length < 2) return;
      const messageTypeId = msg[0];
      const uniqueId = msg[1];

      if (messageTypeId === MessageType.CALL) {
        const action = msg[2];
        const payload = msg[3] || {};
        await handleCall(ws, chargePointId, uniqueId, action, payload);
      } else if (messageTypeId === MessageType.CALLRESULT) {
        handleCallResult(chargePointId, uniqueId, msg[2]);
      } else if (messageTypeId === MessageType.CALLERROR) {
        handleCallError(chargePointId, uniqueId, msg[2], msg[3], msg[4]);
      }
    });

    ws.on('close', async () => {
      connectionRegistry.delete(chargePointId, ws);
      await stationRepository.setConnected(chargePointId, false);
    });

    ws.on('error', (err) => {
      logger.error('ws error', { chargePointId, error: err.message });
    });
  });

  // keepalive
  const interval = setInterval(() => {
    wss.clients.forEach((ws) => {
      if (ws.isAlive === false) return ws.terminate();
      ws.isAlive = false;
      try {
        ws.ping();
      } catch {
        /* ignore */
      }
    });
  }, 30000);
  wss.on('close', () => clearInterval(interval));

  // only upgrade OCPP paths
  server.on('upgrade', () => {
    /* ws library handles when no-server false — we used server option so default */
  });

  logger.info('OCPP WebSocket server ready', {
    subprotocol: config.ocppSubprotocol,
    examplePath: `${config.wsPath}/{chargePointId}`,
  });

  return wss;
}

/**
 * Standalone HTTP+WS bootstrap helper used when REST and WS share one port.
 */
export function attachOcppPathFilter(server) {
  // Optional custom verify — currently accepting /ocpp and /ocpp1.6 prefixes via parseChargePointId
  return server;
}

export default createOcppWebSocketServer;

import { Router } from 'express';
import { requireAuth } from '../auth/jwt.js';
import { Roles } from '../models/types.js';
import { rateLimit } from '../middleware/rateLimit.js';
import { requireFields } from '../middleware/validate.js';
import c from '../controllers/ocppRestController.js';

const router = Router();
const write = requireAuth([Roles.admin, Roles.operator, Roles.installer, Roles.api]);
const admin = requireAuth([Roles.admin]);
const read = requireAuth([]);
const mobile = requireAuth([]); // JWT optional for discover; write needs token in prod

router.use(rateLimit({ windowMs: 60_000, max: 300 }));

router.get('/health', c.health);
router.get('/auth/demo-tokens', c.demoTokens);
router.post('/auth/token', c.authToken);

// Stations
router.get('/stations', read, c.listStations);
router.get('/stations/:id', read, c.getStation);
router.post('/stations', write, requireFields(['charge_point_id']), c.registerStation);
router.patch('/stations/:id', write, c.updateStation);

// Remote commands
router.post('/stations/:id/remote-start', write, c.remoteStart);
router.post('/stations/:id/remote-stop', write, c.remoteStop);
router.post('/stations/:id/reset', write, c.reset);
router.post('/stations/:id/unlock', write, c.unlock);
router.post('/stations/:id/connectors/:connectorId/unlock', write, c.unlock);
router.post('/stations/:id/change-configuration', write, c.changeConfiguration);
router.get('/stations/:id/configuration', read, c.getConfiguration);
router.post('/stations/:id/change-availability', write, c.changeAvailability);
router.post('/stations/:id/data-transfer', write, c.dataTransfer);
router.post('/stations/:id/firmware', write, c.firmware);
router.post('/stations/:id/diagnostics', write, c.diagnostics);
router.post('/stations/:id/reserve', write, c.reserve);
router.post('/stations/:id/cancel-reservation', write, c.cancelReservation);
router.post('/stations/:id/charging-profiles', write, c.setProfile);
router.delete('/stations/:id/charging-profiles', write, c.clearProfile);
router.post('/stations/:id/composite-schedule', write, c.compositeSchedule);
router.post('/stations/:id/composite-schedule/local', write, c.compositeLocal);
router.post('/stations/:id/trigger', write, c.trigger);

// Transactions, sessions, energy
router.get('/transactions', read, c.listTransactions);
router.get('/transactions/:txId', read, c.getTransaction);
router.get('/sessions', read, c.listSessions);
router.get('/reports/energy', read, c.energyReport);
router.get('/analytics/overview', read, c.analyticsOverview);

// RFID / users / roles
router.get('/id-tags', read, c.listIdTags);
router.post('/id-tags', write, c.upsertIdTag);
router.delete('/id-tags/:idTag', write, c.deleteIdTag);
router.get('/users', admin, c.listUsers);
router.post('/users', admin, c.createUserSecure);
router.patch('/users/:userId', admin, c.updateUser);
router.get('/roles', read, c.listRoles);

// Alerts & notifications
router.get('/alerts', read, c.listAlerts);
router.post('/alerts', write, c.createAlert);
router.post('/alerts/:alertId/resolve', write, c.resolveAlert);
router.get('/notifications', read, c.listNotifications);
router.post('/notifications/:id/read', write, c.markNotificationRead);

// Jobs / event bus
router.get('/jobs', admin, c.listJobs);
router.post('/jobs', admin, c.enqueueJob);
router.get('/bus/events', admin, c.listBusEvents);

// Aux OCPP
router.get('/reservations', read, c.listReservations);
router.get('/charging-profiles', read, c.listProfiles);
router.get('/firmware-jobs', read, c.listFirmware);
router.get('/events', read, c.listEvents);
router.get('/audit', admin, c.listAudit);
router.get('/commands', read, c.listCommands);
router.get('/commands/:commandId', read, c.getCommand);

// ── Mobile API (/mobile/*) ───────────────────────────────────────────
router.post('/mobile/auth/login', c.mobileLogin);
router.get('/mobile/chargers', mobile, c.mobileDiscover);
router.get('/mobile/chargers/:id', mobile, c.mobileDetails);
router.post('/mobile/chargers/:id/start', requireAuth(['driver', Roles.admin, Roles.operator]), c.mobileStart);
router.post('/mobile/chargers/:id/stop', requireAuth(['driver', Roles.admin, Roles.operator]), c.mobileStop);
router.get('/mobile/sessions', requireAuth(['driver', Roles.admin, Roles.operator, Roles.viewer]), c.mobileHistory);
router.get('/mobile/favorites', requireAuth(['driver', Roles.admin]), c.mobileFavorites);
router.post('/mobile/favorites', requireAuth(['driver', Roles.admin]), c.mobileAddFavorite);
router.get('/mobile/profile', requireAuth(['driver', Roles.admin, Roles.operator, Roles.viewer]), c.mobileProfile);
router.get('/mobile/notifications', requireAuth(['driver', Roles.admin, Roles.operator, Roles.viewer]), c.mobileNotifications);

export default router;

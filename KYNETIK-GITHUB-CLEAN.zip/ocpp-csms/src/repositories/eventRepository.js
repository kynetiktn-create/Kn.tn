import getDb from '../database/client.js';

const mem = [];
const auditMem = [];

export const eventRepository = {
  async logOcpp({ chargePointId, direction, action, messageId, messageType, payload, errorCode }) {
    const db = getDb();
    const row = {
      charge_point_id: chargePointId || null,
      direction,
      action: action || null,
      message_id: messageId || null,
      message_type: messageType ?? null,
      payload: payload ?? null,
      error_code: errorCode || null,
      created_at: new Date().toISOString(),
    };
    mem.push(row);
    if (mem.length > 5000) mem.shift();
    if (!db) return row;
    const { error } = await db.from('ocpp_event_logs').insert(row);
    if (error) {
      // non-fatal
      return row;
    }
    return row;
  },

  async listEvents(filters = {}) {
    const db = getDb();
    if (!db) {
      let rows = [...mem].reverse();
      if (filters.charge_point_id) rows = rows.filter((r) => r.charge_point_id === filters.charge_point_id);
      if (filters.action) rows = rows.filter((r) => r.action === filters.action);
      return rows.slice(0, Number(filters.limit || 100));
    }
    let q = db.from('ocpp_event_logs').select('*').order('created_at', { ascending: false }).limit(Number(filters.limit || 100));
    if (filters.charge_point_id) q = q.eq('charge_point_id', filters.charge_point_id);
    if (filters.action) q = q.eq('action', filters.action);
    const { data, error } = await q;
    if (error) throw error;
    return data || [];
  },

  async audit({ actor, role, action, resource, resourceId, details, ip }) {
    const db = getDb();
    const row = {
      actor: actor || 'system',
      role: role || null,
      action,
      resource: resource || null,
      resource_id: resourceId || null,
      details: details || {},
      ip: ip || null,
      created_at: new Date().toISOString(),
    };
    auditMem.push(row);
    if (!db) return row;
    await db.from('ocpp_audit_logs').insert(row);
    return row;
  },

  async listAudit(limit = 100) {
    const db = getDb();
    if (!db) return [...auditMem].reverse().slice(0, limit);
    const { data, error } = await db.from('ocpp_audit_logs').select('*').order('created_at', { ascending: false }).limit(limit);
    if (error) throw error;
    return data || [];
  },
};

export default eventRepository;

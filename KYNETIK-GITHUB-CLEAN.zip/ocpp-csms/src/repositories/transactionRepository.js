import getDb from '../database/client.js';

const memTx = new Map();
const memMeter = [];
let txSeq = 100000;

export const transactionRepository = {
  nextId() {
    txSeq += 1;
    return txSeq;
  },

  async start({ chargePointId, connectorId, idTag, meterStart, timestamp, reservationId }) {
    const db = getDb();
    const transactionId = transactionRepository.nextId();
    const row = {
      transaction_id: transactionId,
      charge_point_id: chargePointId,
      connector_id: connectorId,
      id_tag: idTag,
      meter_start: Number(meterStart || 0),
      start_timestamp: timestamp || new Date().toISOString(),
      status: 'active',
      reservation_id: reservationId || null,
      energy_kwh: 0,
      currency: 'TND',
      created_at: new Date().toISOString(),
    };
    memTx.set(transactionId, row);
    if (db) {
      const { data, error } = await db.from('ocpp_transactions').insert(row).select().single();
      if (error) throw error;
      await db
        .from('ocpp_connectors')
        .update({
          current_transaction_id: transactionId,
          status: 'Charging',
          updated_at: new Date().toISOString(),
        })
        .eq('charge_point_id', chargePointId)
        .eq('connector_id', connectorId);
      return data;
    }
    return row;
  },

  async stop({ chargePointId, transactionId, meterStop, timestamp, reason, idTag }) {
    const db = getDb();
    const existing = memTx.get(transactionId) || {};
    const meterStart = Number(existing.meter_start || 0);
    const stop = Number(meterStop || meterStart);
    const energy_kwh = Math.max(0, (stop - meterStart) / 1000);
    const patch = {
      meter_stop: stop,
      stop_timestamp: timestamp || new Date().toISOString(),
      stop_reason: reason || 'Local',
      status: 'completed',
      energy_kwh,
      cost: Number((energy_kwh * 0.45).toFixed(3)),
    };
    memTx.set(transactionId, { ...existing, ...patch, transaction_id: transactionId, charge_point_id: chargePointId });
    if (db) {
      const { data, error } = await db
        .from('ocpp_transactions')
        .update(patch)
        .eq('transaction_id', transactionId)
        .select()
        .maybeSingle();
      if (error) throw error;
      await db
        .from('ocpp_connectors')
        .update({
          current_transaction_id: null,
          status: 'Available',
          power_kw: 0,
          updated_at: new Date().toISOString(),
        })
        .eq('charge_point_id', chargePointId)
        .eq('connector_id', existing.connector_id || data?.connector_id);
      return data || { ...existing, ...patch };
    }
    return memTx.get(transactionId);
  },

  async get(transactionId) {
    const db = getDb();
    if (!db) return memTx.get(Number(transactionId)) || null;
    const { data, error } = await db
      .from('ocpp_transactions')
      .select('*')
      .eq('transaction_id', Number(transactionId))
      .maybeSingle();
    if (error) throw error;
    return data;
  },

  async list(filters = {}) {
    const db = getDb();
    if (!db) {
      let rows = [...memTx.values()];
      if (filters.charge_point_id) rows = rows.filter((r) => r.charge_point_id === filters.charge_point_id);
      if (filters.status) rows = rows.filter((r) => r.status === filters.status);
      return rows.sort((a, b) => String(b.start_timestamp).localeCompare(String(a.start_timestamp)));
    }
    let q = db.from('ocpp_transactions').select('*').order('start_timestamp', { ascending: false });
    if (filters.charge_point_id) q = q.eq('charge_point_id', filters.charge_point_id);
    if (filters.status) q = q.eq('status', filters.status);
    if (filters.id_tag) q = q.eq('id_tag', filters.id_tag);
    if (filters.limit) q = q.limit(Number(filters.limit));
    const { data, error } = await q;
    if (error) throw error;
    return data || [];
  },

  async addMeterValues(chargePointId, payload) {
    const db = getDb();
    const connectorId = Number(payload.connectorId || 0);
    const transactionId = payload.transactionId != null ? Number(payload.transactionId) : null;
    const rows = [];
    for (const mv of payload.meterValue || []) {
      const ts = mv.timestamp || new Date().toISOString();
      for (const s of mv.sampledValue || []) {
        const row = {
          charge_point_id: chargePointId,
          connector_id: connectorId,
          transaction_id: transactionId,
          timestamp: ts,
          measurand: s.measurand || 'Energy.Active.Import.Register',
          value: Number(s.value),
          unit: s.unit || null,
          phase: s.phase || null,
          context: s.context || null,
          format: s.format || null,
          location: s.location || null,
          raw: s,
          created_at: new Date().toISOString(),
        };
        rows.push(row);
        memMeter.push(row);
        if (s.measurand === 'Power.Active.Import' || (!s.measurand && s.unit === 'W')) {
          // update connector power
        }
      }
    }
    // update connector power if present
    const powerSample = rows.find((r) => r.measurand === 'Power.Active.Import');
    const energySample = rows.find((r) => (r.measurand || '').includes('Energy.Active.Import'));
    if (db) {
      if (rows.length) {
        const { error } = await db.from('ocpp_meter_values').insert(rows);
        if (error) throw error;
      }
      const patch = { updated_at: new Date().toISOString() };
      if (powerSample) patch.power_kw = powerSample.unit === 'W' ? powerSample.value / 1000 : powerSample.value;
      if (energySample) patch.meter_wh = energySample.value;
      if (Object.keys(patch).length > 1) {
        await db
          .from('ocpp_connectors')
          .update(patch)
          .eq('charge_point_id', chargePointId)
          .eq('connector_id', connectorId);
      }
    }
    return { ok: true, count: rows.length };
  },

  async energyReport(filters = {}) {
    const list = await transactionRepository.list({
      charge_point_id: filters.charge_point_id,
      status: 'completed',
      limit: filters.limit || 1000,
    });
    const total_kwh = list.reduce((s, r) => s + Number(r.energy_kwh || 0), 0);
    const total_cost = list.reduce((s, r) => s + Number(r.cost || 0), 0);
    const by_station = {};
    for (const r of list) {
      const k = r.charge_point_id || 'unknown';
      if (!by_station[k]) by_station[k] = { charge_point_id: k, sessions: 0, energy_kwh: 0, cost: 0 };
      by_station[k].sessions += 1;
      by_station[k].energy_kwh += Number(r.energy_kwh || 0);
      by_station[k].cost += Number(r.cost || 0);
    }
    return {
      total_sessions: list.length,
      total_kwh: Number(total_kwh.toFixed(3)),
      total_cost: Number(total_cost.toFixed(3)),
      currency: 'TND',
      by_station: Object.values(by_station),
      sessions: list.slice(0, Number(filters.limit || 100)),
    };
  },
};

export default transactionRepository;

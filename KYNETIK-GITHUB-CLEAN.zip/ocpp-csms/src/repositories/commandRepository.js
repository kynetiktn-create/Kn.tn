import { randomUUID } from 'crypto';
import getDb from '../database/client.js';

const mem = new Map();

export const commandRepository = {
  async enqueue({ chargePointId, action, payload, requestedBy }) {
    const db = getDb();
    const row = {
      command_id: randomUUID(),
      charge_point_id: chargePointId,
      action,
      payload: payload || {},
      status: 'pending',
      result: null,
      requested_by: requestedBy || 'system',
      created_at: new Date().toISOString(),
      completed_at: null,
    };
    mem.set(row.command_id, row);
    if (db) {
      const { data, error } = await db.from('ocpp_pending_commands').insert(row).select().single();
      if (error) throw error;
      return data;
    }
    return row;
  },

  async complete(commandId, status, result) {
    const db = getDb();
    const patch = {
      status,
      result: result || {},
      completed_at: new Date().toISOString(),
    };
    const prev = mem.get(commandId) || { command_id: commandId };
    mem.set(commandId, { ...prev, ...patch });
    if (!db) return mem.get(commandId);
    const { data, error } = await db
      .from('ocpp_pending_commands')
      .update(patch)
      .eq('command_id', commandId)
      .select()
      .maybeSingle();
    if (error) throw error;
    return data;
  },

  async get(commandId) {
    const db = getDb();
    if (!db) return mem.get(commandId) || null;
    const { data, error } = await db.from('ocpp_pending_commands').select('*').eq('command_id', commandId).maybeSingle();
    if (error) throw error;
    return data;
  },

  async list(filters = {}) {
    const db = getDb();
    if (!db) {
      let rows = [...mem.values()];
      if (filters.charge_point_id) rows = rows.filter((r) => r.charge_point_id === filters.charge_point_id);
      if (filters.status) rows = rows.filter((r) => r.status === filters.status);
      return rows.sort((a, b) => String(b.created_at).localeCompare(String(a.created_at)));
    }
    let q = db.from('ocpp_pending_commands').select('*').order('created_at', { ascending: false }).limit(Number(filters.limit || 100));
    if (filters.charge_point_id) q = q.eq('charge_point_id', filters.charge_point_id);
    if (filters.status) q = q.eq('status', filters.status);
    const { data, error } = await q;
    if (error) throw error;
    return data || [];
  },
};

export default commandRepository;

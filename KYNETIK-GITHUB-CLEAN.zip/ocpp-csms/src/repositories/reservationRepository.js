import getDb from '../database/client.js';

const mem = new Map();
let seq = 5000;

export const reservationRepository = {
  nextId() {
    seq += 1;
    return seq;
  },

  async create({ chargePointId, connectorId, idTag, expiryDate, parentIdTag }) {
    const db = getDb();
    const reservationId = reservationRepository.nextId();
    const row = {
      reservation_id: reservationId,
      charge_point_id: chargePointId,
      connector_id: connectorId,
      id_tag: idTag,
      expiry_date: expiryDate,
      parent_id_tag: parentIdTag || null,
      status: 'accepted',
      created_at: new Date().toISOString(),
    };
    mem.set(reservationId, row);
    if (!db) return row;
    const { data, error } = await db.from('ocpp_reservations').insert(row).select().single();
    if (error) throw error;
    return data;
  },

  async cancel(reservationId) {
    const db = getDb();
    const patch = { status: 'cancelled' };
    const prev = mem.get(Number(reservationId));
    if (prev) mem.set(Number(reservationId), { ...prev, ...patch });
    if (!db) return mem.get(Number(reservationId));
    const { data, error } = await db
      .from('ocpp_reservations')
      .update(patch)
      .eq('reservation_id', Number(reservationId))
      .select()
      .maybeSingle();
    if (error) throw error;
    return data;
  },

  async list(chargePointId) {
    const db = getDb();
    if (!db) {
      return [...mem.values()].filter((r) => !chargePointId || r.charge_point_id === chargePointId);
    }
    let q = db.from('ocpp_reservations').select('*').order('created_at', { ascending: false });
    if (chargePointId) q = q.eq('charge_point_id', chargePointId);
    const { data, error } = await q;
    if (error) throw error;
    return data || [];
  },
};

export default reservationRepository;

import getDb from '../database/client.js';

const mem = {
  stations: new Map(),
  connectors: new Map(),
};

function keyC(cpId, connectorId) {
  return `${cpId}#${connectorId}`;
}

export const stationRepository = {
  async upsertFromBoot(chargePointId, boot, extras = {}) {
    const db = getDb();
    const row = {
      charge_point_id: chargePointId,
      vendor: boot.chargePointVendor || null,
      model: boot.chargePointModel || null,
      serial_number: boot.chargePointSerialNumber || null,
      firmware_version: boot.firmwareVersion || null,
      iccid: boot.iccid || null,
      imsi: boot.imsi || null,
      meter_type: boot.meterType || null,
      meter_serial: boot.meterSerialNumber || null,
      status: 'online',
      registration_status: extras.registrationStatus || 'Accepted',
      protocol: 'ocpp1.6',
      last_boot: new Date().toISOString(),
      last_heartbeat: new Date().toISOString(),
      connected: true,
      heartbeat_interval: extras.heartbeatInterval || 60,
      updated_at: new Date().toISOString(),
      ...extras.patch,
    };

    mem.stations.set(chargePointId, { ...(mem.stations.get(chargePointId) || {}), ...row });

    if (!db) return mem.stations.get(chargePointId);

    const { data: existing } = await db
      .from('ocpp_stations')
      .select('id')
      .eq('charge_point_id', chargePointId)
      .maybeSingle();

    if (existing?.id) {
      const { data, error } = await db
        .from('ocpp_stations')
        .update(row)
        .eq('id', existing.id)
        .select()
        .single();
      if (error) throw error;
      return data;
    }

    const { data, error } = await db
      .from('ocpp_stations')
      .insert({ ...row, created_at: new Date().toISOString() })
      .select()
      .single();
    if (error) throw error;
    return data;
  },

  async setConnected(chargePointId, connected) {
    const db = getDb();
    const patch = {
      connected,
      status: connected ? 'online' : 'offline',
      updated_at: new Date().toISOString(),
      ...(connected ? {} : {}),
    };
    const prev = mem.stations.get(chargePointId) || { charge_point_id: chargePointId };
    mem.stations.set(chargePointId, { ...prev, ...patch });
    if (!db) return mem.stations.get(chargePointId);
    const { data, error } = await db
      .from('ocpp_stations')
      .update(patch)
      .eq('charge_point_id', chargePointId)
      .select()
      .maybeSingle();
    if (error) throw error;
    return data || mem.stations.get(chargePointId);
  },

  async heartbeat(chargePointId) {
    const db = getDb();
    const patch = {
      last_heartbeat: new Date().toISOString(),
      connected: true,
      status: 'online',
      updated_at: new Date().toISOString(),
    };
    const prev = mem.stations.get(chargePointId) || { charge_point_id: chargePointId };
    mem.stations.set(chargePointId, { ...prev, ...patch });
    if (!db) return { currentTime: patch.last_heartbeat };
    await db.from('ocpp_stations').update(patch).eq('charge_point_id', chargePointId);
    return { currentTime: patch.last_heartbeat };
  },

  async list(filters = {}) {
    const db = getDb();
    if (!db) {
      let rows = [...mem.stations.values()];
      if (filters.status) rows = rows.filter((r) => r.status === filters.status);
      if (filters.connected != null) rows = rows.filter((r) => r.connected === (filters.connected === 'true' || filters.connected === true));
      return rows;
    }
    let q = db.from('ocpp_stations').select('*').order('charge_point_id');
    if (filters.status) q = q.eq('status', filters.status);
    if (filters.connected === 'true' || filters.connected === true) q = q.eq('connected', true);
    if (filters.connected === 'false' || filters.connected === false) q = q.eq('connected', false);
    if (filters.city) q = q.eq('city', filters.city);
    const { data, error } = await q;
    if (error) throw error;
    return data || [];
  },

  async get(chargePointId) {
    const db = getDb();
    if (mem.stations.has(chargePointId) && !db) return mem.stations.get(chargePointId);
    if (!db) return mem.stations.get(chargePointId) || null;
    const { data, error } = await db
      .from('ocpp_stations')
      .select('*')
      .eq('charge_point_id', chargePointId)
      .maybeSingle();
    if (error) throw error;
    return data;
  },

  async register(body) {
    const db = getDb();
    const row = {
      charge_point_id: body.charge_point_id,
      vendor: body.vendor || 'KYNETIK',
      model: body.model || 'NOVA',
      serial_number: body.serial_number || null,
      firmware_version: body.firmware_version || null,
      status: 'registered',
      registration_status: 'Accepted',
      protocol: 'ocpp1.6',
      auth_key: body.auth_key || null,
      site_name: body.site_name || null,
      city: body.city || null,
      latitude: body.latitude ?? null,
      longitude: body.longitude ?? null,
      heartbeat_interval: body.heartbeat_interval || 60,
      configuration: body.configuration || {},
      connected: false,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };
    mem.stations.set(row.charge_point_id, row);
    if (!db) return row;
    const { data, error } = await db.from('ocpp_stations').insert(row).select().single();
    if (error) throw error;
    // ensure connector 1
    await stationRepository.ensureConnector(row.charge_point_id, 1);
    if (body.connectors) {
      for (const c of body.connectors) {
        await stationRepository.ensureConnector(row.charge_point_id, Number(c));
      }
    }
    return data;
  },

  async update(chargePointId, patch) {
    const db = getDb();
    const next = { ...patch, updated_at: new Date().toISOString() };
    const prev = mem.stations.get(chargePointId) || { charge_point_id: chargePointId };
    mem.stations.set(chargePointId, { ...prev, ...next });
    if (!db) return mem.stations.get(chargePointId);
    const { data, error } = await db
      .from('ocpp_stations')
      .update(next)
      .eq('charge_point_id', chargePointId)
      .select()
      .maybeSingle();
    if (error) throw error;
    return data;
  },

  async ensureConnector(chargePointId, connectorId) {
    const db = getDb();
    const k = keyC(chargePointId, connectorId);
    const row = {
      charge_point_id: chargePointId,
      connector_id: connectorId,
      status: 'Available',
      error_code: 'NoError',
      availability: 'Operative',
      meter_wh: 0,
      power_kw: 0,
      updated_at: new Date().toISOString(),
    };
    if (!mem.connectors.has(k)) mem.connectors.set(k, row);
    if (!db) return mem.connectors.get(k);
    const { data: existing } = await db
      .from('ocpp_connectors')
      .select('id')
      .eq('charge_point_id', chargePointId)
      .eq('connector_id', connectorId)
      .maybeSingle();
    if (existing?.id) return existing;
    const { data, error } = await db.from('ocpp_connectors').insert(row).select().single();
    if (error) throw error;
    return data;
  },

  async updateConnectorStatus(chargePointId, payload) {
    const db = getDb();
    const connectorId = Number(payload.connectorId ?? 0);
    await stationRepository.ensureConnector(chargePointId, connectorId || 1);
    const k = keyC(chargePointId, connectorId);
    const patch = {
      status: payload.status || 'Available',
      error_code: payload.errorCode || 'NoError',
      info: payload.info || null,
      vendor_id: payload.vendorId || null,
      vendor_error_code: payload.vendorErrorCode || null,
      updated_at: new Date().toISOString(),
    };
    mem.connectors.set(k, { ...(mem.connectors.get(k) || {}), charge_point_id: chargePointId, connector_id: connectorId, ...patch });
    if (!db) return mem.connectors.get(k);
    const { data, error } = await db
      .from('ocpp_connectors')
      .update(patch)
      .eq('charge_point_id', chargePointId)
      .eq('connector_id', connectorId)
      .select()
      .maybeSingle();
    if (error) throw error;
    return data;
  },

  async listConnectors(chargePointId) {
    const db = getDb();
    if (!db) {
      return [...mem.connectors.values()].filter((c) => !chargePointId || c.charge_point_id === chargePointId);
    }
    let q = db.from('ocpp_connectors').select('*').order('connector_id');
    if (chargePointId) q = q.eq('charge_point_id', chargePointId);
    const { data, error } = await q;
    if (error) throw error;
    return data || [];
  },

  async setAvailability(chargePointId, connectorId, type) {
    const db = getDb();
    const availability = type === 'Inoperative' ? 'Inoperative' : 'Operative';
    const status = type === 'Inoperative' ? 'Unavailable' : 'Available';
    if (connectorId === 0) {
      // charge point level — mark all
      const cons = await stationRepository.listConnectors(chargePointId);
      for (const c of cons) {
        await stationRepository.setAvailability(chargePointId, c.connector_id, type);
      }
      return { status: 'Accepted' };
    }
    await stationRepository.ensureConnector(chargePointId, connectorId);
    const k = keyC(chargePointId, connectorId);
    mem.connectors.set(k, {
      ...(mem.connectors.get(k) || {}),
      availability,
      status,
      updated_at: new Date().toISOString(),
    });
    if (db) {
      await db
        .from('ocpp_connectors')
        .update({ availability, status, updated_at: new Date().toISOString() })
        .eq('charge_point_id', chargePointId)
        .eq('connector_id', connectorId);
    }
    return { status: 'Accepted' };
  },

  async getConfiguration(chargePointId, keys) {
    const st = await stationRepository.get(chargePointId);
    const conf = (st && st.configuration) || {
      HeartbeatInterval: '60',
      MeterValueSampleInterval: '60',
      ConnectionTimeOut: '60',
      AuthorizeRemoteTxRequests: 'true',
      LocalAuthorizeOffline: 'true',
      LocalPreAuthorize: 'false',
      ClockAlignedDataInterval: '0',
      StopTransactionOnEVSideDisconnect: 'true',
      UnlockConnectorOnEVSideDisconnect: 'true',
      AllowOfflineTxForUnknownId: 'false',
    };
    const allKeys = Object.keys(conf);
    const wanted = keys?.length ? keys : allKeys;
    const configurationKey = wanted
      .filter((k) => k in conf)
      .map((k) => ({ key: k, readonly: k === 'SupportedFeatureProfiles', value: String(conf[k]) }));
    const unknownKey = wanted.filter((k) => !(k in conf));
    return { configurationKey, unknownKey };
  },

  async changeConfiguration(chargePointId, key, value) {
    const st = (await stationRepository.get(chargePointId)) || { charge_point_id: chargePointId };
    const conf = { ...(st.configuration || {}) };
    const readonly = ['SupportedFeatureProfiles'];
    if (readonly.includes(key)) return { status: 'Rejected' };
    conf[key] = String(value);
    await stationRepository.update(chargePointId, { configuration: conf });
    if (key === 'HeartbeatInterval') {
      await stationRepository.update(chargePointId, { heartbeat_interval: Number(value) || 60 });
    }
    return { status: 'Accepted' };
  },
};

export default stationRepository;

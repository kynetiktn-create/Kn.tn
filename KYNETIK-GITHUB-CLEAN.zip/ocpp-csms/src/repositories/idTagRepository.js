import getDb from '../database/client.js';
import { AuthorizationStatus } from '../models/types.js';

const mem = new Map();

export const idTagRepository = {
  async authorize(idTag) {
    const db = getDb();
    const now = Date.now();
    let row = mem.get(idTag);
    if (db) {
      const { data } = await db.from('ocpp_id_tags').select('*').eq('id_tag', idTag).maybeSingle();
      if (data) row = data;
    }
    if (!row) {
      // open mode: accept unknown tags for demo/dev (can tighten via config)
      if (process.env.OCPP_ACCEPT_UNKNOWN_TAGS !== 'false') {
        return {
          idTagInfo: { status: AuthorizationStatus.Accepted },
        };
      }
      return { idTagInfo: { status: AuthorizationStatus.Invalid } };
    }
    if (row.status && row.status !== 'Accepted' && row.status !== 'active') {
      return {
        idTagInfo: {
          status: row.status === 'Blocked' ? AuthorizationStatus.Blocked : AuthorizationStatus.Invalid,
          parentIdTag: row.parent_id_tag || undefined,
          expiryDate: row.expiry_date || undefined,
        },
      };
    }
    if (row.expiry_date && new Date(row.expiry_date).getTime() < now) {
      return { idTagInfo: { status: AuthorizationStatus.Expired, expiryDate: row.expiry_date } };
    }
    return {
      idTagInfo: {
        status: AuthorizationStatus.Accepted,
        parentIdTag: row.parent_id_tag || undefined,
        expiryDate: row.expiry_date || undefined,
      },
    };
  },

  async list() {
    const db = getDb();
    if (!db) return [...mem.values()];
    const { data, error } = await db.from('ocpp_id_tags').select('*').order('id_tag');
    if (error) throw error;
    return data || [];
  },

  async upsert(body) {
    const db = getDb();
    const row = {
      id_tag: body.id_tag,
      user_id: body.user_id || null,
      parent_id_tag: body.parent_id_tag || null,
      status: body.status || 'Accepted',
      expiry_date: body.expiry_date || null,
      label: body.label || null,
      meta: body.meta || {},
      created_at: new Date().toISOString(),
    };
    mem.set(row.id_tag, row);
    if (!db) return row;
    const { data: existing } = await db.from('ocpp_id_tags').select('id').eq('id_tag', row.id_tag).maybeSingle();
    if (existing?.id) {
      const { data, error } = await db.from('ocpp_id_tags').update(row).eq('id', existing.id).select().single();
      if (error) throw error;
      return data;
    }
    const { data, error } = await db.from('ocpp_id_tags').insert(row).select().single();
    if (error) throw error;
    return data;
  },

  async remove(idTag) {
    const db = getDb();
    mem.delete(idTag);
    if (!db) return { ok: true };
    const { error } = await db.from('ocpp_id_tags').delete().eq('id_tag', idTag);
    if (error) throw error;
    return { ok: true };
  },
};

export default idTagRepository;

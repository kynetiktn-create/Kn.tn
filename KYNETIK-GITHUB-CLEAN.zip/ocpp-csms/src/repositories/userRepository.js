import getDb from '../database/client.js';
import { randomUUID } from 'crypto';

const mem = new Map();

export const userRepository = {
  async list() {
    const db = getDb();
    if (!db) return [...mem.values()];
    const { data, error } = await db.from('ocpp_users').select('*').order('created_at', { ascending: false });
    if (error) throw error;
    return data || [];
  },

  async create(body) {
    const db = getDb();
    const row = {
      user_id: body.user_id || randomUUID(),
      email: body.email,
      full_name: body.full_name || null,
      role: body.role || 'viewer',
      organization: body.organization || 'KYNETIK',
      status: body.status || 'active',
      phone: body.phone || null,
      meta: body.meta || {},
      created_at: new Date().toISOString(),
    };
    mem.set(row.user_id, row);
    if (!db) return row;
    const { data, error } = await db.from('ocpp_users').insert(row).select().single();
    if (error) throw error;
    return data;
  },

  async update(userId, patch) {
    const db = getDb();
    const prev = mem.get(userId) || { user_id: userId };
    mem.set(userId, { ...prev, ...patch });
    if (!db) return mem.get(userId);
    const { data, error } = await db.from('ocpp_users').update(patch).eq('user_id', userId).select().maybeSingle();
    if (error) throw error;
    return data;
  },
};

export default userRepository;

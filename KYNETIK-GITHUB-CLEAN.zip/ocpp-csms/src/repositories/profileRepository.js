import getDb from '../database/client.js';

const mem = [];

export const profileRepository = {
  async upsert(profile) {
    const db = getDb();
    const row = {
      charging_profile_id: profile.chargingProfileId,
      charge_point_id: profile.chargePointId,
      connector_id: profile.connectorId ?? 0,
      stack_level: profile.stackLevel ?? 0,
      charging_profile_purpose: profile.chargingProfilePurpose,
      charging_profile_kind: profile.chargingProfileKind,
      recurrency_kind: profile.recurrencyKind || null,
      valid_from: profile.validFrom || null,
      valid_to: profile.validTo || null,
      charging_schedule: profile.chargingSchedule || {},
      transaction_id: profile.transactionId || null,
      status: 'active',
      created_at: new Date().toISOString(),
    };
    mem.push(row);
    if (!db) return row;
    const { data, error } = await db.from('ocpp_charging_profiles').insert(row).select().single();
    if (error) throw error;
    return data;
  },

  async clear({ chargePointId, id }) {
    const db = getDb();
    if (!db) {
      const idx = mem.findIndex((p) => p.charge_point_id === chargePointId && p.charging_profile_id === id);
      if (idx >= 0) mem.splice(idx, 1);
      return { status: 'Accepted' };
    }
    await db
      .from('ocpp_charging_profiles')
      .update({ status: 'cleared' })
      .eq('charge_point_id', chargePointId)
      .eq('charging_profile_id', id);
    return { status: 'Accepted' };
  },

  async list(chargePointId) {
    const db = getDb();
    if (!db) return mem.filter((p) => !chargePointId || p.charge_point_id === chargePointId);
    let q = db.from('ocpp_charging_profiles').select('*').order('created_at', { ascending: false });
    if (chargePointId) q = q.eq('charge_point_id', chargePointId);
    const { data, error } = await q;
    if (error) throw error;
    return data || [];
  },
};

export default profileRepository;

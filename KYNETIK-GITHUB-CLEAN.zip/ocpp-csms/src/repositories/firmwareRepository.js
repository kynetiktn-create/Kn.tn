import { randomUUID } from 'crypto';
import getDb from '../database/client.js';

const fwMem = [];
const diagMem = [];

export const firmwareRepository = {
  async createJob({ chargePointId, location, retrieveDate, retries, retryInterval }) {
    const db = getDb();
    const row = {
      job_id: randomUUID(),
      charge_point_id: chargePointId,
      location,
      retrieve_date: retrieveDate || new Date().toISOString(),
      retries: retries ?? 3,
      retry_interval: retryInterval ?? 60,
      status: 'Pending',
      status_info: null,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };
    fwMem.push(row);
    if (!db) return row;
    const { data, error } = await db.from('ocpp_firmware_jobs').insert(row).select().single();
    if (error) throw error;
    return data;
  },

  async updateStatus(chargePointId, status) {
    const db = getDb();
    const patch = { status, updated_at: new Date().toISOString() };
    const last = [...fwMem].reverse().find((j) => j.charge_point_id === chargePointId);
    if (last) Object.assign(last, patch);
    if (!db) return last;
    // update latest job for CP
    const { data: jobs } = await db
      .from('ocpp_firmware_jobs')
      .select('id')
      .eq('charge_point_id', chargePointId)
      .order('created_at', { ascending: false })
      .limit(1);
    if (jobs?.[0]) {
      const { data } = await db.from('ocpp_firmware_jobs').update(patch).eq('id', jobs[0].id).select().single();
      return data;
    }
    return last;
  },

  async listJobs(chargePointId) {
    const db = getDb();
    if (!db) return fwMem.filter((j) => !chargePointId || j.charge_point_id === chargePointId);
    let q = db.from('ocpp_firmware_jobs').select('*').order('created_at', { ascending: false });
    if (chargePointId) q = q.eq('charge_point_id', chargePointId);
    const { data, error } = await q;
    if (error) throw error;
    return data || [];
  },

  async createDiagnostics({ chargePointId, location, startTime, stopTime, retries, retryInterval }) {
    const db = getDb();
    const row = {
      charge_point_id: chargePointId,
      location,
      start_time: startTime || null,
      stop_time: stopTime || null,
      retries: retries ?? 3,
      retry_interval: retryInterval ?? 60,
      status: 'Pending',
      file_name: null,
      created_at: new Date().toISOString(),
    };
    diagMem.push(row);
    if (!db) return row;
    const { data, error } = await db.from('ocpp_diagnostics').insert(row).select().single();
    if (error) throw error;
    return data;
  },

  async updateDiagnosticsStatus(chargePointId, status) {
    const db = getDb();
    const last = [...diagMem].reverse().find((d) => d.charge_point_id === chargePointId);
    if (last) last.status = status;
    if (!db) return last;
    const { data: rows } = await db
      .from('ocpp_diagnostics')
      .select('id')
      .eq('charge_point_id', chargePointId)
      .order('created_at', { ascending: false })
      .limit(1);
    if (rows?.[0]) {
      await db.from('ocpp_diagnostics').update({ status }).eq('id', rows[0].id);
    }
    return last;
  },
};

export default firmwareRepository;

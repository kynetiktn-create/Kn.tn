const LEVELS = { error: 0, warn: 1, info: 2, debug: 3 };

function ts() {
  return new Date().toISOString();
}

function emit(level, msg, meta) {
  const line = {
    ts: ts(),
    level,
    service: 'kynetik-ocpp-csms',
    msg,
    ...(meta && typeof meta === 'object' ? meta : meta != null ? { data: meta } : {}),
  };
  const text = JSON.stringify(line);
  if (level === 'error') console.error(text);
  else if (level === 'warn') console.warn(text);
  else console.log(text);
}

export const logger = {
  error: (msg, meta) => emit('error', msg, meta),
  warn: (msg, meta) => emit('warn', msg, meta),
  info: (msg, meta) => emit('info', msg, meta),
  debug: (msg, meta) => {
    if ((LEVELS[process.env.LOG_LEVEL] ?? 2) >= 3) emit('debug', msg, meta);
  },
};

export default logger;

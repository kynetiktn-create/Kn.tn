import profileRepository from '../repositories/profileRepository.js';

export function buildTxDefaultProfile({
  chargingProfileId,
  transactionId,
  stackLevel = 0,
  limitA = 32,
  unit = 'A',
  startSchedule,
  duration,
}) {
  return {
    chargingProfileId: Number(chargingProfileId),
    transactionId: transactionId != null ? Number(transactionId) : undefined,
    stackLevel: Number(stackLevel),
    chargingProfilePurpose: 'TxDefaultProfile',
    chargingProfileKind: 'Absolute',
    chargingSchedule: {
      duration: duration != null ? Number(duration) : undefined,
      startSchedule: startSchedule || new Date().toISOString(),
      chargingRateUnit: unit,
      chargingSchedulePeriod: [{ startPeriod: 0, limit: Number(limitA) }],
    },
  };
}

export function buildTxProfile({ chargingProfileId, transactionId, stackLevel = 1, periods, unit = 'A' }) {
  return {
    chargingProfileId: Number(chargingProfileId),
    transactionId: Number(transactionId),
    stackLevel: Number(stackLevel),
    chargingProfilePurpose: 'TxProfile',
    chargingProfileKind: 'Absolute',
    chargingSchedule: {
      chargingRateUnit: unit,
      chargingSchedulePeriod: (periods || [{ startPeriod: 0, limit: 16 }]).map((p) => ({
        startPeriod: Number(p.startPeriod || 0),
        limit: Number(p.limit),
        numberPhases: p.numberPhases != null ? Number(p.numberPhases) : undefined,
      })),
    },
  };
}

export async function getCompositeSchedule(chargePointId, connectorId, duration = 3600) {
  const profiles = await profileRepository.list({ charge_point_id: chargePointId });
  const relevant = profiles
    .filter((p) => !p.connector_id || Number(p.connector_id) === Number(connectorId) || Number(p.connector_id) === 0)
    .sort((a, b) => (b.stack_level || 0) - (a.stack_level || 0));

  const top = relevant[0];
  const schedule = top?.charging_schedule || {
    chargingRateUnit: 'A',
    chargingSchedulePeriod: [{ startPeriod: 0, limit: 32 }],
  };

  return {
    status: 'Accepted',
    connectorId: Number(connectorId),
    scheduleStart: new Date().toISOString(),
    chargingSchedule: { duration: Number(duration), ...schedule },
    sources: relevant.map((p) => ({
      id: p.charging_profile_id,
      purpose: p.charging_profile_purpose,
      stack: p.stack_level,
    })),
  };
}

export default { buildTxDefaultProfile, buildTxProfile, getCompositeSchedule };

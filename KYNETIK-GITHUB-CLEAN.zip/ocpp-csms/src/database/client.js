import { createClient } from '@supabase/supabase-js';
import ws from 'ws';
import config from '../config/index.js';
import logger from '../logging/logger.js';

let client = null;

export function getDb() {
  if (client) return client;
  if (!config.supabaseUrl || !config.supabaseKey) {
    logger.warn('Supabase not configured — using in-memory fallback only');
    return null;
  }
  client = createClient(config.supabaseUrl, config.supabaseKey, {
    auth: { persistSession: false, autoRefreshToken: false },
    global: {
      fetch: (...args) => fetch(...args),
    },
    realtime: {
      transport: ws,
    },
  });
  return client;
}

export default getDb;

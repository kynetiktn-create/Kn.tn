import logger from '../logging/logger.js';
import eventQueue from '../queue/eventQueue.js';
import getDb from '../database/client.js';
import { randomUUID } from 'crypto';

const handlers = new Map();

export function registerJob(type, fn) {
  handlers.set(type, fn);
}

export async function enqueue(type, payload = {}, { runAt } = {}) {
  const job = {
    job_id: `job_${randomUUID()}`,
    type,
    payload,
    status: 'pending',
    attempts: 0,
    run_at: (runAt || new Date()).toISOString(),
    created_at: new Date().toISOString(),
  };
  const db = getDb();
  if (db) await db.from('csms_jobs').insert(job);
  setTimeout(() => processJob(job), Math.max(0, new Date(job.run_at) - Date.now()));
  return job;
}

async function processJob(job) {
  const fn = handlers.get(job.type);
  if (!fn) {
    logger.warn('no job handler', { type: job.type });
    return;
  }
  try {
    await fn(job.payload, job);
    const db = getDb();
    if (db) {
      await db.from('csms_jobs').update({
        status: 'completed',
        completed_at: new Date().toISOString(),
        attempts: (job.attempts || 0) + 1,
      }).eq('job_id', job.job_id);
    }
    await eventQueue.publish('job.completed', { job_id: job.job_id, type: job.type });
  } catch (err) {
    logger.error('job failed', { type: job.type, err: err.message });
    const db = getDb();
    if (db) {
      await db.from('csms_jobs').update({
        status: 'failed',
        last_error: err.message,
        attempts: (job.attempts || 0) + 1,
      }).eq('job_id', job.job_id);
    }
  }
}

registerJob('notify', async (payload) => {
  const db = getDb();
  if (!db) return;
  await db.from('csms_notifications').insert({
    user_id: payload.user_id || 'broadcast',
    title: payload.title,
    body: payload.body,
    channel: payload.channel || 'in_app',
    severity: payload.severity || 'info',
    category: payload.category || 'system',
    read: false,
    charge_point_id: payload.charge_point_id || null,
    created_at: new Date().toISOString(),
  });
});

registerJob('reconcile_offline', async () => {
  const db = getDb();
  if (!db) return;
  const cutoff = new Date(Date.now() - 5 * 60_000).toISOString();
  await db.from('ocpp_stations')
    .update({ connected: false, status: 'offline', updated_at: new Date().toISOString() })
    .lt('last_heartbeat', cutoff)
    .eq('connected', true);
});

let timer;
export function startWorkers() {
  if (timer) return;
  timer = setInterval(() => enqueue('reconcile_offline', {}), 60_000);
  logger.info('background workers started');
}

export default { registerJob, enqueue, startWorkers };

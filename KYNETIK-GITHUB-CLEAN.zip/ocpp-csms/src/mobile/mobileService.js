import getDb from '../database/client.js';
import stationRepository from '../repositories/stationRepository.js';
import transactionRepository from '../repositories/transactionRepository.js';
import commandService from '../services/commandService.js';
import { signToken, hashPassword, verifyPassword } from '../auth/jwt.js';
import { randomUUID } from 'crypto';

export const mobileService = {
  async login({ email, password }) {
    const db = getDb();
    if (!db) {
      // demo
      if (email === 'driver@kynetik.tn') {
        return { token: signToken({ sub: 'usr-home-01', email, role: 'driver' }), user: { user_id: 'usr-home-01', email, role: 'driver' } };
      }
      throw Object.assign(new Error('Invalid credentials'), { status: 401 });
    }
    const { data: user } = await db.from('ocpp_users').select('*').eq('email', email).maybeSingle();
    if (!user) throw Object.assign(new Error('Invalid credentials'), { status: 401 });
    const hash = user.meta?.password_hash;
    if (hash && password && !(await verifyPassword(password, hash))) {
      throw Object.assign(new Error('Invalid credentials'), { status: 401 });
    }
    const token = signToken({ sub: user.user_id, email: user.email, role: user.role || 'driver' });
    await db.from('csms_mobile_tokens').insert({
      user_id: user.user_id,
      token_hash: token.slice(-16),
      device: 'mobile',
      expires_at: new Date(Date.now() + 7 * 864e5).toISOString(),
      created_at: new Date().toISOString(),
    });
    return { token, user: { user_id: user.user_id, email: user.email, full_name: user.full_name, role: user.role } };
  },

  async discover({ city, q } = {}) {
    let stations = await stationRepository.list();
    if (city) stations = stations.filter((s) => (s.city || '').toLowerCase() === city.toLowerCase());
    if (q) {
      const qq = q.toLowerCase();
      stations = stations.filter((s) =>
        [s.charge_point_id, s.site_name, s.city, s.model].some((x) => String(x || '').toLowerCase().includes(qq))
      );
    }
    return stations.map((s) => ({
      id: s.charge_point_id,
      name: s.site_name || s.charge_point_id,
      model: s.model,
      city: s.city,
      status: s.status,
      connected: s.connected,
      lat: s.latitude,
      lng: s.longitude,
      power_hint: s.model === 'PRO' ? '22–150 kW' : '7–22 kW',
    }));
  },

  async details(chargePointId) {
    const station = await stationRepository.get(chargePointId);
    if (!station) return null;
    const connectors = await stationRepository.listConnectors(chargePointId);
    return { ...station, connectors };
  },

  async startCharge({ chargePointId, connectorId = 1, idTag }, actor) {
    return commandService.remoteStart(chargePointId, { connectorId, idTag }, actor || 'mobile');
  },

  async stopCharge({ chargePointId, transactionId }, actor) {
    return commandService.remoteStop(chargePointId, { transactionId }, actor || 'mobile');
  },

  async history(userId, limit = 50) {
    const all = await transactionRepository.list({ limit: 200 });
    return all.filter((t) => !userId || t.user_id === userId || t.id_tag).slice(0, limit);
  },

  async favorites(userId) {
    const db = getDb();
    if (!db) return [];
    const { data } = await db.from('csms_favorites').select('*').eq('user_id', userId);
    return data || [];
  },

  async addFavorite(userId, chargePointId, label) {
    const db = getDb();
    if (!db) return { user_id: userId, charge_point_id: chargePointId };
    const { data } = await db.from('csms_favorites').insert({
      user_id: userId,
      charge_point_id: chargePointId,
      label: label || chargePointId,
      created_at: new Date().toISOString(),
    }).select().single();
    return data;
  },

  async profile(userId) {
    const db = getDb();
    if (!db) return { user_id: userId };
    const { data } = await db.from('ocpp_users').select('*').eq('user_id', userId).maybeSingle();
    return data;
  },

  async notifications(userId) {
    const db = getDb();
    if (!db) return [];
    const { data } = await db.from('csms_notifications').select('*').or(`user_id.eq.${userId},user_id.eq.broadcast`).order('created_at', { ascending: false }).limit(50);
    return data || [];
  },
};

export default mobileService;

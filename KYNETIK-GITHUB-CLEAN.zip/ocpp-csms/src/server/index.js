import 'dotenv/config';
/**
 * KYNETIK Charge Station Management System (CSMS)
 * OCPP 1.6J JSON — REST + WebSocket + workers
 *
 * Production: terminate TLS at load balancer (HTTPS + WSS), sticky sessions for WS,
 * shared Postgres, horizontal REST replicas.
 */
import http from 'http';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import swaggerUi from 'swagger-ui-express';
import config from '../config/index.js';
import logger from '../logging/logger.js';
import routes from '../rest/routes.js';
import createOcppWebSocketServer from '../websocket/ocppServer.js';
import { startWorkers } from '../jobs/worker.js';
import openApiSpec from '../openapi/spec.js';

const app = express();
app.set('trust proxy', true);
app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors({ origin: config.corsOrigin === '*' ? true : config.corsOrigin }));
app.use(express.json({ limit: '1mb' }));

app.get('/', (_req, res) => {
  res.json({
    name: 'KYNETIK CSMS',
    version: '1.0.0',
    protocol: 'OCPP 1.6J JSON',
    rest: '/api/ocpp/v1',
    mobile: '/api/ocpp/v1/mobile',
    openapi: '/api/docs',
    websocket: `ws(s)://<host>${config.wsPath}/{chargePointId}`,
    evolution: 'OCPP 2.0.1 adapter boundary ready',
  });
});

app.use('/api/docs', swaggerUi.serve, swaggerUi.setup(openApiSpec, {
  customSiteTitle: 'KYNETIK CSMS API',
  swaggerOptions: { persistAuthorization: true },
}));
app.get('/api/openapi.json', (_req, res) => res.json(openApiSpec));

app.use('/api/ocpp/v1', routes);

app.use((err, _req, res, _next) => {
  logger.error('rest error', { error: err.message, code: err.code });
  const status = err.code === 'CP_OFFLINE' ? 409 : err.status || 500;
  res.status(status).json({ error: err.message, code: err.code });
});

const server = http.createServer(app);
createOcppWebSocketServer(server);
startWorkers();

server.listen(config.restPort, () => {
  logger.info('KYNETIK CSMS listening', {
    restPort: config.restPort,
    restBase: `http://0.0.0.0:${config.restPort}/api/ocpp/v1`,
    docs: `http://0.0.0.0:${config.restPort}/api/docs`,
    wsExample: `ws://0.0.0.0:${config.restPort}${config.wsPath}/KYN-NOVA-001`,
    note: 'Use TLS-terminating proxy for HTTPS/WSS in production',
  });
});

export default server;

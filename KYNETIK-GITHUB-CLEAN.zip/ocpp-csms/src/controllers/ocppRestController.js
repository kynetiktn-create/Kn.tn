import stationRepository from '../repositories/stationRepository.js';
import transactionRepository from '../repositories/transactionRepository.js';
import idTagRepository from '../repositories/idTagRepository.js';
import userRepository from '../repositories/userRepository.js';
import reservationRepository from '../repositories/reservationRepository.js';
import profileRepository from '../repositories/profileRepository.js';
import firmwareRepository from '../repositories/firmwareRepository.js';
import eventRepository from '../repositories/eventRepository.js';
import commandRepository from '../repositories/commandRepository.js';
import commandService from '../services/commandService.js';
import connectionRegistry from '../services/connectionRegistry.js';
import { issueDemoTokens, signToken } from '../auth/jwt.js';
import { Roles } from '../models/types.js';
import config from '../config/index.js';
import healthReport from '../monitoring/health.js';
import mobileService from '../mobile/mobileService.js';
import notificationService from '../notifications/notificationService.js';
import smartCharging from '../smartCharging/engine.js';
import eventQueue from '../queue/eventQueue.js';
import { enqueue } from '../jobs/worker.js';
import getDb from '../database/client.js';
import { hashPassword } from '../auth/jwt.js';

function actor(req) {
  return req.user?.email || req.user?.sub || 'api';
}

export const ocppRestController = {
  async health(req, res) {
    res.json(await healthReport());
  },

  authToken(req, res) {
    const { email, role, name, sub } = req.body || {};
    const token = signToken({
      sub: sub || email || 'user',
      email: email || 'user@kynetik.tn',
      role: role || Roles.operator,
      name: name || 'KYNETIK User',
    });
    res.json({ token, token_type: 'Bearer', expires_in: config.jwtExpiresIn });
  },

  demoTokens(req, res) {
    res.json(issueDemoTokens());
  },

  async listStations(req, res) {
    const rows = await stationRepository.list(req.query);
    const online = new Set(connectionRegistry.listOnline());
    res.json(
      rows.map((r) => ({
        ...r,
        live_connected: online.has(r.charge_point_id),
      }))
    );
  },

  async getStation(req, res) {
    const st = await stationRepository.get(req.params.id);
    if (!st) return res.status(404).json({ error: 'Station not found' });
    const connectors = await stationRepository.listConnectors(req.params.id);
    res.json({
      ...st,
      live_connected: connectionRegistry.isOnline(req.params.id),
      connectors,
    });
  },

  async registerStation(req, res) {
    const body = req.body || {};
    if (!body.charge_point_id) return res.status(400).json({ error: 'charge_point_id required' });
    const existing = await stationRepository.get(body.charge_point_id);
    if (existing) return res.status(409).json({ error: 'Already registered', station: existing });
    const row = await stationRepository.register(body);
    await eventRepository.audit({
      actor: actor(req),
      role: req.user?.role,
      action: 'REGISTER_STATION',
      resource: 'ocpp_stations',
      resourceId: body.charge_point_id,
      details: body,
      ip: req.ip,
    });
    res.status(201).json(row);
  },

  async updateStation(req, res) {
    const row = await stationRepository.update(req.params.id, req.body || {});
    res.json(row);
  },

  async remoteStart(req, res) {
    const result = await commandService.remoteStart(req.params.id, req.body || {}, actor(req));
    res.json(result);
  },

  async remoteStop(req, res) {
    const result = await commandService.remoteStop(req.params.id, req.body || {}, actor(req));
    res.json(result);
  },

  async reset(req, res) {
    const type = req.body?.type || 'Soft';
    const result = await commandService.reset(req.params.id, type, actor(req));
    res.json(result);
  },

  async unlock(req, res) {
    const connectorId = req.body?.connectorId ?? req.params.connectorId ?? 1;
    const result = await commandService.unlockConnector(req.params.id, connectorId, actor(req));
    res.json(result);
  },

  async changeConfiguration(req, res) {
    const { key, value } = req.body || {};
    if (!key) return res.status(400).json({ error: 'key required' });
    const result = await commandService.changeConfiguration(req.params.id, key, value, actor(req));
    res.json(result);
  },

  async getConfiguration(req, res) {
    // Prefer live GetConfiguration when online; else DB cache
    if (connectionRegistry.isOnline(req.params.id)) {
      const keys = req.query.key ? [].concat(req.query.key) : [];
      const result = await commandService.getConfiguration(req.params.id, keys, actor(req));
      return res.json(result);
    }
    const conf = await stationRepository.getConfiguration(
      req.params.id,
      req.query.key ? [].concat(req.query.key) : undefined
    );
    res.json({ status: 'cached', result: conf });
  },

  async changeAvailability(req, res) {
    const result = await commandService.changeAvailability(req.params.id, req.body || {}, actor(req));
    res.json(result);
  },

  async dataTransfer(req, res) {
    const result = await commandService.dataTransfer(req.params.id, req.body || {}, actor(req));
    res.json(result);
  },

  async firmware(req, res) {
    if (!req.body?.location) return res.status(400).json({ error: 'location required' });
    const result = await commandService.updateFirmware(req.params.id, req.body, actor(req));
    res.json(result);
  },

  async diagnostics(req, res) {
    if (!req.body?.location) return res.status(400).json({ error: 'location required' });
    const result = await commandService.getDiagnostics(req.params.id, req.body, actor(req));
    res.json(result);
  },

  async reserve(req, res) {
    const body = req.body || {};
    if (!body.idTag || !body.expiryDate) return res.status(400).json({ error: 'idTag and expiryDate required' });
    const result = await commandService.reserveNow(req.params.id, body, actor(req));
    res.json(result);
  },

  async cancelReservation(req, res) {
    const reservationId = req.body?.reservationId || req.params.reservationId;
    const result = await commandService.cancelReservation(req.params.id, reservationId, actor(req));
    res.json(result);
  },

  async setProfile(req, res) {
    const result = await commandService.setChargingProfile(req.params.id, req.body || {}, actor(req));
    res.json(result);
  },

  async clearProfile(req, res) {
    const result = await commandService.clearChargingProfile(req.params.id, req.body || {}, actor(req));
    res.json(result);
  },

  async compositeSchedule(req, res) {
    const result = await commandService.getCompositeSchedule(req.params.id, req.body || req.query, actor(req));
    res.json(result);
  },

  async trigger(req, res) {
    if (!req.body?.requestedMessage) return res.status(400).json({ error: 'requestedMessage required' });
    const result = await commandService.triggerMessage(req.params.id, req.body, actor(req));
    res.json(result);
  },

  async listTransactions(req, res) {
    const rows = await transactionRepository.list(req.query);
    res.json(rows);
  },

  async getTransaction(req, res) {
    const row = await transactionRepository.get(req.params.txId);
    if (!row) return res.status(404).json({ error: 'Not found' });
    res.json(row);
  },

  async energyReport(req, res) {
    const report = await transactionRepository.energyReport(req.query);
    res.json(report);
  },

  async listIdTags(req, res) {
    res.json(await idTagRepository.list());
  },

  async upsertIdTag(req, res) {
    if (!req.body?.id_tag) return res.status(400).json({ error: 'id_tag required' });
    res.status(201).json(await idTagRepository.upsert(req.body));
  },

  async deleteIdTag(req, res) {
    res.json(await idTagRepository.remove(req.params.idTag));
  },

  async listUsers(req, res) {
    res.json(await userRepository.list());
  },

  async createUser(req, res) {
    if (!req.body?.email) return res.status(400).json({ error: 'email required' });
    res.status(201).json(await userRepository.create(req.body));
  },

  async updateUser(req, res) {
    res.json(await userRepository.update(req.params.userId, req.body || {}));
  },

  async listReservations(req, res) {
    res.json(await reservationRepository.list(req.query.charge_point_id));
  },

  async listProfiles(req, res) {
    res.json(await profileRepository.list(req.query.charge_point_id));
  },

  async listFirmware(req, res) {
    res.json(await firmwareRepository.listJobs(req.query.charge_point_id));
  },

  async listEvents(req, res) {
    res.json(await eventRepository.listEvents(req.query));
  },

  async listAudit(req, res) {
    res.json(await eventRepository.listAudit(Number(req.query.limit || 100)));
  },

  async listCommands(req, res) {
    res.json(await commandRepository.list(req.query));
  },

  async getCommand(req, res) {
    const row = await commandRepository.get(req.params.commandId);
    if (!row) return res.status(404).json({ error: 'Not found' });
    res.json(row);
  },

  // ── Analytics & reporting ──────────────────────────────────────────
  async analyticsOverview(req, res) {
    const stations = await stationRepository.list();
    const txs = await transactionRepository.list({ limit: 500 });
    const online = new Set(connectionRegistry.listOnline());
    const active = txs.filter((t) => t.status === 'active');
    const completed = txs.filter((t) => t.status === 'completed');
    const energy = completed.reduce((s, t) => s + Number(t.energy_kwh || 0), 0);
    const revenue = completed.reduce((s, t) => s + Number(t.cost || 0), 0);
    const byModel = {};
    for (const s of stations) {
      byModel[s.model || 'Unknown'] = (byModel[s.model || 'Unknown'] || 0) + 1;
    }
    const faulted = stations.filter((s) => String(s.status).toLowerCase().includes('fault') || s.status === 'faulted');
    res.json({
      stations_total: stations.length,
      stations_online: [...online].length,
      stations_charging: stations.filter((s) => s.status === 'charging' || online.has(s.charge_point_id) && s.status === 'charging').length,
      active_sessions: active.length,
      completed_sessions: completed.length,
      energy_kwh: Number(energy.toFixed(3)),
      revenue: Number(revenue.toFixed(3)),
      currency: 'TND',
      by_model: byModel,
      faulted: faulted.length,
      utilization: stations.length ? Number(((active.length / Math.max(stations.length, 1)) * 100).toFixed(1)) : 0,
    });
  },

  async listAlerts(req, res) {
    const db = getDb();
    if (!db) return res.json([]);
    let q = db.from('csms_alerts').select('*').order('created_at', { ascending: false }).limit(Number(req.query.limit || 100));
    if (req.query.status) q = q.eq('status', req.query.status);
    if (req.query.severity) q = q.eq('severity', req.query.severity);
    const { data, error } = await q;
    if (error) throw error;
    res.json(data || []);
  },

  async createAlert(req, res) {
    const db = getDb();
    const body = req.body || {};
    const row = {
      alert_id: body.alert_id || `ALT-${Date.now()}`,
      charge_point_id: body.charge_point_id,
      connector_id: body.connector_id ?? null,
      severity: body.severity || 'warning',
      code: body.code || 'GENERIC',
      title: body.title || 'Alert',
      body: body.body || '',
      status: 'open',
      created_at: new Date().toISOString(),
    };
    if (!db) return res.status(201).json(row);
    const { data, error } = await db.from('csms_alerts').insert(row).select().single();
    if (error) throw error;
    await notificationService.notify({
      title: row.title,
      body: row.body,
      severity: row.severity,
      category: 'alert',
      chargePointId: row.charge_point_id,
    });
    res.status(201).json(data);
  },

  async resolveAlert(req, res) {
    const db = getDb();
    if (!db) return res.json({ ok: true });
    const { data, error } = await db.from('csms_alerts').update({
      status: 'resolved',
      resolved_at: new Date().toISOString(),
    }).eq('alert_id', req.params.alertId).select().maybeSingle();
    if (error) throw error;
    res.json(data || { ok: true });
  },

  async listNotifications(req, res) {
    res.json(await notificationService.list({
      userId: req.query.user_id || req.user?.sub,
      unreadOnly: req.query.unread === '1',
      limit: Number(req.query.limit || 50),
    }));
  },

  async markNotificationRead(req, res) {
    res.json(await notificationService.markRead(req.params.id));
  },

  async listRoles(req, res) {
    const db = getDb();
    if (!db) {
      return res.json([
        { code: 'admin', name: 'Administrator', permissions: ['*'] },
        { code: 'operator', name: 'NOC Operator', permissions: ['stations:read', 'stations:command', 'tx:read'] },
        { code: 'installer', name: 'Installer', permissions: ['stations:read', 'stations:command'] },
        { code: 'viewer', name: 'Viewer', permissions: ['stations:read', 'tx:read'] },
        { code: 'driver', name: 'Driver', permissions: ['mobile:*'] },
      ]);
    }
    const { data } = await db.from('csms_roles').select('*').order('sort_order');
    res.json(data || []);
  },

  async listSessions(req, res) {
    const db = getDb();
    if (!db) {
      const txs = await transactionRepository.list(req.query);
      return res.json(txs.map((t) => ({
        session_id: `SES-${t.transaction_id}`,
        transaction_id: t.transaction_id,
        charge_point_id: t.charge_point_id,
        status: t.status,
        energy_kwh: t.energy_kwh,
        cost: t.cost,
        started_at: t.start_timestamp,
        ended_at: t.stop_timestamp,
      })));
    }
    let q = db.from('csms_sessions').select('*').order('started_at', { ascending: false }).limit(Number(req.query.limit || 100));
    if (req.query.status) q = q.eq('status', req.query.status);
    const { data, error } = await q;
    if (error) throw error;
    res.json(data || []);
  },

  async listJobs(req, res) {
    const db = getDb();
    if (!db) return res.json([]);
    const { data } = await db.from('csms_jobs').select('*').order('created_at', { ascending: false }).limit(100);
    res.json(data || []);
  },

  async listBusEvents(req, res) {
    res.json(eventQueue.recent(Number(req.query.limit || 50)));
  },

  async enqueueJob(req, res) {
    const { type, payload } = req.body || {};
    if (!type) return res.status(400).json({ error: 'type required' });
    const job = await enqueue(type, payload || {});
    res.status(202).json(job);
  },

  async compositeLocal(req, res) {
    const result = await smartCharging.getCompositeSchedule(
      req.params.id,
      Number(req.body?.connectorId || 1),
      Number(req.body?.duration || 3600)
    );
    res.json(result);
  },

  // ── Mobile API ─────────────────────────────────────────────────────
  async mobileLogin(req, res) {
    try {
      const result = await mobileService.login(req.body || {});
      res.json(result);
    } catch (e) {
      res.status(e.status || 500).json({ error: e.message });
    }
  },

  async mobileDiscover(req, res) {
    res.json(await mobileService.discover(req.query));
  },

  async mobileDetails(req, res) {
    const d = await mobileService.details(req.params.id);
    if (!d) return res.status(404).json({ error: 'Not found' });
    res.json(d);
  },

  async mobileStart(req, res) {
    try {
      const result = await mobileService.startCharge({
        chargePointId: req.params.id,
        connectorId: req.body?.connectorId || 1,
        idTag: req.body?.idTag || req.user?.id_tag || 'MOBILE',
      }, req.user?.sub || 'mobile');
      res.json(result);
    } catch (e) {
      res.status(e.status || e.code === 'CP_OFFLINE' ? 409 : 500).json({ error: e.message, code: e.code });
    }
  },

  async mobileStop(req, res) {
    try {
      const result = await mobileService.stopCharge({
        chargePointId: req.params.id,
        transactionId: req.body?.transactionId,
      }, req.user?.sub || 'mobile');
      res.json(result);
    } catch (e) {
      res.status(e.status || e.code === 'CP_OFFLINE' ? 409 : 500).json({ error: e.message, code: e.code });
    }
  },

  async mobileHistory(req, res) {
    res.json(await mobileService.history(req.user?.sub || req.query.user_id, Number(req.query.limit || 50)));
  },

  async mobileFavorites(req, res) {
    res.json(await mobileService.favorites(req.user?.sub || req.query.user_id));
  },

  async mobileAddFavorite(req, res) {
    const userId = req.user?.sub || req.body?.user_id;
    res.status(201).json(await mobileService.addFavorite(userId, req.body?.charge_point_id, req.body?.label));
  },

  async mobileProfile(req, res) {
    res.json(await mobileService.profile(req.user?.sub || req.query.user_id));
  },

  async mobileNotifications(req, res) {
    res.json(await mobileService.notifications(req.user?.sub || req.query.user_id));
  },

  async createUserSecure(req, res) {
    const body = { ...(req.body || {}) };
    if (body.password) {
      const password_hash = await hashPassword(body.password);
      body.meta = { ...(body.meta || {}), password_hash };
      delete body.password;
    }
    const row = await userRepository.create(body);
    res.status(201).json({ ...row, meta: { ...(row.meta || {}), password_hash: undefined } });
  },
};

export default ocppRestController;

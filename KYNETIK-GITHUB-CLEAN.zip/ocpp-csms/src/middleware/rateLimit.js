const buckets = new Map();

export function rateLimit({ windowMs = 60_000, max = 120 } = {}) {
  return (req, res, next) => {
    const key = `${req.ip}:${req.path}`;
    const now = Date.now();
    let b = buckets.get(key);
    if (!b || now - b.start > windowMs) b = { start: now, count: 0 };
    b.count += 1;
    buckets.set(key, b);
    res.setHeader('X-RateLimit-Limit', String(max));
    res.setHeader('X-RateLimit-Remaining', String(Math.max(0, max - b.count)));
    if (b.count > max) return res.status(429).json({ error: 'Rate limit exceeded', code: 'RATE_LIMIT' });
    next();
  };
}

export default rateLimit;

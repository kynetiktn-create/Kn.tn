export function requireFields(fields = []) {
  return (req, res, next) => {
    const missing = fields.filter((f) => req.body?.[f] == null || req.body?.[f] === '');
    if (missing.length) {
      return res.status(400).json({ error: 'Validation failed', missing, code: 'VALIDATION' });
    }
    next();
  };
}

export function sanitizeString(s, max = 256) {
  if (s == null) return s;
  return String(s).slice(0, max).trim();
}

export default { requireFields, sanitizeString };

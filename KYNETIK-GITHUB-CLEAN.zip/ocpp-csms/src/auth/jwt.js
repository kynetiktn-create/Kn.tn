import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import config from '../config/index.js';
import { Roles } from '../models/types.js';

export function signToken(payload, expiresIn = config.jwtExpiresIn) {
  return jwt.sign(payload, config.jwtSecret, { expiresIn });
}

export function verifyToken(token) {
  return jwt.verify(token, config.jwtSecret);
}

export async function hashPassword(password) {
  return bcrypt.hash(String(password), 10);
}

export async function verifyPassword(password, hash) {
  if (!hash) return false;
  return bcrypt.compare(String(password), String(hash));
}

/**
 * Express middleware — Authorization: Bearer <jwt>
 * Dev bypass: header X-API-Key: kynetik-dev or Bearer demo
 */
export function requireAuth(requiredRoles = []) {
  return (req, res, next) => {
    try {
      const header = req.headers.authorization || '';
      const apiKey = req.headers['x-api-key'];
      if (apiKey === process.env.OCPP_API_KEY || apiKey === 'kynetik-dev') {
        req.user = { sub: 'api-key', role: Roles.admin, name: 'API Key' };
        return next();
      }
      if (!header.startsWith('Bearer ')) {
        if (config.env !== 'production' && req.method === 'GET') {
          req.user = { sub: 'anonymous', role: Roles.viewer, name: 'Anonymous' };
          return next();
        }
        return res.status(401).json({ error: 'Unauthorized', message: 'Bearer token required' });
      }
      const token = header.slice(7);
      if (token === 'demo') {
        req.user = { sub: 'demo', role: Roles.admin, name: 'Demo Admin' };
        return next();
      }
      const decoded = verifyToken(token);
      req.user = decoded;
      if (requiredRoles.length) {
        const role = decoded.role || Roles.viewer;
        if (!requiredRoles.includes(role) && role !== Roles.admin) {
          return res.status(403).json({ error: 'Forbidden', message: `Requires role: ${requiredRoles.join('|')}` });
        }
      }
      return next();
    } catch (e) {
      return res.status(401).json({ error: 'Invalid token', message: e.message });
    }
  };
}

export function issueDemoTokens() {
  return {
    admin: signToken({ sub: 'admin-1', email: 'admin@kynetik.tn', role: Roles.admin, name: 'KYNETIK Admin' }),
    operator: signToken({ sub: 'ops-1', email: 'ops@kynetik.tn', role: Roles.operator, name: 'NOC Operator' }),
    viewer: signToken({ sub: 'view-1', email: 'viewer@kynetik.tn', role: Roles.viewer, name: 'Viewer' }),
    driver: signToken({ sub: 'usr-home-01', email: 'driver@kynetik.tn', role: 'driver', name: 'Driver' }),
  };
}

export default { signToken, verifyToken, requireAuth, issueDemoTokens, hashPassword, verifyPassword };

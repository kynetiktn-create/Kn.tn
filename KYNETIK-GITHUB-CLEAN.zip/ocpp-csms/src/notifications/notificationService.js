import getDb from '../database/client.js';
import eventQueue from '../queue/eventQueue.js';
import { enqueue } from '../jobs/worker.js';

export const notificationService = {
  async notify({ userId = 'broadcast', title, body, severity = 'info', category = 'system', chargePointId, channel = 'in_app' }) {
    await enqueue('notify', {
      user_id: userId,
      title,
      body,
      severity,
      category,
      charge_point_id: chargePointId,
      channel,
    });
    await eventQueue.publish('notification.created', { userId, title, severity });
  },

  async list({ userId, unreadOnly, limit = 50 } = {}) {
    const db = getDb();
    if (!db) return [];
    let q = db.from('csms_notifications').select('*').order('created_at', { ascending: false }).limit(limit);
    if (userId) q = q.or(`user_id.eq.${userId},user_id.eq.broadcast`);
    if (unreadOnly) q = q.eq('read', false);
    const { data } = await q;
    return data || [];
  },

  async markRead(id) {
    const db = getDb();
    if (!db) return null;
    const { data } = await db.from('csms_notifications').update({ read: true }).eq('id', id).select().maybeSingle();
    return data;
  },
};

export default notificationService;

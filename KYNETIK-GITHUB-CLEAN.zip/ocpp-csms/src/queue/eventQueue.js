import { EventEmitter } from 'events';
import logger from '../logging/logger.js';
import getDb from '../database/client.js';

class EventQueue extends EventEmitter {
  constructor() {
    super();
    this.setMaxListeners(100);
    this.buffer = [];
  }

  async publish(type, payload = {}) {
    const event = {
      id: `evt_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
      type,
      payload,
      ts: new Date().toISOString(),
    };
    this.buffer.push(event);
    if (this.buffer.length > 5000) this.buffer.shift();
    this.emit(type, event);
    this.emit('*', event);
    logger.debug('event', { type, id: event.id });
    const db = getDb();
    if (db) {
      try {
        await db.from('csms_jobs').insert({
          job_id: event.id,
          type: `event:${type}`,
          payload,
          status: 'published',
          attempts: 0,
          created_at: event.ts,
          run_at: event.ts,
        });
      } catch { /* non-fatal */ }
    }
    return event;
  }

  recent(limit = 50) {
    return this.buffer.slice(-limit).reverse();
  }
}

export const eventQueue = new EventQueue();
export default eventQueue;

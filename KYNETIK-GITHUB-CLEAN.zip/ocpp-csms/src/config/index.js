/** KYNETIK OCPP CSMS configuration */
export const config = {
  env: process.env.NODE_ENV || 'development',
  restPort: Number(process.env.OCPP_REST_PORT || process.env.PORT || 8080),
  wsPort: Number(process.env.OCPP_WS_PORT || 9000),
  wsPath: process.env.OCPP_WS_PATH || '/ocpp',
  /** OCPP 1.6J subprotocol */
  ocppSubprotocol: 'ocpp1.6',
  heartbeatIntervalSec: Number(process.env.OCPP_HEARTBEAT_INTERVAL || 60),
  jwtSecret: process.env.OCPP_JWT_SECRET || process.env.JWT_SECRET || 'kynetik-ocpp-dev-secret-change-me',
  jwtExpiresIn: process.env.OCPP_JWT_EXPIRES || '12h',
  /** Basic auth for charge points: chargePointId:authKey in connection URL or header */
  requireCpAuth: process.env.OCPP_REQUIRE_CP_AUTH !== 'false',
  supabaseUrl: process.env.NEXT_PUBLIC_SUPABASE_URL || process.env.SUPABASE_URL || '',
  supabaseKey:
    process.env.SUPABASE_SERVICE_ROLE_KEY ||
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ||
    '',
  corsOrigin: process.env.CORS_ORIGIN || '*',
  logLevel: process.env.LOG_LEVEL || 'info',
  /** Max concurrent stations this process advertises (scale horizontally behind LB sticky sessions) */
  maxStationsPerNode: Number(process.env.OCPP_MAX_STATIONS || 5000),
};

export default config;

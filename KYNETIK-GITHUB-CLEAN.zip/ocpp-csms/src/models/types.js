/**
 * OCPP 1.6J message types (JSON over WebSocket)
 * [MessageTypeId, UniqueId, Action, Payload] CALL
 * [MessageTypeId, UniqueId, Payload] CALLRESULT
 * [MessageTypeId, UniqueId, errorCode, errorDescription, errorDetails] CALLERROR
 */
export const MessageType = {
  CALL: 2,
  CALLRESULT: 3,
  CALLERROR: 4,
};

export const RegistrationStatus = {
  Accepted: 'Accepted',
  Pending: 'Pending',
  Rejected: 'Rejected',
};

export const AuthorizationStatus = {
  Accepted: 'Accepted',
  Blocked: 'Blocked',
  Expired: 'Expired',
  Invalid: 'Invalid',
  ConcurrentTx: 'ConcurrentTx',
};

export const ChargePointStatus = {
  Available: 'Available',
  Preparing: 'Preparing',
  Charging: 'Charging',
  SuspendedEVSE: 'SuspendedEVSE',
  SuspendedEV: 'SuspendedEV',
  Finishing: 'Finishing',
  Reserved: 'Reserved',
  Unavailable: 'Unavailable',
  Faulted: 'Faulted',
};

export const AvailabilityType = {
  Inoperative: 'Inoperative',
  Operative: 'Operative',
};

export const ResetType = {
  Hard: 'Hard',
  Soft: 'Soft',
};

export const Roles = {
  admin: 'admin',
  operator: 'operator',
  installer: 'installer',
  viewer: 'viewer',
  api: 'api',
  driver: 'driver',
};

export default {
  MessageType,
  RegistrationStatus,
  AuthorizationStatus,
  ChargePointStatus,
  AvailabilityType,
  ResetType,
  Roles,
};

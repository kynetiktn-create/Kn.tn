import config from '../config/index.js';
import { RegistrationStatus, AuthorizationStatus } from '../models/types.js';
import stationRepository from '../repositories/stationRepository.js';
import transactionRepository from '../repositories/transactionRepository.js';
import idTagRepository from '../repositories/idTagRepository.js';
import firmwareRepository from '../repositories/firmwareRepository.js';
import profileRepository from '../repositories/profileRepository.js';
import logger from '../logging/logger.js';

/**
 * Handlers for CALL messages originating from Charge Points (OCPP 1.6J).
 * Each returns the CALLRESULT payload object.
 */
export const cpHandlers = {
  async BootNotification(cpId, payload) {
    const interval = config.heartbeatIntervalSec;
    await stationRepository.upsertFromBoot(cpId, payload || {}, {
      registrationStatus: RegistrationStatus.Accepted,
      heartbeatInterval: interval,
    });
    await stationRepository.ensureConnector(cpId, 1);
    logger.info('BootNotification', { cpId, vendor: payload?.chargePointVendor, model: payload?.chargePointModel });
    return {
      status: RegistrationStatus.Accepted,
      currentTime: new Date().toISOString(),
      interval,
    };
  },

  async Heartbeat(cpId) {
    const { currentTime } = await stationRepository.heartbeat(cpId);
    return { currentTime };
  },

  async StatusNotification(cpId, payload) {
    await stationRepository.updateConnectorStatus(cpId, payload || {});
    return {};
  },

  async Authorize(cpId, payload) {
    const result = await idTagRepository.authorize(payload?.idTag);
    logger.info('Authorize', { cpId, idTag: payload?.idTag, status: result.idTagInfo?.status });
    return result;
  },

  async StartTransaction(cpId, payload) {
    const auth = await idTagRepository.authorize(payload?.idTag);
    if (auth.idTagInfo?.status !== AuthorizationStatus.Accepted) {
      return {
        transactionId: 0,
        idTagInfo: auth.idTagInfo,
      };
    }
    const tx = await transactionRepository.start({
      chargePointId: cpId,
      connectorId: Number(payload?.connectorId || 1),
      idTag: payload?.idTag,
      meterStart: payload?.meterStart,
      timestamp: payload?.timestamp,
      reservationId: payload?.reservationId,
    });
    return {
      transactionId: tx.transaction_id,
      idTagInfo: { status: AuthorizationStatus.Accepted },
    };
  },

  async StopTransaction(cpId, payload) {
    const tx = await transactionRepository.stop({
      chargePointId: cpId,
      transactionId: Number(payload?.transactionId),
      meterStop: payload?.meterStop,
      timestamp: payload?.timestamp,
      reason: payload?.reason,
      idTag: payload?.idTag,
    });
    let idTagInfo;
    if (payload?.idTag) {
      idTagInfo = (await idTagRepository.authorize(payload.idTag)).idTagInfo;
    }
    return idTagInfo ? { idTagInfo } : {};
  },

  async MeterValues(cpId, payload) {
    await transactionRepository.addMeterValues(cpId, payload || {});
    return {};
  },

  async DataTransfer(cpId, payload) {
    logger.info('DataTransfer from CP', { cpId, vendorId: payload?.vendorId, messageId: payload?.messageId });
    return { status: 'Accepted', data: payload?.data || '' };
  },

  async DiagnosticsStatusNotification(cpId, payload) {
    await firmwareRepository.updateDiagnosticsStatus(cpId, payload?.status || 'Unknown');
    return {};
  },

  async FirmwareStatusNotification(cpId, payload) {
    await firmwareRepository.updateStatus(cpId, payload?.status || 'Unknown');
    return {};
  },
};

export default cpHandlers;

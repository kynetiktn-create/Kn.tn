import callChargePoint from './ocppCall.js';
import commandRepository from '../repositories/commandRepository.js';
import stationRepository from '../repositories/stationRepository.js';
import reservationRepository from '../repositories/reservationRepository.js';
import profileRepository from '../repositories/profileRepository.js';
import firmwareRepository from '../repositories/firmwareRepository.js';
import eventRepository from '../repositories/eventRepository.js';
import connectionRegistry from './connectionRegistry.js';

async function trackedCall(chargePointId, action, payload, actor) {
  const cmd = await commandRepository.enqueue({
    chargePointId,
    action,
    payload,
    requestedBy: actor || 'api',
  });
  try {
    const { result } = await callChargePoint(chargePointId, action, payload);
    await commandRepository.complete(cmd.command_id, 'completed', result);
    await eventRepository.audit({
      actor: actor || 'api',
      action: action,
      resource: 'charge_point',
      resourceId: chargePointId,
      details: { payload, result, command_id: cmd.command_id },
    });
    return { command_id: cmd.command_id, status: 'completed', result };
  } catch (err) {
    await commandRepository.complete(cmd.command_id, 'failed', { error: err.message, code: err.code });
    throw err;
  }
}

export const commandService = {
  isOnline: (id) => connectionRegistry.isOnline(id),
  listOnline: () => connectionRegistry.listOnline(),

  remoteStart(chargePointId, { connectorId = 1, idTag, chargingProfile }, actor) {
    const payload = { connectorId: Number(connectorId), idTag };
    if (chargingProfile) payload.chargingProfile = chargingProfile;
    return trackedCall(chargePointId, 'RemoteStartTransaction', payload, actor);
  },

  remoteStop(chargePointId, { transactionId }, actor) {
    return trackedCall(chargePointId, 'RemoteStopTransaction', { transactionId: Number(transactionId) }, actor);
  },

  reset(chargePointId, type = 'Soft', actor) {
    return trackedCall(chargePointId, 'Reset', { type }, actor);
  },

  unlockConnector(chargePointId, connectorId = 1, actor) {
    return trackedCall(chargePointId, 'UnlockConnector', { connectorId: Number(connectorId) }, actor);
  },

  async changeConfiguration(chargePointId, key, value, actor) {
    // persist desired config then instruct CP
    await stationRepository.changeConfiguration(chargePointId, key, value);
    return trackedCall(chargePointId, 'ChangeConfiguration', { key, value: String(value) }, actor);
  },

  getConfiguration(chargePointId, key = [], actor) {
    return trackedCall(chargePointId, 'GetConfiguration', { key: Array.isArray(key) ? key : [key].filter(Boolean) }, actor);
  },

  changeAvailability(chargePointId, { connectorId = 0, type = 'Operative' }, actor) {
    return trackedCall(
      chargePointId,
      'ChangeAvailability',
      { connectorId: Number(connectorId), type },
      actor
    );
  },

  dataTransfer(chargePointId, { vendorId, messageId, data }, actor) {
    return trackedCall(
      chargePointId,
      'DataTransfer',
      { vendorId: vendorId || 'KYNETIK', messageId, data },
      actor
    );
  },

  async updateFirmware(chargePointId, body, actor) {
    await firmwareRepository.createJob({
      chargePointId,
      location: body.location,
      retrieveDate: body.retrieveDate,
      retries: body.retries,
      retryInterval: body.retryInterval,
    });
    return trackedCall(
      chargePointId,
      'UpdateFirmware',
      {
        location: body.location,
        retrieveDate: body.retrieveDate || new Date().toISOString(),
        retries: body.retries,
        retryInterval: body.retryInterval,
      },
      actor
    );
  },

  async getDiagnostics(chargePointId, body, actor) {
    await firmwareRepository.createDiagnostics({
      chargePointId,
      location: body.location,
      startTime: body.startTime,
      stopTime: body.stopTime,
      retries: body.retries,
      retryInterval: body.retryInterval,
    });
    return trackedCall(
      chargePointId,
      'GetDiagnostics',
      {
        location: body.location,
        startTime: body.startTime,
        stopTime: body.stopTime,
        retries: body.retries,
        retryInterval: body.retryInterval,
      },
      actor
    );
  },

  async reserveNow(chargePointId, body, actor) {
    const reservation = await reservationRepository.create({
      chargePointId,
      connectorId: Number(body.connectorId || 1),
      idTag: body.idTag,
      expiryDate: body.expiryDate,
      parentIdTag: body.parentIdTag,
    });
    try {
      const res = await trackedCall(
        chargePointId,
        'ReserveNow',
        {
          connectorId: Number(body.connectorId || 1),
          expiryDate: body.expiryDate,
          idTag: body.idTag,
          reservationId: reservation.reservation_id,
          parentIdTag: body.parentIdTag,
        },
        actor
      );
      return { ...res, reservation };
    } catch (e) {
      await reservationRepository.cancel(reservation.reservation_id);
      throw e;
    }
  },

  async cancelReservation(chargePointId, reservationId, actor) {
    const res = await trackedCall(
      chargePointId,
      'CancelReservation',
      { reservationId: Number(reservationId) },
      actor
    );
    await reservationRepository.cancel(reservationId);
    return res;
  },

  async setChargingProfile(chargePointId, body, actor) {
    const profile = body.csChargingProfiles || body.chargingProfile || body;
    await profileRepository.upsert({
      chargePointId,
      connectorId: body.connectorId ?? 0,
      chargingProfileId: profile.chargingProfileId,
      stackLevel: profile.stackLevel,
      chargingProfilePurpose: profile.chargingProfilePurpose,
      chargingProfileKind: profile.chargingProfileKind,
      recurrencyKind: profile.recurrencyKind,
      validFrom: profile.validFrom,
      validTo: profile.validTo,
      chargingSchedule: profile.chargingSchedule,
      transactionId: profile.transactionId,
    });
    return trackedCall(
      chargePointId,
      'SetChargingProfile',
      {
        connectorId: Number(body.connectorId ?? 0),
        csChargingProfiles: profile,
      },
      actor
    );
  },

  clearChargingProfile(chargePointId, body = {}, actor) {
    return trackedCall(chargePointId, 'ClearChargingProfile', body, actor);
  },

  getCompositeSchedule(chargePointId, body, actor) {
    return trackedCall(
      chargePointId,
      'GetCompositeSchedule',
      {
        connectorId: Number(body.connectorId ?? 0),
        duration: Number(body.duration || 3600),
        chargingRateUnit: body.chargingRateUnit,
      },
      actor
    );
  },

  triggerMessage(chargePointId, { requestedMessage, connectorId }, actor) {
    const payload = { requestedMessage };
    if (connectorId != null) payload.connectorId = Number(connectorId);
    return trackedCall(chargePointId, 'TriggerMessage', payload, actor);
  },

  clearCache(chargePointId, actor) {
    return trackedCall(chargePointId, 'ClearCache', {}, actor);
  },

  getLocalListVersion(chargePointId, actor) {
    return trackedCall(chargePointId, 'GetLocalListVersion', {}, actor);
  },

  sendLocalList(chargePointId, body, actor) {
    return trackedCall(chargePointId, 'SendLocalList', body, actor);
  },
};

export default commandService;

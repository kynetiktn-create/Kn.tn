/**
 * In-memory registry of live WebSocket charge-point sessions.
 * For multi-node scale-out: put sticky sessions on LB and/or back commands with Redis pub/sub.
 */
import logger from '../logging/logger.js';

class ConnectionRegistry {
  constructor() {
    /** @type {Map<string, import('ws').WebSocket & { chargePointId?: string }>} */
    this.byId = new Map();
    /** pending CALL results: key = `${cpId}:${uniqueId}` */
    this.pending = new Map();
  }

  set(chargePointId, ws) {
    const prev = this.byId.get(chargePointId);
    if (prev && prev !== ws && prev.readyState === 1) {
      try {
        prev.close(4000, 'Replaced by new connection');
      } catch {
        /* ignore */
      }
    }
    this.byId.set(chargePointId, ws);
    logger.info('station connected', { chargePointId, online: this.byId.size });
  }

  delete(chargePointId, ws) {
    const cur = this.byId.get(chargePointId);
    if (cur === ws || !ws) {
      this.byId.delete(chargePointId);
      logger.info('station disconnected', { chargePointId, online: this.byId.size });
    }
  }

  get(chargePointId) {
    return this.byId.get(chargePointId);
  }

  isOnline(chargePointId) {
    const ws = this.byId.get(chargePointId);
    return Boolean(ws && ws.readyState === 1);
  }

  listOnline() {
    return [...this.byId.keys()].filter((id) => this.isOnline(id));
  }

  size() {
    return this.byId.size;
  }

  waitForResult(chargePointId, uniqueId, timeoutMs = 30000) {
    const key = `${chargePointId}:${uniqueId}`;
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pending.delete(key);
        reject(new Error(`OCPP call timeout for ${uniqueId}`));
      }, timeoutMs);
      this.pending.set(key, {
        resolve: (v) => {
          clearTimeout(timer);
          resolve(v);
        },
        reject: (e) => {
          clearTimeout(timer);
          reject(e);
        },
      });
    });
  }

  resolvePending(chargePointId, uniqueId, result) {
    const key = `${chargePointId}:${uniqueId}`;
    const p = this.pending.get(key);
    if (p) {
      this.pending.delete(key);
      p.resolve(result);
      return true;
    }
    return false;
  }

  rejectPending(chargePointId, uniqueId, error) {
    const key = `${chargePointId}:${uniqueId}`;
    const p = this.pending.get(key);
    if (p) {
      this.pending.delete(key);
      p.reject(error);
      return true;
    }
    return false;
  }
}

export const connectionRegistry = new ConnectionRegistry();
export default connectionRegistry;

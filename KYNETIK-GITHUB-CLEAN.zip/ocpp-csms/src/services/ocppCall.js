import { randomUUID } from 'crypto';
import { MessageType } from '../models/types.js';
import connectionRegistry from './connectionRegistry.js';
import eventRepository from '../repositories/eventRepository.js';
import logger from '../logging/logger.js';

/**
 * Send OCPP CALL to a connected charge point and wait for CALLRESULT.
 */
export async function callChargePoint(chargePointId, action, payload = {}, timeoutMs = 30000) {
  const ws = connectionRegistry.get(chargePointId);
  if (!ws || ws.readyState !== 1) {
    const err = new Error(`Charge point offline: ${chargePointId}`);
    err.code = 'CP_OFFLINE';
    throw err;
  }
  const uniqueId = randomUUID();
  const message = [MessageType.CALL, uniqueId, action, payload || {}];
  const wait = connectionRegistry.waitForResult(chargePointId, uniqueId, timeoutMs);
  ws.send(JSON.stringify(message));
  await eventRepository.logOcpp({
    chargePointId,
    direction: 'out',
    action,
    messageId: uniqueId,
    messageType: MessageType.CALL,
    payload,
  });
  logger.debug('ocpp CALL sent', { chargePointId, action, uniqueId });
  const result = await wait;
  return { uniqueId, action, result };
}

export default callChargePoint;

import connectionRegistry from '../services/connectionRegistry.js';
import getDb from '../database/client.js';
import eventQueue from '../queue/eventQueue.js';

export async function healthReport() {
  const online = connectionRegistry.listOnline();
  let dbOk = false;
  try {
    const db = getDb();
    if (db) {
      const { error } = await db.from('ocpp_stations').select('id').limit(1);
      dbOk = !error;
    }
  } catch {
    dbOk = false;
  }
  return {
    ok: true,
    service: 'kynetik-csms',
    protocol: 'OCPP 1.6J JSON',
    version: '1.0.0',
    time: new Date().toISOString(),
    checks: {
      database: dbOk ? 'up' : 'degraded',
      websocket: 'up',
      event_queue: 'up',
    },
    metrics: {
      online_stations: online.length,
      online_ids: online,
      recent_events: eventQueue.recent(5).map((e) => e.type),
    },
    scale: {
      model: 'sticky-sessions + shared Postgres',
      ocpp2_ready: 'adapter boundary prepared in handlers',
    },
  };
}

export default healthReport;

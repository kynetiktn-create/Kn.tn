/** OpenAPI 3.0 specification for KYNETIK CSMS REST API */
export const openApiSpec = {
  openapi: '3.0.3',
  info: {
    title: 'KYNETIK CSMS API',
    description: 'Charge Station Management System — OCPP 1.6J JSON central system REST surface for dashboard and mobile apps.',
    version: '1.0.0',
    contact: { name: 'KYNETIK Platform', email: 'platform@kynetik.tn' },
  },
  servers: [
    { url: '/api/ocpp/v1', description: 'CSMS REST v1' },
  ],
  tags: [
    { name: 'Health' },
    { name: 'Auth' },
    { name: 'Stations' },
    { name: 'Commands' },
    { name: 'Transactions' },
    { name: 'Analytics' },
    { name: 'Users' },
    { name: 'Mobile' },
    { name: 'Alerts' },
  ],
  components: {
    securitySchemes: {
      bearerAuth: { type: 'http', scheme: 'bearer', bearerFormat: 'JWT' },
      apiKey: { type: 'apiKey', in: 'header', name: 'X-API-Key' },
    },
    schemas: {
      Station: {
        type: 'object',
        properties: {
          charge_point_id: { type: 'string' },
          vendor: { type: 'string' },
          model: { type: 'string' },
          status: { type: 'string' },
          connected: { type: 'boolean' },
          site_name: { type: 'string' },
          city: { type: 'string' },
          latitude: { type: 'number' },
          longitude: { type: 'number' },
        },
      },
      Error: {
        type: 'object',
        properties: { error: { type: 'string' }, code: { type: 'string' } },
      },
    },
  },
  security: [{ bearerAuth: [] }, { apiKey: [] }],
  paths: {
    '/health': {
      get: {
        tags: ['Health'],
        security: [],
        summary: 'Health & readiness',
        responses: { 200: { description: 'OK' } },
      },
    },
    '/auth/token': {
      post: {
        tags: ['Auth'],
        security: [],
        summary: 'Issue JWT',
        requestBody: {
          content: {
            'application/json': {
              schema: {
                type: 'object',
                properties: {
                  email: { type: 'string' },
                  role: { type: 'string', enum: ['admin', 'operator', 'installer', 'viewer', 'driver'] },
                  name: { type: 'string' },
                },
              },
            },
          },
        },
        responses: { 200: { description: 'Token issued' } },
      },
    },
    '/auth/demo-tokens': {
      get: { tags: ['Auth'], security: [], summary: 'Demo JWTs', responses: { 200: { description: 'OK' } } },
    },
    '/stations': {
      get: {
        tags: ['Stations'],
        summary: 'List charging stations',
        parameters: [
          { name: 'status', in: 'query', schema: { type: 'string' } },
          { name: 'city', in: 'query', schema: { type: 'string' } },
        ],
        responses: { 200: { description: 'Station list' } },
      },
      post: {
        tags: ['Stations'],
        summary: 'Register station',
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: {
                type: 'object',
                required: ['charge_point_id'],
                properties: {
                  charge_point_id: { type: 'string' },
                  vendor: { type: 'string' },
                  model: { type: 'string' },
                  auth_key: { type: 'string' },
                  site_name: { type: 'string' },
                  city: { type: 'string' },
                  connectors: { type: 'array', items: { type: 'integer' } },
                },
              },
            },
          },
        },
        responses: { 201: { description: 'Created' }, 409: { description: 'Exists' } },
      },
    },
    '/stations/{id}': {
      get: {
        tags: ['Stations'],
        summary: 'Station detail + connectors',
        parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'string' } }],
        responses: { 200: { description: 'OK' }, 404: { description: 'Not found' } },
      },
    },
    '/stations/{id}/remote-start': {
      post: {
        tags: ['Commands'],
        summary: 'RemoteStartTransaction',
        parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'string' } }],
        requestBody: {
          content: {
            'application/json': {
              schema: {
                type: 'object',
                properties: {
                  connectorId: { type: 'integer' },
                  idTag: { type: 'string' },
                  chargingProfile: { type: 'object' },
                },
              },
            },
          },
        },
        responses: { 200: { description: 'Command result' }, 409: { description: 'CP offline' } },
      },
    },
    '/stations/{id}/remote-stop': {
      post: {
        tags: ['Commands'],
        summary: 'RemoteStopTransaction',
        parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'string' } }],
        requestBody: {
          content: {
            'application/json': {
              schema: { type: 'object', properties: { transactionId: { type: 'integer' } } },
            },
          },
        },
        responses: { 200: { description: 'OK' } },
      },
    },
    '/stations/{id}/reset': {
      post: {
        tags: ['Commands'],
        summary: 'Reset (Hard|Soft)',
        parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'string' } }],
        responses: { 200: { description: 'OK' } },
      },
    },
    '/stations/{id}/unlock': {
      post: {
        tags: ['Commands'],
        summary: 'UnlockConnector',
        parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'string' } }],
        responses: { 200: { description: 'OK' } },
      },
    },
    '/stations/{id}/firmware': {
      post: {
        tags: ['Commands'],
        summary: 'UpdateFirmware',
        parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'string' } }],
        responses: { 200: { description: 'OK' } },
      },
    },
    '/stations/{id}/reserve': {
      post: {
        tags: ['Commands'],
        summary: 'ReserveNow',
        parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'string' } }],
        responses: { 200: { description: 'OK' } },
      },
    },
    '/stations/{id}/charging-profiles': {
      post: {
        tags: ['Commands'],
        summary: 'SetChargingProfile',
        parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'string' } }],
        responses: { 200: { description: 'OK' } },
      },
    },
    '/transactions': {
      get: {
        tags: ['Transactions'],
        summary: 'Transaction history',
        responses: { 200: { description: 'OK' } },
      },
    },
    '/reports/energy': {
      get: {
        tags: ['Analytics'],
        summary: 'Energy report',
        responses: { 200: { description: 'OK' } },
      },
    },
    '/analytics/overview': {
      get: {
        tags: ['Analytics'],
        summary: 'Dashboard KPIs',
        responses: { 200: { description: 'OK' } },
      },
    },
    '/alerts': {
      get: { tags: ['Alerts'], summary: 'List alerts', responses: { 200: { description: 'OK' } } },
      post: { tags: ['Alerts'], summary: 'Create alert', responses: { 201: { description: 'Created' } } },
    },
    '/users': {
      get: { tags: ['Users'], summary: 'List users', responses: { 200: { description: 'OK' } } },
      post: { tags: ['Users'], summary: 'Create user (hashed password)', responses: { 201: { description: 'Created' } } },
    },
    '/roles': {
      get: { tags: ['Users'], summary: 'RBAC roles', responses: { 200: { description: 'OK' } } },
    },
    '/mobile/auth/login': {
      post: {
        tags: ['Mobile'],
        security: [],
        summary: 'Mobile login',
        responses: { 200: { description: 'JWT + profile' } },
      },
    },
    '/mobile/chargers': {
      get: {
        tags: ['Mobile'],
        summary: 'Charger discovery',
        responses: { 200: { description: 'OK' } },
      },
    },
    '/mobile/chargers/{id}/start': {
      post: {
        tags: ['Mobile'],
        summary: 'Start charging',
        parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'string' } }],
        responses: { 200: { description: 'OK' } },
      },
    },
    '/mobile/chargers/{id}/stop': {
      post: {
        tags: ['Mobile'],
        summary: 'Stop charging',
        parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'string' } }],
        responses: { 200: { description: 'OK' } },
      },
    },
    '/mobile/sessions': {
      get: { tags: ['Mobile'], summary: 'Session history', responses: { 200: { description: 'OK' } } },
    },
    '/mobile/favorites': {
      get: { tags: ['Mobile'], summary: 'Favorites', responses: { 200: { description: 'OK' } } },
      post: { tags: ['Mobile'], summary: 'Add favorite', responses: { 201: { description: 'Created' } } },
    },
    '/mobile/profile': {
      get: { tags: ['Mobile'], summary: 'User profile', responses: { 200: { description: 'OK' } } },
    },
    '/mobile/notifications': {
      get: { tags: ['Mobile'], summary: 'Notifications', responses: { 200: { description: 'OK' } } },
    },
  },
};

export default openApiSpec;

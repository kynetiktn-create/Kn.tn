/**
 * Minimal OCPP 1.6J charge point simulator for local testing.
 * Usage: node scripts/charge-point-simulator.js [wsUrl] [chargePointId]
 */
import WebSocket from 'ws';
import { randomUUID } from 'crypto';

const url = process.argv[2] || 'ws://127.0.0.1:8080/ocpp/KYN-SIM-001';
const cpId = process.argv[3] || url.split('/').pop();

const ws = new WebSocket(url, ['ocpp1.6']);
const pending = new Map();

function call(action, payload = {}) {
  const id = randomUUID();
  const msg = [2, id, action, payload];
  return new Promise((resolve, reject) => {
    pending.set(id, { resolve, reject });
    ws.send(JSON.stringify(msg));
    setTimeout(() => {
      if (pending.has(id)) {
        pending.delete(id);
        reject(new Error('timeout ' + action));
      }
    }, 15000);
  });
}

ws.on('open', async () => {
  console.log('connected', url);
  try {
    const boot = await call('BootNotification', {
      chargePointVendor: 'KYNETIK',
      chargePointModel: 'NOVA',
      chargePointSerialNumber: cpId,
      firmwareVersion: '2.4.0',
    });
    console.log('BootNotification', boot);
    await call('StatusNotification', {
      connectorId: 1,
      errorCode: 'NoError',
      status: 'Available',
    });
    setInterval(() => {
      call('Heartbeat', {}).then((r) => console.log('Heartbeat', r.currentTime)).catch(console.error);
    }, Math.max(10, boot.interval || 60) * 1000);
  } catch (e) {
    console.error(e);
  }
});

ws.on('message', async (raw) => {
  const msg = JSON.parse(raw.toString());
  if (msg[0] === 3) {
    const p = pending.get(msg[1]);
    if (p) {
      pending.delete(msg[1]);
      p.resolve(msg[2]);
    }
  } else if (msg[0] === 2) {
    const [, uid, action, payload] = msg;
    console.log('CSMS CALL', action, payload);
    let result = { status: 'Accepted' };
    if (action === 'RemoteStartTransaction') {
      result = { status: 'Accepted' };
      setTimeout(async () => {
        try {
          await call('StatusNotification', { connectorId: payload.connectorId || 1, errorCode: 'NoError', status: 'Preparing' });
          const start = await call('StartTransaction', {
            connectorId: payload.connectorId || 1,
            idTag: payload.idTag,
            meterStart: 1000,
            timestamp: new Date().toISOString(),
          });
          console.log('StartTransaction', start);
          await call('StatusNotification', { connectorId: payload.connectorId || 1, errorCode: 'NoError', status: 'Charging' });
        } catch (e) {
          console.error(e);
        }
      }, 300);
    } else if (action === 'RemoteStopTransaction') {
      result = { status: 'Accepted' };
      setTimeout(async () => {
        try {
          await call('StopTransaction', {
            transactionId: payload.transactionId,
            meterStop: 5500,
            timestamp: new Date().toISOString(),
            reason: 'Remote',
          });
          await call('StatusNotification', { connectorId: 1, errorCode: 'NoError', status: 'Available' });
        } catch (e) {
          console.error(e);
        }
      }, 200);
    } else if (action === 'UnlockConnector') result = { status: 'Unlocked' };
    else if (action === 'GetConfiguration') {
      result = {
        configurationKey: [{ key: 'HeartbeatInterval', readonly: false, value: '60' }],
        unknownKey: [],
      };
    } else if (action === 'Reset') result = { status: 'Accepted' };
    else if (action === 'ChangeConfiguration') result = { status: 'Accepted' };
    else if (action === 'TriggerMessage') result = { status: 'Accepted' };
    else if (action === 'ReserveNow') result = { status: 'Accepted' };
    else if (action === 'CancelReservation') result = { status: 'Accepted' };
    else if (action === 'SetChargingProfile') result = { status: 'Accepted' };
    else if (action === 'ClearChargingProfile') result = { status: 'Accepted' };
    else if (action === 'UpdateFirmware') result = {};
    else if (action === 'GetDiagnostics') result = { fileName: 'diag.log' };
    else if (action === 'ChangeAvailability') result = { status: 'Accepted' };
    else if (action === 'DataTransfer') result = { status: 'Accepted' };
    else if (action === 'GetCompositeSchedule') {
      result = { status: 'Accepted', connectorId: payload?.connectorId || 0, scheduleStart: new Date().toISOString(), chargingSchedule: {} };
    }
    ws.send(JSON.stringify([3, uid, result]));
  } else if (msg[0] === 4) {
    const p = pending.get(msg[1]);
    if (p) {
      pending.delete(msg[1]);
      p.reject(new Error(msg[3] || msg[2]));
    }
  }
});

ws.on('close', () => console.log('closed'));
ws.on('error', (e) => console.error('error', e.message));

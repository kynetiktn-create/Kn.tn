# KYNETIK CSMS — OCPP 1.6J JSON

Production-oriented **Charge Station Management System** for KYNETIK.

## Modules

| Module | Path |
|--------|------|
| OCPP Central System handlers | `src/services/ocppHandlers.js` |
| WebSocket server (ocpp1.6) | `src/websocket/ocppServer.js` |
| REST API | `src/rest`, `src/controllers` |
| Auth / RBAC / password hash | `src/auth` |
| Smart charging engine | `src/smartCharging` |
| Notifications | `src/notifications` |
| Background jobs | `src/jobs` |
| Event queue | `src/queue` |
| Mobile API service | `src/mobile` |
| OpenAPI | `src/openapi` + `/api/docs` |
| Monitoring | `src/monitoring` |

## Quick start

```bash
cp .env.example .env
npm install
npm start
# docs: http://localhost:8080/api/docs
# WS:   ws://localhost:8080/ocpp/{chargePointId}
npm run simulate
npm test
```

## Docker

```bash
docker compose up --build
```

## Scale-out

- Terminate **HTTPS/WSS** at LB (nginx, ALB, Cloudflare)
- Sticky sessions for WebSocket connections
- Shared Postgres (Supabase) for all nodes
- Command bus can move to Redis pub/sub for multi-node remote commands
- OCPP 2.0.1: add adapter beside `ocppHandlers` without changing REST contracts

## Security

- JWT + API key
- bcrypt password hashing
- Helmet, CORS, rate limits
- Audit logs on privileged actions
- Optional charge-point auth key on WebSocket connect

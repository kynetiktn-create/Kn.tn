# KYNETIK OCPP REST API Reference

Base URL: `/api/ocpp/v1`

## Auth

```http
POST /auth/token
{ "email": "ops@kynetik.tn", "role": "operator" }
```

```http
Authorization: Bearer <jwt>
# or
X-API-Key: <OCPP_API_KEY>
```

## Register charger

```http
POST /stations
{
  "charge_point_id": "KYN-NOVA-001",
  "vendor": "KYNETIK",
  "model": "NOVA",
  "auth_key": "secret",
  "site_name": "Lac 2 HQ",
  "city": "Tunis",
  "connectors": [1, 2]
}
```

## Remote start

```http
POST /stations/KYN-NOVA-001/remote-start
{ "connectorId": 1, "idTag": "RFID-1001" }
```

## Energy report

```http
GET /reports/energy?charge_point_id=KYN-NOVA-001
```

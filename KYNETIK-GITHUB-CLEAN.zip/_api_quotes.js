import supabase from './db-client.js';

function clientMeta(req) {
  const ua = req.headers['user-agent'] || '';
  const ip =
    (req.headers['x-forwarded-for'] || '').toString().split(',')[0].trim() ||
    req.headers['x-real-ip'] ||
    req.socket?.remoteAddress ||
    '';
  return { user_agent: ua, ip_address: ip };
}

async function nextReference() {
  const year = new Date().getFullYear();
  const { count } = await supabase
    .from('quotes')
    .select('*', { count: 'exact', head: true });
  const n = (count || 0) + 1;
  return `KY-${year}-${String(n).padStart(6, '0')}`;
}

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { reference, id } = req.query;
      if (reference) {
        const { data, error } = await supabase.from('quotes').select('*').eq('reference', reference).single();
        if (error) throw error;
        return res.status(200).json(data);
      }
      if (id) {
        const { data, error } = await supabase.from('quotes').select('*').eq('id', id).single();
        if (error) throw error;
        return res.status(200).json(data);
      }
      const { data, error } = await supabase.from('quotes').select('*').order('id', { ascending: false }).limit(100);
      if (error) throw error;
      return res.status(200).json(data);
    }

    if (req.method === 'POST') {
      const body = req.body || {};
      const customer = body.customer || {};
      const project = body.project || {};
      const products = body.products || [];
      const installation = body.installation || {};

      if (!project.type) return res.status(400).json({ error: 'project.type is required' });
      if (!products.length) return res.status(400).json({ error: 'At least one product is required' });
      if (!installation.country) return res.status(400).json({ error: 'installation.country is required' });
      if (!installation.chargers || Number(installation.chargers) < 1) {
        return res.status(400).json({ error: 'installation.chargers must be >= 1' });
      }
      if (installation.desired_date) {
        const d = new Date(installation.desired_date);
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        if (d < today) return res.status(400).json({ error: 'Desired date cannot be in the past' });
      }
      if (!customer.email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(customer.email)) {
        return res.status(400).json({ error: 'Valid customer email is required' });
      }
      if (!customer.first_name || !customer.last_name) {
        return res.status(400).json({ error: 'First and last name are required' });
      }
      if (!customer.phone) return res.status(400).json({ error: 'Phone is required' });

      const meta = clientMeta(req);
      const reference = await nextReference();

      const row = {
        reference,
        status: 'submitted',
        project_type: project.type,
        customer_first_name: customer.first_name,
        customer_last_name: customer.last_name,
        customer_company: customer.company || '',
        customer_email: customer.email,
        customer_phone: customer.phone,
        customer_address: customer.address || '',
        preferred_language: customer.language || 'fr',
        country: installation.country,
        city: installation.city || '',
        indoor_outdoor: installation.location || '',
        parking_type: installation.parking_type || '',
        chargers_count: Number(installation.chargers) || 1,
        electrical_phase: installation.phase || '',
        desired_date: installation.desired_date || null,
        products_json: JSON.stringify(products),
        project_json: JSON.stringify(project),
        installation_json: JSON.stringify(installation),
        customer_json: JSON.stringify(customer),
        ip_address: meta.ip_address,
        user_agent: meta.user_agent,
      };

      const { data, error } = await supabase.from('quotes').insert(row).select().single();
      if (error) throw error;

      await supabase.from('marketing_leads').insert({
        type: 'quote',
        name: `${customer.first_name} ${customer.last_name}`.trim(),
        email: customer.email,
        phone: customer.phone,
        company: customer.company || '',
        subject: `Quote ${reference} · ${project.type}`,
        message: `Reference ${reference}`,
        payload: JSON.stringify({ reference, products, installation, project }),
        status: 'new',
      });

      await supabase.from('analytics_events').insert({
        event: 'Quote Completed',
        path: '/quote',
        meta: JSON.stringify({ reference, project_type: project.type, products }),
        ip_address: meta.ip_address,
        user_agent: meta.user_agent,
      });

      return res.status(201).json({ status: 'success', reference, quote: data });
    }

    if (req.method === 'PUT') {
      const { id, ...updates } = req.body || {};
      if (!id) return res.status(400).json({ error: 'id is required' });
      const { data, error } = await supabase.from('quotes').update(updates).eq('id', id).select().single();
      if (error) throw error;
      return res.status(200).json(data);
    }

    if (req.method === 'DELETE') {
      const { id } = req.body || {};
      if (!id) return res.status(400).json({ error: 'id is required' });
      const { error } = await supabase.from('quotes').delete().eq('id', id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }

    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('quotes API error:', err);
    try {
      const meta = clientMeta(req);
      await supabase.from('analytics_events').insert({
        event: 'Quote Failed',
        path: '/quote',
        meta: JSON.stringify({ error: err.message }),
        ip_address: meta.ip_address,
        user_agent: meta.user_agent,
      });
    } catch {}
    res.status(500).json({ error: err.message, status: 'failed' });
  }
}

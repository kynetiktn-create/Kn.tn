# KYNETIK Production Migration Report

**Document purpose:** Prepare the existing Design Arena full-stack project for export to GitHub and independent production infrastructure.  
**Inspection mode:** Read-only inventory of the current workspace.  
**Date of inspection:** 2026-08-09 (workspace snapshot)  
**Project root package name:** `placeholder-model-1` (should be renamed on export)  
**OCPP package name:** `@kynetik/ocpp-csms`

> **Security note:** This report lists environment **variable names only**. No passwords, API keys, tokens, connection strings, or secret values are included.

---

## 1. Current Architecture

### 1.1 High-level topology

The project is a **monorepo-style workspace** with three logical runtimes:

| Layer | Technology | Role |
|-------|------------|------|
| **Frontend SPA** | Vite + React 19 + TypeScript + Tailwind CSS v4 | Marketing site, design system, portals, dashboards, mobile UX prototypes, CSMS UI |
| **HTTP API (serverless)** | Vercel Node serverless functions in `/api` | CRUD against Supabase Postgres for app content and ops UIs |
| **OCPP CSMS (long-running)** | Node.js Express + `ws` in `/ocpp-csms` | OCPP 1.6J JSON WebSocket central system + REST/mobile APIs |
| **Database** | Supabase (managed Postgres) | Persistent data for SPA APIs and CSMS |
| **Auth (partial)** | Supabase Auth env + CSMS JWT/bcrypt | Dual model (see Authentication) |
| **Static assets** | `/public`, `/uploads` | Brand, product renders, marketing imagery |

### 1.2 Request flow (production intent)

```
Browser / Mobile Web UI
    │
    ├─ static SPA (Vite build → dist/) ── CDN / Vercel Static
    │
    ├─ REST /api/* ── Vercel Serverless ── Supabase (service role)
    │
    └─ (optional direct) Supabase REST with anon key
           used by src/lib/ocppClient.ts for OCPP tables

Charge Points (AC/DC)
    │
    └─ WSS ocpp1.6 ── ocpp-csms Node process ── Supabase
                              │
                              └─ REST /api/ocpp/v1 ── Dashboard / Mobile backends
```

### 1.3 Design Arena–specific coupling

| Artifact | Purpose | Migration impact |
|----------|---------|------------------|
| `api/db-wake.js` + `FULLSTACK_RESTORE_API_URL` | Wake/restore paused Design Arena Supabase | Replace with normal health checks / no-op in independent hosting |
| `FULLSTACK_PROJECT_REF` | Project reference for restore | Drop or map to your Supabase project ref |
| `.vercel/` linkage | Design Arena Vercel team/project | Re-link or recreate Vercel project under KYNETIK org |
| Root package name `placeholder-model-1` | Scaffold default | Rename for GitHub |
| `api/` directory ownership historically root-locked | Some CSMS bridge handlers live under `ocpp-csms/vercel-api/` instead | Consolidate API layout on export |
| No SQL migration folder | Schema applied live via platform tools | Must dump schema before cutover |

---

## 2. Frontend Structure

### 2.1 Stack

- **Runtime / bundler:** Vite `^7.3.1`
- **UI:** React `^19.2.0`, React DOM `^19.2.0`
- **Language:** TypeScript `~5.9.3`
- **Routing:** `react-router-dom` `^7.13.1`
- **Styling:** Tailwind CSS `^4.2.1` via `@tailwindcss/vite`
- **Motion:** `framer-motion` `^12.35.0`
- **Icons:** `lucide-react` `^0.577.0`
- **Data client:** `@supabase/supabase-js` `^2.99.1` (browser helper)

### 2.2 Entry and shell

| Path | Role |
|------|------|
| `index.html` | SPA shell, page title, favicon |
| `src/main.tsx` | React bootstrap |
| `src/index.css` | Global + Tailwind styles |
| `src/App.tsx` | **Central router** (~200 route declarations, many aliases) |
| `src/components/Layout.tsx` | Design-system hub shell (nav) |
| `src/components/LayoutWritable.tsx` | Alternate/writable nav shell used by some wiring |
| `vite.config.ts` | React + Tailwind plugins; injects `VITE_*` and `NEXT_PUBLIC_*` into `process.env.*` for browser |

### 2.3 Source tree (application code)

```
src/
  App.tsx                 # All routes
  main.tsx
  index.css
  assets/
  components/             # Shared UI chrome, mobile frames, marketing shell, cloud widgets
  lib/                    # api helpers, supabase browser, ocppClient, quotes, analytics
  pages/                  # ~92 page modules (product surfaces + internal systems)
  ui/                     # Design system primitives, patterns, KYNETIK domain widgets, tokens
```

**Approximate scale (excluding `node_modules`):** ~141 `.tsx` files under project; frontend is the majority of the product surface.

### 2.4 Page domains (`src/pages/`)

| Domain | Representative routes / files | Description |
|--------|------------------------------|-------------|
| **Marketing / website** | `/`, `/home`, `SiteHome`, `HomePage`, `BrandMarketingLaunch`, `marketing/*` | Public site, GTM, contact, quote, FAQ, careers, support |
| **Product catalog** | `/products`, `products/*`, `ProductSystemPage`, configurator | Hardware lines NOVA/PRIME/GO/EDGE/PRO/FLEX |
| **Cloud / CSMS UI** | `/csms`, `/ocpp`, `CloudDashboard`, `CsmsDashboard`, `OcppCsmsConsole` | Operator console + OCPP lab |
| **Customer portal** | `/portal/*` | Chargers, energy, map, history, vehicles, billing, tickets |
| **Installer / field** | `/installer`, calendar, installation details, maintenance | Field ops UIs |
| **Admin enterprise** | `/admin`, `/enterprise` | Internal admin portal views |
| **Developer platform** | `/developers/*` | API docs UX, keys, playground, status |
| **Academy** | `/academy` (layout), `/academy-landing` | Learning platform UI |
| **Design system** | design bible, UI library, tokens, overview | Brand + component system |
| **Documentation / PRD** | master docs, FRD, architecture packs, handoff | Investor/eng documentation surfaces |
| **Mobile UX** | `KynetikMobileApp`, `MobileApp`, `AppLanding` + `components/mobile/*` | Phone-framed app prototype (not native) |
| **AI / advisor** | energy advisor, predictive maintenance, AI platform | Productized AI dashboards |

### 2.5 Design system (`src/ui/`)

- **Tokens:** `src/ui/tokens.ts`
- **Primitives:** Button, Input, Card, Badge, Table, Tabs, etc.
- **Patterns:** FormField, EmptyState, Toast
- **KYNETIK widgets:** ChargeRing, GlassPanel, MetricTile, ProductStage, StatusPill, etc.
- **Barrel:** `src/ui/index.ts`

### 2.6 Frontend libraries (`src/lib/`)

| File | Role |
|------|------|
| `utils.ts` | `apiGet` / `apiPost` helpers, `cn()` |
| `supabase.ts` | Browser Supabase client (anon key) |
| `ocppClient.ts` | Direct Supabase REST access for OCPP/CSMS tables + command simulation |
| `quoteService.ts` | Quote flow client logic |
| `analytics.ts` | Lightweight analytics helpers |
| `dashboardApi.ts` | Dashboard fetch helpers |
| `productTypes.ts` | Product type helpers |
| `docsSuiteData.ts` | Documentation suite content helpers |

### 2.7 Static assets

- `public/images/` — heroes, academy, cloud, brand lockups, product PNGs
- `public/images/products/` — NOVA, PRIME, GO, EDGE, PRO, FLEX renders
- `public/images/brand/` — logo variants
- `public/favicon*.svg|png`, `apple-touch-icon.png`
- `uploads/` and `public/uploads/` — additional brand/product assets

### 2.8 What the frontend is **not**

- Not a native iOS/Android app (mobile is a **web prototype** with phone chrome)
- Not Next.js (Vite SPA); `NEXT_PUBLIC_*` names are for Supabase/env compatibility only
- Not a single product page — it is a **full brand + ops ecosystem** with many internal tools

---

## 3. Backend Structure

### 3.1 Vercel serverless API (`/api`)

**Count:** 63 JavaScript handlers (including infrastructure).

**Pattern (consistent):**

- Default export `handler(req, res)`
- CORS headers on all routes
- `OPTIONS` → 204
- Import `supabase` from `./db-client.js`
- CRUD via Supabase query builder (`.from().select|insert|update|delete`)
- **Uses service role key** server-side (`SUPABASE_SERVICE_ROLE_KEY`)

**Infrastructure handlers:**

| File | Role |
|------|------|
| `api/db-client.js` | Shared Supabase client + fetch hook to trigger DB wake on 5xx |
| `api/db-wake.js` | Calls Design Arena restore endpoint when DB appears paused |

**Domain handlers (filename → HTTP path `/api/<name>`):**

| Group | Files (basename without `.js`) |
|-------|--------------------------------|
| Products / brand | `products`, `product-lines`, `product-spec`, `production-assets`, `brand-tokens`, `design-assets`, `design-bible`, `social-templates`, `website-sections` |
| Cloud ops | `charge-points`, `charging-sessions`, `cloud-metrics`, `cloud-users`, `cloud-notifications`, `cloud-landing`, `fleets`, `ocpp-events` |
| Portal | `portal-account`, `portal-billing`, `portal-chargers`, `portal-downloads`, `portal-notifications`, `portal-sessions`, `portal-tickets`, `portal-vehicles` |
| Admin | `admin-analytics`, `admin-billing`, `admin-cms`, `admin-customers`, `admin-infra`, `admin-installers`, `admin-kpis`, `admin-notifications`, `admin-products`, `admin-security`, `admin-tickets` |
| Installer | `installer-calendar`, `installer-dashboard`, `installer-jobs` |
| Marketing / sales | `leads`, `marketing-content`, `support-tickets` |
| Academy | `academy-courses` |
| Maintenance / AI | `maintenance`, `predictive-maintenance`, `ai-insights` |
| Developer platform | `dev-content`, `dev-keys`, `dev-playground`, `dev-usage` |
| Docs / UX systems | `docs-suite`, `master-docs`, `ux-journeys`, `ux-kpis`, `ux-notifications`, `ux-screens`, `handoff`, `prototype`, `app-screens`, `app-landing`, `billing` |

**Related but outside `/api` (export candidates):**

- `api2/quotes.js` — alternate quotes handler location
- `_api_quotes.js`, `_api_analytics.js`, `quotes-api.js` — root-level API drafts
- `ocpp-csms/vercel-api/*.js` — OCPP-oriented serverless drafts (`ocpp-stations`, `ocpp-transactions`, `ocpp-meta`) **not mounted** unless copied into `/api` or reconfigured

### 3.2 OCPP CSMS backend (`/ocpp-csms`)

Standalone Node package intended to run **continuously** (not as a pure serverless function).

```
ocpp-csms/
  package.json
  Dockerfile
  docker-compose.yml
  README.md
  docs/API.md
  scripts/charge-point-simulator.js
  tests/
  src/
    server/index.js          # HTTP + WS bootstrap
    websocket/ocppServer.js  # OCPP 1.6J JSON WebSocket
    rest/routes.js           # Express router
    controllers/             # REST controllers
    services/                # OCPP handlers, commands, connection registry
    repositories/            # Data access
    auth/jwt.js              # JWT + bcrypt + RBAC middleware
    smartCharging/           # Profile engine
    mobile/                  # Mobile API service
    notifications/
    jobs/ + queue/           # Background work + in-process bus
    monitoring/health.js
    openapi/spec.js
    middleware/              # rate limit, validation
    database/client.js       # Supabase client (ws transport for Node 20)
    config/ logging/ models/
  vercel-api/                # Optional serverless stubs (not primary path)
```

**CSMS dependencies:** `express`, `ws`, `jsonwebtoken`, `bcryptjs`, `cors`, `helmet`, `express-rate-limit`, `swagger-ui-express`, `uuid`, `@supabase/supabase-js`, `dotenv`.

**Engine:** Node `>=18` (developed/tested on Node 20).

### 3.3 Dual-backend reality (critical for migration)

| Capability | Implemented where | Notes |
|------------|-------------------|-------|
| Content/CRUD for SPA | Vercel `/api/*` | Primary for marketing, portal, admin |
| Live OCPP WebSocket | `ocpp-csms` only | **Cannot** run as standard Vercel serverless WS |
| OCPP REST (full) | `ocpp-csms` `/api/ocpp/v1` | OpenAPI at `/api/docs` |
| OCPP data in SPA | Often `src/lib/ocppClient.ts` → Supabase REST (anon) | Bypasses CSMS process; works if RLS/grants allow |
| Dashboard UI | React pages `/csms`, `/ocpp` | Consumes DB and/or CSMS |

Production must run **at least two compute services**: (1) SPA+serverless or SPA+API, (2) always-on CSMS.

---

## 4. Database Architecture

### 4.1 Provider

- **Supabase Postgres** (hosted)
- Accessed by:
  - Serverless API with **service role**
  - CSMS with **service role**
  - Browser `ocppClient` / `supabase.ts` with **anon key**

### 4.2 Migrations

**Finding:** There is **no** checked-in SQL migration history (`*.sql` migration folders not present).  
Schema was created and evolved **in the live Supabase project** (platform table tools / dashboard), not via Prisma/Drizzle/Flyway/etc.

**Migration requirement:** Before leaving Design Arena, export:

1. Full schema DDL (tables, columns, types, defaults, PK/FK)
2. Indexes
3. Views (if any)
4. Functions / triggers (if any)
5. RLS policies
6. Grants / roles
7. Storage buckets + policies (if used)
8. Seed/reference data subsets needed for prod

**Recommended commands (run in your controlled environment, not documented with secrets here):**

- Supabase CLI: `supabase db dump` / `supabase db pull`
- Or `pg_dump --schema-only` and selective `--data-only`

### 4.3 Tables referenced by application code

Tables observed via `.from('...')` usage across `api/`, `ocpp-csms/`, and `src/`:

#### Product / brand / content

- `products`, `product_lines`, `product_spec`, `production_assets`
- `brand_tokens`, `design_assets`, `design_bible`, `social_templates`, `website_sections`
- `prototype_flows`, `app_screens`, `app_landing`

#### Marketing / CRM-ish

- `marketing_content`, `marketing_leads`, `quotes`, `support_tickets`, `leads` (via API)
- `analytics_events`

#### Cloud / charging (app-level, pre-CSMS)

- `charge_points`, `charging_sessions`, `cloud_metrics`, `cloud_users`, `cloud_notifications`, `cloud_landing`, `fleets`

#### OCPP / CSMS domain

- `ocpp_stations`, `ocpp_connectors`, `ocpp_transactions`, `ocpp_meter_values`
- `ocpp_id_tags`, `ocpp_users`, `ocpp_reservations`, `ocpp_charging_profiles`
- `ocpp_firmware_jobs`, `ocpp_diagnostics`, `ocpp_event_logs`, `ocpp_audit_logs`
- `ocpp_pending_commands`, `ocpp_events`

#### CSMS ops extensions

- `csms_roles`, `csms_sessions`, `csms_notifications`, `csms_favorites`
- `csms_alerts`, `csms_jobs`, `csms_mobile_tokens`

#### Customer portal

- `portal_profiles`, `portal_chargers`, `portal_sessions`, `portal_vehicles`
- `portal_invoices`, `portal_subscriptions`, `portal_tickets`, `portal_notifications`
- `portal_downloads`, `portal_warranties`

#### Installer / maintenance

- `installer_jobs`, `installer_calendar`, `installer_appointments`, `installer_chargers`, `installer_maintenance`
- `installations`, `maintenance_ops`, `predictive_maintenance`

#### Admin

- `admin_analytics`, `admin_billing`, `admin_cms`, `admin_customers`, `admin_infra`
- `admin_installers`, `admin_kpis`, `admin_notifications`, `admin_products`, `admin_security`, `admin_tickets`

#### Academy / docs / UX systems

- `academy_courses`
- `docs_suite`, `master_docs`, `design_handoff`
- `ux_journeys`, `ux_kpis`, `ux_notifications`, `ux_screens`

#### AI / billing / developer

- `ai_insights`, `ai_platform`, `energy_advisor`
- `billing_records`
- `dev_api_keys`, `dev_content`, `dev_usage`

### 4.4 Relationships (logical — enforce in prod)

There is **no guarantee** all foreign keys are declared in Postgres today. Logical relationships:

```
ocpp_stations 1──* ocpp_connectors
ocpp_stations 1──* ocpp_transactions 1──* ocpp_meter_values
ocpp_stations 1──* ocpp_reservations / ocpp_charging_profiles / ocpp_firmware_jobs / ocpp_diagnostics
ocpp_id_tags *──1 ocpp_users (via user_id text)
ocpp_transactions ≈ csms_sessions (parallel session projection)
ocpp_stations *──* csms_favorites (user_id + charge_point_id)
charge_points / portal_chargers  (parallel models — risk of dual sources of truth)
products / product_lines (catalog)
academy_courses (standalone content)
```

**Production risk:** Several domains use **parallel tables** for similar concepts (`charge_points` vs `ocpp_stations`, `charging_sessions` vs `ocpp_transactions` vs `csms_sessions`). Consolidate or define clear boundaries.

### 4.5 Indexes, triggers, functions, RLS

| Object type | Status in repo |
|-------------|----------------|
| Indexes | **Not versioned** — must dump from live DB |
| Triggers | **Not versioned** — inspect live DB |
| Functions | **Not versioned** — inspect live DB |
| RLS policies | **Not versioned** — critically important: anon client writes from `ocppClient` imply either open policies or grants that may be too permissive for production |
| Auth schema | Supabase managed `auth.*` (if Auth enabled on project) |

**Action:** After schema dump, review RLS so browser anon key cannot escalate beyond intended scopes. Prefer routing all mutations through authenticated APIs.

### 4.6 Storage

- Public brand/product images are mostly **repo static files** under `public/`.
- Supabase Storage buckets may exist for portal uploads; **not fully evidenced** as a first-class module in this inventory. Verify buckets in Supabase dashboard on export.

---

## 5. API Endpoints

### 5.1 Vercel SPA APIs

Base: `https://<web-host>/api/<handler>`

Each `api/<name>.js` typically supports some of: `GET`, `POST`, `PUT`, `DELETE` (+ `OPTIONS`).

Examples:

| Endpoint | Domain |
|----------|--------|
| `GET/POST/PUT/DELETE /api/products` | Product catalog |
| `GET/POST/PUT/DELETE /api/academy-courses` | Academy |
| `GET/POST/PUT/DELETE /api/charge-points` | Cloud charge points |
| `GET/POST/PUT/DELETE /api/charging-sessions` | Sessions |
| `GET/POST/PUT/DELETE /api/portal-*` | Customer portal resources |
| `GET/POST/PUT/DELETE /api/admin-*` | Admin resources |
| `GET/POST/PUT/DELETE /api/leads` | Marketing leads |
| `GET/POST/PUT/DELETE /api/support-tickets` | Support |
| `GET/POST /api/dev-playground` | Developer playground |

**Auth on these routes:** Generally **not** enforcing end-user JWT in the simple CRUD handlers inspected; they rely on service role server-side and open CORS. **Must harden for production.**

### 5.2 OCPP CSMS REST (`ocpp-csms`)

Base: `http(s)://<csms-host>/api/ocpp/v1`

| Method | Path | Purpose |
|--------|------|---------|
| GET | `/health` | Health + metrics |
| GET | `/auth/demo-tokens` | Demo JWTs (disable in prod) |
| POST | `/auth/token` | Issue JWT |
| GET/POST/PATCH | `/stations`, `/stations/:id` | Station registry |
| POST | `/stations/:id/remote-start` | RemoteStartTransaction |
| POST | `/stations/:id/remote-stop` | RemoteStopTransaction |
| POST | `/stations/:id/reset` | Reset |
| POST | `/stations/:id/unlock` | UnlockConnector |
| POST | `/stations/:id/change-configuration` | ChangeConfiguration |
| GET | `/stations/:id/configuration` | GetConfiguration |
| POST | `/stations/:id/change-availability` | ChangeAvailability |
| POST | `/stations/:id/data-transfer` | DataTransfer |
| POST | `/stations/:id/firmware` | UpdateFirmware |
| POST | `/stations/:id/diagnostics` | GetDiagnostics |
| POST | `/stations/:id/reserve` | ReserveNow |
| POST | `/stations/:id/cancel-reservation` | CancelReservation |
| POST/DELETE | `/stations/:id/charging-profiles` | Set/ClearChargingProfile |
| POST | `/stations/:id/composite-schedule` | GetCompositeSchedule |
| POST | `/stations/:id/trigger` | TriggerMessage |
| GET | `/transactions`, `/transactions/:txId` | TX history |
| GET | `/sessions` | CSMS sessions |
| GET | `/reports/energy` | Energy report |
| GET | `/analytics/overview` | Dashboard KPIs |
| CRUD-ish | `/id-tags`, `/users`, `/roles` | Authz entities |
| GET/POST | `/alerts`, resolve | Fault management |
| GET/POST | `/notifications` | Notifications |
| GET/POST | `/jobs` | Background jobs |
| GET | `/bus/events` | In-process event bus peek |
| GET | `/reservations`, `/charging-profiles`, `/firmware-jobs` | Aux lists |
| GET | `/events`, `/audit`, `/commands` | Observability |

**Mobile API (same CSMS process):**

| Method | Path |
|--------|------|
| POST | `/mobile/auth/login` |
| GET | `/mobile/chargers`, `/mobile/chargers/:id` |
| POST | `/mobile/chargers/:id/start`, `.../stop` |
| GET | `/mobile/sessions`, `/mobile/favorites`, `/mobile/profile`, `/mobile/notifications` |
| POST | `/mobile/favorites` |

**Docs:**

- Swagger UI: `/api/docs`
- OpenAPI JSON: `/api/openapi.json`
- Root service descriptor: `GET /`

### 5.3 OCPP WebSocket

- **URL pattern:** `ws(s)://<csms-host>/ocpp/{chargePointId}` (path configurable via `OCPP_WS_PATH`)
- **Subprotocol:** `ocpp1.6`
- **TLS:** Terminate at reverse proxy / load balancer for WSS

---

## 6. Authentication

### 6.1 Models present

| Model | Where | Status |
|-------|-------|--------|
| **Supabase Auth (env ready)** | `VITE_SUPABASE_*`, `NEXT_PUBLIC_SUPABASE_*`, Google OAuth client/proxy env vars | Client helper `src/lib/supabase.ts` exists; **no full AuthProvider / googleAuth module found** in `src/` inventory — Google sign-in appears **prepared by env, not fully wired as a complete app auth system** |
| **CSMS JWT** | `ocpp-csms/src/auth/jwt.js` | Production-shaped: sign/verify, RBAC roles, API key bypass, bcrypt password hashing for CSMS users |
| **CSMS API key** | Header `X-API-Key` | Dev-friendly admin bypass — **must rotate and restrict in prod** |
| **Demo tokens** | `/auth/demo-tokens`, Bearer `demo` | **Must disable in production** |
| **Serverless APIs** | Service role | Backend trusted; **missing per-user authz** on many CRUD routes |
| **Portal UI** | Customer portal pages | App-level UX; verify whether session is real Supabase auth or demo state |

### 6.2 CSMS roles (code)

- `admin`, `operator`, `installer`, `viewer`, `api`, `driver`

### 6.3 Production auth recommendations (non-code; planning only)

1. Choose **one** primary identity provider (Supabase Auth recommended for SPA + portal).
2. Propagate `Authorization: Bearer <access_token>` to all `/api/*` routes; validate with Supabase JWT.
3. Keep CSMS JWT for machine-to-machine / NOC tools or unify on Supabase JWT with custom claims.
4. Enforce RLS for any browser-direct Supabase access; or remove browser-direct writes.
5. Disable demo tokens, anonymous GET bypass, and shared API keys outside secrets manager.

---

## 7. OCPP / CSMS Implementation

### 7.1 Compliance target

**OCPP 1.6J JSON** over WebSocket, subprotocol `ocpp1.6`.

### 7.2 Charge Point → CSMS handlers

Implemented in `ocpp-csms/src/services/ocppHandlers.js`:

- BootNotification  
- Heartbeat  
- StatusNotification  
- Authorize  
- StartTransaction  
- StopTransaction  
- MeterValues  
- DataTransfer  
- DiagnosticsStatusNotification  
- FirmwareStatusNotification  

### 7.3 CSMS → Charge Point commands

Implemented in `ocpp-csms/src/services/commandService.js` (via CALL):

- RemoteStartTransaction / RemoteStopTransaction  
- Reset  
- UnlockConnector  
- ChangeConfiguration / GetConfiguration  
- ChangeAvailability  
- DataTransfer  
- UpdateFirmware / GetDiagnostics  
- ReserveNow / CancelReservation  
- SetChargingProfile / ClearChargingProfile / GetCompositeSchedule  
- TriggerMessage  
- ClearCache  
- GetLocalListVersion / SendLocalList  

### 7.4 Supporting subsystems

| Subsystem | Path |
|-----------|------|
| Connection registry (in-memory WS map) | `services/connectionRegistry.js` |
| Smart charging engine | `smartCharging/engine.js` |
| Notifications | `notifications/notificationService.js` |
| Jobs worker | `jobs/worker.js` |
| Event queue | `queue/eventQueue.js` |
| Health | `monitoring/health.js` |
| CP simulator | `scripts/charge-point-simulator.js` |
| Unit tests | `tests/*.test.js` |

### 7.5 Scale model (as designed)

- Horizontal REST with shared Postgres  
- WebSocket **sticky sessions** at load balancer  
- Multi-node remote commands need shared bus (Redis) — **noted in README, not fully implemented**  
- OCPP 2.0.1: adapter boundary mentioned; **not implemented**

### 7.6 Operator UIs

| Route | Page | Role |
|-------|------|------|
| `/csms` | `CsmsDashboard.tsx` | Full CSMS operator dashboard (dark/light) |
| `/ocpp` | `OcppCsmsConsole.tsx` | OCPP lab / console |
| `/console` | Cloud dashboard variant | Cloud ops UI |

### 7.7 Docker

- `ocpp-csms/Dockerfile` — Node 20 Alpine, port 8080, healthcheck on `/api/ocpp/v1/health`
- `ocpp-csms/docker-compose.yml` — single `csms` service with env passthrough

---

## 8. Mobile Application Code

### 8.1 What exists

**Web-based mobile UX prototype**, not a React Native / Flutter / native repo.

| Path | Role |
|------|------|
| `src/pages/KynetikMobileApp.tsx` | Mobile app experience page |
| `src/pages/MobileApp.tsx` | Mobile app UX module |
| `src/pages/AppLanding.tsx` | App marketing landing |
| `src/components/mobile/KynetikAppFlow.tsx` | Multi-screen app flow |
| `src/components/mobile/screens.tsx` / `screensExtra.tsx` | Screen compositions |
| `src/components/mobile/PhoneChrome.tsx` | Device frame |
| `src/components/PhoneFrame.tsx` | Shared phone frame |
| `src/components/AppBottomNav.tsx` / `AppDownloadCTA.tsx` | App chrome / download CTAs |
| CSMS `src/mobile/mobileService.js` + REST `/mobile/*` | Backend API for a future/real app |

### 8.2 Customer portal (account app)

`src/pages/portal/*` — authenticated-style account area:

- chargers, energy, map, history, vehicles, subscription, warranty, service, notifications, downloads, profile

### 8.3 Missing for true mobile production

- Native or Capacitor/React Native project  
- Push notification infrastructure (FCM/APNs) beyond table stubs  
- Store listing assets / CI  
- Hardened mobile OAuth deep links  

---

## 9. KYNETIK Academy / Learning Platform

### 9.1 Frontend

| Path | Route | Role |
|------|-------|------|
| `src/pages/Academy.tsx` | Under design-system layout `academy` | Course browser UI; loads `/api/academy-courses` + design assets |
| `src/pages/marketing/AcademyLandingPage.tsx` | `/academy-landing` | Marketing landing; tracks (Installer / Business / Cloud); course list from API |
| Cross-links | Home, installer, marketing hub, docs | Academy referenced across site |

### 9.2 Backend / data

| Piece | Detail |
|-------|--------|
| API | `api/academy-courses.js` — full CRUD on `academy_courses` |
| Table | `academy_courses` (fields used: title, level, duration, modules, description, sort_order, …) |
| Assets | Optional `design_assets` filtered by category `academy`; image `public/images/academy.jpg` |

### 9.3 Academy maturity

- **Present:** Catalog UI, marketing landing, CRUD API, content table  
- **Not present / incomplete for LMS production:** enrollments, progress tracking, video hosting, quizzes, certificates issuance engine, payments for courses, instructor CMS workflow (beyond generic admin CMS tables)

---

## 10. Environment Variables Required

**Names only — configure values in a secrets manager. Do not commit values.**

### 10.1 Frontend (Vite)

| Variable | Required | Purpose |
|----------|----------|---------|
| `VITE_SUPABASE_URL` | Yes | Supabase project URL for browser client |
| `VITE_SUPABASE_ANON_KEY` | Yes | Supabase anon/public key |
| `NEXT_PUBLIC_SUPABASE_URL` | Recommended | Alias loaded by Vite `envPrefix` / define |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | Recommended | Alias for anon key |
| `VITE_GOOGLE_CLIENT_ID` | Optional | Google OAuth (if wiring Google sign-in) |
| `VITE_GOOGLE_AUTH_PROXY` | Optional | OAuth callback proxy URL |

### 10.2 Vercel serverless `/api`

| Variable | Required | Purpose |
|----------|----------|---------|
| `NEXT_PUBLIC_SUPABASE_URL` | Yes | DB URL |
| `SUPABASE_SERVICE_ROLE_KEY` | Yes | Server-side Supabase (elevated) |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | Often present | Some tooling / dual use |
| `FULLSTACK_PROJECT_REF` | Design Arena only | Drop or replace |
| `FULLSTACK_RESTORE_API_URL` | Design Arena only | Drop or replace `db-wake` |

### 10.3 OCPP CSMS (`ocpp-csms`)

| Variable | Required | Purpose |
|----------|----------|---------|
| `PORT` / `OCPP_REST_PORT` | Yes | HTTP listen port (default 8080) |
| `OCPP_WS_PATH` | Optional | WebSocket base path (default `/ocpp`) |
| `OCPP_WS_PORT` | Optional | If split WS port used |
| `NEXT_PUBLIC_SUPABASE_URL` or `SUPABASE_URL` | Yes | DB |
| `SUPABASE_SERVICE_ROLE_KEY` | Yes | DB service key |
| `OCPP_JWT_SECRET` or `JWT_SECRET` | Yes | JWT signing |
| `OCPP_JWT_EXPIRES` | Optional | Token TTL |
| `OCPP_API_KEY` | Recommended | Machine API key |
| `OCPP_REQUIRE_CP_AUTH` | Optional | Require charge point auth key on connect |
| `OCPP_AUTO_REGISTER` | Optional | Auto-register unknown CPs |
| `OCPP_ACCEPT_UNKNOWN_TAGS` | Optional | Authorize unknown RFID in dev |
| `OCPP_HEARTBEAT_INTERVAL` | Optional | Default heartbeat |
| `OCPP_MAX_STATIONS` | Optional | Capacity guard |
| `CORS_ORIGIN` | Recommended | Restrict CORS in prod |
| `LOG_LEVEL` | Optional | Logging |
| `NODE_ENV` | Yes | `production` |

### 10.4 vercel.json env keys currently declared (names)

`NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE_KEY`, `VITE_SUPABASE_URL`, `VITE_SUPABASE_ANON_KEY`, `VITE_GOOGLE_CLIENT_ID`, `VITE_GOOGLE_AUTH_PROXY`, `FULLSTACK_PROJECT_REF`, `FULLSTACK_RESTORE_API_URL`

---

## 11. External Services and Integrations

| Service | Usage |
|---------|-------|
| **Supabase** | Postgres + optional Auth + REST |
| **Vercel** | SPA hosting + serverless `/api` |
| **Google OAuth** | Env placeholders for client ID + auth proxy (Design Arena proxy pattern) |
| **Design Arena fullstack restore** | `db-wake` / `FULLSTACK_RESTORE_API_URL` — **remove in independent prod** |
| **Pexels / image gen (historical)** | Assets already materialized under `public/`; no runtime dependency required |
| **Charge points** | Real devices or simulator via OCPP WS |
| **Email/SMS/payment** | Tables/UI concepts exist (billing, notifications); **no first-class Stripe/Twilio/Resend integration verified as production-complete in this inventory** |

---

## 12. Dependencies and Runtime Versions

### 12.1 Toolchain observed in workspace

| Tool | Version (inspection environment) |
|------|----------------------------------|
| Node.js | `v20.20.2` |
| npm | `11.19.0` |

### 12.2 Root `package.json` dependencies

**Runtime:** `@supabase/supabase-js`, `@tailwindcss/vite`, `framer-motion`, `lucide-react`, `react`, `react-dom`, `react-router-dom`, `tailwindcss`  

**Dev:** Vite 7, TypeScript 5.9, ESLint 9, `@vitejs/plugin-react`, React types, etc.

### 12.3 CSMS `ocpp-csms/package.json` dependencies

`express`, `ws`, `jsonwebtoken`, `bcryptjs`, `cors`, `helmet`, `express-rate-limit`, `swagger-ui-express`, `uuid`, `@supabase/supabase-js`, `dotenv`

### 12.4 Lockfiles

- Root: `package-lock.json` present  
- CSMS: `ocpp-csms/package-lock.json` present  
- Note: prior deploys may have used pnpm on Vercel if a pnpm lock was present historically; current root shows **npm** lockfile. Align package manager on export.

---

## 13. Build and Deployment Configuration

### 13.1 Frontend scripts (root)

| Command | Purpose |
|---------|---------|
| `npm install` | Install SPA deps |
| `npm run dev` | Vite dev server |
| `npm run build` | `vite build` → `dist/` |
| `npm run preview` | Preview production build |
| `npm run lint` | ESLint |
| `npm run ocpp` | Start CSMS (`node ocpp-csms/src/server/index.js`) |
| `npm run ocpp:sim` | Charge point simulator |

**Note:** Root `build` script is `vite build` only (not `tsc -b && vite build` in current package.json). CI may still typecheck separately.

### 13.2 CSMS scripts

| Command | Purpose |
|---------|---------|
| `cd ocpp-csms && npm install` | Install CSMS deps |
| `npm start` / `npm run dev` | Run CSMS |
| `npm test` | Node test runner |
| `npm run simulate` | Simulator |
| `docker compose up --build` | Containerized CSMS |

### 13.3 Vercel

- Config file: `vercel.json`
  - Injects env var **names** listed in §10.4  
  - SPA rewrite: all non-`/api/*` → `/index.html`
- Serverless functions: files under `/api/*.js`
- Output: static `dist/` + serverless  

### 13.4 Recommended production topology (target)

```
                    ┌─────────────────────┐
                    │  CDN / Vercel / S3  │
                    │  SPA (dist/)        │
                    └─────────┬───────────┘
                              │ /api/*
                    ┌─────────▼───────────┐
                    │  API (Vercel/Node)  │── service role ──┐
                    └─────────────────────┘                 │
                                                            ▼
┌──────────────┐    WSS/HTTPS                    ┌──────────────────┐
│ Charge Points│───────────────────────────────►│ CSMS (ECS/K8s/VM) │── service role ──► Supabase Postgres
└──────────────┘                                 │ Express + ws      │
                                                 └────────▲─────────┘
                                                          │ REST /api/ocpp/v1
                                                 NOC Dashboard / Mobile backends
```

---

## 14. Missing Components (gaps vs independent production)

1. **Versioned database migrations** and documented ERD with real FKs  
2. **Hardened auth** on serverless CRUD (per-user JWT + RLS)  
3. **Removal of Design Arena restore/wake** coupling  
4. **Unified charging domain model** (merge or formally separate `charge_points` vs `ocpp_stations`)  
5. **Redis/NATS command bus** for multi-node CSMS remote commands  
6. **Native mobile apps** (only web prototype + mobile REST)  
7. **Complete LMS** (progress, certs, media pipeline)  
8. **Payment provider** integration (billing tables/UI without full PSP wiring)  
9. **Email/SMS** providers for notifications  
10. **CI/CD** pipelines (GitHub Actions not present in inventory)  
11. **Infrastructure as code** (Terraform/Pulumi not present)  
12. **Secrets management** workflow (currently `.env` / vercel env)  
13. **Observability stack** (APM, centralized logs, uptime) beyond console JSON logs  
14. **Package rename** and monorepo tooling (workspaces) cleanup  
15. **Mounting** of `ocpp-csms/vercel-api` (currently not the live serverless surface)  
16. **Disable demo auth** paths before public internet exposure  
17. **Load testing** artifacts for thousands of WS connections  
18. **OCPP 2.0.1** implementation (forward-looking only)  
19. **Legal/compliance** packs (GDPR export automation) as runnable services  
20. **Git history** — export may be a snapshot without prior VCS; initialize clean GitHub repo  

---

## 15. Production Risks

| Risk | Severity | Notes |
|------|----------|-------|
| Service role in serverless + open CORS | **Critical** | Anyone who can hit `/api/*` may mutate data if routes stay unauthenticated |
| Browser anon writes via `ocppClient` | **Critical** | Depends on RLS; may be wide open |
| Demo JWT / API key bypass | **Critical** | Must disable in prod |
| Dual sources of truth (sessions/stations) | **High** | Reporting and ops confusion |
| CSMS in-memory connection registry | **High** | Lost on restart; multi-instance sticky required |
| No migration history | **High** | Drift and unrecoverable schema knowledge |
| Design Arena DB pause/wake | **Medium** | Wrong failure modes outside Arena |
| Large SPA bundle | **Medium** | Build warns >500kB–2MB+ JS; code-split for perf |
| Root `api/` permission / incomplete bridges | **Medium** | Some handlers never landed in deployable `/api` |
| Secrets in local `.env` / vercel.json env | **High** if committed | Ensure `.gitignore` + secret scan; rotate all keys on export |
| Package name `placeholder-model-1` | **Low** | Branding/confusion |
| WebSocket on serverless misconception | **High** | CSMS must be always-on process |
| Incomplete Google auth wiring | **Medium** | Env without full UI/provider flow |
| Seed/demo data in DB | **Medium** | Sanitize before production |

**Immediate pre-production actions:** rotate all Supabase and JWT secrets after clone; lock down API auth; dump schema; run CSMS on VMs/containers with WSS.

---

## 16. Migration Steps (Design Arena → GitHub → Independent Prod)

### Phase A — Freeze and inventory (no behavior change)

1. Stop feature work; tag this workspace as export candidate.  
2. Keep this document with the repo: `KYNETIK_PRODUCTION_MIGRATION.md`.  
3. Inventory secrets **in a password manager** (values never in Git).  
4. Dump Supabase schema + critical data (anonymize PII).  
5. Export Storage buckets if any.  
6. List all custom Supabase Auth users/providers.

### Phase B — GitHub repository

1. Create private GitHub org/repo (e.g. `kynetik/platform`).  
2. Copy source **excluding** `node_modules/`, `dist/`, `.vercel/`, `.env`, logs.  
3. Ensure `.gitignore` covers `.env`, `.vercel`, `dist`, `node_modules`.  
4. Rename package to `@kynetik/web` or similar.  
5. Optionally split monorepo: `apps/web`, `apps/csms`, `packages/shared` (later).  
6. Commit lockfiles; document Node 20.  
7. Secret scanning (gitleaks) on first push.  
8. **Rotate every credential** that ever lived in Design Arena env.

### Phase C — Independent Supabase (or Postgres)

1. Create new Supabase project (or self-hosted Postgres).  
2. Apply schema from dump; add missing FKs/indexes intentionally.  
3. Configure RLS policies properly.  
4. Enable Auth providers (email, Google) under KYNETIK OAuth clients.  
5. Seed only necessary reference data (products, roles).  
6. Verify service role and anon keys in secrets manager only.

### Phase D — Web + serverless API

1. Create Vercel (or Cloudflare/Netlify+API) project linked to GitHub.  
2. Set env vars (§10) without Design Arena restore variables.  
3. Replace or no-op `db-wake` restore behavior.  
4. Deploy SPA + `/api`.  
5. Smoke-test critical routes: products, portal, academy, admin.  
6. Add authentication middleware plan (implement in a follow-up hardening sprint).

### Phase E — CSMS service

1. Deploy `ocpp-csms` to ECS/Fargate, Cloud Run, Render, Fly.io, or K8s.  
2. Attach env vars; mount TLS via ALB/nginx/Traefik (WSS + HTTPS).  
3. Configure sticky sessions for WebSocket.  
4. Health checks: `GET /api/ocpp/v1/health`.  
5. Point DNS e.g. `csms.kynetik.tn`, `wss://csms.kynetik.tn/ocpp/{id}`.  
6. Run simulator against staging; then lab charge point.  
7. Disable `/auth/demo-tokens` and anonymous GET bypass for production builds.

### Phase F — Networking and security

1. CORS allowlist production domains only.  
2. WAF rate limits on `/api` and CSMS REST.  
3. Separate staging/production projects and keys.  
4. Backup policy for Postgres (PITR).  
5. Audit logging retention.

### Phase G — Cutover

1. DNS cutover for marketing site.  
2. Provision first production charge points to new CSMS URL.  
3. Monitor heartbeats, boot notifications, transaction success rate.  
4. Decommission Design Arena deployment after soak period.  
5. Document runbooks (pager, firmware, incident).

### Phase H — Hardening backlog (post-move)

1. AuthZ on all serverless routes  
2. Domain model consolidation  
3. Redis command bus  
4. CI (lint, typecheck, test, build)  
5. Mobile app project kickoff using `/mobile` API  
6. Academy LMS features  
7. OCPP 2.0.1 roadmap  

---

## 17. Suggested Repository Layout After Export

```
kynetik-platform/
  README.md
  KYNETIK_PRODUCTION_MIGRATION.md
  apps/
    web/                 # current Vite React app (src, api, public)
    csms/                # current ocpp-csms
  packages/              # optional shared types later
  infra/                 # terraform / compose overlays
  docs/
    architecture.md
    api-map.md
    ocpp-runbook.md
  .github/workflows/
```

(Restructuring is optional; a single-repo copy of the current tree is valid for v1 export.)

---

## 18. Quick Reference — Run Locally (post-clone)

```bash
# Web
cp .env.example .env   # create from names in §10 — do not copy production secrets into git
npm install
npm run dev

# CSMS (second terminal)
cd ocpp-csms
cp .env.example .env
npm install
npm start
# OpenAPI: http://localhost:8080/api/docs
# WS: ws://localhost:8080/ocpp/KYN-TEST-001

# Simulator (third terminal)
npm run ocpp:sim   # from root, or csms npm run simulate
```

**Build web:** `npm run build` → deploy `dist/` + `api/`.  
**Build CSMS image:** `docker compose -f ocpp-csms/docker-compose.yml up --build`.

---

## 19. File-Level Checklist for GitHub Export

**Include**

- `src/`, `public/`, `api/`, `ocpp-csms/` (without node_modules)
- `package.json`, `package-lock.json`, `vite.config.ts`, `tsconfig*.json`
- `index.html`, `eslint.config.js`, `.gitignore`
- `KYNETIK_PRODUCTION_MIGRATION.md`, `README.md` (update README after export)
- `uploads/` if product assets are not fully under `public/`
- `ocpp-csms/Dockerfile`, `docker-compose.yml`, `docs/`, `tests/`

**Exclude**

- `node_modules/`, `ocpp-csms/node_modules/`
- `dist/`
- `.env` and any file containing secrets
- `.vercel/`, `.vercel.bak/`
- Log files, `*.local`
- Design Arena internal restore tooling configs if they embed secrets

**Sanitize before push**

- Search for accidental keys in `vercel.json` history, docs, and seed files  
- Rotate Supabase service role, anon keys, JWT secrets, Google client secrets  

---

## 20. Summary Assessment

| Area | Completeness in this workspace | Production readiness |
|------|--------------------------------|----------------------|
| Marketing / brand frontend | High (broad surface) | Good as static+API after auth hardening |
| Design system | High | Good |
| Serverless content APIs | High volume, simple CRUD | Needs authz + migrations |
| OCPP 1.6J CSMS | Strong modular foundation | Good staging candidate; scale/HA work remains |
| CSMS operator dashboard | Strong UI | Depends on data plane security |
| Mobile | Prototype + API stubs | Not app-store ready |
| Academy | Catalog + landing | Not full LMS |
| Auth | Split / incomplete SPA auth | **Blocker for public prod** |
| DB migrations | Missing in repo | **Blocker for controlled releases** |
| Independent ops | Coupled to Design Arena wake/restore | Remove on migrate |

**Bottom line:** The KYNETIK project is a **large, multi-surface full-stack system** with a real OCPP CSMS package, extensive React frontends, and a Supabase-backed data layer. It **can** be migrated to GitHub and independent infrastructure as-is, provided you (1) export and version the database schema, (2) run CSMS as a dedicated always-on service with WSS, (3) rotate and re-scope all secrets, and (4) treat authentication/authorization hardening as a release gate before public production traffic.

---

*End of report. No application source files were modified in the preparation of this document beyond adding this migration report file.*

import supabase from './db-client.js';

function genKey(prefix = 'kyn') {
  const rand = () => Math.random().toString(36).slice(2) + Math.random().toString(36).slice(2);
  return `${prefix}_live_${rand()}${rand()}`.slice(0, 48);
}

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { data, error } = await supabase
        .from('dev_api_keys')
        .select('*')
        .order('created_at', { ascending: false });
      if (error) throw error;
      return res.status(200).json(data || []);
    }
    if (req.method === 'POST') {
      const { name, permissions, environment } = req.body || {};
      if (!name) return res.status(400).json({ error: 'name is required' });
      const key_value = genKey(environment === 'test' ? 'kyn_test' : 'kyn');
      const { data, error } = await supabase
        .from('dev_api_keys')
        .insert({
          name,
          key_value,
          permissions: permissions || 'read,write',
          environment: environment || 'live',
          status: 'active',
          last_used: null,
        })
        .select()
        .single();
      if (error) throw error;
      return res.status(201).json(data);
    }
    if (req.method === 'PUT') {
      const { id, action, name, permissions, status } = req.body || {};
      if (!id) return res.status(400).json({ error: 'id is required' });
      const updates = {};
      if (action === 'rotate') {
        const { data: existing } = await supabase.from('dev_api_keys').select('environment').eq('id', id).single();
        updates.key_value = genKey(existing?.environment === 'test' ? 'kyn_test' : 'kyn');
        updates.status = 'active';
      }
      if (action === 'disable') updates.status = 'disabled';
      if (action === 'enable') updates.status = 'active';
      if (name) updates.name = name;
      if (permissions) updates.permissions = permissions;
      if (status) updates.status = status;
      const { data, error } = await supabase.from('dev_api_keys').update(updates).eq('id', id).select().single();
      if (error) throw error;
      return res.status(200).json(data);
    }
    if (req.method === 'DELETE') {
      const { id } = req.body || {};
      if (!id) return res.status(400).json({ error: 'id is required' });
      const { error } = await supabase.from('dev_api_keys').delete().eq('id', id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }
    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('API error:', err);
    res.status(500).json({ error: err.message });
  }
}

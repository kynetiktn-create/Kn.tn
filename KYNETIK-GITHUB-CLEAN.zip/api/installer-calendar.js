import supabase from './db-client.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { type, date, status } = req.query;
      let q = supabase
        .from('installer_calendar')
        .select('*')
        .order('starts_at', { ascending: true });
      if (type) q = q.eq('type', type);
      if (status) q = q.eq('status', status);
      if (date) {
        const dayStart = `${date}T00:00:00.000Z`;
        const dayEnd = `${date}T23:59:59.999Z`;
        q = q.gte('starts_at', dayStart).lte('starts_at', dayEnd);
      }
      const { data, error } = await q;
      if (error) throw error;
      return res.status(200).json(data);
    }

    if (req.method === 'POST') {
      const body = req.body || {};
      if (!body.title || !body.starts_at || !body.type) {
        return res.status(400).json({ error: 'title, type and starts_at are required' });
      }
      const { data, error } = await supabase
        .from('installer_calendar')
        .insert({
          title: body.title,
          type: body.type,
          customer: body.customer || '',
          city: body.city || '',
          address: body.address || '',
          product: body.product || '',
          installer: body.installer || '',
          status: body.status || 'scheduled',
          priority: body.priority || 'normal',
          starts_at: body.starts_at,
          ends_at: body.ends_at || null,
          notes: body.notes || '',
          contact_phone: body.contact_phone || '',
        })
        .select()
        .single();
      if (error) throw error;
      return res.status(201).json(data);
    }

    if (req.method === 'PUT') {
      const { id, ...updates } = req.body || {};
      if (!id) return res.status(400).json({ error: 'id is required' });
      const { data, error } = await supabase
        .from('installer_calendar')
        .update(updates)
        .eq('id', id)
        .select()
        .single();
      if (error) throw error;
      return res.status(200).json(data);
    }

    if (req.method === 'DELETE') {
      const { id } = req.body || {};
      if (!id) return res.status(400).json({ error: 'id is required' });
      const { error } = await supabase.from('installer_calendar').delete().eq('id', id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }

    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('installer-calendar API error:', err);
    return res.status(500).json({ error: err.message });
  }
}

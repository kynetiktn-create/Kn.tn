import supabase from './db-client.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { type } = req.query;
      let query = supabase.from('marketing_leads').select('*').order('id', { ascending: false });
      if (type) query = query.eq('type', type);
      const { data, error } = await query.limit(100);
      if (error) throw error;
      return res.status(200).json(data);
    }
    if (req.method === 'POST') {
      const body = req.body || {};
      if (!body.email && !body.name) {
        return res.status(400).json({ error: 'name or email is required' });
      }
      const payload = {
        type: body.type || 'contact',
        name: body.name || '',
        email: body.email || '',
        phone: body.phone || '',
        company: body.company || '',
        subject: body.subject || '',
        message: body.message || '',
        payload: body.payload ? JSON.stringify(body.payload) : null,
        status: 'new',
      };
      const { data, error } = await supabase
        .from('marketing_leads')
        .insert(payload)
        .select()
        .single();
      if (error) throw error;
      return res.status(201).json(data);
    }
    if (req.method === 'PUT') {
      const { id, ...updates } = req.body || {};
      if (!id) return res.status(400).json({ error: 'id is required' });
      if (updates.payload && typeof updates.payload === 'object') {
        updates.payload = JSON.stringify(updates.payload);
      }
      const { data, error } = await supabase
        .from('marketing_leads')
        .update(updates)
        .eq('id', id)
        .select()
        .single();
      if (error) throw error;
      return res.status(200).json(data);
    }
    if (req.method === 'DELETE') {
      const { id } = req.body || {};
      if (!id) return res.status(400).json({ error: 'id is required' });
      const { error } = await supabase.from('marketing_leads').delete().eq('id', id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }
    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('API error:', err);
    res.status(500).json({ error: err.message });
  }
}

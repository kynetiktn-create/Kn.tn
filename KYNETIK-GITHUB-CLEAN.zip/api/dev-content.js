import supabase from './db-client.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { type, category, q } = req.query;
      let query = supabase.from('dev_content').select('*').order('sort_order', { ascending: true });
      if (type) query = query.eq('type', type);
      if (category) query = query.eq('category', category);
      const { data, error } = await query;
      if (error) throw error;
      let rows = data || [];
      if (q) {
        const s = String(q).toLowerCase();
        rows = rows.filter(
          (r) =>
            (r.title || '').toLowerCase().includes(s) ||
            (r.body || '').toLowerCase().includes(s) ||
            (r.category || '').toLowerCase().includes(s) ||
            (r.meta || '').toLowerCase().includes(s)
        );
      }
      return res.status(200).json(rows);
    }
    if (req.method === 'POST') {
      const body = req.body;
      if (!body.title || !body.type) return res.status(400).json({ error: 'title and type required' });
      const { data, error } = await supabase.from('dev_content').insert(body).select().single();
      if (error) throw error;
      return res.status(201).json(data);
    }
    if (req.method === 'PUT') {
      const { id, ...updates } = req.body;
      if (!id) return res.status(400).json({ error: 'id is required' });
      const { data, error } = await supabase.from('dev_content').update(updates).eq('id', id).select().single();
      if (error) throw error;
      return res.status(200).json(data);
    }
    if (req.method === 'DELETE') {
      const { id } = req.body;
      if (!id) return res.status(400).json({ error: 'id is required' });
      const { error } = await supabase.from('dev_content').delete().eq('id', id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }
    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('API error:', err);
    res.status(500).json({ error: err.message });
  }
}

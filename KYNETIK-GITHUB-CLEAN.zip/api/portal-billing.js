import supabase from './db-client.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    const { kind } = req.query;
    if (req.method === 'GET') {
      if (kind === 'subscription') {
        const { data, error } = await supabase.from('portal_subscriptions').select('*').order('id', { ascending: true }).limit(1);
        if (error) throw error;
        return res.status(200).json(data?.[0] || null);
      }
      if (kind === 'invoices') {
        const { data, error } = await supabase.from('portal_invoices').select('*').order('issued_at', { ascending: false });
        if (error) throw error;
        return res.status(200).json(data);
      }
      const [sub, inv] = await Promise.all([
        supabase.from('portal_subscriptions').select('*').limit(1),
        supabase.from('portal_invoices').select('*').order('issued_at', { ascending: false }),
      ]);
      if (sub.error) throw sub.error;
      if (inv.error) throw inv.error;
      return res.status(200).json({ subscription: sub.data?.[0] || null, invoices: inv.data || [] });
    }
    if (req.method === 'POST') {
      const { table = 'portal_invoices', ...body } = req.body;
      const { data, error } = await supabase.from(table).insert(body).select().single();
      if (error) throw error;
      return res.status(201).json(data);
    }
    if (req.method === 'PUT') {
      const { table = 'portal_subscriptions', id, ...updates } = req.body;
      if (!id) return res.status(400).json({ error: 'id required' });
      const { data, error } = await supabase.from(table).update(updates).eq('id', id).select().single();
      if (error) throw error;
      return res.status(200).json(data);
    }
    if (req.method === 'DELETE') {
      const { table = 'portal_invoices', id } = req.body;
      if (!id) return res.status(400).json({ error: 'id required' });
      const { error } = await supabase.from(table).delete().eq('id', id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }
    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
}

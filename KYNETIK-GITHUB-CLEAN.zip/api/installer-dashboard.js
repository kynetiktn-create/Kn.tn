import supabase from './db-client.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { section } = req.query;

      if (section === 'jobs' || !section) {
        const { data: jobs, error: jErr } = await supabase
          .from('installer_jobs')
          .select('*')
          .order('sort_order', { ascending: true });
        if (jErr) throw jErr;

        if (section === 'jobs') return res.status(200).json(jobs);

        const [maint, tickets, chargers, appointments] = await Promise.all([
          supabase.from('installer_maintenance').select('*').order('sort_order', { ascending: true }),
          supabase.from('support_tickets').select('*').order('id', { ascending: false }).limit(12),
          supabase.from('installer_chargers').select('*').order('sort_order', { ascending: true }),
          supabase.from('installer_appointments').select('*').order('sort_order', { ascending: true }),
        ]);

        if (maint.error) throw maint.error;
        if (tickets.error) throw tickets.error;
        if (chargers.error) throw chargers.error;
        if (appointments.error) throw appointments.error;

        const assigned = (jobs || []).filter((j) =>
          ['pending', 'in_progress', 'scheduled', 'open', 'assigned'].includes(String(j.status || '').toLowerCase())
        );
        const today = (jobs || []).filter((j) => {
          const s = String(j.scheduled_at || '');
          return s.includes('2026-03-24') || s.includes('Today') || String(j.status).toLowerCase() === 'in_progress';
        });

        return res.status(200).json({
          jobs: jobs || [],
          assigned,
          schedule: today.length ? today : (jobs || []).slice(0, 4),
          maintenance: maint.data || [],
          tickets: tickets.data || [],
          chargers: chargers.data || [],
          appointments: appointments.data || [],
          kpis: {
            assigned: assigned.length,
            today: today.length || Math.min(4, (jobs || []).length),
            maintenance: (maint.data || []).filter((m) => m.status !== 'done').length,
            openTickets: (tickets.data || []).filter((t) => t.status === 'open' || t.status === 'pending').length,
            installed: (chargers.data || []).length,
            appointments: (appointments.data || []).filter((a) => a.status !== 'cancelled').length,
          },
        });
      }

      if (section === 'maintenance') {
        const { data, error } = await supabase.from('installer_maintenance').select('*').order('sort_order');
        if (error) throw error;
        return res.status(200).json(data);
      }
      if (section === 'chargers') {
        const { data, error } = await supabase.from('installer_chargers').select('*').order('sort_order');
        if (error) throw error;
        return res.status(200).json(data);
      }
      if (section === 'appointments') {
        const { data, error } = await supabase.from('installer_appointments').select('*').order('sort_order');
        if (error) throw error;
        return res.status(200).json(data);
      }
      if (section === 'tickets') {
        const { data, error } = await supabase.from('support_tickets').select('*').order('id', { ascending: false });
        if (error) throw error;
        return res.status(200).json(data);
      }

      if (section === 'installations') {
        const { id } = req.query;
        if (id) {
          const { data, error } = await supabase.from('installations').select('*').eq('id', id).single();
          if (error) throw error;
          return res.status(200).json(data);
        }
        const { data, error } = await supabase
          .from('installations')
          .select('*')
          .order('id', { ascending: false });
        if (error) throw error;
        return res.status(200).json(data);
      }

      return res.status(400).json({ error: 'Unknown section' });
    }

    if (req.method === 'POST') {
      const { table, ...row } = req.body || {};
      const allowed = [
        'installer_jobs',
        'installer_maintenance',
        'installer_chargers',
        'installer_appointments',
        'installations',
      ];
      if (!allowed.includes(table)) return res.status(400).json({ error: 'Invalid table' });
      if (table === 'installations' && row.status === 'completed' && !row.completed_at) {
        row.completed_at = new Date().toISOString();
      }
      const { data, error } = await supabase.from(table).insert(row).select().single();
      if (error) throw error;
      return res.status(201).json(data);
    }

    if (req.method === 'PUT') {
      const { table, id, ...updates } = req.body || {};
      const allowed = [
        'installer_jobs',
        'installer_maintenance',
        'installer_chargers',
        'installer_appointments',
        'support_tickets',
        'installations',
      ];
      if (!allowed.includes(table) || !id) return res.status(400).json({ error: 'table and id required' });
      if (table === 'installations' && updates.status === 'completed' && !updates.completed_at) {
        updates.completed_at = new Date().toISOString();
      }
      const { data, error } = await supabase.from(table).update(updates).eq('id', id).select().single();
      if (error) throw error;
      return res.status(200).json(data);
    }

    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('installer-dashboard error:', err);
    res.status(500).json({ error: err.message });
  }
}

import supabase from './db-client.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { period } = req.query;
      let query = supabase.from('portal_sessions').select('*').order('started_at', { ascending: false });
      if (period && period !== 'all') {
        const now = new Date();
        let from = new Date(0);
        if (period === 'today') {
          from = new Date(now.getFullYear(), now.getMonth(), now.getDate());
        } else if (period === 'week') {
          from = new Date(now.getTime() - 7 * 86400000);
        } else if (period === 'month') {
          from = new Date(now.getFullYear(), now.getMonth(), 1);
        } else if (period === 'year') {
          from = new Date(now.getFullYear(), 0, 1);
        }
        query = query.gte('started_at', from.toISOString());
      }
      const { data, error } = await query;
      if (error) throw error;
      return res.status(200).json(data);
    }
    if (req.method === 'POST') {
      const body = req.body;
      const { data, error } = await supabase.from('portal_sessions').insert(body).select().single();
      if (error) throw error;
      return res.status(201).json(data);
    }
    if (req.method === 'PUT') {
      const { id, ...updates } = req.body;
      if (!id) return res.status(400).json({ error: 'id required' });
      const { data, error } = await supabase.from('portal_sessions').update(updates).eq('id', id).select().single();
      if (error) throw error;
      return res.status(200).json(data);
    }
    if (req.method === 'DELETE') {
      const { id } = req.body;
      if (!id) return res.status(400).json({ error: 'id required' });
      const { error } = await supabase.from('portal_sessions').delete().eq('id', id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }
    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
}

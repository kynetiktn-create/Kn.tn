import supabase from './db-client.js';

const SAMPLE = {
  'GET /v1/stations': {
    status: 200,
    body: {
      data: [
        { id: 'stn_tn_lac2_01', name: 'Hub Lac 2', status: 'online', power_kw: 120, connectors: 4 },
        { id: 'stn_tn_marsa_02', name: 'NOVA Marsa', status: 'charging', power_kw: 22, connectors: 1 },
      ],
      has_more: false,
    },
  },
  'POST /v1/sessions/remote-start': {
    status: 200,
    body: {
      session_id: 'ses_k88421',
      status: 'Accepted',
      station_id: 'stn_tn_lac2_01',
      connector_id: 2,
      latency_ms: 612,
    },
  },
  'GET /v1/sessions': {
    status: 200,
    body: {
      data: [
        { id: 'ses_k88421', energy_kwh: 18.4, status: 'active', started_at: '2026-03-26T09:12:00Z' },
        { id: 'ses_k88402', energy_kwh: 42.1, status: 'completed', started_at: '2026-03-26T07:01:00Z' },
      ],
      has_more: true,
    },
  },
  'GET /v1/webhooks': {
    status: 200,
    body: {
      data: [
        { id: 'wh_01', url: 'https://api.partner.tn/hooks/kynetik', events: ['charging.started', 'charging.finished'] },
      ],
    },
  },
};

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { data, error } = await supabase
        .from('dev_content')
        .select('*')
        .eq('type', 'endpoint')
        .order('sort_order', { ascending: true });
      if (error) throw error;
      return res.status(200).json(data || []);
    }

    if (req.method === 'POST') {
      const { method = 'GET', path = '/v1/stations', apiKey } = req.body || {};
      const key = `${String(method).toUpperCase()} ${path}`;
      const sample = SAMPLE[key] || {
        status: 200,
        body: {
          ok: true,
          message: 'Simulated KYNETIK API response',
          request: { method: method.toUpperCase(), path },
          authenticated: Boolean(apiKey),
        },
      };

      // log playground hit
      try {
        await supabase.from('dev_usage').insert({
          type: 'log',
          label: `${method.toUpperCase()} ${path}`,
          value: String(sample.status),
          meta: apiKey ? 'key=present' : 'key=none',
          sort_order: Date.now() % 100000,
        });
      } catch {
        /* non-blocking */
      }

      return res.status(200).json({
        ...sample,
        latency_ms: 40 + Math.floor(Math.random() * 120),
        timestamp: new Date().toISOString(),
      });
    }

    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('API error:', err);
    res.status(500).json({ error: err.message });
  }
}

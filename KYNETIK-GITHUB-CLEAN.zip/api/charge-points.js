import supabase from './db-client.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { status, city, search } = req.query;
      let query = supabase.from('charge_points').select('*').order('name', { ascending: true });
      if (status) query = query.eq('status', status);
      if (city) query = query.eq('city', city);
      const { data, error } = await query;
      if (error) throw error;
      let rows = data || [];
      if (search) {
        const q = String(search).toLowerCase();
        rows = rows.filter(
          (r) =>
            r.name?.toLowerCase().includes(q) ||
            r.station_id?.toLowerCase().includes(q) ||
            r.city?.toLowerCase().includes(q) ||
            r.model?.toLowerCase().includes(q)
        );
      }
      return res.status(200).json(rows);
    }
    if (req.method === 'POST') {
      const body = req.body;
      if (!body.name || !body.station_id) return res.status(400).json({ error: 'name and station_id required' });
      const { data, error } = await supabase.from('charge_points').insert(body).select().single();
      if (error) throw error;
      return res.status(201).json(data);
    }
    if (req.method === 'PUT') {
      const { id, action, ...updates } = req.body;
      if (!id) return res.status(400).json({ error: 'id is required' });
      let patch = { ...updates };
      if (action === 'remote_start') patch = { ...patch, status: 'charging', connector_status: 'Occupied' };
      if (action === 'remote_stop') patch = { ...patch, status: 'available', connector_status: 'Available', power_kw: 0, current_a: 0 };
      if (action === 'restart') patch = { ...patch, status: 'available', last_seen: new Date().toISOString() };
      if (action === 'lock') patch = { ...patch, locked: true };
      if (action === 'unlock') patch = { ...patch, locked: false };
      const { data, error } = await supabase.from('charge_points').update(patch).eq('id', id).select().single();
      if (error) throw error;
      return res.status(200).json(data);
    }
    if (req.method === 'DELETE') {
      const { id } = req.body;
      if (!id) return res.status(400).json({ error: 'id is required' });
      const { error } = await supabase.from('charge_points').delete().eq('id', id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }
    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('API error:', err);
    res.status(500).json({ error: err.message });
  }
}

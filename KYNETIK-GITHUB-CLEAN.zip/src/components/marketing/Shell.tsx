import { useEffect, useState, type ReactNode } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  ArrowRight, Menu, X, MessageCircle, Linkedin, Instagram, Facebook, Mail, Phone, MapPin
} from 'lucide-react';
import BrandLogo from '../BrandLogo';
import { cn } from '../../lib/utils';

const nav = [
  { to: '/', label: 'Home' },
  { to: '/products', label: 'Products' },
  { to: '/cloud', label: 'Cloud' },
  { to: '/grow', label: 'Grow' },
  { to: '/success-stories', label: 'Stories' },
  { to: '/resources', label: 'Resources' },
  { to: '/academy-landing', label: 'Academy' },
  { to: '/support', label: 'Support' },
  { to: '/contact', label: 'Contact' },
];

const salesLinks = [
  { to: '/quote', label: 'Request a Quote' },
  { to: '/installers', label: 'Become an Installer' },
  { to: '/distributors', label: 'Become a Distributor' },
  { to: '/careers', label: 'Careers' },
  { to: '/faq', label: 'FAQ' },
];

export function Fade({
  children,
  className,
  delay = 0,
}: {
  children: ReactNode;
  className?: string;
  delay?: number;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 28 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-60px' }}
      transition={{ duration: 0.65, delay, ease: [0.22, 1, 0.36, 1] }}
      className={className}
    >
      {children}
    </motion.div>
  );
}

export function Field({
  label,
  children,
  error,
}: {
  label: string;
  children: ReactNode;
  error?: string;
}) {
  return (
    <label className="block">
      <span className="text-[11px] uppercase tracking-wider text-kyn-metal font-medium">{label}</span>
      <div className="mt-1.5">{children}</div>
      {error && <p className="mt-1 text-xs text-red-400">{error}</p>}
    </label>
  );
}

export const inputClass =
  'w-full rounded-xl bg-kyn-steel/50 border border-white/10 px-3.5 py-3 text-sm text-white placeholder:text-kyn-metal focus:outline-none focus:border-kyn-green/50 focus:ring-1 focus:ring-kyn-green/30 transition-colors';

export function SuccessBanner({ title, body }: { title: string; body: string }) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.98 }}
      animate={{ opacity: 1, scale: 1 }}
      className="rounded-2xl border border-kyn-green/30 bg-kyn-green/10 p-6 text-center"
    >
      <p className="font-display text-xl font-bold text-kyn-green">{title}</p>
      <p className="mt-2 text-sm text-kyn-silver">{body}</p>
    </motion.div>
  );
}

export default function MarketingShell({
  children,
  ctaLabel = 'Request a Quote',
  ctaTo = '/quote',
}: {
  children: ReactNode;
  ctaLabel?: string;
  ctaTo?: string;
}) {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [chatOpen, setChatOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    setOpen(false);
    window.scrollTo(0, 0);
  }, [location.pathname]);

  return (
    <div className="min-h-screen bg-kyn-black text-white">
      <header
        className={cn(
          'fixed top-0 inset-x-0 z-50 transition-all duration-300',
          scrolled ? 'bg-kyn-black/85 backdrop-blur-xl border-b border-white/5' : 'bg-transparent'
        )}
      >
        <div className="max-w-7xl mx-auto px-5 md:px-8 h-16 md:h-[72px] flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2">
            <BrandLogo height={28} />
          </Link>
          <nav className="hidden xl:flex items-center gap-6">
            {nav.map((l) => (
              <Link
                key={l.to}
                to={l.to}
                className={cn(
                  'text-xs font-medium transition-colors',
                  location.pathname === l.to ? 'text-kyn-green' : 'text-kyn-silver hover:text-white'
                )}
              >
                {l.label}
              </Link>
            ))}
          </nav>
          <div className="flex items-center gap-2 sm:gap-3">
            <Link
              to={ctaTo}
              className="hidden sm:inline-flex items-center gap-2 px-4 py-2 rounded-full bg-kyn-green text-kyn-black text-xs font-bold hover:bg-kyn-green-glow transition-colors"
            >
              {ctaLabel} <ArrowRight size={13} />
            </Link>
            <button type="button" className="xl:hidden p-2 text-kyn-silver" onClick={() => setOpen(!open)} aria-label="Menu">
              {open ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </div>
        {open && (
          <div className="xl:hidden border-t border-white/5 bg-kyn-void/98 backdrop-blur-xl px-5 py-4 max-h-[80vh] overflow-y-auto">
            <div className="space-y-1">
              {[...nav, ...salesLinks].map((l) => (
                <Link key={l.to} to={l.to} className="block py-2.5 text-sm text-kyn-silver hover:text-white">
                  {l.label}
                </Link>
              ))}
            </div>
            <Link to={ctaTo} className="mt-4 block text-center rounded-full bg-kyn-green text-kyn-black text-xs font-bold py-3">
              {ctaLabel}
            </Link>
          </div>
        )}
      </header>

      <main className="pt-16 md:pt-[72px]">{children}</main>

      <footer className="border-t border-white/5 bg-kyn-void">
        <div className="max-w-7xl mx-auto px-5 md:px-8 py-14">
          <div className="grid md:grid-cols-2 lg:grid-cols-5 gap-10">
            <div className="lg:col-span-2">
              <BrandLogo height={32} />
              <p className="mt-4 text-sm text-kyn-metal max-w-sm leading-relaxed">
                L'énergie en mouvement — premium EV charging technology for homes, businesses and networks across Tunisia and beyond.
              </p>
              <div className="mt-5 flex gap-3">
                {[Linkedin, Instagram, Facebook].map((Icon, i) => (
                  <a key={i} href="#" className="w-9 h-9 rounded-full border border-white/10 flex items-center justify-center text-kyn-metal hover:text-kyn-green hover:border-kyn-green/40 transition-colors">
                    <Icon size={15} />
                  </a>
                ))}
              </div>
            </div>
            <div>
              <p className="text-[11px] uppercase tracking-widest text-kyn-metal mb-4">Convert</p>
              <div className="space-y-2.5">
                {salesLinks.map((l) => (
                  <Link key={l.to} to={l.to} className="block text-sm text-kyn-silver hover:text-white">{l.label}</Link>
                ))}
              </div>
            </div>
            <div>
              <p className="text-[11px] uppercase tracking-widest text-kyn-metal mb-4">Company</p>
              <div className="space-y-2.5">
                {[
                  { to: '/success-stories', label: 'Success Stories' },
                  { to: '/resources', label: 'Resources' },
                  { to: '/academy-landing', label: 'Academy' },
                  { to: '/careers', label: 'Careers' },
                  { to: '/support', label: 'Support' },
                ].map((l) => (
                  <Link key={l.to} to={l.to} className="block text-sm text-kyn-silver hover:text-white">{l.label}</Link>
                ))}
              </div>
            </div>
            <div>
              <p className="text-[11px] uppercase tracking-widest text-kyn-metal mb-4">Contact</p>
              <div className="space-y-3 text-sm text-kyn-silver">
                <p className="flex items-start gap-2"><MapPin size={14} className="text-kyn-green mt-0.5 shrink-0" /> Les Berges du Lac, Tunis</p>
                <a href="mailto:hello@kynetik.tn" className="flex items-center gap-2 hover:text-white"><Mail size={14} className="text-kyn-green" /> hello@kynetik.tn</a>
                <a href="tel:+21671000000" className="flex items-center gap-2 hover:text-white"><Phone size={14} className="text-kyn-green" /> +216 71 000 000</a>
              </div>
            </div>
          </div>
          <div className="mt-12 pt-6 border-t border-white/5 flex flex-wrap justify-between gap-3 text-[11px] text-kyn-metal">
            <p>© {new Date().getFullYear()} KYNETIK — Premium EV Charging Technology</p>
            <div className="flex gap-4">
              <Link to="/design-system" className="hover:text-white">Design System</Link>
              <Link to="/faq" className="hover:text-white">FAQ</Link>
              <Link to="/contact" className="hover:text-white">Contact</Link>
            </div>
          </div>
        </div>
      </footer>

      {/* Live chat */}
      <div className="fixed bottom-5 right-5 z-50 flex flex-col items-end gap-3">
        {chatOpen && (
          <motion.div
            initial={{ opacity: 0, y: 12, scale: 0.96 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            className="w-[300px] sm:w-[340px] rounded-2xl border border-white/10 bg-kyn-void/95 backdrop-blur-xl shadow-2xl overflow-hidden"
          >
            <div className="px-4 py-3 border-b border-white/5 flex items-center justify-between bg-kyn-green/10">
              <div>
                <p className="text-sm font-semibold">KYNETIK Live</p>
                <p className="text-[10px] text-kyn-green">Typically replies in minutes</p>
              </div>
              <button type="button" onClick={() => setChatOpen(false)} className="text-kyn-metal hover:text-white"><X size={16} /></button>
            </div>
            <div className="p-4 space-y-3">
              <div className="rounded-xl bg-white/5 border border-white/8 px-3 py-2 text-xs text-kyn-silver">
                Bonjour 👋 How can we help — quote, install, partnership or support?
              </div>
              <div className="grid grid-cols-2 gap-2">
                {[
                  { to: '/quote', l: 'Get a quote' },
                  { to: '/support', l: 'Open ticket' },
                  { to: '/installers', l: 'Installers' },
                  { to: '/contact', l: 'Talk to sales' },
                ].map((x) => (
                  <Link key={x.to} to={x.to} className="rounded-lg border border-white/10 bg-black/30 px-2 py-2 text-[11px] text-center hover:border-kyn-green/40 hover:text-kyn-green transition-colors">
                    {x.l}
                  </Link>
                ))}
              </div>
              <a href="mailto:hello@kynetik.tn" className="block text-center text-xs text-kyn-green font-semibold">Email hello@kynetik.tn</a>
            </div>
          </motion.div>
        )}
        <button
          type="button"
          onClick={() => setChatOpen(!chatOpen)}
          className="w-14 h-14 rounded-full bg-kyn-green text-kyn-black flex items-center justify-center shadow-lg shadow-kyn-green/30 hover:bg-kyn-green-glow transition-colors"
          aria-label="Live chat"
        >
          {chatOpen ? <X size={22} /> : <MessageCircle size={22} />}
        </button>
      </div>
    </div>
  );
}

import { NavLink, Outlet } from 'react-router-dom';
import { useState } from 'react';
import {
  Menu, X, Palette, Share2, Smartphone, Globe, Cloud,
  GraduationCap, Presentation, Briefcase, LayoutGrid, Package, Sparkles, Rocket,
  Play, Code2, Star, Layers, TrendingUp, UserCircle2, Zap, Terminal, Wrench, CalendarDays,
  BookOpen, Component, FileText
} from 'lucide-react';
import BrandLogo from './BrandLogo';
import { cn } from '../lib/utils';

const nav = [
  { to: '/docs-suite', label: 'Documentation Suite', icon: BookOpen },
  { to: '/database', label: 'DB Architecture 11–20', icon: FileText },
  { to: '/master-docs-v2', label: 'Master Docs v2', icon: FileText },
  { to: '/ux-journeys', label: 'UX Flows & Journeys', icon: FileText },
  { to: '/product-spec', label: 'Product Specification', icon: FileText },
  { to: '/design-bible', label: 'Design Bible', icon: BookOpen },
  { to: '/ui-library', label: 'UI Component Library', icon: Component },
  { to: '/', label: 'Installer Calendar', icon: CalendarDays },
  { to: '/installer', label: 'Installer Dashboard', icon: Wrench },
  { to: '/developers', label: 'Developer Platform', icon: Terminal },
  { to: '/portal', label: 'Customer Portal', icon: UserCircle2 },
  { to: '/grow', label: 'Marketing & Sales', icon: TrendingUp },
  { to: '/home', label: 'Homepage', icon: Rocket },
  { to: '/contact', label: 'Contact', icon: Share2 },
  { to: '/quote', label: 'Request a Quote', icon: Briefcase },
  { to: '/production', label: 'Production Assets', icon: Layers },
  { to: '/showcase', label: 'Final Showcase', icon: Star },
  { to: '/prototype', label: 'Interactive Prototype', icon: Play },
  { to: '/handoff', label: 'Dev Handoff', icon: Code2 },
  { to: '/console', label: 'Cloud Dashboard', icon: Cloud },
  { to: '/installation-details', label: 'Installation Details', icon: Wrench },
  { to: '/maintenance', label: 'Maintenance', icon: Wrench },
  { to: '/ai-platform', label: 'KYNETIK AI Platform', icon: Sparkles },
  { to: '/energy-advisor', label: 'AI Energy Advisor', icon: Zap },
  { to: '/predictive-maintenance', label: 'Predictive Maintenance', icon: Wrench },
  { to: '/ai-dashboard', label: 'AI Dashboard', icon: Sparkles },
  { to: '/app-landing', label: 'KYNETIK App', icon: Smartphone },
  { to: '/cloud', label: 'Cloud Marketing', icon: Cloud },
  { to: '/products', label: 'Product System', icon: Package },
  { to: '/configurator', label: 'Product Configurator', icon: Sparkles },
  { to: '/product-system', label: 'Product Family', icon: Package },
  { to: '/design-system', label: 'System Overview', icon: LayoutGrid },
  { to: '/cloud-console', label: 'Cloud Console UX', icon: Cloud },
  { to: '/brand', label: 'Brand Foundation', icon: Palette },
  { to: '/tokens', label: 'UI Tokens', icon: Sparkles },
  { to: '/catalog', label: 'Products Catalog', icon: Package },
  { to: '/social', label: 'Social Media Kit', icon: Share2 },
  { to: '/app', label: 'Mobile App UX', icon: Smartphone },
  { to: '/website', label: 'Website UX', icon: Globe },
  { to: '/academy', label: 'Academy Platform', icon: GraduationCap },
  { to: '/investor', label: 'Investor Deck', icon: Presentation },
  { to: '/stationery', label: 'Stationery', icon: Briefcase },
];

export default function Layout() {
  const [open, setOpen] = useState(false);

  return (
    <div className="min-h-screen bg-kyn-black flex">
      <aside className="hidden lg:flex w-72 flex-col border-r border-white/5 bg-kyn-void sticky top-0 h-screen">
        <div className="p-6 border-b border-white/5">
          <BrandLogo height={34} />
          <p className="mt-3 text-xs text-kyn-metal tracking-wide uppercase">
            UI/UX Design System
          </p>
        </div>
        <nav className="flex-1 overflow-y-auto p-4 space-y-1">
          {nav.map(({ to, label, icon: Icon }) => (
            <NavLink
              key={to}
              to={to}
              end={to === '/' || to === '/design-system'}
              className={({ isActive }) =>
                cn(
                  'flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-all',
                  isActive
                    ? 'bg-kyn-green/10 text-kyn-green border border-kyn-green/20'
                    : 'text-kyn-silver hover:bg-white/5 hover:text-white'
                )
              }
            >
              <Icon size={16} />
              {label}
            </NavLink>
          ))}
        </nav>
        <div className="p-4 border-t border-white/5">
          <div className="glass-card rounded-xl p-4">
            <div className="flex items-center gap-2 text-kyn-green text-xs font-medium mb-1">
              <Zap size={12} /> App · Web · Cloud
            </div>
            <p className="text-[11px] text-kyn-metal leading-relaxed">
              Complete KYNETIK digital ecosystem design system.
            </p>
          </div>
        </div>
      </aside>

      <div className="lg:hidden fixed top-0 inset-x-0 z-50 bg-kyn-void/95 backdrop-blur border-b border-white/5">
        <div className="flex items-center justify-between px-4 h-14">
          <BrandLogo height={26} />
          <button
            onClick={() => setOpen(!open)}
            className="p-2 text-kyn-silver hover:text-white"
            aria-label="Menu"
          >
            {open ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
        {open && (
          <nav className="px-3 pb-4 space-y-1 max-h-[70vh] overflow-y-auto">
            {nav.map(({ to, label, icon: Icon }) => (
              <NavLink
                key={to}
                to={to}
                end={to === '/' || to === '/design-system'}
                onClick={() => setOpen(false)}
                className={({ isActive }) =>
                  cn(
                    'flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm',
                    isActive ? 'bg-kyn-green/10 text-kyn-green' : 'text-kyn-silver'
                  )
                }
              >
                <Icon size={16} />
                {label}
              </NavLink>
            ))}
          </nav>
        )}
      </div>

      <main className="flex-1 min-w-0 pt-14 lg:pt-0">
        <Outlet />
      </main>
    </div>
  );
}

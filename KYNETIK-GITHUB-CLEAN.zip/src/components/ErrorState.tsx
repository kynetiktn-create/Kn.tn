export default function ErrorState({ message }: { message: string }) {
  return (
    <div className="glass-card rounded-xl p-6 border border-red-500/20 text-center">
      <p className="text-red-400 text-sm font-medium">Unable to load data</p>
      <p className="text-kyn-metal text-xs mt-2">{message}</p>
    </div>
  );
}

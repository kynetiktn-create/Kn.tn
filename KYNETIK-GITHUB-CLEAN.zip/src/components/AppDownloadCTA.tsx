import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Smartphone, Zap, MapPin, Wallet, BarChart3, Star } from 'lucide-react';
import { cn } from '../lib/utils';

function AppleIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="currentColor" aria-hidden>
      <path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.8-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.37 2.83M13 3.5c.73-.83 1.94-1.46 2.94-1.5.13 1.17-.34 2.35-1.04 3.19-.69.85-1.83 1.51-2.95 1.42-.15-1.15.41-2.35 1.05-3.11z" />
    </svg>
  );
}

function PlayIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="currentColor" aria-hidden>
      <path d="M3.609 1.814L13.792 12 3.61 22.186a.996.996 0 0 1-.61-.92V2.734a1 1 0 0 1 .609-.92zm10.89 10.893l2.302 2.302-10.937 6.333 8.635-8.635zm3.199-3.198l2.807 1.626a1 1 0 0 1 0 1.73l-2.808 1.626L15.206 12l2.492-2.491zM5.864 2.658L16.802 8.99l-2.303 2.303-8.635-8.635z" />
    </svg>
  );
}

interface Props {
  className?: string;
  id?: string;
  compact?: boolean;
  accent?: string;
  /** Centered single-column layout (no phone mock) */
  centered?: boolean;
}

const features = [
  { icon: Zap, label: 'Start & stop charge' },
  { icon: MapPin, label: 'Find stations' },
  { icon: Wallet, label: 'Wallet & billing' },
  { icon: BarChart3, label: 'Energy insights' },
];

export default function AppDownloadCTA({
  className,
  id = 'download-app',
  compact = false,
  accent = '#00e676',
  centered = false,
}: Props) {
  const storeButtons = (
    <div className={cn('flex flex-wrap gap-3', centered && 'justify-center')}>
      <a
        href="https://apps.apple.com"
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Download on the App Store"
        className="group inline-flex items-center gap-3 rounded-2xl bg-white text-kyn-black pl-4 pr-6 py-3.5 min-w-[180px] hover:bg-kyn-green transition-all shadow-xl shadow-black/40 hover:scale-[1.02]"
      >
        <AppleIcon className="w-8 h-8 shrink-0" />
        <span className="text-left leading-tight">
          <span className="block text-[10px] uppercase tracking-wider text-kyn-graphite group-hover:text-kyn-black/70">
            Download on the
          </span>
          <span className="block text-base font-bold tracking-tight">App Store</span>
        </span>
      </a>

      <a
        href="https://play.google.com/store"
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Get it on Google Play"
        className="group inline-flex items-center gap-3 rounded-2xl border border-white/20 bg-black/60 text-white pl-4 pr-6 py-3.5 min-w-[180px] hover:border-kyn-green/60 hover:bg-kyn-green/10 transition-all hover:scale-[1.02]"
      >
        <PlayIcon className="w-8 h-8 shrink-0 text-kyn-green" />
        <span className="text-left leading-tight">
          <span className="block text-[10px] uppercase tracking-wider text-kyn-metal">Get it on</span>
          <span className="block text-base font-bold tracking-tight">Google Play</span>
        </span>
      </a>
    </div>
  );

  if (centered) {
    return (
      <section id={id} className={cn('relative overflow-hidden border-y border-white/5', className)}>
        <div className="absolute inset-0 bg-kyn-void" />
        <div
          className="absolute inset-0"
          style={{
            background: `radial-gradient(ellipse 60% 70% at 50% 50%, ${accent}20, transparent 60%)`,
          }}
        />
        <div className="absolute inset-0 grid-bg opacity-25" />

        <div className={cn('relative z-10 max-w-3xl mx-auto px-5 md:px-8 text-center', compact ? 'py-16' : 'py-20 md:py-28')}>
          <motion.div
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.55 }}
          >
            <div
              className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border text-[11px] font-semibold mb-6"
              style={{ color: accent, borderColor: `${accent}55`, background: `${accent}14` }}
            >
              <Smartphone size={13} />
              KYNETIK Mobile
            </div>

            <h2 className="font-display text-3xl sm:text-4xl md:text-5xl font-bold leading-[1.08] tracking-tight">
              Ready to Take Control?
            </h2>
            <p className="mt-4 text-lg md:text-xl text-white font-medium">Download the KYNETIK App</p>
            <p className="mt-4 text-sm md:text-base text-kyn-silver max-w-lg mx-auto leading-relaxed">
              Pilot your charger, locate stations, manage payments and track energy — the full ecosystem in your pocket.
            </p>

            <div className="mt-9">{storeButtons}</div>

            <div className="mt-8 flex flex-wrap justify-center gap-4 text-[11px] text-kyn-metal">
              <span className="inline-flex items-center gap-1.5">
                <Star size={12} style={{ color: accent }} /> iOS & Android
              </span>
              <span className="inline-flex items-center gap-1.5">
                <Zap size={12} style={{ color: accent }} /> Cloud-synced
              </span>
              <span className="inline-flex items-center gap-1.5">
                <MapPin size={12} style={{ color: accent }} /> Tunisia network
              </span>
            </div>
          </motion.div>
        </div>
      </section>
    );
  }

  return (
    <section id={id} className={cn('relative overflow-hidden border-y border-white/5', className)}>
      <div className="absolute inset-0 bg-kyn-void" />
      <div
        className="absolute inset-0 opacity-90"
        style={{
          background: `radial-gradient(ellipse 70% 80% at 80% 50%, ${accent}22, transparent 55%), radial-gradient(ellipse 50% 60% at 15% 80%, rgba(0,230,118,0.08), transparent 50%)`,
        }}
      />
      <div className="absolute inset-0 grid-bg opacity-30" />

      <div className={cn('relative z-10 max-w-7xl mx-auto px-5 md:px-8', compact ? 'py-16 md:py-20' : 'py-20 md:py-28')}>
        <div className="grid lg:grid-cols-[1.15fr_0.85fr] gap-12 lg:gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-40px' }}
            transition={{ duration: 0.55 }}
          >
            <div
              className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border text-[11px] font-semibold mb-6"
              style={{ color: accent, borderColor: `${accent}55`, background: `${accent}14` }}
            >
              <Smartphone size={13} />
              KYNETIK Mobile
            </div>

            <h2 className="font-display text-3xl sm:text-4xl md:text-5xl font-bold leading-[1.08] tracking-tight">
              Ready to Take Control?
            </h2>
            <p className="mt-4 text-lg md:text-xl text-white/95 font-medium">Download the KYNETIK App</p>
            <p className="mt-4 text-sm md:text-base text-kyn-silver max-w-xl leading-relaxed">
              Pilot your charger, locate stations, manage payments and track energy — the full KYNETIK ecosystem in your
              pocket.
            </p>

            <div className="mt-8">{storeButtons}</div>

            <div className="mt-8 grid grid-cols-2 sm:grid-cols-4 gap-2.5 max-w-xl">
              {features.map(({ icon: Icon, label }) => (
                <div
                  key={label}
                  className="rounded-xl border border-white/8 bg-black/30 px-3 py-2.5 flex items-center gap-2"
                >
                  <Icon size={14} style={{ color: accent }} className="shrink-0" />
                  <span className="text-[11px] text-kyn-silver font-medium leading-snug">{label}</span>
                </div>
              ))}
            </div>

            <div className="mt-8">
              <Link
                to="/app-landing"
                className="inline-flex items-center gap-2 text-sm font-semibold transition-all hover:gap-3"
                style={{ color: accent }}
              >
                Explore the app experience →
              </Link>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.96, y: 16 }}
            whileInView={{ opacity: 1, scale: 1, y: 0 }}
            viewport={{ once: true, margin: '-40px' }}
            transition={{ duration: 0.6, delay: 0.08 }}
            className="relative flex justify-center lg:justify-end"
          >
            <div
              className="absolute w-56 h-56 md:w-72 md:h-72 rounded-full blur-[80px]"
              style={{ background: `${accent}33` }}
            />
            <div className="phone-frame relative w-[220px] sm:w-[250px] h-[450px] sm:h-[510px] rounded-[2.4rem] p-2.5">
              <div className="w-full h-full rounded-[1.9rem] bg-kyn-black overflow-hidden relative border border-white/5">
                <div className="absolute top-0 left-1/2 -translate-x-1/2 w-24 h-5 bg-black rounded-b-2xl z-20" />
                <div className="absolute inset-0 grid-bg opacity-40" />
                <div
                  className="absolute inset-0"
                  style={{
                    background: `radial-gradient(circle at 50% 35%, ${accent}28, transparent 55%)`,
                  }}
                />

                <div className="relative z-10 h-full flex flex-col px-5 pt-12 pb-6">
                  <p className="text-[10px] text-kyn-metal tracking-[0.2em] uppercase">KYNETIK</p>
                  <p className="font-display font-bold text-lg mt-1">Take control</p>
                  <p className="text-[11px] text-kyn-silver mt-1">L&apos;énergie en mouvement</p>

                  <div
                    className="mt-8 mx-auto w-36 h-36 rounded-full flex items-center justify-center"
                    style={{
                      background: `conic-gradient(from 210deg, ${accent} 0%, ${accent} 72%, #2a2a30 72%)`,
                      padding: 5,
                    }}
                  >
                    <div className="w-full h-full rounded-full bg-kyn-void flex flex-col items-center justify-center border border-white/5">
                      <span className="font-display text-3xl font-bold" style={{ color: accent }}>
                        72%
                      </span>
                      <span className="text-[9px] text-kyn-metal mt-0.5">Charging</span>
                    </div>
                  </div>

                  <div className="mt-8 grid grid-cols-2 gap-2">
                    {[
                      { l: 'Power', v: '11.2 kW' },
                      { l: 'Left', v: '28 min' },
                    ].map((x) => (
                      <div key={x.l} className="rounded-xl bg-white/[0.04] border border-white/8 p-2.5">
                        <p className="text-[8px] text-kyn-metal uppercase tracking-wider">{x.l}</p>
                        <p className="text-xs font-semibold mt-0.5">{x.v}</p>
                      </div>
                    ))}
                  </div>

                  <div
                    className="mt-auto rounded-xl py-2.5 text-center text-[11px] font-bold text-kyn-black"
                    style={{ background: accent }}
                  >
                    Open session
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

import Logo from './Logo';

export default function LoadingState({ label = 'Loading design system…' }: { label?: string }) {
  return (
    <div className="flex flex-col items-center justify-center min-h-[50vh] gap-4">
      <Logo size="lg" glowing showWordmark={false} />
      <div className="h-1 w-32 rounded-full bg-kyn-graphite overflow-hidden">
        <div className="h-full w-1/2 bg-kyn-green animate-pulse rounded-full" />
      </div>
      <p className="text-sm text-kyn-metal">{label}</p>
    </div>
  );
}

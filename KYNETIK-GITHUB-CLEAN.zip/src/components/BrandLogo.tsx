import { cn } from '../lib/utils';

interface Props {
  variant?: 'white' | 'dark';
  className?: string;
  height?: number;
  showTagline?: boolean;
  markOnly?: boolean;
  glow?: boolean;
}

/** Cache-bust for new green bolt lockup */
const V = 'bolt1';

/**
 * Official KYNETIK logo
 * Green bolt mark + KYNETIK wordmark
 * white → dark UI · dark → light UI
 */
export default function BrandLogo({
  variant = 'white',
  className,
  height = 36,
  showTagline = false,
  markOnly = false,
  glow = false,
}: Props) {
  const src = markOnly
    ? `/images/kynetik-mark-white.png?v=${V}`
    : glow
      ? variant === 'white'
        ? `/images/kynetik-logo-white-glow.png?v=${V}`
        : `/images/kynetik-logo-dark-glow.png?v=${V}`
      : variant === 'white'
        ? `/images/kynetik-logo-white.png?v=${V}`
        : `/images/kynetik-logo-dark.png?v=${V}`;

  return (
    <div className={cn('inline-flex flex-col items-start', className)}>
      <img
        src={src}
        alt="KYNETIK"
        style={{ height, width: 'auto' }}
        className="object-contain object-left select-none"
        draggable={false}
      />
      {showTagline && (
        <span
          className={cn(
            'mt-1.5 text-[9px] font-medium uppercase tracking-[0.22em]',
            variant === 'white' ? 'text-kyn-metal' : 'text-neutral-500'
          )}
        >
          L&apos;énergie en mouvement
        </span>
      )}
    </div>
  );
}

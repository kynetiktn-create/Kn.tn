import { Home, Plug, Map, BarChart3, User } from 'lucide-react';
import { cn } from '../lib/utils';

const tabs = [
  { id: 'home', label: 'Home', icon: Home },
  { id: 'chargers', label: 'Bornes', icon: Plug },
  { id: 'map', label: 'Map', icon: Map },
  { id: 'analytics', label: 'Energy', icon: BarChart3 },
  { id: 'profile', label: 'Profil', icon: User },
] as const;

export type AppTab = (typeof tabs)[number]['id'];

export default function AppBottomNav({
  active,
  onChange,
}: {
  active: string;
  onChange?: (id: AppTab) => void;
}) {
  return (
    <div className="mt-auto border-t border-white/8 bg-kyn-void/95 backdrop-blur px-1 py-2 flex justify-around">
      {tabs.map(({ id, label, icon: Icon }) => {
        const isActive = active === id;
        return (
          <button
            key={id}
            type="button"
            onClick={() => onChange?.(id)}
            className={cn(
              'flex flex-col items-center gap-0.5 min-w-[48px] py-1 rounded-lg transition-colors',
              isActive ? 'text-kyn-green' : 'text-kyn-metal'
            )}
          >
            <Icon size={16} strokeWidth={isActive ? 2.4 : 1.8} />
            <span className="text-[8px] font-medium">{label}</span>
          </button>
        );
      })}
    </div>
  );
}

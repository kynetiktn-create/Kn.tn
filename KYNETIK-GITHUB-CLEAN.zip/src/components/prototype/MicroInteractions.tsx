import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Check, Loader2, AlertCircle, Zap, Heart } from 'lucide-react';
import { cn } from '../../lib/utils';

export default function MicroInteractions() {
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState(false);
  const [liked, setLiked] = useState(false);
  const [progress, setProgress] = useState(0);
  const [toast, setToast] = useState('');

  const runLoad = () => {
    setLoading(true);
    setSuccess(false);
    setError(false);
    setProgress(0);
    const t = setInterval(() => {
      setProgress((p) => {
        if (p >= 100) {
          clearInterval(t);
          setLoading(false);
          setSuccess(true);
          setToast('Charge démarrée avec succès');
          setTimeout(() => setToast(''), 2500);
          return 100;
        }
        return p + 8;
      });
    }, 80);
  };

  const runError = () => {
    setError(true);
    setSuccess(false);
    setToast('Connexion borne impossible');
    setTimeout(() => {
      setError(false);
      setToast('');
    }, 2500);
  };

  return (
    <div className="space-y-8">
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="glass-card rounded-2xl p-5">
          <p className="text-[10px] uppercase tracking-wider text-kyn-metal mb-3">Primary CTA</p>
          <button
            type="button"
            onClick={runLoad}
            disabled={loading}
            className="w-full rounded-2xl bg-kyn-green text-kyn-black text-sm font-bold py-3 glow-green hover:scale-[1.02] active:scale-[0.98] transition-transform disabled:opacity-70 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-kyn-green"
          >
            {loading ? (
              <span className="inline-flex items-center gap-2 justify-center">
                <Loader2 size={16} className="animate-spin" /> Chargement…
              </span>
            ) : success ? (
              <span className="inline-flex items-center gap-2 justify-center">
                <Check size={16} /> Succès
              </span>
            ) : (
              'Démarrer la charge'
            )}
          </button>
          {loading && (
            <div className="mt-3 h-1.5 rounded-full bg-white/10 overflow-hidden">
              <motion.div className="h-full bg-kyn-green" animate={{ width: `${progress}%` }} />
            </div>
          )}
        </div>

        <div className="glass-card rounded-2xl p-5">
          <p className="text-[10px] uppercase tracking-wider text-kyn-metal mb-3">Error state</p>
          <button
            type="button"
            onClick={runError}
            className="w-full rounded-2xl border border-red-500/40 text-red-400 text-sm font-semibold py-3 hover:bg-red-500/10 transition-colors focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-red-400"
          >
            Simuler une erreur
          </button>
          {error && (
            <p className="mt-3 text-xs text-red-400 flex items-center gap-1.5">
              <AlertCircle size={12} /> Échec réseau OCPP
            </p>
          )}
        </div>

        <div className="glass-card rounded-2xl p-5 group hover:border-kyn-green/30 transition-all hover:-translate-y-1 cursor-default">
          <p className="text-[10px] uppercase tracking-wider text-kyn-metal mb-3">Card hover</p>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-kyn-green/10 border border-kyn-green/20 flex items-center justify-center text-kyn-green group-hover:glow-green transition-shadow">
              <Zap size={18} />
            </div>
            <div>
              <p className="font-semibold text-sm">NOVA 22kW</p>
              <p className="text-[11px] text-kyn-metal group-hover:text-kyn-silver transition-colors">Hover me</p>
            </div>
          </div>
        </div>

        <div className="glass-card rounded-2xl p-5">
          <p className="text-[10px] uppercase tracking-wider text-kyn-metal mb-3">Toggle / like</p>
          <button
            type="button"
            onClick={() => setLiked(!liked)}
            className={cn(
              'w-full rounded-2xl border py-3 text-sm font-semibold flex items-center justify-center gap-2 transition-all focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-kyn-green',
              liked ? 'border-kyn-green/40 bg-kyn-green/10 text-kyn-green' : 'border-white/15 text-kyn-silver'
            )}
            aria-pressed={liked}
          >
            <Heart size={16} className={liked ? 'fill-kyn-green' : ''} />
            {liked ? 'Favori' : 'Ajouter favori'}
          </button>
        </div>
      </div>

      {/* Skeleton */}
      <div>
        <p className="text-xs text-kyn-metal uppercase tracking-wider mb-3">Skeleton loading</p>
        <div className="grid sm:grid-cols-3 gap-3">
          {[1, 2, 3].map((i) => (
            <div key={i} className="rounded-2xl border border-white/8 p-4 space-y-3">
              <div className="h-24 rounded-xl bg-white/5 animate-pulse" />
              <div className="h-3 w-2/3 rounded bg-white/5 animate-pulse" />
              <div className="h-3 w-1/2 rounded bg-white/5 animate-pulse" />
            </div>
          ))}
        </div>
      </div>

      <AnimatePresence>
        {toast && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 10 }}
            className={cn(
              'fixed bottom-8 left-1/2 -translate-x-1/2 z-[100] px-5 py-3 rounded-full text-sm font-semibold shadow-2xl',
              toast.includes('impossible') ? 'bg-red-500 text-white' : 'bg-kyn-green text-kyn-black'
            )}
            role="status"
          >
            {toast}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

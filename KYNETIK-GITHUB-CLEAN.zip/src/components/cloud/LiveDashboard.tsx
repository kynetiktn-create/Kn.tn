import { Activity, Zap, Server, Radio } from 'lucide-react';
import { cn } from '../../lib/utils';

interface Metric {
  label: string;
  value: string;
  delta: string;
}

export default function LiveDashboard({ metrics = [] as Metric[] }) {
  const cards = metrics.length
    ? metrics.slice(0, 4)
    : [
        { label: 'Bornes online', value: '118', delta: '+6' },
        { label: 'Sessions 24h', value: '1 284', delta: '+12%' },
        { label: 'Uptime', value: '99.4%', delta: 'SLA OK' },
        { label: 'kWh today', value: '8.2k', delta: '+4.1%' },
      ];

  const bars = [32, 48, 40, 62, 55, 70, 68, 82, 75, 90, 78, 88, 72, 85, 95, 80, 70, 78, 86, 92, 84, 76, 68, 60];

  return (
    <div className="rounded-2xl border border-white/10 bg-gradient-to-b from-[#12141a] to-[#08090c] overflow-hidden shadow-2xl shadow-kyn-green/5">
      {/* Title bar */}
      <div className="flex items-center justify-between px-4 md:px-5 py-3 border-b border-white/5 bg-white/[0.02]">
        <div className="flex items-center gap-3">
          <div className="flex gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-red-500/80" />
            <span className="w-2.5 h-2.5 rounded-full bg-yellow-500/80" />
            <span className="w-2.5 h-2.5 rounded-full bg-green-500/80" />
          </div>
          <span className="text-[11px] text-kyn-silver font-medium tracking-wide">KYNETIK Cloud · Operations</span>
        </div>
        <span className="flex items-center gap-1.5 text-[10px] text-kyn-green font-semibold">
          <span className="w-1.5 h-1.5 rounded-full bg-kyn-green animate-pulse" /> LIVE
        </span>
      </div>

      <div className="p-4 md:p-5">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-2.5 mb-4">
          {cards.map((m) => (
            <div key={m.label} className="rounded-xl border border-white/8 bg-white/[0.03] p-3 backdrop-blur">
              <p className="text-[9px] uppercase tracking-wider text-kyn-metal">{m.label}</p>
              <p className="font-display text-xl md:text-2xl font-bold mt-1 text-white">{m.value}</p>
              <p className="text-[10px] text-kyn-green mt-0.5">{m.delta}</p>
            </div>
          ))}
        </div>

        <div className="grid lg:grid-cols-3 gap-3">
          <div className="lg:col-span-2 rounded-xl border border-white/8 bg-black/40 p-4">
            <div className="flex items-center justify-between mb-3">
              <p className="text-xs font-semibold text-kyn-silver">Energy throughput · 24h</p>
              <Activity size={13} className="text-kyn-green" />
            </div>
            <div className="h-28 md:h-36 flex items-end gap-1">
              {bars.map((h, i) => (
                <div
                  key={i}
                  className="flex-1 rounded-t-sm bg-gradient-to-t from-kyn-green/25 via-kyn-green/70 to-kyn-green"
                  style={{ height: `${h}%`, opacity: 0.55 + (i / bars.length) * 0.45 }}
                />
              ))}
            </div>
          </div>

          <div className="rounded-xl border border-white/8 bg-black/40 p-4 space-y-3">
            <p className="text-xs font-semibold text-kyn-silver mb-1">Network health</p>
            {[
              { icon: Server, l: 'API Gateway', s: 'Operational' },
              { icon: Radio, l: 'OCPP Broker', s: 'Operational' },
              { icon: Zap, l: 'Smart Load', s: 'Balancing' },
            ].map(({ icon: Icon, l, s }) => (
              <div key={l} className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-[11px] text-kyn-silver">
                  <Icon size={12} className="text-kyn-green" /> {l}
                </div>
                <span className={cn('text-[10px]', s === 'Balancing' ? 'text-amber-300' : 'text-kyn-green')}>{s}</span>
              </div>
            ))}
            <div className="pt-2 border-t border-white/5">
              <div className="flex justify-between text-[10px] text-kyn-metal mb-1">
                <span>Grid capacity</span>
                <span className="text-kyn-green">72%</span>
              </div>
              <div className="h-1.5 rounded-full bg-white/10 overflow-hidden">
                <div className="h-full w-[72%] rounded-full bg-gradient-to-r from-kyn-green-dim to-kyn-green" />
              </div>
            </div>
          </div>
        </div>

        <div className="mt-3 rounded-xl border border-white/8 bg-black/30 overflow-hidden">
          <div className="grid grid-cols-5 text-[9px] text-kyn-metal uppercase tracking-wider px-3 py-2 border-b border-white/5">
            <span>Station</span><span>Type</span><span>Status</span><span>Power</span><span>Load</span>
          </div>
          {[
            ['Hub Lac 2', 'PRIME 120', 'Charging', '94 kW', '78%'],
            ['NOVA Marsa', 'NOVA 22', 'Online', '11 kW', '45%'],
            ['Depot Sfax', 'PRO 180', 'Online', '142 kW', '61%'],
          ].map((row) => (
            <div key={row[0]} className="grid grid-cols-5 text-[10px] md:text-[11px] px-3 py-2 border-b border-white/[0.03] text-kyn-silver">
              <span className="font-medium text-white truncate">{row[0]}</span>
              <span className="truncate">{row[1]}</span>
              <span className="text-kyn-green">{row[2]}</span>
              <span>{row[3]}</span>
              <span>{row[4]}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

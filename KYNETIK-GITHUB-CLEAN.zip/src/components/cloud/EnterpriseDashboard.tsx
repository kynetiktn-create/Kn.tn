import { motion } from 'framer-motion';
import { Activity, Zap, Server, Radio, TrendingUp, AlertTriangle, MapPin } from 'lucide-react';
import { cn } from '../../lib/utils';

interface Metric {
  label: string;
  value: string;
  delta: string;
}

export default function EnterpriseDashboard({
  metrics = [] as Metric[],
  compact = false,
}: {
  metrics?: Metric[];
  compact?: boolean;
}) {
  const cards = metrics.length >= 4
    ? metrics.slice(0, 4)
    : [
        { label: 'Chargers online', value: '118', delta: '+6' },
        { label: 'Sessions 24h', value: '1,284', delta: '+12%' },
        { label: 'Uptime', value: '99.95%', delta: 'SLA' },
        { label: 'Energy today', value: '8.2 MWh', delta: '+4.1%' },
      ];

  const bars = [28, 42, 38, 55, 48, 62, 70, 58, 75, 68, 82, 90, 78, 85, 95, 80, 72, 78, 88, 92, 84, 76, 65, 58];
  const spark = [40, 48, 45, 52, 60, 58, 70, 68, 75, 82, 78, 88];
  const pins = [
    { t: '18%', l: '22%', ok: true },
    { t: '42%', l: '58%', ok: true },
    { t: '55%', l: '35%', ok: false },
    { t: '28%', l: '70%', ok: true },
    { t: '68%', l: '48%', ok: true },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className={cn(
        'rounded-2xl border border-white/10 bg-gradient-to-b from-[#141820] via-[#0c0e14] to-[#07080b] overflow-hidden',
        'shadow-[0_30px_100px_rgba(0,0,0,0.65),0_0_0_1px_rgba(0,230,118,0.08),0_0_80px_rgba(0,230,118,0.08)]'
      )}
    >
      {/* Title bar */}
      <div className="flex items-center justify-between px-4 md:px-5 py-3 border-b border-white/5 bg-white/[0.025]">
        <div className="flex items-center gap-3 min-w-0">
          <div className="flex gap-1.5 shrink-0">
            <span className="w-2.5 h-2.5 rounded-full bg-red-500/80" />
            <span className="w-2.5 h-2.5 rounded-full bg-yellow-500/80" />
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500/80" />
          </div>
          <span className="text-[11px] text-zinc-400 font-medium tracking-wide truncate font-[inherit]">
            KYNETIK Cloud · Network Operations
          </span>
        </div>
        <span className="flex items-center gap-1.5 text-[10px] text-[#00e676] font-semibold shrink-0">
          <span className="relative flex h-1.5 w-1.5">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#00e676] opacity-60" />
            <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-[#00e676]" />
          </span>
          LIVE
        </span>
      </div>

      <div className={cn('p-3 md:p-5', compact && 'p-3')}>
        {/* KPI row */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-2 md:gap-2.5 mb-3 md:mb-4">
          {cards.map((m, i) => (
            <motion.div
              key={m.label}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.08 * i }}
              className="rounded-xl border border-white/8 bg-white/[0.035] p-2.5 md:p-3 backdrop-blur-sm"
            >
              <p className="text-[8px] md:text-[9px] uppercase tracking-wider text-zinc-500">{m.label}</p>
              <p className="font-display text-lg md:text-2xl font-bold mt-0.5 text-white tracking-tight">{m.value}</p>
              <p className="text-[9px] md:text-[10px] text-[#00e676] mt-0.5 flex items-center gap-1">
                <TrendingUp size={10} /> {m.delta}
              </p>
            </motion.div>
          ))}
        </div>

        <div className="grid lg:grid-cols-3 gap-2.5 md:gap-3">
          {/* Energy chart */}
          <div className="lg:col-span-2 rounded-xl border border-white/8 bg-black/45 p-3 md:p-4 relative overflow-hidden">
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,rgba(0,230,118,0.08),transparent_55%)]" />
            <div className="relative flex items-center justify-between mb-3">
              <p className="text-[11px] md:text-xs font-semibold text-zinc-300">Energy throughput · 24h</p>
              <Activity size={13} className="text-[#00e676]" />
            </div>
            <div className="relative h-24 md:h-36 flex items-end gap-0.5 md:gap-1">
              {bars.map((h, i) => (
                <motion.div
                  key={i}
                  initial={{ height: 0 }}
                  animate={{ height: `${h}%` }}
                  transition={{ duration: 0.8, delay: 0.02 * i, ease: [0.22, 1, 0.36, 1] }}
                  className="flex-1 rounded-t-sm bg-gradient-to-t from-[#00e676]/15 via-[#00e676]/65 to-[#6effb0]"
                  style={{ opacity: 0.55 + (i / bars.length) * 0.45 }}
                />
              ))}
            </div>
            <div className="relative mt-2 flex justify-between text-[8px] text-zinc-600">
              <span>00:00</span><span>06:00</span><span>12:00</span><span>18:00</span><span>24:00</span>
            </div>
          </div>

          {/* Health + mini map */}
          <div className="space-y-2.5 md:space-y-3">
            <div className="rounded-xl border border-white/8 bg-black/45 p-3 md:p-4 space-y-2.5">
              <p className="text-[11px] md:text-xs font-semibold text-zinc-300">System health</p>
              {[
                { icon: Server, l: 'API Gateway', s: 'Operational', ok: true },
                { icon: Radio, l: 'OCPP Broker', s: 'Operational', ok: true },
                { icon: Zap, l: 'Smart Load', s: 'Balancing', ok: false },
              ].map(({ icon: Icon, l, s, ok }) => (
                <div key={l} className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-[10px] md:text-[11px] text-zinc-400">
                    <Icon size={12} className="text-[#00e676]" /> {l}
                  </div>
                  <span className={cn('text-[9px] md:text-[10px]', ok ? 'text-[#00e676]' : 'text-amber-300')}>{s}</span>
                </div>
              ))}
              <div className="pt-2 border-t border-white/5">
                <div className="flex justify-between text-[9px] text-zinc-500 mb-1">
                  <span>Grid capacity</span>
                  <span className="text-[#00e676]">72%</span>
                </div>
                <div className="h-1.5 rounded-full bg-white/10 overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: '72%' }}
                    transition={{ duration: 1.1, delay: 0.3 }}
                    className="h-full rounded-full bg-gradient-to-r from-[#00a844] to-[#00e676]"
                  />
                </div>
              </div>
              <div className="flex items-end gap-0.5 h-8 pt-1">
                {spark.map((h, i) => (
                  <div key={i} className="flex-1 rounded-sm bg-[#00e676]/45" style={{ height: `${h}%` }} />
                ))}
              </div>
            </div>

            {!compact && (
              <div className="rounded-xl border border-white/8 bg-black/45 p-3 relative overflow-hidden h-[110px] hidden lg:block">
                <div className="flex items-center justify-between mb-2 relative z-10">
                  <p className="text-[10px] font-semibold text-zinc-300 flex items-center gap-1">
                    <MapPin size={11} className="text-[#00e676]" /> Station map
                  </p>
                  <span className="text-[9px] text-zinc-500">Tunis corridor</span>
                </div>
                <div
                  className="absolute inset-0 opacity-50"
                  style={{
                    backgroundImage:
                      'linear-gradient(rgba(0,230,118,0.07) 1px, transparent 1px), linear-gradient(90deg, rgba(0,230,118,0.07) 1px, transparent 1px)',
                    backgroundSize: '18px 18px',
                  }}
                />
                {pins.map((pin, i) => (
                  <motion.div
                    key={i}
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ delay: 0.4 + i * 0.08 }}
                    className="absolute z-10"
                    style={{ top: pin.t, left: pin.l }}
                  >
                    <div
                      className={cn(
                        'w-5 h-5 rounded-full border flex items-center justify-center',
                        pin.ok
                          ? 'border-[#00e676] bg-[#00e676]/20 text-[#00e676]'
                          : 'border-amber-400 bg-amber-400/15 text-amber-300'
                      )}
                    >
                      <Zap size={9} />
                    </div>
                  </motion.div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Stations table */}
        <div className="mt-2.5 md:mt-3 rounded-xl border border-white/8 bg-black/30 overflow-hidden hidden sm:block">
          <div className="grid grid-cols-6 text-[8px] md:text-[9px] text-zinc-500 uppercase tracking-wider px-3 py-2 border-b border-white/5">
            <span className="col-span-2">Station</span>
            <span>Type</span>
            <span>Status</span>
            <span>Power</span>
            <span>Load</span>
          </div>
          {[
            ['Hub Lac 2', 'PRIME 22', 'Charging', '18 kW', '78%', true],
            ['NOVA Marsa', 'NOVA 22', 'Online', '11 kW', '45%', true],
            ['GO Fleet-03', 'GO CEE', 'Online', '7 kW', '52%', true],
            ['Hotel Palm', 'PRIME 22', 'Alert', '0 kW', '0%', false],
          ].map((row, i) => (
            <motion.div
              key={String(row[0])}
              initial={{ opacity: 0, x: -6 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.5 + i * 0.06 }}
              className="grid grid-cols-6 text-[10px] md:text-[11px] px-3 py-2 border-b border-white/[0.03] text-zinc-400 hover:bg-white/[0.02]"
            >
              <span className="col-span-2 font-medium text-white truncate">{row[0]}</span>
              <span className="truncate">{row[1]}</span>
              <span className={row[5] ? 'text-[#00e676]' : 'text-amber-300 flex items-center gap-1'}>
                {!row[5] && <AlertTriangle size={10} />} {row[2]}
              </span>
              <span>{row[3]}</span>
              <span>{row[4]}</span>
            </motion.div>
          ))}
        </div>
      </div>
    </motion.div>
  );
}

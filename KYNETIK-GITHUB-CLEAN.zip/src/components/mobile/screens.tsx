import {
  Battery, Zap, Wifi, ChevronRight, Navigation, Play, Pause, Settings,
  Share2, MapPin, CreditCard, FileText, Car, Bell, HelpCircle, LogOut,
  Leaf, Wallet, ArrowUpRight, Filter, Check
} from 'lucide-react';
import Logo from '../Logo';
import AppBottomNav, { type AppTab } from '../AppBottomNav';
import { cn } from '../../lib/utils';

function StatusBar() {
  return (
    <div className="flex justify-between items-center px-5 pt-3 pb-1 text-[9px] text-kyn-metal relative z-20">
      <span>09:41</span>
      <div className="flex gap-1 items-center">
        <Wifi size={10} />
        <Battery size={10} />
      </div>
    </div>
  );
}

export function SplashScreen() {
  return (
    <div className="h-full flex flex-col items-center justify-center relative grid-bg">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(0,230,118,0.18),transparent_55%)]" />
      <div className="relative">
        <Logo size="lg" glowing showWordmark={false} />
        <div className="absolute inset-x-0 top-1/2 h-0.5 overflow-hidden">
          <div className="h-full w-full bg-gradient-to-r from-transparent via-kyn-green to-transparent animate-pulse" />
        </div>
      </div>
      <p className="mt-7 font-display font-bold tracking-[0.35em] text-sm relative">KYNETIK</p>
      <p className="mt-2 text-[10px] text-kyn-metal tracking-wide relative">L'énergie en mouvement</p>
      <div className="absolute bottom-16 w-28 h-0.5 bg-kyn-graphite rounded overflow-hidden">
        <div className="h-full w-2/3 bg-kyn-green animate-pulse rounded-full" />
      </div>
    </div>
  );
}

export function OnboardingScreen({ page = 1 }: { page?: number }) {
  const pages = [
    { img: '/images/charger-wall.jpg', title: 'Rechargez votre véhicule simplement', body: 'Installez NOVA et pilotez chaque session depuis votre téléphone.' },
    { img: '/images/tech-abstract.jpg', title: 'Contrôlez votre énergie partout', body: 'KYNETIK Cloud supervise puissance, coûts et disponibilité en temps réel.' },
    { img: '/images/hero-city.jpg', title: "L'avenir de la mobilité électrique", body: 'Un écosystème premium pensé pour la Tunisie et prêt pour le monde.' },
  ];
  const p = pages[Math.min(page, pages.length) - 1];
  return (
    <div className="h-full flex flex-col bg-kyn-black relative">
      <img src={p.img} alt="" className="absolute inset-0 w-full h-full object-cover opacity-35" />
      <div className="absolute inset-0 bg-gradient-to-t from-kyn-black via-kyn-black/70 to-kyn-black/30" />
      <StatusBar />
      <div className="relative z-10 flex-1 flex flex-col justify-end p-6 pb-8">
        <div className="flex gap-1.5 mb-5">
          {pages.map((_, i) => (
            <div key={i} className={cn('h-1 rounded-full transition-all', i === page - 1 ? 'w-6 bg-kyn-green' : 'w-1.5 bg-white/25')} />
          ))}
        </div>
        <h2 className="font-display text-xl font-bold leading-snug">{p.title}</h2>
        <p className="mt-2 text-[11px] text-kyn-silver leading-relaxed">{p.body}</p>
        {page === 3 ? (
          <button type="button" className="mt-6 w-full rounded-2xl bg-kyn-green text-kyn-black text-xs font-bold py-3.5 glow-green">
            Commencer
          </button>
        ) : (
          <button type="button" className="mt-6 w-full rounded-2xl border border-white/15 text-xs font-semibold py-3.5">
            Continuer
          </button>
        )}
      </div>
    </div>
  );
}

export function AuthScreen() {
  return (
    <div className="h-full flex flex-col relative">
      <img src="/images/charger-closeup.jpg" alt="" className="absolute inset-0 w-full h-full object-cover opacity-20" />
      <div className="absolute inset-0 bg-gradient-to-b from-kyn-black/85 via-kyn-black/95 to-kyn-black" />
      <StatusBar />
      <div className="relative z-10 px-5 pt-6 flex-1 flex flex-col">
        <Logo size="sm" glowing />
        <h2 className="mt-8 font-display text-xl font-bold">Bienvenue chez KYNETIK</h2>
        <p className="text-[11px] text-kyn-metal mt-1">Connectez-vous pour piloter votre énergie</p>
        <div className="mt-7 space-y-3">
          <div className="rounded-2xl bg-kyn-steel/70 border border-white/8 px-3.5 py-3 text-[11px] text-kyn-metal">Email</div>
          <div className="rounded-2xl bg-kyn-steel/70 border border-white/8 px-3.5 py-3 text-[11px] text-kyn-metal">Mot de passe</div>
          <p className="text-right text-[10px] text-kyn-green">Mot de passe oublié ?</p>
          <button type="button" className="w-full rounded-2xl bg-kyn-green text-kyn-black text-xs font-bold py-3.5">Connexion</button>
          <button type="button" className="w-full rounded-2xl border border-white/12 text-xs font-semibold py-3.5">Créer un compte</button>
        </div>
        <div className="mt-6 flex items-center gap-3">
          <div className="flex-1 h-px bg-white/10" />
          <span className="text-[9px] text-kyn-metal">ou</span>
          <div className="flex-1 h-px bg-white/10" />
        </div>
        <div className="mt-4 grid grid-cols-2 gap-2">
          <button type="button" className="rounded-xl bg-white/5 border border-white/10 py-2.5 text-[10px] font-medium">Google</button>
          <button type="button" className="rounded-xl bg-white/5 border border-white/10 py-2.5 text-[10px] font-medium">Apple</button>
        </div>
      </div>
    </div>
  );
}

export function DashboardScreen({ onNav }: { onNav?: (t: AppTab) => void }) {
  return (
    <div className="h-full flex flex-col bg-kyn-void">
      <StatusBar />
      <div className="px-5 pt-2 flex-1 overflow-hidden">
        <p className="text-[11px] text-kyn-metal">Bonjour Khalifa 👋</p>
        <h2 className="font-display font-bold text-lg mt-0.5">Tableau de bord</h2>

        <div className="mt-4 rounded-2xl border border-kyn-green/30 bg-gradient-to-br from-kyn-steel to-kyn-black p-4 glow-green">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-[9px] text-kyn-metal uppercase tracking-wider">Votre borne</p>
              <p className="font-display font-bold mt-1 text-sm">KYNETIK NOVA 22kW</p>
            </div>
            <span className="flex items-center gap-1 text-[9px] text-kyn-green bg-kyn-green/10 px-2 py-1 rounded-full">
              <span className="w-1.5 h-1.5 rounded-full bg-kyn-green animate-pulse-glow" /> En ligne
            </span>
          </div>
          <div className="mt-4 grid grid-cols-3 gap-2">
            {[
              { l: 'Puissance', v: '11.2 kW' },
              { l: 'Temps', v: '42 min' },
              { l: 'Énergie', v: '18.4 kWh' },
            ].map((x) => (
              <div key={x.l} className="rounded-xl bg-black/45 p-2">
                <p className="text-[8px] text-kyn-metal">{x.l}</p>
                <p className="text-[11px] font-semibold mt-0.5">{x.v}</p>
              </div>
            ))}
          </div>
        </div>

        <p className="mt-5 text-[10px] text-kyn-metal uppercase tracking-wider">Actions rapides</p>
        <div className="mt-2 grid grid-cols-3 gap-2">
          {[
            { icon: Play, l: 'Démarrer' },
            { icon: Pause, l: 'Pause' },
            { icon: Settings, l: 'Config' },
          ].map(({ icon: Icon, l }) => (
            <button key={l} type="button" className="rounded-2xl bg-kyn-steel/60 border border-white/8 py-3 flex flex-col items-center gap-1.5">
              <Icon size={14} className="text-kyn-green" />
              <span className="text-[9px] font-medium">{l}</span>
            </button>
          ))}
        </div>

        <div className="mt-4 space-y-2">
          {['Session en cours', 'Historique du mois'].map((item) => (
            <div key={item} className="flex items-center justify-between rounded-xl bg-kyn-steel/40 border border-white/5 px-3 py-2.5">
              <span className="text-[11px]">{item}</span>
              <ChevronRight size={12} className="text-kyn-metal" />
            </div>
          ))}
        </div>
      </div>
      <AppBottomNav active="home" onChange={onNav} />
    </div>
  );
}

export function ChargingScreen() {
  return (
    <div className="h-full flex flex-col bg-kyn-black">
      <StatusBar />
      <div className="px-5 pt-2 flex-1 flex flex-col items-center">
        <p className="text-[10px] text-kyn-metal uppercase tracking-widest">Session active</p>
        <p className="text-xs text-kyn-silver mt-1">NOVA Home · Garage</p>

        <div className="relative mt-8 w-44 h-44">
          <div className="absolute inset-0 rounded-full opacity-90" style={{
            background: 'conic-gradient(from 220deg, #00e676 0%, #00e676 75%, #2a2a30 75%, #2a2a30 100%)',
            padding: 5,
          }}>
            <div className="w-full h-full rounded-full bg-kyn-black" />
          </div>
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <span className="font-display text-4xl font-bold text-kyn-green text-glow">75%</span>
            <span className="text-[10px] text-kyn-metal mt-1">Recharge en cours</span>
          </div>
          <div className="absolute inset-[-8px] rounded-full border border-kyn-green/15 animate-pulse-glow" />
        </div>

        <div className="mt-8 w-full grid grid-cols-2 gap-2">
          {[
            { l: 'Voltage', v: '230 V' },
            { l: 'Current', v: '48 A' },
            { l: 'Power', v: '11.2 kW' },
            { l: 'Restant', v: '28 min' },
          ].map((x) => (
            <div key={x.l} className="rounded-2xl bg-kyn-steel/50 border border-white/6 p-3">
              <p className="text-[9px] text-kyn-metal">{x.l}</p>
              <p className="font-semibold text-sm mt-0.5">{x.v}</p>
            </div>
          ))}
        </div>

        <div className="mt-6 w-full flex items-center justify-between text-[9px] text-kyn-metal px-1">
          <div className="flex flex-col items-center gap-1"><Wifi size={14} className="text-kyn-green" />Grid</div>
          <div className="flex-1 h-px mx-2 bg-gradient-to-r from-kyn-green/20 via-kyn-green to-kyn-green/20" />
          <div className="flex flex-col items-center gap-1"><Zap size={14} className="text-kyn-green" />Charger</div>
          <div className="flex-1 h-px mx-2 bg-gradient-to-r from-kyn-green/20 via-kyn-green to-kyn-green/20" />
          <div className="flex flex-col items-center gap-1"><Battery size={14} className="text-kyn-green" />Vehicle</div>
        </div>

        <button type="button" className="mt-auto mb-6 w-full rounded-2xl border border-red-500/40 text-red-400 text-xs font-semibold py-3">
          Arrêter la charge
        </button>
      </div>
    </div>
  );
}

export function StationScreen({ onNav }: { onNav?: (t: AppTab) => void }) {
  const stations = [
    { name: 'NOVA Home', addr: 'La Marsa, Tunis', status: 'En ligne', last: 'Il y a 12 min', online: true },
    { name: 'NOVA Bureau', addr: 'Lac 2, Tunis', status: 'En charge', last: 'Maintenant', online: true },
    { name: 'GO Flotte 01', addr: 'Sfax Depot', status: 'Hors ligne', last: 'Hier 18:20', online: false },
  ];
  return (
    <div className="h-full flex flex-col bg-kyn-void">
      <StatusBar />
      <div className="px-5 pt-2 flex-1 overflow-hidden">
        <h2 className="font-display font-bold text-lg">Mes bornes</h2>
        <p className="text-[11px] text-kyn-metal mt-0.5">Station management</p>
        <div className="mt-4 space-y-3">
          {stations.map((s) => (
            <div key={s.name} className="rounded-2xl border border-white/8 bg-kyn-steel/40 p-3.5">
              <div className="flex justify-between items-start">
                <div>
                  <p className="font-semibold text-sm">{s.name}</p>
                  <p className="text-[10px] text-kyn-metal mt-0.5 flex items-center gap-1"><MapPin size={10} />{s.addr}</p>
                </div>
                <span className={cn('text-[9px] px-2 py-1 rounded-full', s.online ? 'text-kyn-green bg-kyn-green/10' : 'text-kyn-metal bg-white/5')}>
                  {s.status}
                </span>
              </div>
              <p className="text-[9px] text-kyn-metal mt-2">Dernière utilisation · {s.last}</p>
              <div className="mt-3 flex gap-2">
                <button type="button" className="flex-1 rounded-xl bg-kyn-green/10 border border-kyn-green/25 text-kyn-green text-[10px] font-semibold py-2 flex items-center justify-center gap-1">
                  <Settings size={11} /> Configurer
                </button>
                <button type="button" className="flex-1 rounded-xl bg-white/5 border border-white/10 text-[10px] font-semibold py-2 flex items-center justify-center gap-1">
                  <Share2 size={11} /> Partager
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
      <AppBottomNav active="chargers" onChange={onNav} />
    </div>
  );
}

export function MapScreen({ onNav }: { onNav?: (t: AppTab) => void }) {
  return (
    <div className="h-full flex flex-col bg-[#0d1110] relative">
      <div className="absolute inset-0 opacity-40" style={{
        backgroundImage: `linear-gradient(rgba(0,230,118,0.08) 1px, transparent 1px), linear-gradient(90deg, rgba(0,230,118,0.08) 1px, transparent 1px)`,
        backgroundSize: '28px 28px',
      }} />
      {[
        { t: '22%', l: '28%', ok: true },
        { t: '40%', l: '58%', ok: true },
        { t: '58%', l: '38%', ok: false },
        { t: '33%', l: '72%', ok: true },
        { t: '70%', l: '50%', ok: true },
      ].map((pin, i) => (
        <div key={i} className="absolute z-10" style={{ top: pin.t, left: pin.l }}>
          <div className={cn('w-7 h-7 rounded-full flex items-center justify-center border-2', pin.ok ? 'bg-kyn-green/20 border-kyn-green text-kyn-green' : 'bg-kyn-graphite border-kyn-metal text-kyn-metal')}>
            <Zap size={12} />
          </div>
        </div>
      ))}
      <div className="relative z-20">
        <StatusBar />
        <div className="px-4 pt-1">
          <div className="rounded-2xl bg-kyn-void/90 border border-white/10 px-3 py-2.5 flex items-center gap-2">
            <Navigation size={12} className="text-kyn-green" />
            <span className="text-[11px] text-kyn-metal flex-1">Stations près de Tunis…</span>
            <Filter size={12} className="text-kyn-metal" />
          </div>
          <div className="mt-2 flex gap-1.5 overflow-hidden">
            {['AC', 'DC Fast', 'Disponible'].map((f, i) => (
              <span key={f} className={cn('px-2.5 py-1 rounded-full text-[9px] font-semibold border', i === 2 ? 'bg-kyn-green text-kyn-black border-kyn-green' : 'bg-kyn-void/80 border-white/10 text-kyn-silver')}>
                {f}
              </span>
            ))}
          </div>
        </div>
      </div>
      <div className="mt-auto relative z-20 p-3 pb-0">
        <div className="rounded-2xl bg-kyn-void border border-white/10 p-4 mb-2">
          <div className="flex justify-between">
            <div>
              <p className="font-semibold text-sm">KYNETIK Hub Lac 2</p>
              <p className="text-[10px] text-kyn-metal mt-0.5">1.2 km · DC 120 kW · 4/6 libres</p>
            </div>
            <span className="text-kyn-green text-xs font-bold">0.45 DT</span>
          </div>
          <button type="button" className="mt-3 w-full rounded-xl bg-kyn-green text-kyn-black text-xs font-bold py-2.5">Itinéraire</button>
        </div>
      </div>
      <div className="relative z-20">
        <AppBottomNav active="map" onChange={onNav} />
      </div>
    </div>
  );
}

export function AnalyticsScreen({ onNav }: { onNav?: (t: AppTab) => void }) {
  const bars = [40, 65, 45, 80, 55, 90, 70];
  return (
    <div className="h-full flex flex-col bg-kyn-void">
      <StatusBar />
      <div className="px-5 pt-2 flex-1 overflow-hidden">
        <h2 className="font-display font-bold text-lg">Energy Analytics</h2>
        <p className="text-[11px] text-kyn-metal">Consommation mensuelle</p>

        <div className="mt-4 grid grid-cols-3 gap-2">
          {[
            { l: 'Ce mois', v: '124 kWh', icon: Zap },
            { l: 'Coût', v: '56.8 DT', icon: Wallet },
            { l: 'CO₂ sauvé', v: '−32 kg', icon: Leaf },
          ].map(({ l, v, icon: Icon }) => (
            <div key={l} className="rounded-2xl border border-white/8 bg-kyn-steel/40 p-2.5">
              <Icon size={12} className="text-kyn-green mb-1" />
              <p className="text-[8px] text-kyn-metal">{l}</p>
              <p className="text-[11px] font-bold mt-0.5">{v}</p>
            </div>
          ))}
        </div>

        <div className="mt-5 rounded-2xl border border-white/8 bg-kyn-steel/30 p-4">
          <div className="flex justify-between items-center mb-4">
            <p className="text-[10px] font-semibold">kWh · 7 jours</p>
            <ArrowUpRight size={12} className="text-kyn-green" />
          </div>
          <div className="flex items-end gap-1.5 h-24">
            {bars.map((h, i) => (
              <div key={i} className="flex-1 rounded-t-md bg-gradient-to-t from-kyn-green/40 to-kyn-green" style={{ height: `${h}%` }} />
            ))}
          </div>
          <div className="mt-2 flex justify-between text-[8px] text-kyn-metal">
            {['L', 'M', 'M', 'J', 'V', 'S', 'D'].map((d) => <span key={d}>{d}</span>)}
          </div>
        </div>

        <div className="mt-4 space-y-2">
          {[
            { l: 'Sessions', v: '18' },
            { l: 'Moyenne / charge', v: '6.9 kWh' },
            { l: 'Pic puissance', v: '21.4 kW' },
          ].map((r) => (
            <div key={r.l} className="flex justify-between rounded-xl bg-kyn-steel/30 border border-white/5 px-3 py-2.5 text-[11px]">
              <span className="text-kyn-metal">{r.l}</span>
              <span className="font-semibold">{r.v}</span>
            </div>
          ))}
        </div>
      </div>
      <AppBottomNav active="analytics" onChange={onNav} />
    </div>
  );
}

export function PaymentsScreen() {
  return (
    <div className="h-full flex flex-col bg-kyn-void">
      <StatusBar />
      <div className="px-5 pt-2 flex-1">
        <h2 className="font-display font-bold text-lg">Paiements</h2>
        <p className="text-[11px] text-kyn-metal">Wallet & facturation</p>

        <div className="mt-4 rounded-2xl bg-gradient-to-br from-kyn-green/20 via-kyn-steel to-kyn-black border border-kyn-green/25 p-4">
          <p className="text-[9px] text-kyn-metal uppercase tracking-wider">KYNETIK Wallet</p>
          <p className="font-display text-3xl font-bold mt-2">84.50 <span className="text-base text-kyn-metal">DT</span></p>
          <div className="mt-4 flex gap-2">
            <button type="button" className="flex-1 rounded-xl bg-kyn-green text-kyn-black text-[10px] font-bold py-2">Recharger</button>
            <button type="button" className="flex-1 rounded-xl bg-white/10 text-[10px] font-semibold py-2">Historique</button>
          </div>
        </div>

        <p className="mt-5 text-[10px] text-kyn-metal uppercase tracking-wider">Transactions</p>
        <div className="mt-2 space-y-2">
          {[
            { t: 'Hub Lac 2 · DC', a: '−12.40 DT', d: 'Aujourd\'hui' },
            { t: 'NOVA Home', a: '−4.20 DT', d: 'Hier' },
            { t: 'Top-up Wallet', a: '+50.00 DT', d: '12 Mar' },
          ].map((tx) => (
            <div key={tx.t + tx.d} className="flex items-center justify-between rounded-xl bg-kyn-steel/40 border border-white/5 px-3 py-2.5">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-kyn-green/10 flex items-center justify-center">
                  <CreditCard size={13} className="text-kyn-green" />
                </div>
                <div>
                  <p className="text-[11px] font-medium">{tx.t}</p>
                  <p className="text-[9px] text-kyn-metal">{tx.d}</p>
                </div>
              </div>
              <span className={cn('text-[11px] font-semibold', tx.a.startsWith('+') ? 'text-kyn-green' : 'text-white')}>{tx.a}</span>
            </div>
          ))}
        </div>

        <button type="button" className="mt-4 w-full rounded-xl border border-white/10 py-2.5 text-[11px] font-medium flex items-center justify-center gap-2">
          <FileText size={12} className="text-kyn-green" /> Voir les factures
        </button>
      </div>
    </div>
  );
}

export function ProfileScreen({ onNav }: { onNav?: (t: AppTab) => void }) {
  const rows = [
    { icon: UserIcon, l: 'Données personnelles' },
    { icon: Car, l: 'Mes véhicules' },
    { icon: CreditCard, l: 'Abonnements' },
    { icon: Bell, l: 'Notifications' },
    { icon: HelpCircle, l: 'Support' },
  ];
  return (
    <div className="h-full flex flex-col bg-kyn-void">
      <StatusBar />
      <div className="px-5 pt-2 flex-1">
        <div className="flex items-center gap-3">
          <div className="w-14 h-14 rounded-2xl bg-kyn-green/15 border border-kyn-green/30 flex items-center justify-center font-display font-bold text-kyn-green text-lg">KB</div>
          <div>
            <p className="font-display font-bold">Khalifa Ben Ali</p>
            <p className="text-[11px] text-kyn-metal">khalifa@kynetik.tn</p>
            <span className="inline-flex mt-1 text-[9px] text-kyn-green bg-kyn-green/10 px-2 py-0.5 rounded-full">Premium · Pro</span>
          </div>
        </div>

        <div className="mt-6 space-y-1.5">
          {rows.map(({ icon: Icon, l }) => (
            <div key={l} className="flex items-center justify-between rounded-xl bg-kyn-steel/30 border border-white/5 px-3 py-3">
              <div className="flex items-center gap-2.5">
                <Icon size={14} className="text-kyn-green" />
                <span className="text-[11px] font-medium">{l}</span>
              </div>
              <ChevronRight size={12} className="text-kyn-metal" />
            </div>
          ))}
        </div>

        <button type="button" className="mt-6 w-full rounded-xl border border-red-500/30 text-red-400 text-[11px] font-semibold py-3 flex items-center justify-center gap-2">
          <LogOut size={12} /> Déconnexion
        </button>
      </div>
      <AppBottomNav active="profile" onChange={onNav} />
    </div>
  );
}

function UserIcon(props: { size?: number; className?: string }) {
  return (
    <svg width={props.size || 14} height={props.size || 14} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className={props.className}>
      <path d="M20 21a8 8 0 0 0-16 0" />
      <circle cx="12" cy="7" r="4" />
    </svg>
  );
}

export function DesignTokensMini() {
  return (
    <div className="h-full flex flex-col bg-kyn-black p-5 pt-10">
      <p className="text-[10px] text-kyn-green tracking-widest uppercase font-semibold">UI Tokens</p>
      <h3 className="font-display font-bold text-lg mt-1">Mobile kit</h3>
      <div className="mt-5 grid grid-cols-4 gap-2">
        {['#050505', '#1E1E1E', '#00E676', '#FFFFFF'].map((c) => (
          <div key={c}>
            <div className="aspect-square rounded-xl border border-white/10" style={{ background: c }} />
            <p className="text-[7px] text-kyn-metal mt-1 font-mono">{c}</p>
          </div>
        ))}
      </div>
      <div className="mt-5 space-y-2">
        <button type="button" className="w-full rounded-2xl bg-kyn-green text-kyn-black text-xs font-bold py-3 glow-green">Primary CTA</button>
        <button type="button" className="w-full rounded-2xl border border-white/15 text-xs font-semibold py-3">Secondary</button>
        <div className="rounded-2xl glass-card p-3 text-[10px] text-kyn-silver">Glass card · radius 16px</div>
      </div>
      <div className="mt-auto flex items-center gap-2 text-[9px] text-kyn-metal">
        <Check size={10} className="text-kyn-green" /> Montserrat display · Inter body
      </div>
    </div>
  );
}

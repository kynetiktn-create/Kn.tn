import type { ReactNode } from 'react';
import { cn } from '../../lib/utils';

export function StatusBar({ light = false }: { light?: boolean }) {
  return (
    <div
      className={cn(
        'flex justify-between items-center px-5 pt-3 pb-1 text-[10px] font-medium relative z-30',
        light ? 'text-white/80' : 'text-kyn-metal'
      )}
    >
      <span>09:41</span>
      <div className="flex gap-1.5 items-center text-[9px]">
        <span>●●●</span>
        <span>5G</span>
        <span className="px-1 py-0.5 rounded bg-white/10 text-[8px]">87%</span>
      </div>
    </div>
  );
}

export function PhoneShell({
  children,
  className,
  glow = 'green',
}: {
  children: ReactNode;
  className?: string;
  glow?: 'green' | 'blue';
}) {
  return (
    <div className={cn('relative mx-auto', className)}>
      <div
        className={cn(
          'absolute -inset-10 rounded-full blur-3xl opacity-40',
          glow === 'blue' ? 'bg-kyn-blue/25' : 'bg-kyn-green/20'
        )}
      />
      <div className="relative w-[300px] sm:w-[320px] h-[620px] sm:h-[660px] rounded-[2.9rem] p-[3px] bg-gradient-to-b from-white/25 via-white/10 to-white/5 shadow-2xl shadow-black/60">
        <div className="w-full h-full rounded-[2.75rem] bg-black p-[7px] overflow-hidden">
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-28 h-6 bg-black rounded-b-2xl z-40" />
          <div className="w-full h-full rounded-[2.25rem] overflow-hidden bg-kyn-black relative text-white">
            {children}
          </div>
        </div>
      </div>
    </div>
  );
}

export function BottomNav({
  active,
  onChange,
}: {
  active: string;
  onChange: (id: string) => void;
}) {
  const tabs = [
    { id: 'home', label: 'Home', icon: '⌂' },
    { id: 'charge', label: 'Charge', icon: '⚡' },
    { id: 'map', label: 'Map', icon: '⌖' },
    { id: 'analytics', label: 'Analytics', icon: '◉' },
    { id: 'profile', label: 'Profile', icon: '☺' },
  ];
  return (
    <div className="mt-auto border-t border-white/8 bg-kyn-void/95 backdrop-blur-xl px-1 py-2 flex justify-around shrink-0">
      {tabs.map((t) => {
        const on = active === t.id;
        return (
          <button
            key={t.id}
            type="button"
            onClick={() => onChange(t.id)}
            className={cn(
              'flex flex-col items-center gap-0.5 min-w-[52px] py-1 rounded-lg transition-colors',
              on ? 'text-kyn-green' : 'text-kyn-metal'
            )}
          >
            <span className="text-sm leading-none">{t.icon}</span>
            <span className="text-[8px] font-semibold tracking-wide">{t.label}</span>
          </button>
        );
      })}
    </div>
  );
}

import { useEffect, useMemo, useState, type ReactNode } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  ArrowRight, Battery, Bell, Car, Check, ChevronRight, CreditCard, Filter,
  Leaf, Lock, LogOut, MapPin, Navigation, Pause, Play, Settings, Share2,
  Smartphone, Wallet, Wifi, WifiOff, Zap, Clock, Gauge, Building2, Hotel,
  ParkingCircle, Briefcase, Apple, Mail, Phone, Eye, EyeOff, Plus, Wrench,
  Download, UserPlus, RotateCcw, Power
} from 'lucide-react';
import BrandLogo from '../BrandLogo';
import { apiGet, cn } from '../../lib/utils';
import { StatusBar, BottomNav } from './PhoneChrome';

type Screen =
  | 'splash'
  | 'onboarding'
  | 'auth'
  | 'home'
  | 'charge'
  | 'map'
  | 'analytics'
  | 'profile'
  | 'history'
  | 'devices'
  | 'wallet'
  | 'notifications'
  | 'settings';

interface Charger {
  id: number;
  name: string;
  model: string;
  serial_number: string;
  status: string;
  online: boolean;
  firmware: string;
  last_activity: string;
  location: string;
  image_url: string;
  power_kw: number;
  energy_month_kwh: number;
}

interface Session {
  id: number;
  started_at: string;
  duration_min: number;
  energy_kwh: number;
  cost_dt: number;
  location: string;
  charger_name: string;
  status: string;
  vehicle: string;
}

interface Notif {
  id: number;
  title: string;
  body: string;
  type: string;
  read: boolean;
  created_at: string;
}

interface Station {
  id: number;
  name: string;
  city: string;
  address?: string;
  status: string;
  model?: string;
  power_kw?: number;
  lat?: number;
  lng?: number;
}

function Btn({
  children,
  onClick,
  variant = 'primary',
  className,
  disabled,
}: {
  children: ReactNode;
  onClick?: () => void;
  variant?: 'primary' | 'ghost' | 'soft' | 'danger';
  className?: string;
  disabled?: boolean;
}) {
  const styles = {
    primary: 'bg-kyn-green text-kyn-black font-bold',
    ghost: 'border border-white/15 text-white font-semibold',
    soft: 'bg-white/8 border border-white/10 text-white font-semibold',
    danger: 'bg-red-500/15 border border-red-500/30 text-red-300 font-semibold',
  }[variant];
  return (
    <button
      type="button"
      disabled={disabled}
      onClick={onClick}
      className={cn(
        'w-full rounded-2xl py-3 text-[12px] transition-all active:scale-[0.98] disabled:opacity-40',
        styles,
        className
      )}
    >
      {children}
    </button>
  );
}

function Field({
  label,
  children,
}: {
  label: string;
  children: ReactNode;
}) {
  return (
    <label className="block">
      <span className="text-[10px] uppercase tracking-wider text-kyn-metal font-medium">{label}</span>
      <div className="mt-1.5">{children}</div>
    </label>
  );
}

const inputCls =
  'w-full rounded-xl bg-white/5 border border-white/10 px-3 py-2.5 text-[12px] text-white placeholder:text-kyn-metal focus:outline-none focus:border-kyn-green/40';

export default function KynetikAppFlow({
  embedded = false,
  onScreenChange,
}: {
  embedded?: boolean;
  onScreenChange?: (s: string) => void;
}) {
  const [screen, setScreen] = useState<Screen>('splash');
  const [onboardStep, setOnboardStep] = useState(0);
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');
  const [clientType, setClientType] = useState<'particulier' | 'pro'>('particulier');
  const [proKind, setProKind] = useState('Entreprise');
  const [showPass, setShowPass] = useState(false);
  const [name] = useState('Khalifa');
  const [charging, setCharging] = useState(true);
  const [powerKw, setPowerKw] = useState(11.4);
  const [battery, setBattery] = useState(67);
  const [remainMin, setRemainMin] = useState(35);
  const [period, setPeriod] = useState<'day' | 'week' | 'month'>('day');
  const [mapFilter, setMapFilter] = useState('all');
  const [chargers, setChargers] = useState<Charger[]>([]);
  const [sessions, setSessions] = useState<Session[]>([]);
  const [notifs, setNotifs] = useState<Notif[]>([]);
  const [stations, setStations] = useState<Station[]>([]);
  const [toast, setToast] = useState('');
  const [vehicle, setVehicle] = useState({ model: 'Tesla Model 3', battery: '60 kWh', range: '420 km' });

  const go = (s: Screen) => {
    setScreen(s);
    onScreenChange?.(s);
  };

  useEffect(() => {
    if (screen !== 'splash') return;
    const t = setTimeout(() => go('onboarding'), 2200);
    return () => clearTimeout(t);
  }, [screen]);

  useEffect(() => {
    Promise.all([
      apiGet<Charger[]>('/api/portal-chargers').catch(() => []),
      apiGet<Session[]>('/api/portal-sessions').catch(() => []),
      apiGet<Notif[]>('/api/portal-notifications').catch(() => []),
      apiGet<Station[]>('/api/charge-points').catch(() => []),
    ]).then(([c, s, n, st]) => {
      setChargers(c || []);
      setSessions(s || []);
      setNotifs(n || []);
      setStations(st || []);
    });
  }, []);

  useEffect(() => {
    if (!charging) return;
    const t = setInterval(() => {
      setBattery((b) => Math.min(100, b + 0.15));
      setRemainMin((m) => Math.max(0, m - 0.2));
      setPowerKw(10.8 + Math.random() * 1.2);
    }, 1800);
    return () => clearInterval(t);
  }, [charging]);

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(''), 2000);
  };

  const mainCharger = chargers[0] || {
    id: 1,
    name: 'KYNETIK PRIME',
    model: 'PRIME 22 kW',
    serial_number: 'KYN-PR-24-001',
    status: charging ? 'charging' : 'available',
    online: true,
    firmware: 'v1.0.3',
    last_activity: "À l'instant",
    location: 'Home',
    image_url: '/images/products/prime-tethered.png',
    power_kw: powerKw,
    energy_month_kwh: 186,
  };

  const energyStats = useMemo(() => {
    const list = sessions.length
      ? sessions
      : [
          { energy_kwh: 12.2, cost_dt: 3.66 },
          { energy_kwh: 8.1, cost_dt: 2.43 },
          { energy_kwh: 4.2, cost_dt: 1.26 },
        ];
    const kwh = list.reduce((a, s) => a + Number(s.energy_kwh || 0), 0);
    const cost = list.reduce((a, s) => a + Number(s.cost_dt || 0), 0);
    const mult = period === 'day' ? 0.35 : period === 'week' ? 0.7 : 1;
    return {
      kwh: (kwh * mult || 24.5).toFixed(1),
      cost: (cost * mult || 7.35).toFixed(3),
      co2: ((kwh * mult || 24.5) * 0.5).toFixed(1),
      bars:
        period === 'day'
          ? [4, 8, 6, 12, 9, 14, 11, 7, 10, 13, 8, 5]
          : period === 'week'
            ? [22, 28, 19, 31, 26, 34, 29]
            : [80, 92, 75, 110, 98, 120, 105, 88, 95, 112, 100, 118],
    };
  }, [sessions, period]);

  const filteredStations = useMemo(() => {
    let list = stations.length
      ? stations
      : [
          { id: 1, name: 'Hub Lac 2 · A1', city: 'Tunis', status: 'available', power_kw: 22, model: 'PRIME' },
          { id: 2, name: 'Marsa Centre', city: 'La Marsa', status: 'charging', power_kw: 11, model: 'NOVA' },
          { id: 3, name: 'Sfax Depot', city: 'Sfax', status: 'available', power_kw: 44, model: 'PRO' },
        ];
    if (mapFilter === '7') list = list.filter((s) => Number(s.power_kw || 11) <= 11);
    if (mapFilter === '22') list = list.filter((s) => Number(s.power_kw || 22) >= 11 && Number(s.power_kw || 22) <= 22);
    if (mapFilter === 'fast') list = list.filter((s) => Number(s.power_kw || 0) >= 22 || /pro|fast/i.test(s.model || s.name));
    return list.slice(0, 8);
  }, [stations, mapFilter]);

  const unread = notifs.filter((n) => !n.read).length;

  const shell = (body: ReactNode, tab?: string) => (
    <div className="h-full flex flex-col bg-kyn-black relative overflow-hidden">
      {body}
      {tab && (
        <BottomNav
          active={tab}
          onChange={(id) => {
            if (id === 'home') go('home');
            if (id === 'charge') go('charge');
            if (id === 'map') go('map');
            if (id === 'analytics') go('analytics');
            if (id === 'profile') go('profile');
          }}
        />
      )}
      <AnimatePresence>
        {toast && (
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className="absolute bottom-20 left-4 right-4 z-50 rounded-xl bg-kyn-green text-kyn-black text-[11px] font-bold text-center py-2.5 shadow-lg"
          >
            {toast}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );

  /* ——— SPLASH ——— */
  if (screen === 'splash') {
    return shell(
      <div className="flex-1 flex flex-col items-center justify-center relative">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(0,230,118,0.2),transparent_55%)]" />
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.6 }}
          className="relative"
        >
          <BrandLogo height={36} markOnly />
          <motion.div
            className="absolute -inset-8 rounded-full border border-kyn-green/30"
            animate={{ scale: [1, 1.25, 1], opacity: [0.5, 0.15, 0.5] }}
            transition={{ duration: 2, repeat: Infinity }}
          />
        </motion.div>
        <motion.div
          className="mt-6 flex items-center gap-2 text-kyn-green"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4 }}
        >
          <Zap size={14} />
          <span className="text-[10px]">→</span>
          <span className="text-[10px] px-2 py-0.5 rounded border border-kyn-green/30">Charger</span>
          <span className="text-[10px]">→</span>
          <Car size={14} />
        </motion.div>
        <p className="mt-6 font-display font-bold tracking-[0.35em] text-sm relative">KYNETIK</p>
        <p className="mt-2 text-[11px] text-kyn-metal relative">L&apos;énergie en mouvement</p>
        <div className="absolute bottom-16 w-32 h-0.5 bg-white/10 rounded overflow-hidden">
          <motion.div
            className="h-full bg-kyn-green rounded"
            initial={{ width: '0%' }}
            animate={{ width: '100%' }}
            transition={{ duration: 2 }}
          />
        </div>
      </div>
    );
  }

  /* ——— ONBOARDING ——— */
  if (screen === 'onboarding') {
    const pages = [
      {
        title: 'Bienvenue chez KYNETIK',
        body: 'Votre solution intelligente de recharge électrique',
        img: '/images/hero-city.jpg',
        visual: (
          <div className="relative h-44 flex items-end justify-center gap-3">
            <img src="/images/products/prime-tethered.png" alt="" className="h-36 object-contain drop-shadow-2xl" />
            <img src="/images/products/nova-tethered.png" alt="" className="h-28 object-contain opacity-80" />
          </div>
        ),
      },
      {
        title: 'Connectez votre véhicule',
        body: 'Ajoutez votre voiture, capacité batterie et autonomie pour des sessions optimisées.',
        img: '/images/tech-abstract.jpg',
        visual: (
          <div className="space-y-2 px-1">
            {[
              ['Modèle', vehicle.model],
              ['Batterie', vehicle.battery],
              ['Autonomie', vehicle.range],
            ].map(([k, v]) => (
              <div key={k} className="rounded-xl border border-white/10 bg-black/40 px-3 py-2.5 flex justify-between text-[11px]">
                <span className="text-kyn-metal">{k}</span>
                <span className="font-semibold">{v}</span>
              </div>
            ))}
            <button
              type="button"
              onClick={() => setVehicle({ model: 'MG4 Electric', battery: '64 kWh', range: '450 km' })}
              className="w-full text-[10px] text-kyn-green font-semibold py-2"
            >
              + Ajouter véhicule
            </button>
          </div>
        ),
      },
      {
        title: 'Contrôlez votre recharge',
        body: 'Suivi temps réel, programmation intelligente et historique de consommation.',
        img: '/images/charger-closeup.jpg',
        visual: (
          <div className="grid grid-cols-3 gap-2">
            {[
              { t: 'Live', d: '11.4 kW' },
              { t: 'Schedule', d: '22:00' },
              { t: 'History', d: '186 kWh' },
            ].map((x) => (
              <div key={x.t} className="rounded-xl border border-kyn-green/25 bg-kyn-green/10 p-3 text-center">
                <p className="text-[9px] text-kyn-metal">{x.t}</p>
                <p className="text-[11px] font-bold text-kyn-green mt-1">{x.d}</p>
              </div>
            ))}
          </div>
        ),
      },
    ];
    const p = pages[onboardStep];
    return shell(
      <>
        <div className="absolute inset-0">
          <img src={p.img} alt="" className="w-full h-full object-cover opacity-30" />
          <div className="absolute inset-0 bg-gradient-to-t from-kyn-black via-kyn-black/80 to-kyn-black/40" />
        </div>
        <StatusBar />
        <div className="relative z-10 flex-1 flex flex-col px-5 pb-6 pt-2">
          <div className="flex justify-between items-center mb-4">
            <BrandLogo height={22} />
            <button type="button" className="text-[10px] text-kyn-metal" onClick={() => go('auth')}>
              Passer
            </button>
          </div>
          <div className="flex-1 flex flex-col justify-center">{p.visual}</div>
          <div className="flex gap-1.5 mb-4">
            {pages.map((_, i) => (
              <div
                key={i}
                className={cn('h-1 rounded-full transition-all', i === onboardStep ? 'w-6 bg-kyn-green' : 'w-1.5 bg-white/25')}
              />
            ))}
          </div>
          <h2 className="font-display text-xl font-bold leading-snug">{p.title}</h2>
          <p className="mt-2 text-[11px] text-kyn-silver leading-relaxed">{p.body}</p>
          <div className="mt-5">
            {onboardStep < 2 ? (
              <Btn onClick={() => setOnboardStep((s) => s + 1)}>Continuer</Btn>
            ) : (
              <Btn onClick={() => go('auth')}>Commencer</Btn>
            )}
          </div>
        </div>
      </>
    );
  }

  /* ——— AUTH ——— */
  if (screen === 'auth') {
    return shell(
      <>
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(0,230,118,0.12),transparent_50%)]" />
        <StatusBar />
        <div className="relative z-10 flex-1 flex flex-col px-5 pb-6 overflow-y-auto">
          <div className="pt-4 mb-5">
            <BrandLogo height={26} />
            <h2 className="font-display text-2xl font-bold mt-5">
              {authMode === 'login' ? 'Connexion' : 'Créer un compte'}
            </h2>
            <p className="text-[11px] text-kyn-metal mt-1">KYNETIK App · Client & Pro</p>
          </div>

          <div className="flex rounded-xl bg-white/5 p-1 mb-4">
            {(
              [
                ['particulier', 'Particulier'],
                ['pro', 'Professionnel'],
              ] as const
            ).map(([id, label]) => (
              <button
                key={id}
                type="button"
                onClick={() => setClientType(id)}
                className={cn(
                  'flex-1 rounded-lg py-2 text-[11px] font-semibold',
                  clientType === id ? 'bg-kyn-green text-kyn-black' : 'text-kyn-metal'
                )}
              >
                {label}
              </button>
            ))}
          </div>

          {clientType === 'pro' && (
            <div className="grid grid-cols-2 gap-2 mb-4">
              {[
                { id: 'Entreprise', icon: Briefcase },
                { id: 'Fleet', icon: Car },
                { id: 'Hôtel', icon: Hotel },
                { id: 'Parking', icon: ParkingCircle },
                { id: 'Immobilier', icon: Building2 },
              ].map(({ id, icon: Icon }) => (
                <button
                  key={id}
                  type="button"
                  onClick={() => setProKind(id)}
                  className={cn(
                    'rounded-xl border px-2.5 py-2.5 text-left flex items-center gap-2',
                    proKind === id ? 'border-kyn-green/40 bg-kyn-green/10' : 'border-white/10 bg-white/[0.03]'
                  )}
                >
                  <Icon size={13} className="text-kyn-green shrink-0" />
                  <span className="text-[10px] font-semibold">{id}</span>
                </button>
              ))}
            </div>
          )}

          <div className="space-y-3">
            <Field label="Email">
              <div className="relative">
                <Mail size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-kyn-metal" />
                <input className={cn(inputCls, 'pl-9')} placeholder="vous@email.com" defaultValue="khalifa@kynetik.tn" />
              </div>
            </Field>
            <Field label="Téléphone">
              <div className="relative">
                <Phone size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-kyn-metal" />
                <input className={cn(inputCls, 'pl-9')} placeholder="+216 ···" defaultValue="+216 20 000 000" />
              </div>
            </Field>
            <Field label="Password">
              <div className="relative">
                <Lock size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-kyn-metal" />
                <input
                  type={showPass ? 'text' : 'password'}
                  className={cn(inputCls, 'pl-9 pr-9')}
                  defaultValue="••••••••"
                />
                <button
                  type="button"
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-kyn-metal"
                  onClick={() => setShowPass(!showPass)}
                >
                  {showPass ? <EyeOff size={13} /> : <Eye size={13} />}
                </button>
              </div>
            </Field>
          </div>

          <div className="mt-5 space-y-2.5">
            <Btn
              onClick={() => {
                showToast(clientType === 'pro' ? `Espace ${proKind}` : 'Bienvenue Khalifa');
                go('home');
              }}
            >
              {authMode === 'login' ? 'Se connecter' : "S'inscrire"}
            </Btn>
            <div className="flex items-center gap-2 text-[9px] text-kyn-metal my-1">
              <div className="flex-1 h-px bg-white/10" />
              ou
              <div className="flex-1 h-px bg-white/10" />
            </div>
            <Btn variant="soft" className="flex items-center justify-center gap-2">
              <span className="text-sm">G</span> Continuer avec Google
            </Btn>
            <Btn variant="soft" className="flex items-center justify-center gap-2">
              <Apple size={14} /> Continuer avec Apple
            </Btn>
          </div>

          <button
            type="button"
            className="mt-4 text-[11px] text-kyn-silver"
            onClick={() => setAuthMode(authMode === 'login' ? 'register' : 'login')}
          >
            {authMode === 'login' ? 'Pas de compte ? ' : 'Déjà un compte ? '}
            <span className="text-kyn-green font-semibold">
              {authMode === 'login' ? "S'inscrire" : 'Se connecter'}
            </span>
          </button>
        </div>
      </>
    );
  }

  /* ——— HOME DASHBOARD ——— */
  if (screen === 'home') {
    return shell(
      <>
        <StatusBar />
        <div className="flex-1 overflow-y-auto px-4 pb-3">
          <div className="flex items-start justify-between pt-2 mb-4">
            <div>
              <p className="text-[11px] text-kyn-metal">Bonjour {name} 👋</p>
              <div className="flex items-center gap-1.5 mt-1">
                <span className="w-2 h-2 rounded-full bg-kyn-green animate-pulse" />
                <span className="text-[11px] font-semibold text-kyn-green">Charger connecté</span>
              </div>
            </div>
            <button
              type="button"
              onClick={() => go('notifications')}
              className="relative w-9 h-9 rounded-full border border-white/10 bg-white/5 flex items-center justify-center"
            >
              <Bell size={15} />
              {unread > 0 && (
                <span className="absolute -top-0.5 -right-0.5 w-4 h-4 rounded-full bg-kyn-green text-kyn-black text-[8px] font-bold flex items-center justify-center">
                  {unread}
                </span>
              )}
            </button>
          </div>

          {/* Main charger card */}
          <div className="rounded-3xl border border-kyn-green/25 bg-gradient-to-b from-kyn-green/15 to-white/[0.03] p-4 relative overflow-hidden">
            <div className="absolute right-0 top-0 w-32 h-32 bg-kyn-green/10 blur-2xl rounded-full" />
            <div className="flex items-start justify-between relative">
              <div>
                <p className="text-[10px] uppercase tracking-wider text-kyn-green font-semibold">My Charger</p>
                <h3 className="font-display text-lg font-bold mt-0.5">{mainCharger.name}</h3>
                <p className="text-[11px] text-kyn-metal">{mainCharger.model.includes('kW') ? mainCharger.model : 'PRIME 22 kW'}</p>
              </div>
              <img src={mainCharger.image_url || '/images/products/prime-tethered.png'} alt="" className="h-16 object-contain" />
            </div>

            <div className="mt-4 grid grid-cols-2 gap-2 relative">
              <div className="rounded-2xl bg-black/35 border border-white/8 p-3">
                <p className="text-[9px] text-kyn-metal">Status</p>
                <p className="text-sm font-bold text-kyn-green mt-0.5">{charging ? 'Charging' : 'Ready'}</p>
              </div>
              <div className="rounded-2xl bg-black/35 border border-white/8 p-3">
                <p className="text-[9px] text-kyn-metal">Power</p>
                <p className="text-sm font-bold mt-0.5">{charging ? `${powerKw.toFixed(1)} kW` : '0 kW'}</p>
              </div>
              <div className="rounded-2xl bg-black/35 border border-white/8 p-3">
                <p className="text-[9px] text-kyn-metal">Battery</p>
                <p className="text-sm font-bold mt-0.5">{Math.round(battery)}%</p>
              </div>
              <div className="rounded-2xl bg-black/35 border border-white/8 p-3">
                <p className="text-[9px] text-kyn-metal">Time remaining</p>
                <p className="text-sm font-bold mt-0.5">{charging ? `${Math.round(remainMin)} min` : '—'}</p>
              </div>
            </div>

            <div className="mt-3 h-2 rounded-full bg-white/10 overflow-hidden">
              <div className="h-full bg-gradient-to-r from-kyn-green to-emerald-300 rounded-full transition-all" style={{ width: `${battery}%` }} />
            </div>

            <div className="mt-4 grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => {
                  setCharging(true);
                  showToast('Charge démarrée');
                }}
                className="rounded-xl bg-kyn-green text-kyn-black py-2.5 flex flex-col items-center gap-1 text-[10px] font-bold"
              >
                <Play size={14} fill="currentColor" /> Start
              </button>
              <button
                type="button"
                onClick={() => {
                  setCharging(false);
                  showToast('Charge en pause');
                }}
                className="rounded-xl border border-white/15 bg-black/30 py-2.5 flex flex-col items-center gap-1 text-[10px] font-semibold"
              >
                <Pause size={14} /> Pause
              </button>
              <button
                type="button"
                onClick={() => go('devices')}
                className="rounded-xl border border-white/15 bg-black/30 py-2.5 flex flex-col items-center gap-1 text-[10px] font-semibold"
              >
                <Settings size={14} /> Settings
              </button>
            </div>
          </div>

          {/* Quick stats */}
          <div className="mt-4 grid grid-cols-3 gap-2">
            {[
              { icon: Zap, l: 'Today', v: `${energyStats.kwh} kWh`, c: 'text-kyn-green' },
              { icon: Wallet, l: 'Cost', v: `${energyStats.cost} TND`, c: 'text-sky-300' },
              { icon: Leaf, l: 'CO₂', v: `−${energyStats.co2} kg`, c: 'text-emerald-300' },
            ].map(({ icon: Icon, l, v, c }) => (
              <button
                key={l}
                type="button"
                onClick={() => go('analytics')}
                className="rounded-2xl border border-white/8 bg-white/[0.03] p-3 text-left"
              >
                <Icon size={12} className={c} />
                <p className="text-[9px] text-kyn-metal mt-2">{l}</p>
                <p className={cn('text-[11px] font-bold mt-0.5', c)}>{v}</p>
              </button>
            ))}
          </div>

          <div className="mt-4 space-y-2">
            {[
              { t: 'Charging history', s: 'history', icon: Clock },
              { t: 'My devices', s: 'devices', icon: Power },
              { t: 'Wallet & payments', s: 'wallet', icon: CreditCard },
            ].map(({ t, s, icon: Icon }) => (
              <button
                key={s}
                type="button"
                onClick={() => go(s as Screen)}
                className="w-full rounded-2xl border border-white/8 bg-white/[0.03] px-3.5 py-3 flex items-center gap-3"
              >
                <div className="w-8 h-8 rounded-xl bg-kyn-green/10 border border-kyn-green/20 flex items-center justify-center text-kyn-green">
                  <Icon size={14} />
                </div>
                <span className="flex-1 text-left text-[12px] font-semibold">{t}</span>
                <ChevronRight size={14} className="text-kyn-metal" />
              </button>
            ))}
          </div>
        </div>
      </>,
      'home'
    );
  }

  /* ——— CHARGE TAB ——— */
  if (screen === 'charge') {
    return shell(
      <>
        <StatusBar />
        <div className="flex-1 overflow-y-auto px-4 pb-3">
          <div className="pt-2 mb-3 flex items-center justify-between">
            <h2 className="font-display text-lg font-bold">Charge</h2>
            <span className={cn('text-[10px] px-2 py-1 rounded-full border', charging ? 'text-kyn-green border-kyn-green/30 bg-kyn-green/10' : 'text-kyn-metal border-white/10')}>
              {charging ? 'Live session' : 'Idle'}
            </span>
          </div>

          <div className="rounded-3xl border border-white/10 bg-kyn-void p-5 text-center relative overflow-hidden">
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(0,230,118,0.12),transparent_60%)]" />
            <p className="text-[10px] text-kyn-metal relative">Real-time power</p>
            <p className="font-display text-4xl font-bold text-kyn-green relative mt-1">
              {charging ? powerKw.toFixed(1) : '0.0'}
              <span className="text-base text-kyn-metal ml-1">kW</span>
            </p>
            <div className="mt-4 mx-auto w-36 h-36 rounded-full border-4 border-kyn-green/30 flex items-center justify-center relative">
              <div
                className="absolute inset-1 rounded-full border-4 border-kyn-green border-t-transparent animate-spin"
                style={{ animationDuration: charging ? '1.2s' : '0s', opacity: charging ? 1 : 0.2 }}
              />
              <div>
                <Battery size={22} className="text-kyn-green mx-auto" />
                <p className="text-xl font-bold mt-1">{Math.round(battery)}%</p>
              </div>
            </div>
            <p className="mt-3 text-[11px] text-kyn-silver relative">
              {charging ? `${Math.round(remainMin)} min remaining · ${vehicle.model}` : 'Ready to charge'}
            </p>
          </div>

          <div className="mt-4 grid grid-cols-2 gap-2">
            <Btn
              onClick={() => {
                setCharging(true);
                showToast('▶ Start charging');
              }}
            >
              ▶ Start
            </Btn>
            <Btn
              variant="ghost"
              onClick={() => {
                setCharging(false);
                showToast('⏸ Paused');
              }}
            >
              ⏸ Pause
            </Btn>
          </div>

          <div className="mt-4 rounded-2xl border border-white/8 p-4">
            <p className="text-[10px] uppercase tracking-wider text-kyn-metal font-semibold mb-3">Schedule</p>
            <div className="flex items-center justify-between text-[12px]">
              <span>Start at</span>
              <span className="font-bold text-kyn-green">22:00</span>
            </div>
            <div className="flex items-center justify-between text-[12px] mt-2">
              <span>Target SoC</span>
              <span className="font-bold">90%</span>
            </div>
            <div className="flex items-center justify-between text-[12px] mt-2">
              <span>Power limit</span>
              <span className="font-bold">16 A</span>
            </div>
            <Btn
              variant="soft"
              className="mt-3"
              onClick={() => showToast('Schedule saved')}
            >
              Modifier la programmation
            </Btn>
          </div>

          <button type="button" onClick={() => go('history')} className="mt-3 w-full text-[11px] text-kyn-green font-semibold py-2">
            Voir l&apos;historique →
          </button>
        </div>
      </>,
      'charge'
    );
  }

  /* ——— ENERGY / ANALYTICS ——— */
  if (screen === 'analytics') {
    const max = Math.max(...energyStats.bars, 1);
    return shell(
      <>
        <StatusBar />
        <div className="flex-1 overflow-y-auto px-4 pb-3">
          <div className="pt-2 mb-3">
            <h2 className="font-display text-lg font-bold">Energy</h2>
            <p className="text-[11px] text-kyn-metal">Consommation · coût · impact</p>
          </div>

          <div className="flex rounded-xl bg-white/5 p-1 mb-4">
            {(['day', 'week', 'month'] as const).map((p) => (
              <button
                key={p}
                type="button"
                onClick={() => setPeriod(p)}
                className={cn(
                  'flex-1 rounded-lg py-1.5 text-[10px] font-semibold capitalize',
                  period === p ? 'bg-kyn-green text-kyn-black' : 'text-kyn-metal'
                )}
              >
                {p === 'day' ? 'Daily' : p === 'week' ? 'Weekly' : 'Monthly'}
              </button>
            ))}
          </div>

          <div className="grid grid-cols-1 gap-2">
            {[
              { icon: Zap, l: 'Energy', v: `${energyStats.kwh} kWh`, sub: 'Today' },
              { icon: Wallet, l: 'Cost', v: `${energyStats.cost} TND`, sub: 'Estimated' },
              { icon: Leaf, l: 'CO₂ saved', v: `${energyStats.co2} kg`, sub: 'Avoided' },
            ].map(({ icon: Icon, l, v, sub }) => (
              <div key={l} className="rounded-2xl border border-white/8 bg-white/[0.03] px-4 py-3 flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-kyn-green/10 flex items-center justify-center text-kyn-green">
                  <Icon size={16} />
                </div>
                <div className="flex-1">
                  <p className="text-[10px] text-kyn-metal">{l} · {sub}</p>
                  <p className="text-base font-bold">{v}</p>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-4 rounded-2xl border border-white/8 bg-kyn-void p-4">
            <p className="text-[10px] text-kyn-metal mb-3 font-semibold uppercase tracking-wider">Chart</p>
            <div className="flex items-end gap-1 h-28">
              {energyStats.bars.map((v, i) => (
                <div
                  key={i}
                  className="flex-1 rounded-t-md bg-gradient-to-t from-kyn-green/40 to-kyn-green"
                  style={{ height: `${(v / max) * 100}%` }}
                />
              ))}
            </div>
          </div>

          <Btn variant="soft" className="mt-4" onClick={() => go('history')}>
            Charging history
          </Btn>
        </div>
      </>,
      'analytics'
    );
  }

  /* ——— HISTORY ——— */
  if (screen === 'history') {
    const rows =
      sessions.length > 0
        ? sessions
        : [
            {
              id: 1,
              started_at: '2026-08-02T18:20:00',
              energy_kwh: 32,
              cost_dt: 9.6,
              duration_min: 105,
              location: 'Home',
              charger_name: 'PRIME',
              status: 'completed',
              vehicle: 'Model 3',
            },
            {
              id: 2,
              started_at: '2026-08-01T21:10:00',
              energy_kwh: 18.4,
              cost_dt: 5.52,
              duration_min: 72,
              location: 'Home',
              charger_name: 'PRIME',
              status: 'completed',
              vehicle: 'Model 3',
            },
            {
              id: 3,
              started_at: '2026-07-30T09:05:00',
              energy_kwh: 11.2,
              cost_dt: 3.36,
              duration_min: 48,
              location: 'Hub Lac 2',
              charger_name: 'EDGE',
              status: 'completed',
              vehicle: 'Model 3',
            },
          ];
    return shell(
      <>
        <StatusBar />
        <div className="flex-1 overflow-y-auto px-4 pb-3">
          <div className="pt-2 mb-3 flex items-center gap-2">
            <button type="button" onClick={() => go('home')} className="text-kyn-metal text-xs">
              ←
            </button>
            <h2 className="font-display text-lg font-bold">Charging History</h2>
          </div>
          <div className="rounded-2xl border border-white/8 overflow-hidden">
            <div className="grid grid-cols-4 gap-1 px-3 py-2 bg-white/5 text-[9px] text-kyn-metal font-semibold uppercase">
              <span>Date</span>
              <span>Energy</span>
              <span>Cost</span>
              <span>Duration</span>
            </div>
            {rows.map((s) => {
              const d = new Date(s.started_at);
              const date = Number.isNaN(d.getTime())
                ? s.started_at
                : d.toLocaleDateString('fr-TN', { day: '2-digit', month: '2-digit', year: 'numeric' });
              const h = Math.floor(Number(s.duration_min) / 60);
              const m = Math.round(Number(s.duration_min) % 60);
              return (
                <div key={s.id} className="grid grid-cols-4 gap-1 px-3 py-3 border-t border-white/5 text-[11px]">
                  <span className="font-medium">{date}</span>
                  <span className="text-kyn-green">{s.energy_kwh} kWh</span>
                  <span>{Number(s.cost_dt).toFixed(3)} TND</span>
                  <span className="text-kyn-metal">
                    {h ? `${h}h` : ''}
                    {m}m
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      </>,
      'analytics'
    );
  }

  /* ——— DEVICES / CHARGER MGMT ——— */
  if (screen === 'devices') {
    const list = chargers.length
      ? chargers
      : [
          {
            ...mainCharger,
            name: 'KYNETIK PRIME',
            model: '22 kW',
            online: true,
            location: 'Home',
            firmware: 'v1.0.3',
          },
        ];
    return shell(
      <>
        <StatusBar />
        <div className="flex-1 overflow-y-auto px-4 pb-3">
          <div className="pt-2 mb-3 flex items-center gap-2">
            <button type="button" onClick={() => go('home')} className="text-kyn-metal text-xs">
              ←
            </button>
            <h2 className="font-display text-lg font-bold">My Devices</h2>
          </div>
          {list.map((c) => (
            <div key={c.id} className="rounded-3xl border border-white/10 bg-kyn-void p-4 mb-3">
              <div className="flex gap-3">
                <img src={c.image_url || '/images/products/prime-tethered.png'} alt="" className="h-16 w-14 object-contain" />
                <div className="flex-1">
                  <p className="font-display font-bold">{c.name}</p>
                  <p className="text-[11px] text-kyn-metal">{c.model} · {c.power_kw || 22} kW</p>
                  <div className="flex items-center gap-1.5 mt-1">
                    {c.online ? <Wifi size={11} className="text-kyn-green" /> : <WifiOff size={11} className="text-kyn-metal" />}
                    <span className={cn('text-[10px] font-semibold', c.online ? 'text-kyn-green' : 'text-kyn-metal')}>
                      {c.online ? 'Online' : 'Offline'}
                    </span>
                  </div>
                </div>
              </div>
              <div className="mt-3 space-y-1.5 text-[11px]">
                <div className="flex justify-between">
                  <span className="text-kyn-metal">Location</span>
                  <span className="font-medium">{c.location || 'Home'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-kyn-metal">Firmware</span>
                  <span className="font-medium">{c.firmware || 'v1.0.3'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-kyn-metal">S/N</span>
                  <span className="font-mono text-[10px]">{c.serial_number}</span>
                </div>
              </div>
              <div className="mt-3 grid grid-cols-2 gap-2">
                {[
                  { t: 'Rename', icon: Settings },
                  { t: 'Share access', icon: Share2 },
                  { t: 'Update firmware', icon: Download },
                  { t: 'Maintenance', icon: Wrench },
                ].map(({ t, icon: Icon }) => (
                  <button
                    key={t}
                    type="button"
                    onClick={() => showToast(`${t}…`)}
                    className="rounded-xl border border-white/10 bg-black/30 py-2.5 text-[10px] font-semibold flex items-center justify-center gap-1.5 hover:border-kyn-green/40"
                  >
                    <Icon size={12} /> {t}
                  </button>
                ))}
              </div>
            </div>
          ))}
          <Btn variant="soft" onClick={() => showToast('Scan QR to add charger')}>
            <span className="inline-flex items-center gap-1">
              <Plus size={14} /> Add device
            </span>
          </Btn>
        </div>
      </>,
      'charge'
    );
  }

  /* ——— MAP ——— */
  if (screen === 'map') {
    return shell(
      <>
        <StatusBar />
        <div className="flex-1 flex flex-col min-h-0">
          <div className="px-4 pt-2 pb-2">
            <h2 className="font-display text-lg font-bold">KYNETIK Network</h2>
            <p className="text-[11px] text-kyn-metal">Stations nearby · availability</p>
            <div className="mt-2 flex gap-1.5 overflow-x-auto pb-1">
              {[
                { id: 'all', l: 'All' },
                { id: '7', l: '⚡ 7 kW' },
                { id: '22', l: '⚡ 22 kW' },
                { id: 'fast', l: '⚡ Fast' },
              ].map((f) => (
                <button
                  key={f.id}
                  type="button"
                  onClick={() => setMapFilter(f.id)}
                  className={cn(
                    'shrink-0 px-2.5 py-1 rounded-full text-[10px] font-semibold border',
                    mapFilter === f.id
                      ? 'bg-kyn-green text-kyn-black border-kyn-green'
                      : 'border-white/12 text-kyn-silver'
                  )}
                >
                  {f.l}
                </button>
              ))}
            </div>
          </div>

          <div className="relative mx-4 h-40 rounded-2xl border border-white/10 overflow-hidden bg-[#0c1210]">
            <div
              className="absolute inset-0 opacity-40"
              style={{
                backgroundImage:
                  'linear-gradient(rgba(0,230,118,0.12) 1px, transparent 1px), linear-gradient(90deg, rgba(0,230,118,0.12) 1px, transparent 1px)',
                backgroundSize: '22px 22px',
              }}
            />
            {filteredStations.slice(0, 5).map((s, i) => (
              <div
                key={s.id}
                className="absolute"
                style={{ left: `${18 + i * 14}%`, top: `${25 + (i % 3) * 18}%` }}
              >
                <div
                  className={cn(
                    'w-3.5 h-3.5 rounded-full border-2 border-kyn-black shadow',
                    s.status === 'available' ? 'bg-kyn-green' : s.status === 'charging' ? 'bg-sky-400' : 'bg-amber-400'
                  )}
                />
              </div>
            ))}
            <div className="absolute bottom-2 left-2 right-2 flex gap-2 text-[8px]">
              <span className="flex items-center gap-1">
                <i className="w-2 h-2 rounded-full bg-kyn-green inline-block" /> Available
              </span>
              <span className="flex items-center gap-1">
                <i className="w-2 h-2 rounded-full bg-sky-400 inline-block" /> Busy
              </span>
            </div>
          </div>

          <div className="flex-1 overflow-y-auto px-4 mt-3 pb-2 space-y-2">
            {filteredStations.map((s) => (
              <div key={s.id} className="rounded-2xl border border-white/8 bg-white/[0.03] p-3">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <p className="text-[12px] font-bold">{s.name}</p>
                    <p className="text-[10px] text-kyn-metal mt-0.5 flex items-center gap-1">
                      <MapPin size={10} /> {s.city}
                      {s.address ? ` · ${s.address}` : ''}
                    </p>
                  </div>
                  <span
                    className={cn(
                      'text-[9px] px-2 py-0.5 rounded-full border capitalize',
                      s.status === 'available'
                        ? 'text-kyn-green border-kyn-green/30'
                        : 'text-sky-300 border-sky-400/30'
                    )}
                  >
                    {s.status}
                  </span>
                </div>
                <div className="mt-2 flex items-center justify-between">
                  <span className="text-[10px] text-kyn-silver">
                    {s.model || 'KYNETIK'} · {s.power_kw || 22} kW
                  </span>
                  <button
                    type="button"
                    onClick={() => showToast(`Navigation → ${s.name}`)}
                    className="inline-flex items-center gap-1 text-[10px] font-bold text-kyn-green"
                  >
                    <Navigation size={11} /> Go
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </>,
      'map'
    );
  }

  /* ——— WALLET ——— */
  if (screen === 'wallet') {
    return shell(
      <>
        <StatusBar />
        <div className="flex-1 overflow-y-auto px-4 pb-3">
          <div className="pt-2 mb-3 flex items-center gap-2">
            <button type="button" onClick={() => go('profile')} className="text-kyn-metal text-xs">
              ←
            </button>
            <h2 className="font-display text-lg font-bold">Payment</h2>
          </div>
          <div className="rounded-3xl border border-kyn-green/30 bg-gradient-to-br from-kyn-green/20 to-transparent p-5">
            <p className="text-[10px] text-kyn-metal uppercase tracking-wider">Wallet balance</p>
            <p className="font-display text-3xl font-bold mt-1">48.500 <span className="text-base text-kyn-metal">TND</span></p>
            <Btn className="mt-4" onClick={() => showToast('Top-up initiated')}>
              Recharger le wallet
            </Btn>
          </div>
          <p className="mt-5 text-[10px] uppercase tracking-wider text-kyn-metal font-semibold mb-2">Payment methods</p>
          {[
            { t: 'Carte bancaire', d: '•••• 4242', icon: CreditCard },
            { t: 'Mobile payment', d: 'Flouci / D17', icon: Smartphone },
            { t: 'Subscription', d: 'Cloud Home · 29 TND/mo', icon: Gauge },
          ].map(({ t, d, icon: Icon }) => (
            <div key={t} className="rounded-2xl border border-white/8 px-3 py-3 mb-2 flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-white/5 flex items-center justify-center text-kyn-green">
                <Icon size={15} />
              </div>
              <div className="flex-1">
                <p className="text-[12px] font-semibold">{t}</p>
                <p className="text-[10px] text-kyn-metal">{d}</p>
              </div>
              <ChevronRight size={14} className="text-kyn-metal" />
            </div>
          ))}
        </div>
      </>,
      'profile'
    );
  }

  /* ——— NOTIFICATIONS ——— */
  if (screen === 'notifications') {
    const items =
      notifs.length > 0
        ? notifs
        : [
            { id: 1, title: 'Charging completed', body: 'PRIME · 32 kWh · Home', type: 'success', read: false, created_at: '' },
            { id: 2, title: 'Abnormal consumption detected', body: 'Peak 18.2 kW unusual for schedule', type: 'warning', read: false, created_at: '' },
            { id: 3, title: 'Firmware update available', body: 'v1.0.4 ready for PRIME', type: 'info', read: true, created_at: '' },
          ];
    return shell(
      <>
        <StatusBar />
        <div className="flex-1 overflow-y-auto px-4 pb-3">
          <div className="pt-2 mb-3 flex items-center gap-2">
            <button type="button" onClick={() => go('home')} className="text-kyn-metal text-xs">
              ←
            </button>
            <h2 className="font-display text-lg font-bold">Notifications</h2>
          </div>
          <div className="space-y-2">
            {items.map((n) => (
              <div
                key={n.id}
                className={cn(
                  'rounded-2xl border p-3',
                  n.read ? 'border-white/8 bg-white/[0.02]' : 'border-kyn-green/25 bg-kyn-green/5'
                )}
              >
                <div className="flex items-start gap-2">
                  <Bell size={14} className="text-kyn-green mt-0.5 shrink-0" />
                  <div>
                    <p className="text-[12px] font-semibold">{n.title}</p>
                    <p className="text-[11px] text-kyn-metal mt-0.5 leading-relaxed">{n.body}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </>,
      'home'
    );
  }

  /* ——— PROFILE ——— */
  if (screen === 'profile') {
    return shell(
      <>
        <StatusBar />
        <div className="flex-1 overflow-y-auto px-4 pb-3">
          <div className="pt-2 mb-4 flex items-center gap-3">
            <div className="w-14 h-14 rounded-2xl bg-kyn-green/15 border border-kyn-green/30 flex items-center justify-center font-display font-bold text-lg text-kyn-green">
              KH
            </div>
            <div>
              <p className="font-display font-bold text-lg">{name} Hammami</p>
              <p className="text-[11px] text-kyn-metal">khalifa@kynetik.tn · Particulier</p>
            </div>
          </div>

          <div className="rounded-2xl border border-white/8 p-3 mb-3">
            <p className="text-[10px] text-kyn-metal uppercase tracking-wider mb-2">Vehicle</p>
            <div className="flex items-center gap-2">
              <Car size={16} className="text-kyn-green" />
              <div>
                <p className="text-[12px] font-semibold">{vehicle.model}</p>
                <p className="text-[10px] text-kyn-metal">
                  {vehicle.battery} · {vehicle.range}
                </p>
              </div>
            </div>
          </div>

          {[
            { t: 'Wallet & payments', s: 'wallet' as Screen, icon: Wallet },
            { t: 'Notifications', s: 'notifications' as Screen, icon: Bell },
            { t: 'My devices', s: 'devices' as Screen, icon: Power },
            { t: 'Charging history', s: 'history' as Screen, icon: Clock },
          ].map(({ t, s, icon: Icon }) => (
            <button
              key={t}
              type="button"
              onClick={() => go(s)}
              className="w-full rounded-2xl border border-white/8 bg-white/[0.03] px-3 py-3 mb-2 flex items-center gap-3"
            >
              <Icon size={15} className="text-kyn-green" />
              <span className="flex-1 text-left text-[12px] font-semibold">{t}</span>
              <ChevronRight size={14} className="text-kyn-metal" />
            </button>
          ))}

          <Btn
            variant="danger"
            className="mt-4"
            onClick={() => {
              setCharging(false);
              go('auth');
            }}
          >
            <span className="inline-flex items-center gap-2">
              <LogOut size={14} /> Déconnexion
            </span>
          </Btn>
        </div>
      </>,
      'profile'
    );
  }

  return shell(
    <div className="flex-1 flex items-center justify-center text-xs text-kyn-metal">Loading…</div>
  );
}

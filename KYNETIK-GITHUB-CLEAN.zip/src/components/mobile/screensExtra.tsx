import {
  ArrowLeft, Battery, Bell, Car, Check, ChevronRight, CreditCard, Heart,
  HelpCircle, History, Languages, Lock, MapPin, MessageCircle, Moon, Nfc,
  Pause, Play, QrCode, ScanLine, Search, Settings, Shield, Square, Star,
  Ticket, Wallet, Zap, Sun, User, FileText, Plus, Phone
} from 'lucide-react';
import AppBottomNav, { type AppTab } from '../AppBottomNav';
import { cn } from '../../lib/utils';

function StatusBar() {
  return (
    <div className="flex justify-between items-center px-5 pt-3 pb-1 text-[9px] text-kyn-metal relative z-20">
      <span>09:41</span>
      <div className="flex gap-1 items-center"><span className="w-3 h-1.5 rounded-sm border border-kyn-metal" /><span className="text-[8px]">5G</span></div>
    </div>
  );
}

function Header({ title, onBack }: { title: string; onBack?: boolean }) {
  return (
    <div className="flex items-center gap-2 px-4 pt-1 pb-2">
      {onBack !== false && (
        <div className="w-8 h-8 rounded-full bg-white/5 border border-white/10 flex items-center justify-center">
          <ArrowLeft size={14} className="text-kyn-silver" />
        </div>
      )}
      <h2 className="font-display font-bold text-base flex-1">{title}</h2>
    </div>
  );
}

export function SignupScreen() {
  return (
    <div className="h-full flex flex-col bg-kyn-black">
      <StatusBar />
      <div className="px-5 pt-6 flex-1">
        <p className="text-[10px] text-kyn-green tracking-widest uppercase font-semibold">Créer un compte</p>
        <h2 className="font-display text-xl font-bold mt-1">Rejoindre KYNETIK</h2>
        <div className="mt-6 space-y-2.5">
          {['Nom complet', 'Email', 'Téléphone', 'Mot de passe'].map((f) => (
            <div key={f} className="rounded-2xl bg-kyn-steel/60 border border-white/8 px-3.5 py-3 text-[11px] text-kyn-metal">{f}</div>
          ))}
          <label className="flex items-center gap-2 text-[10px] text-kyn-metal pt-1">
            <span className="w-4 h-4 rounded border border-kyn-green/40 bg-kyn-green/10" />
            J'accepte les CGU & politique de confidentialité
          </label>
          <button type="button" className="w-full rounded-2xl bg-kyn-green text-kyn-black text-xs font-bold py-3.5 mt-2">Créer mon compte</button>
        </div>
      </div>
    </div>
  );
}

export function FindChargerScreen({ onNav }: { onNav?: (t: AppTab) => void }) {
  const list = [
    { n: 'Hub Lac 2', d: '1.2 km', p: '120 kW DC', a: '4/6', price: '0.45 DT' },
    { n: 'NOVA Marsa', d: '2.8 km', p: '22 kW AC', a: '1/1', price: '0.38 DT' },
    { n: 'EDGE Centre-ville', d: '3.1 km', p: '22 kW AC', a: '2/4', price: '0.40 DT' },
  ];
  return (
    <div className="h-full flex flex-col bg-kyn-void">
      <StatusBar />
      <div className="px-4 pt-2 flex-1 overflow-hidden">
        <h2 className="font-display font-bold text-lg px-1">Find Charger</h2>
        <div className="mt-3 rounded-2xl bg-kyn-steel/50 border border-white/8 px-3 py-2.5 flex items-center gap-2">
          <Search size={13} className="text-kyn-green" />
          <span className="text-[11px] text-kyn-metal flex-1">Adresse, ville, hub…</span>
          <FilterIcon />
        </div>
        <div className="mt-2 flex gap-1.5 overflow-hidden">
          {['Nearby', 'DC Fast', 'Available', 'Favorites'].map((f, i) => (
            <span key={f} className={cn('px-2.5 py-1 rounded-full text-[9px] font-semibold border shrink-0', i === 0 ? 'bg-kyn-green text-kyn-black border-kyn-green' : 'border-white/10 text-kyn-silver')}>{f}</span>
          ))}
        </div>
        <div className="mt-4 space-y-2">
          {list.map((s) => (
            <div key={s.n} className="rounded-2xl border border-white/8 bg-kyn-steel/30 p-3.5">
              <div className="flex justify-between">
                <div>
                  <p className="font-semibold text-sm">{s.n}</p>
                  <p className="text-[10px] text-kyn-metal mt-0.5 flex items-center gap-1"><MapPin size={10} />{s.d} · {s.p}</p>
                </div>
                <div className="text-right">
                  <p className="text-kyn-green text-xs font-bold">{s.price}</p>
                  <p className="text-[9px] text-kyn-metal mt-0.5">{s.a} free</p>
                </div>
              </div>
              <div className="mt-3 flex gap-2">
                <button type="button" className="flex-1 rounded-xl bg-kyn-green text-kyn-black text-[10px] font-bold py-2">Détails</button>
                <button type="button" className="rounded-xl border border-white/10 px-3 py-2"><Heart size={12} className="text-kyn-metal" /></button>
              </div>
            </div>
          ))}
        </div>
      </div>
      <AppBottomNav active="map" onChange={onNav} />
    </div>
  );
}

function FilterIcon() {
  return <span className="text-[9px] text-kyn-green font-semibold">Filter</span>;
}

export function ChargerDetailsScreen() {
  return (
    <div className="h-full flex flex-col bg-kyn-void">
      <StatusBar />
      <Header title="Charger details" />
      <div className="px-4 flex-1">
        <div className="rounded-2xl border border-kyn-green/25 bg-gradient-to-br from-kyn-steel to-black p-4">
          <div className="flex justify-between items-start">
            <div>
              <p className="font-display font-bold text-lg">KYNETIK Hub Lac 2</p>
              <p className="text-[10px] text-kyn-metal mt-1">Les Berges du Lac, Tunis</p>
            </div>
            <span className="text-[9px] text-kyn-green bg-kyn-green/10 px-2 py-1 rounded-full">Open</span>
          </div>
          <div className="mt-4 grid grid-cols-3 gap-2">
            {[['Power', '120 kW'], ['Price', '0.45 DT'], ['Avail.', '4/6']].map(([l, v]) => (
              <div key={l} className="rounded-xl bg-black/40 p-2">
                <p className="text-[8px] text-kyn-metal">{l}</p>
                <p className="text-[11px] font-semibold mt-0.5">{v}</p>
              </div>
            ))}
          </div>
        </div>
        <p className="mt-4 text-[10px] text-kyn-metal uppercase tracking-wider">Connectors</p>
        <div className="mt-2 space-y-2">
          {[['CCS2 #1', 'Available', true], ['CCS2 #2', 'In use', false], ['Type 2', 'Available', true]].map(([n, s, ok]) => (
            <div key={String(n)} className="flex items-center justify-between rounded-xl bg-kyn-steel/40 border border-white/5 px-3 py-2.5">
              <div className="flex items-center gap-2">
                <Zap size={13} className={ok ? 'text-kyn-green' : 'text-kyn-metal'} />
                <span className="text-[11px] font-medium">{n}</span>
              </div>
              <span className={cn('text-[9px]', ok ? 'text-kyn-green' : 'text-amber-300')}>{s}</span>
            </div>
          ))}
        </div>
        <div className="mt-4 grid grid-cols-2 gap-2">
          <button type="button" className="rounded-xl border border-white/10 py-2.5 text-[10px] font-semibold">Itinéraire</button>
          <button type="button" className="rounded-xl bg-kyn-green text-kyn-black py-2.5 text-[10px] font-bold">Start charging</button>
        </div>
      </div>
    </div>
  );
}

export function QrScanScreen() {
  return (
    <div className="h-full flex flex-col bg-kyn-black">
      <StatusBar />
      <Header title="QR Scan" />
      <div className="flex-1 flex flex-col items-center justify-center px-6">
        <div className="relative w-52 h-52 rounded-3xl border-2 border-kyn-green/50 bg-kyn-green/5 flex items-center justify-center">
          <div className="absolute top-0 left-0 w-8 h-8 border-t-2 border-l-2 border-kyn-green rounded-tl-xl" />
          <div className="absolute top-0 right-0 w-8 h-8 border-t-2 border-r-2 border-kyn-green rounded-tr-xl" />
          <div className="absolute bottom-0 left-0 w-8 h-8 border-b-2 border-l-2 border-kyn-green rounded-bl-xl" />
          <div className="absolute bottom-0 right-0 w-8 h-8 border-b-2 border-r-2 border-kyn-green rounded-br-xl" />
          <QrCode size={64} className="text-kyn-green/80" />
          <div className="absolute inset-x-4 top-1/2 h-0.5 bg-kyn-green animate-pulse" />
        </div>
        <p className="mt-6 text-sm font-semibold text-center">Scannez le QR de la borne</p>
        <p className="mt-1 text-[10px] text-kyn-metal text-center">Ou saisissez le code station manuellement</p>
        <button type="button" className="mt-6 rounded-2xl border border-white/12 px-5 py-2.5 text-[11px] font-semibold flex items-center gap-2">
          <ScanLine size={14} className="text-kyn-green" /> Entrer le code
        </button>
      </div>
    </div>
  );
}

export function StartChargingScreen() {
  return (
    <div className="h-full flex flex-col bg-kyn-void">
      <StatusBar />
      <Header title="Start charging" />
      <div className="px-5 flex-1">
        <div className="rounded-2xl border border-white/8 bg-kyn-steel/40 p-4">
          <p className="text-[10px] text-kyn-metal uppercase tracking-wider">Selected</p>
          <p className="font-display font-bold mt-1">NOVA Home · Connector T2</p>
          <p className="text-[11px] text-kyn-silver mt-1">Vehicle: Tesla Model 3 · 54%</p>
        </div>
        <p className="mt-5 text-[10px] text-kyn-metal uppercase tracking-wider">Charge limit</p>
        <div className="mt-2 rounded-2xl border border-kyn-green/25 bg-kyn-green/5 p-4">
          <div className="flex justify-between text-sm font-semibold">
            <span>Target SoC</span>
            <span className="text-kyn-green">80%</span>
          </div>
          <div className="mt-3 h-2 rounded-full bg-white/10 overflow-hidden">
            <div className="h-full w-4/5 bg-kyn-green rounded-full" />
          </div>
        </div>
        <div className="mt-4 grid grid-cols-2 gap-2">
          {[['Max power', '11 kW'], ['Payment', 'Wallet'], ['Schedule', 'Now'], ['RFID', 'Optional']].map(([l, v]) => (
            <div key={l} className="rounded-xl bg-kyn-steel/40 border border-white/5 p-3">
              <p className="text-[9px] text-kyn-metal">{l}</p>
              <p className="text-[11px] font-semibold mt-0.5">{v}</p>
            </div>
          ))}
        </div>
        <button type="button" className="mt-6 w-full rounded-2xl bg-kyn-green text-kyn-black text-xs font-bold py-3.5 flex items-center justify-center gap-2 glow-green">
          <Play size={14} fill="currentColor" /> Démarrer la charge
        </button>
      </div>
    </div>
  );
}

export function ChargingLiveScreen() {
  return (
    <div className="h-full flex flex-col bg-kyn-black items-center px-5">
      <StatusBar />
      <p className="text-[10px] text-kyn-metal uppercase tracking-widest mt-4">Live session</p>
      <div className="relative mt-8 w-44 h-44">
        <div className="absolute inset-0 rounded-full" style={{ background: 'conic-gradient(from 200deg,#00e676 0%,#00e676 62%,#2a2a30 62%)', padding: 5 }}>
          <div className="w-full h-full rounded-full bg-kyn-black" />
        </div>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className="font-display text-4xl font-bold text-kyn-green text-glow">62%</span>
          <span className="text-[10px] text-kyn-metal mt-1">Charging live</span>
        </div>
      </div>
      <div className="mt-8 w-full grid grid-cols-3 gap-2">
        {[['11.4 kW', 'Power'], ['28 min', 'ETA'], ['14.2 kWh', 'Energy']].map(([v, l]) => (
          <div key={l} className="rounded-xl bg-kyn-steel/50 border border-white/5 p-2.5 text-center">
            <p className="text-xs font-bold">{v}</p>
            <p className="text-[8px] text-kyn-metal mt-0.5">{l}</p>
          </div>
        ))}
      </div>
      <div className="mt-auto mb-8 w-full grid grid-cols-3 gap-2">
        <button type="button" className="rounded-xl border border-white/12 py-3 flex flex-col items-center gap-1 text-[9px]"><Pause size={14} className="text-kyn-green" />Pause</button>
        <button type="button" className="rounded-xl border border-white/12 py-3 flex flex-col items-center gap-1 text-[9px]"><Play size={14} className="text-kyn-green" />Resume</button>
        <button type="button" className="rounded-xl border border-red-500/40 text-red-400 py-3 flex flex-col items-center gap-1 text-[9px]"><Square size={14} />Stop</button>
      </div>
    </div>
  );
}

export function PauseResumeScreen() {
  return (
    <div className="h-full flex flex-col bg-kyn-void">
      <StatusBar />
      <Header title="Session control" />
      <div className="px-5 flex-1 flex flex-col items-center pt-8">
        <div className="w-20 h-20 rounded-full bg-amber-400/10 border border-amber-400/30 flex items-center justify-center">
          <Pause size={28} className="text-amber-300" />
        </div>
        <p className="mt-5 font-display text-xl font-bold">Charge en pause</p>
        <p className="mt-2 text-[11px] text-kyn-metal text-center">Session conservée · connecteur verrouillé · facturation suspendue</p>
        <div className="mt-8 w-full rounded-2xl border border-white/8 bg-kyn-steel/40 p-4 space-y-2 text-[11px]">
          <div className="flex justify-between"><span className="text-kyn-metal">SoC</span><span>62%</span></div>
          <div className="flex justify-between"><span className="text-kyn-metal">Énergie</span><span>14.2 kWh</span></div>
          <div className="flex justify-between"><span className="text-kyn-metal">Durée</span><span>41 min</span></div>
        </div>
        <button type="button" className="mt-6 w-full rounded-2xl bg-kyn-green text-kyn-black text-xs font-bold py-3.5 flex items-center justify-center gap-2">
          <Play size={14} fill="currentColor" /> Reprendre
        </button>
        <button type="button" className="mt-2 w-full rounded-2xl border border-red-500/40 text-red-400 text-xs font-semibold py-3">Arrêter définitivement</button>
      </div>
    </div>
  );
}

export function StopChargingScreen() {
  return (
    <div className="h-full flex flex-col bg-kyn-black">
      <StatusBar />
      <div className="flex-1 flex flex-col items-center justify-center px-6">
        <div className="w-16 h-16 rounded-full bg-red-500/10 border border-red-500/30 flex items-center justify-center">
          <Square size={24} className="text-red-400" />
        </div>
        <p className="mt-5 font-display text-xl font-bold text-center">Arrêter la session ?</p>
        <p className="mt-2 text-[11px] text-kyn-metal text-center">Le connecteur se déverrouillera et le résumé de charge sera généré.</p>
        <div className="mt-8 w-full space-y-2">
          <button type="button" className="w-full rounded-2xl bg-red-500/90 text-white text-xs font-bold py-3.5">Confirmer l'arrêt</button>
          <button type="button" className="w-full rounded-2xl border border-white/12 text-xs font-semibold py-3.5">Continuer la charge</button>
        </div>
      </div>
    </div>
  );
}

export function ChargingSummaryScreen() {
  return (
    <div className="h-full flex flex-col bg-kyn-void">
      <StatusBar />
      <div className="px-5 pt-6 flex-1">
        <div className="text-center">
          <div className="w-14 h-14 mx-auto rounded-full bg-kyn-green/15 border border-kyn-green/30 flex items-center justify-center">
            <Check size={24} className="text-kyn-green" />
          </div>
          <p className="mt-4 font-display text-xl font-bold">Session terminée</p>
          <p className="text-[11px] text-kyn-metal mt-1">NOVA Home · Aujourd'hui 09:12</p>
        </div>
        <div className="mt-6 rounded-2xl border border-white/8 bg-kyn-steel/40 p-4 space-y-3">
          {[
            ['Énergie livrée', '18.6 kWh'],
            ['Durée', '1h 24m'],
            ['Puissance moy.', '13.2 kW'],
            ['Coût', '7.10 DT'],
            ['CO₂ évité', '4.2 kg'],
          ].map(([l, v]) => (
            <div key={l} className="flex justify-between text-[12px]">
              <span className="text-kyn-metal">{l}</span>
              <span className="font-semibold">{v}</span>
            </div>
          ))}
        </div>
        <button type="button" className="mt-6 w-full rounded-2xl bg-kyn-green text-kyn-black text-xs font-bold py-3.5">Télécharger le reçu</button>
        <button type="button" className="mt-2 w-full rounded-2xl border border-white/12 text-xs font-semibold py-3">Retour à l'accueil</button>
      </div>
    </div>
  );
}

export function PaymentMethodsScreen() {
  return (
    <div className="h-full flex flex-col bg-kyn-void">
      <StatusBar />
      <Header title="Payment methods" />
      <div className="px-4 flex-1 space-y-2">
        {[
          { t: 'Visa ···· 4242', s: 'Default', ok: true },
          { t: 'KYNETIK Wallet', s: '84.50 DT', ok: true },
          { t: 'Mastercard ···· 8811', s: 'Backup', ok: false },
        ].map((c) => (
          <div key={c.t} className="flex items-center justify-between rounded-2xl border border-white/8 bg-kyn-steel/40 px-3.5 py-3">
            <div className="flex items-center gap-2.5">
              <CreditCard size={16} className="text-kyn-green" />
              <div>
                <p className="text-[12px] font-medium">{c.t}</p>
                <p className="text-[9px] text-kyn-metal">{c.s}</p>
              </div>
            </div>
            {c.ok && <Check size={14} className="text-kyn-green" />}
          </div>
        ))}
        <button type="button" className="w-full mt-3 rounded-2xl border border-dashed border-kyn-green/40 text-kyn-green text-[11px] font-semibold py-3 flex items-center justify-center gap-2">
          <Plus size={14} /> Ajouter une carte
        </button>
      </div>
    </div>
  );
}

export function WalletScreen() {
  return (
    <div className="h-full flex flex-col bg-kyn-void">
      <StatusBar />
      <Header title="Wallet" />
      <div className="px-4 flex-1">
        <div className="rounded-2xl bg-gradient-to-br from-kyn-green/25 via-kyn-steel to-black border border-kyn-green/30 p-5">
          <p className="text-[10px] text-kyn-metal uppercase tracking-wider">Balance</p>
          <p className="font-display text-4xl font-bold mt-2">84.50 <span className="text-base text-kyn-metal">DT</span></p>
          <div className="mt-4 flex gap-2">
            <button type="button" className="flex-1 rounded-xl bg-kyn-green text-kyn-black text-[10px] font-bold py-2.5">Top up</button>
            <button type="button" className="flex-1 rounded-xl bg-white/10 text-[10px] font-semibold py-2.5">Send</button>
          </div>
        </div>
        <p className="mt-5 text-[10px] text-kyn-metal uppercase tracking-wider">Recent</p>
        <div className="mt-2 space-y-2">
          {[['+50.00', 'Top-up'], ['-7.10', 'NOVA Home'], ['-12.40', 'Hub Lac 2']].map(([a, t]) => (
            <div key={t + a} className="flex justify-between rounded-xl bg-kyn-steel/40 border border-white/5 px-3 py-2.5 text-[11px]">
              <span>{t}</span>
              <span className={a.startsWith('+') ? 'text-kyn-green font-semibold' : 'font-semibold'}>{a} DT</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export function SubscriptionScreen() {
  return (
    <div className="h-full flex flex-col bg-kyn-void">
      <StatusBar />
      <Header title="Subscription" />
      <div className="px-4 flex-1 space-y-3">
        {[
          { n: 'Free', p: '0 DT', f: ['Map access', 'Pay as you go'], cur: false },
          { n: 'Premium', p: '29 DT/mo', f: ['Priority support', '-8% energy', 'Multi-vehicle'], cur: true },
          { n: 'Business', p: '99 DT/mo', f: ['Fleet seats', 'Invoices', 'RFID packs'], cur: false },
        ].map((pl) => (
          <div key={pl.n} className={cn('rounded-2xl border p-4', pl.cur ? 'border-kyn-green/40 bg-kyn-green/5' : 'border-white/8 bg-kyn-steel/30')}>
            <div className="flex justify-between items-center">
              <p className="font-display font-bold">{pl.n}</p>
              <p className="text-sm text-kyn-green font-semibold">{pl.p}</p>
            </div>
            <ul className="mt-2 space-y-1">
              {pl.f.map((x) => (
                <li key={x} className="text-[10px] text-kyn-metal flex items-center gap-1.5"><Check size={10} className="text-kyn-green" />{x}</li>
              ))}
            </ul>
            {pl.cur && <p className="mt-2 text-[9px] text-kyn-green font-semibold">Plan actuel</p>}
          </div>
        ))}
      </div>
    </div>
  );
}

export function HistoryScreen({ onNav }: { onNav?: (t: AppTab) => void }) {
  return (
    <div className="h-full flex flex-col bg-kyn-void">
      <StatusBar />
      <div className="px-4 pt-2 flex-1">
        <h2 className="font-display font-bold text-lg">Charging history</h2>
        <div className="mt-4 space-y-2">
          {[
            ['NOVA Home', '18.6 kWh', '7.10 DT', 'Aujourd\'hui'],
            ['Hub Lac 2', '34.2 kWh', '15.40 DT', 'Hier'],
            ['EDGE Sfax', '9.1 kWh', '3.60 DT', '12 Mar'],
            ['GO Travel', '4.4 kWh', '1.80 DT', '10 Mar'],
          ].map(([n, e, c, d]) => (
            <div key={n + d} className="flex items-center justify-between rounded-xl border border-white/8 bg-kyn-steel/30 px-3 py-3">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-kyn-green/10 flex items-center justify-center"><History size={14} className="text-kyn-green" /></div>
                <div>
                  <p className="text-[12px] font-medium">{n}</p>
                  <p className="text-[9px] text-kyn-metal">{d} · {e}</p>
                </div>
              </div>
              <span className="text-[11px] font-semibold">{c}</span>
            </div>
          ))}
        </div>
      </div>
      <AppBottomNav active="analytics" onChange={onNav} />
    </div>
  );
}

export function NotificationsScreen() {
  return (
    <div className="h-full flex flex-col bg-kyn-void">
      <StatusBar />
      <Header title="Notifications" />
      <div className="px-4 flex-1 space-y-2">
        {[
          { t: 'Charge complete', d: 'NOVA Home reached 80%', time: '2m', unread: true },
          { t: 'Promo weekend', d: '-10% on public DC hubs', time: '1h', unread: true },
          { t: 'Firmware ready', d: 'NOVA update 2.4.1 available', time: '1d', unread: false },
          { t: 'Invoice ready', d: 'March statement available', time: '2d', unread: false },
        ].map((n) => (
          <div key={n.t} className={cn('rounded-2xl border px-3.5 py-3', n.unread ? 'border-kyn-green/25 bg-kyn-green/5' : 'border-white/8 bg-kyn-steel/30')}>
            <div className="flex justify-between">
              <p className="text-[12px] font-semibold">{n.t}</p>
              <span className="text-[9px] text-kyn-metal">{n.time}</span>
            </div>
            <p className="text-[10px] text-kyn-metal mt-1">{n.d}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

export function FavoritesScreen() {
  return (
    <div className="h-full flex flex-col bg-kyn-void">
      <StatusBar />
      <Header title="Favorites" />
      <div className="px-4 flex-1 space-y-2">
        {['Hub Lac 2', 'NOVA Home', 'Hotel Palm DC', 'Depot Sfax PRO'].map((n) => (
          <div key={n} className="flex items-center justify-between rounded-2xl border border-white/8 bg-kyn-steel/30 px-3.5 py-3">
            <div className="flex items-center gap-2.5">
              <Heart size={14} className="text-kyn-green" fill="currentColor" />
              <span className="text-[12px] font-medium">{n}</span>
            </div>
            <ChevronRight size={12} className="text-kyn-metal" />
          </div>
        ))}
      </div>
    </div>
  );
}

export function VehiclesScreen() {
  return (
    <div className="h-full flex flex-col bg-kyn-void">
      <StatusBar />
      <Header title="Vehicles" />
      <div className="px-4 flex-1 space-y-3">
        {[
          { n: 'Tesla Model 3', p: 'CCS2 · 75 kWh', def: true },
          { n: 'MG4 Electric', p: 'CCS2 · 64 kWh', def: false },
        ].map((v) => (
          <div key={v.n} className="rounded-2xl border border-white/8 bg-kyn-steel/40 p-4">
            <div className="flex items-start justify-between">
              <div className="flex gap-3">
                <div className="w-10 h-10 rounded-xl bg-kyn-green/10 flex items-center justify-center"><Car size={18} className="text-kyn-green" /></div>
                <div>
                  <p className="font-semibold text-sm">{v.n}</p>
                  <p className="text-[10px] text-kyn-metal mt-0.5">{v.p}</p>
                </div>
              </div>
              {v.def && <span className="text-[9px] text-kyn-green bg-kyn-green/10 px-2 py-0.5 rounded-full">Default</span>}
            </div>
          </div>
        ))}
        <button type="button" className="w-full rounded-2xl border border-dashed border-kyn-green/40 text-kyn-green text-[11px] font-semibold py-3 flex items-center justify-center gap-2">
          <Plus size={14} /> Ajouter un véhicule
        </button>
      </div>
    </div>
  );
}

export function RfidScreen() {
  return (
    <div className="h-full flex flex-col bg-kyn-void">
      <StatusBar />
      <Header title="RFID cards" />
      <div className="px-4 flex-1">
        <div className="rounded-2xl border border-kyn-green/30 bg-gradient-to-br from-kyn-steel to-black p-5 relative overflow-hidden">
          <Nfc className="absolute right-4 top-4 text-kyn-green/30" size={40} />
          <p className="text-[10px] text-kyn-metal uppercase tracking-wider">Primary RFID</p>
          <p className="font-display text-lg font-bold mt-3 tracking-[0.2em]">KYN · 8842 1190</p>
          <p className="text-[10px] text-kyn-green mt-4">Active · Linked to Premium</p>
        </div>
        <div className="mt-4 space-y-2">
          {[['Guest card', 'Inactive'], ['Fleet card #02', 'Active']].map(([n, s]) => (
            <div key={n} className="flex justify-between rounded-xl border border-white/8 bg-kyn-steel/30 px-3 py-3 text-[11px]">
              <span>{n}</span>
              <span className={s === 'Active' ? 'text-kyn-green' : 'text-kyn-metal'}>{s}</span>
            </div>
          ))}
        </div>
        <button type="button" className="mt-4 w-full rounded-2xl bg-kyn-green text-kyn-black text-xs font-bold py-3">Commander une carte</button>
      </div>
    </div>
  );
}

export function SupportScreen() {
  return (
    <div className="h-full flex flex-col bg-kyn-void">
      <StatusBar />
      <Header title="Support Center" />
      <div className="px-4 flex-1 space-y-2">
        {[
          { icon: MessageCircle, t: 'Chat support', d: 'Réponse moyenne 3 min' },
          { icon: Ticket, t: 'Mes tickets', d: '2 ouverts' },
          { icon: Phone, t: 'Hotline', d: '+216 70 000 000' },
          { icon: HelpCircle, t: 'FAQ', d: 'Installation, billing, OCPP' },
          { icon: FileText, t: 'Guides', d: 'NOVA · PRIME · GO · PRO' },
        ].map(({ icon: Icon, t, d }) => (
          <div key={t} className="flex items-center justify-between rounded-2xl border border-white/8 bg-kyn-steel/30 px-3.5 py-3">
            <div className="flex items-center gap-2.5">
              <Icon size={15} className="text-kyn-green" />
              <div>
                <p className="text-[12px] font-medium">{t}</p>
                <p className="text-[9px] text-kyn-metal">{d}</p>
              </div>
            </div>
            <ChevronRight size={12} className="text-kyn-metal" />
          </div>
        ))}
      </div>
    </div>
  );
}

export function ChatSupportScreen() {
  return (
    <div className="h-full flex flex-col bg-kyn-black">
      <StatusBar />
      <Header title="Chat KYNETIK" />
      <div className="flex-1 px-4 space-y-3 overflow-hidden">
        <div className="max-w-[80%] rounded-2xl rounded-tl-sm bg-kyn-steel/60 border border-white/8 px-3 py-2 text-[11px] text-kyn-silver">
          Bonjour Khalifa 👋 Comment pouvons-nous vous aider ?
        </div>
        <div className="max-w-[80%] ml-auto rounded-2xl rounded-tr-sm bg-kyn-green text-kyn-black px-3 py-2 text-[11px] font-medium">
          Ma session NOVA ne démarre pas
        </div>
        <div className="max-w-[80%] rounded-2xl rounded-tl-sm bg-kyn-steel/60 border border-white/8 px-3 py-2 text-[11px] text-kyn-silver">
          Je vérifie le statut OCPP de NOVA Home… Borne online. Essayez un remote start.
        </div>
      </div>
      <div className="p-3 border-t border-white/5">
        <div className="rounded-2xl bg-kyn-steel/50 border border-white/10 px-3 py-2.5 text-[11px] text-kyn-metal">Écrire un message…</div>
      </div>
    </div>
  );
}

export function TicketsScreen() {
  return (
    <div className="h-full flex flex-col bg-kyn-void">
      <StatusBar />
      <Header title="Tickets" />
      <div className="px-4 flex-1 space-y-2">
        {[
          { id: '#T-2041', t: 'Remote start failed', s: 'Open', c: 'text-amber-300' },
          { id: '#T-1988', t: 'Invoice March PDF', s: 'Pending', c: 'text-sky-300' },
          { id: '#T-1902', t: 'RFID pair request', s: 'Resolved', c: 'text-kyn-green' },
        ].map((t) => (
          <div key={t.id} className="rounded-2xl border border-white/8 bg-kyn-steel/30 px-3.5 py-3">
            <div className="flex justify-between">
              <p className="text-[10px] text-kyn-metal">{t.id}</p>
              <span className={cn('text-[9px] font-semibold', t.c)}>{t.s}</span>
            </div>
            <p className="text-[12px] font-medium mt-1">{t.t}</p>
          </div>
        ))}
        <button type="button" className="w-full mt-2 rounded-2xl bg-kyn-green text-kyn-black text-xs font-bold py-3">Nouveau ticket</button>
      </div>
    </div>
  );
}

export function SettingsScreen() {
  return (
    <div className="h-full flex flex-col bg-kyn-void">
      <StatusBar />
      <Header title="Settings" />
      <div className="px-4 flex-1 space-y-1.5">
        {[
          { icon: User, t: 'Account' },
          { icon: Bell, t: 'Notifications prefs' },
          { icon: Languages, t: 'Language · FR / EN / AR' },
          { icon: Moon, t: 'Dark / Light mode' },
          { icon: Shield, t: 'Privacy' },
          { icon: Lock, t: 'Security' },
          { icon: Settings, t: 'About KYNETIK' },
        ].map(({ icon: Icon, t }) => (
          <div key={t} className="flex items-center justify-between rounded-xl border border-white/5 bg-kyn-steel/30 px-3 py-3">
            <div className="flex items-center gap-2.5">
              <Icon size={14} className="text-kyn-green" />
              <span className="text-[11px] font-medium">{t}</span>
            </div>
            <ChevronRight size={12} className="text-kyn-metal" />
          </div>
        ))}
      </div>
    </div>
  );
}

export function LanguageScreen() {
  return (
    <div className="h-full flex flex-col bg-kyn-void">
      <StatusBar />
      <Header title="Language" />
      <div className="px-4 flex-1 space-y-2">
        {[
          { c: 'Français', s: true },
          { c: 'English', s: false },
          { c: 'العربية', s: false },
        ].map((l) => (
          <div key={l.c} className={cn('flex items-center justify-between rounded-2xl border px-4 py-3.5', l.s ? 'border-kyn-green/40 bg-kyn-green/5' : 'border-white/8 bg-kyn-steel/30')}>
            <span className="text-sm font-medium">{l.c}</span>
            {l.s && <Check size={16} className="text-kyn-green" />}
          </div>
        ))}
      </div>
    </div>
  );
}

export function ThemeScreen() {
  return (
    <div className="h-full flex flex-col bg-kyn-void">
      <StatusBar />
      <Header title="Appearance" />
      <div className="px-4 flex-1 grid grid-cols-2 gap-3 content-start">
        <div className="rounded-2xl border border-kyn-green/40 bg-kyn-black p-4 min-h-[140px]">
          <Moon size={18} className="text-kyn-green mb-3" />
          <p className="font-semibold text-sm">Dark</p>
          <p className="text-[10px] text-kyn-metal mt-1">Default KYNETIK</p>
          <span className="inline-block mt-3 text-[9px] text-kyn-green">Selected</span>
        </div>
        <div className="rounded-2xl border border-white/10 bg-kyn-white text-kyn-black p-4 min-h-[140px]">
          <Sun size={18} className="text-kyn-green-dark mb-3" />
          <p className="font-semibold text-sm">Light</p>
          <p className="text-[10px] text-kyn-graphite mt-1">Daytime UI</p>
        </div>
      </div>
    </div>
  );
}

export function PrivacyScreen() {
  return (
    <div className="h-full flex flex-col bg-kyn-void">
      <StatusBar />
      <Header title="Privacy" />
      <div className="px-4 flex-1 space-y-3">
        {[
          ['Share analytics', true],
          ['Personalized offers', true],
          ['Location always', false],
          ['Crash reports', true],
        ].map(([t, on]) => (
          <div key={String(t)} className="flex items-center justify-between rounded-xl border border-white/8 bg-kyn-steel/30 px-3.5 py-3">
            <span className="text-[12px]">{t as string}</span>
            <div className={cn('w-10 h-5 rounded-full relative', on ? 'bg-kyn-green' : 'bg-kyn-graphite')}>
              <div className={cn('absolute top-0.5 w-4 h-4 rounded-full bg-white', on ? 'right-0.5' : 'left-0.5')} />
            </div>
          </div>
        ))}
        <p className="text-[10px] text-kyn-metal leading-relaxed pt-2">Vos données de session sont chiffrées et hébergées selon la politique KYNETIK Cloud.</p>
      </div>
    </div>
  );
}

export function SecurityScreen() {
  return (
    <div className="h-full flex flex-col bg-kyn-void">
      <StatusBar />
      <Header title="Security" />
      <div className="px-4 flex-1 space-y-2">
        {[
          { t: 'Biometric login', d: 'Face ID / empreinte' },
          { t: 'Change password', d: 'Dernière maj il y a 60j' },
          { t: '2FA', d: 'SMS + authenticator' },
          { t: 'Active sessions', d: '2 appareils' },
        ].map((r) => (
          <div key={r.t} className="rounded-2xl border border-white/8 bg-kyn-steel/30 px-3.5 py-3 flex justify-between items-center">
            <div>
              <p className="text-[12px] font-medium">{r.t}</p>
              <p className="text-[9px] text-kyn-metal mt-0.5">{r.d}</p>
            </div>
            <ChevronRight size={12} className="text-kyn-metal" />
          </div>
        ))}
      </div>
    </div>
  );
}

export function AboutScreen() {
  return (
    <div className="h-full flex flex-col bg-kyn-black">
      <StatusBar />
      <Header title="About KYNETIK" />
      <div className="px-6 flex-1 flex flex-col items-center pt-10">
        <div className="w-16 h-16 rounded-2xl border border-kyn-green/30 bg-kyn-green/10 flex items-center justify-center">
          <Zap size={28} className="text-kyn-green" />
        </div>
        <p className="mt-4 font-display font-bold tracking-[0.25em]">KYNETIK</p>
        <p className="text-[11px] text-kyn-metal mt-1">L'énergie en mouvement</p>
        <p className="text-[10px] text-kyn-green mt-3">App version 2.4.0 (build 884)</p>
        <div className="mt-8 w-full space-y-2 text-[11px]">
          {['Terms of use', 'Privacy policy', 'Open source licenses', 'Rate the app'].map((l) => (
            <div key={l} className="flex justify-between rounded-xl border border-white/8 bg-kyn-steel/30 px-3 py-3">
              <span>{l}</span>
              <ChevronRight size={12} className="text-kyn-metal" />
            </div>
          ))}
        </div>
        <p className="mt-auto mb-8 text-[9px] text-kyn-metal">© KYNETIK · Tunisie</p>
      </div>
    </div>
  );
}

import { useEffect, useState, type ReactNode } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, ArrowRight } from 'lucide-react';
import BrandLogo from '../BrandLogo';
import { cn } from '../../lib/utils';

const nav = [
  { to: '/products', label: 'All Products' },
  { to: '/products/go', label: 'GO' },
  { to: '/products/flex', label: 'FLEX' },
  { to: '/products/nova', label: 'NOVA' },
  { to: '/products/prime', label: 'PRIME' },
  { to: '/products/edge', label: 'EDGE' },
  { to: '/products/pro', label: 'PRO' },
  { to: '/products/compare', label: 'Compare' },
];

export default function ProductShell({
  children,
  ctaLabel = 'Request quote',
  ctaHref = '#quote',
}: {
  children: ReactNode;
  ctaLabel?: string;
  ctaHref?: string;
}) {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const { pathname } = useLocation();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <div className="min-h-screen bg-kyn-black text-white">
      <header
        className={cn(
          'fixed top-0 inset-x-0 z-50 transition-all duration-300',
          scrolled ? 'bg-kyn-black/85 backdrop-blur-xl border-b border-white/5' : 'bg-transparent'
        )}
      >
        <div className="max-w-7xl mx-auto px-5 md:px-8 h-16 md:h-[4.5rem] flex items-center justify-between gap-4">
          <Link to="/" className="flex items-center gap-3 shrink-0">
            <BrandLogo height={28} />
          </Link>
          <nav className="hidden xl:flex items-center gap-6 text-[11px] font-medium tracking-wide text-kyn-silver">
            {nav.map((item) => (
              <Link
                key={item.to}
                to={item.to}
                className={cn(
                  'hover:text-white transition-colors',
                  pathname === item.to || (item.to !== '/products' && pathname.startsWith(item.to))
                    ? 'text-kyn-green'
                    : ''
                )}
              >
                {item.label}
              </Link>
            ))}
          </nav>
          <div className="flex items-center gap-2 sm:gap-3">
            <Link to="/cloud" className="hidden md:inline text-[11px] text-kyn-metal hover:text-white">
              Cloud
            </Link>
            <a
              href={ctaHref}
              className="hidden sm:inline-flex items-center gap-1.5 px-4 py-2 rounded-full bg-kyn-green text-kyn-black text-[11px] font-bold"
            >
              {ctaLabel} <ArrowRight size={12} />
            </a>
            <button type="button" className="xl:hidden p-2 text-kyn-silver" onClick={() => setOpen(!open)} aria-label="Menu">
              {open ? <X size={18} /> : <Menu size={18} />}
            </button>
          </div>
        </div>
        {open && (
          <div className="xl:hidden border-t border-white/5 bg-kyn-void/95 backdrop-blur-xl px-5 py-4 space-y-1">
            {nav.map((item) => (
              <Link
                key={item.to}
                to={item.to}
                onClick={() => setOpen(false)}
                className="block py-2.5 text-sm text-kyn-silver hover:text-white"
              >
                {item.label}
              </Link>
            ))}
            <a href={ctaHref} className="mt-2 block text-center rounded-full bg-kyn-green text-kyn-black text-xs font-bold py-3">
              {ctaLabel}
            </a>
          </div>
        )}
      </header>
      {children}
      <footer className="border-t border-white/5 py-10">
        <div className="max-w-7xl mx-auto px-5 md:px-8 flex flex-wrap items-center justify-between gap-4">
          <BrandLogo height={26} />
          <p className="text-[11px] text-kyn-metal">© KYNETIK · Product System · L'énergie en mouvement</p>
          <div className="flex gap-4 text-[11px] text-kyn-metal">
            <Link to="/" className="hover:text-white">Home</Link>
            <Link to="/products" className="hover:text-white">Products</Link>
            <Link to="/cloud" className="hover:text-white">Cloud</Link>
          </div>
        </div>
      </footer>
    </div>
  );
}

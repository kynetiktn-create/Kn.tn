import { cn } from '../lib/utils';

interface Props {
  eyebrow?: string;
  title: string;
  description?: string;
  className?: string;
}

export default function SectionHeader({ eyebrow, title, description, className }: Props) {
  return (
    <div className={cn('mb-10', className)}>
      {eyebrow && (
        <p className="text-kyn-green text-xs font-semibold tracking-[0.25em] uppercase mb-3">
          {eyebrow}
        </p>
      )}
      <h1 className="font-display text-3xl md:text-4xl lg:text-5xl font-bold text-white tracking-tight">
        {title}
      </h1>
      {description && (
        <p className="mt-4 text-kyn-metal max-w-2xl text-base md:text-lg leading-relaxed">
          {description}
        </p>
      )}
      <div className="energy-line mt-6 max-w-xs" />
    </div>
  );
}

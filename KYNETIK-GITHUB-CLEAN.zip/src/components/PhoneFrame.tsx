import type { ReactNode } from 'react';
import { cn } from '../lib/utils';

interface Props {
  children: ReactNode;
  className?: string;
  label?: string;
  width?: number;
}

export default function PhoneFrame({ children, className, label, width = 280 }: Props) {
  return (
    <div className={cn('flex flex-col items-center', className)}>
      <div
        className="phone-frame rounded-[2.6rem] p-2.5 relative overflow-hidden shrink-0"
        style={{ width, height: width * 2.08 }}
      >
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-28 h-6 bg-black rounded-b-2xl z-30" />
        <div className="w-full h-full rounded-[2.1rem] overflow-hidden bg-kyn-black relative">
          {children}
        </div>
      </div>
      {label && <p className="mt-4 text-sm font-medium text-kyn-silver text-center">{label}</p>}
    </div>
  );
}

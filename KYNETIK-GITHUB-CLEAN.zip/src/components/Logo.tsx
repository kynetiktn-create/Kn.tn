import { cn } from '../lib/utils';

interface LogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showWordmark?: boolean;
  className?: string;
  glowing?: boolean;
  variant?: 'white' | 'dark';
}

const heights = { sm: 22, md: 30, lg: 42, xl: 68 } as const;
const V = 'bolt1';

/**
 * KYNETIK bolt mark / full lockup
 */
export default function Logo({
  size = 'md',
  showWordmark = true,
  className,
  glowing,
  variant = 'white',
}: LogoProps) {
  const h = heights[size];
  const mark = `/images/kynetik-mark-white.png?v=${V}`;
  const word =
    variant === 'white'
      ? `/images/kynetik-logo-white.png?v=${V}`
      : `/images/kynetik-logo-dark.png?v=${V}`;

  if (showWordmark) {
    return (
      <div className={cn('inline-flex items-center', className)}>
        <img
          src={word}
          alt="KYNETIK"
          style={{ height: h }}
          className={cn(
            'w-auto object-contain',
            glowing && 'drop-shadow-[0_0_18px_rgba(0,230,118,0.35)]'
          )}
          draggable={false}
        />
      </div>
    );
  }

  return (
    <div className={cn('inline-flex items-center', className)}>
      <img
        src={mark}
        alt="KYNETIK"
        style={{ height: h, width: h }}
        className={cn(
          'object-contain',
          glowing && 'drop-shadow-[0_0_16px_rgba(0,230,118,0.45)]'
        )}
        draggable={false}
      />
    </div>
  );
}

import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Layout from './components/LayoutWritable';
import Overview from './pages/Overview';
import Brand from './pages/Brand';
import Products from './pages/Products';
import Social from './pages/Social';
import MobileApp from './pages/MobileApp';
import Website from './pages/Website';
import Cloud from './pages/Cloud';
import CloudDashboard from './pages/CloudDashboard';
import KynetikCloudPlatform from './pages/KynetikCloudPlatform';
import CloudSaaS from './pages/CloudSaaS';
import CloudWebsite from './pages/CloudWebsite';
import ProductSystemPage from './pages/ProductSystemPage';
import ProductConfigurator from './pages/ProductConfigurator';
import ProductCatalog from './pages/products/ProductCatalog';
import ProductDetail from './pages/products/ProductDetail';
import ProductCompare from './pages/products/ProductCompare';
import AppLanding from './pages/AppLanding';
import KynetikMobileApp from './pages/KynetikMobileApp';
import Academy from './pages/Academy';
import Investor from './pages/Investor';
import Stationery from './pages/Stationery';
import UITokens from './pages/UITokens';
import DesignSystemTokens from './pages/DesignSystemTokens';
import DesignSystemHub from './pages/DesignSystemHub';
import Prototype from './pages/Prototype';
import Handoff from './pages/Handoff';
import DeveloperHandoff from './pages/DeveloperHandoff';
import DeliveryArchitecture from './pages/DeliveryArchitecture';
import Showcase from './pages/Showcase';
import ProductionAssets from './pages/ProductionAssets';
import HomePage from './pages/HomePage';
import SiteHome from './pages/SiteHome';
import BrandMarketingLaunch from './pages/BrandMarketingLaunch';
import SalesSystem from './pages/SalesSystem';
import OperationalBlueprint from './pages/OperationalBlueprint';
import EnterpriseArchitecture from './pages/EnterpriseArchitecture';
import ProductRequirements from './pages/ProductRequirements';
import EnterpriseEngineeringPack from './pages/EnterpriseEngineeringPack';
import OcppCsmsConsole from './pages/OcppCsmsConsole';
import CsmsDashboard from './pages/CsmsDashboard';
import BrandExperience from './pages/BrandExperience';
import AIDashboard from './pages/AIDashboard';
import AIPlatform from './pages/AIPlatform';
import EnergyAdvisor from './pages/EnergyAdvisor';
import PredictiveMaintenance from './pages/PredictiveMaintenance';
import Maintenance from './pages/Maintenance';
import InstallerDashboard from './pages/InstallerDashboard';
import InstallationDetails from './pages/InstallationDetails';
import InstallerCalendar from './pages/InstallerCalendar';
import DesignBible from './pages/DesignBible';
import ComponentLibrary from './pages/ComponentLibrary';
import ProductSpec from './pages/ProductSpec';
import UxJourneys from './pages/UxJourneys';
import MasterDocumentation from './pages/MasterDocumentation';
import DocumentationSuite from './pages/DocumentationSuite';
import DatabaseArchitecture from './pages/DatabaseArchitecture';

import MarketingHub from './pages/marketing/MarketingHub';
import ContactPage from './pages/marketing/ContactPage';
import QuotePage from './pages/marketing/QuotePage';
import InstallerPage from './pages/marketing/InstallerPage';
import DistributorPage from './pages/marketing/DistributorPage';
import SuccessStoriesPage from './pages/marketing/SuccessStoriesPage';
import ResourcesPage from './pages/marketing/ResourcesPage';
import FaqPage from './pages/marketing/FaqPage';
import SupportPage from './pages/marketing/SupportPage';
import AcademyLandingPage from './pages/marketing/AcademyLandingPage';
import CareersPage from './pages/marketing/CareersPage';
import CustomerPortal from './pages/portal/CustomerPortal';
import AdminPortal from './pages/admin/AdminPortal';
import {
  DevShell, DevHome, DevDocs, DevSdks, DevWebhooks, DevPlayground,
  DevDashboard, DevKeys, DevStatus, DevSearch, DevCommunity,
} from './pages/devplatform';

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/* Developer Platform */}
        <Route path="/developers" element={<DevShell />}>
          <Route index element={<DevHome />} />
          <Route path="docs" element={<DevDocs />} />
          <Route path="sdks" element={<DevSdks />} />
          <Route path="webhooks" element={<DevWebhooks />} />
          <Route path="playground" element={<DevPlayground />} />
          <Route path="dashboard" element={<DevDashboard />} />
          <Route path="keys" element={<DevKeys />} />
          <Route path="status" element={<DevStatus />} />
          <Route path="search" element={<DevSearch />} />
          <Route path="community" element={<DevCommunity />} />
        </Route>
        <Route path="/dev" element={<DevShell />}>
          <Route index element={<DevHome />} />
          <Route path="docs" element={<DevDocs />} />
          <Route path="sdks" element={<DevSdks />} />
          <Route path="webhooks" element={<DevWebhooks />} />
          <Route path="playground" element={<DevPlayground />} />
          <Route path="dashboard" element={<DevDashboard />} />
          <Route path="keys" element={<DevKeys />} />
          <Route path="status" element={<DevStatus />} />
          <Route path="search" element={<DevSearch />} />
          <Route path="community" element={<DevCommunity />} />
        </Route>
        <Route path="/api-docs" element={<DevShell />}>
          <Route index element={<DevHome />} />
          <Route path="*" element={<DevDocs />} />
        </Route>

        {/* Enterprise Admin Portal — global command center */}
        <Route path="/admin" element={<AdminPortal />} />
        <Route path="/admin/:section" element={<AdminPortal />} />
        <Route path="/enterprise" element={<AdminPortal />} />
        <Route path="/enterprise/:section" element={<AdminPortal />} />

        {/* Customer Account Portal */}
        <Route path="/portal/*" element={<CustomerPortal />} />
        <Route path="/account/*" element={<CustomerPortal />} />
        <Route path="/my-account/*" element={<CustomerPortal />} />

        {/* Public website (FRD Volume 01) */}
        <Route path="/" element={<SiteHome />} />
        <Route path="/phase-21" element={<SiteHome />} />
        <Route path="/brand-launch" element={<BrandMarketingLaunch />} />
        <Route path="/marketing-launch" element={<BrandMarketingLaunch />} />
        <Route path="/phase-22" element={<BrandMarketingLaunch />} />
        <Route path="/gtm" element={<BrandMarketingLaunch />} />
        <Route path="/sales" element={<SalesSystem />} />
        <Route path="/sales-system" element={<SalesSystem />} />
        <Route path="/commercial" element={<SalesSystem />} />
        <Route path="/phase-23" element={<SalesSystem />} />
        <Route path="/ops" element={<OperationalBlueprint />} />
        <Route path="/operations" element={<OperationalBlueprint />} />
        <Route path="/operational-blueprint" element={<OperationalBlueprint />} />
        <Route path="/phase-24" element={<OperationalBlueprint />} />
        <Route path="/sop" element={<OperationalBlueprint />} />
        <Route path="/architecture" element={<EnterpriseArchitecture />} />
        <Route path="/enterprise-architecture" element={<EnterpriseArchitecture />} />
        <Route path="/tech-stack" element={<EnterpriseArchitecture />} />
        <Route path="/phase-25" element={<EnterpriseArchitecture />} />
        <Route path="/stack" element={<EnterpriseArchitecture />} />
        <Route path="/prd" element={<ProductRequirements />} />
        <Route path="/product-requirements" element={<ProductRequirements />} />
        <Route path="/requirements" element={<ProductRequirements />} />
        <Route path="/phase-26" element={<ProductRequirements />} />
        <Route path="/product-prd" element={<ProductRequirements />} />
        <Route path="/engineering-pack" element={<EnterpriseEngineeringPack />} />
        <Route path="/enterprise-pack" element={<EnterpriseEngineeringPack />} />
        <Route path="/eng-pack" element={<EnterpriseEngineeringPack />} />
        <Route path="/sad" element={<EnterpriseEngineeringPack />} />
        <Route path="/openapi" element={<EnterpriseEngineeringPack />} />
        <Route path="/api-spec" element={<EnterpriseEngineeringPack />} />
        <Route path="/devops-guide" element={<EnterpriseEngineeringPack />} />
        <Route path="/test-strategy" element={<EnterpriseEngineeringPack />} />
        <Route path="/ops-manual" element={<EnterpriseEngineeringPack />} />
        <Route path="/cybersecurity" element={<EnterpriseEngineeringPack />} />
        <Route path="/phase-27" element={<EnterpriseEngineeringPack />} />

        <Route path="/website-premium" element={<SiteHome />} />
        {/* Installer Field Dashboard + Calendar */}
        <Route path="/calendar" element={<InstallerCalendar />} />
        <Route path="/installer-calendar" element={<InstallerCalendar />} />
        <Route path="/installer/calendar" element={<InstallerCalendar />} />
        <Route path="/installer" element={<InstallerDashboard />} />
        <Route path="/installer-dashboard" element={<InstallerDashboard />} />
        <Route path="/installation" element={<InstallationDetails />} />
        <Route path="/installation-details" element={<InstallationDetails />} />
        <Route path="/installer/installation" element={<InstallationDetails />} />

        {/* Premium website & product surfaces */}
        <Route path="/site" element={<SiteHome />} />
        <Route path="/website-home" element={<SiteHome />} />
        <Route path="/home" element={<SiteHome />} />
        <Route path="/home-classic" element={<HomePage />} />
        <Route path="/design-bible" element={<DesignBible />} />
        <Route path="/bible" element={<DesignBible />} />
        <Route path="/ui-library" element={<ComponentLibrary />} />
        <Route path="/design-system/hub" element={<DesignSystemHub />} />
        <Route path="/ds" element={<DesignSystemHub />} />
        <Route path="/design-system/tokens" element={<DesignSystemTokens />} />
        <Route path="/ds-tokens" element={<DesignSystemTokens />} />
        <Route path="/system-tokens" element={<DesignSystemTokens />} />
        <Route path="/components" element={<ComponentLibrary />} />
        <Route path="/component-library" element={<ComponentLibrary />} />
        <Route path="/design-system/components" element={<ComponentLibrary />} />
        <Route path="/product-spec" element={<ProductSpec />} />
        <Route path="/product-specification" element={<ProductSpec />} />
        <Route path="/spec" element={<ProductSpec />} />
        <Route path="/ux-journeys" element={<UxJourneys />} />
        <Route path="/ux-flows" element={<UxJourneys />} />
        <Route path="/user-journeys" element={<UxJourneys />} />
        <Route path="/journeys" element={<UxJourneys />} />
        <Route path="/docs-suite" element={<DocumentationSuite />} />
        <Route path="/documentation-suite" element={<DocumentationSuite />} />
        <Route path="/product-documentation-suite" element={<DocumentationSuite />} />
        <Route path="/master-docs" element={<DocumentationSuite />} />
        <Route path="/master-documentation" element={<DocumentationSuite />} />
        <Route path="/documentation" element={<DocumentationSuite />} />
        <Route path="/docs/master" element={<DocumentationSuite />} />
        <Route path="/product-documentation" element={<DocumentationSuite />} />
        <Route path="/master-docs-v2" element={<MasterDocumentation />} />
        <Route path="/database" element={<DatabaseArchitecture />} />
        <Route path="/db-architecture" element={<DatabaseArchitecture />} />
        <Route path="/data-model" element={<DatabaseArchitecture />} />
        <Route path="/database-architecture" element={<DatabaseArchitecture />} />
        <Route path="/experience" element={<BrandExperience />} />
        <Route path="/brand-experience" element={<BrandExperience />} />
        <Route path="/cloud" element={<CloudWebsite />} />
        <Route path="/cloud-saas" element={<CloudSaaS />} />
        <Route path="/products" element={<ProductCatalog />} />
        <Route path="/products/compare" element={<ProductCompare />} />
        <Route path="/compare" element={<ProductCompare />} />
        <Route path="/products/:slug" element={<ProductDetail />} />
        <Route path="/product-system" element={<ProductSystemPage />} />
        <Route path="/configurator" element={<ProductConfigurator />} />
        <Route path="/configure" element={<ProductConfigurator />} />
        <Route path="/app-landing" element={<AppLanding />} />
        <Route path="/kynetik-app" element={<KynetikMobileApp />} />
        <Route path="/mobile-app" element={<KynetikMobileApp />} />
        <Route path="/app-ux" element={<KynetikMobileApp />} />
        <Route path="/phase-19" element={<KynetikMobileApp />} />
        <Route path="/kynetik-mobile" element={<KynetikMobileApp />} />

        {/* Marketing & Sales Ecosystem */}
        <Route path="/grow" element={<MarketingHub />} />
        <Route path="/marketing" element={<MarketingHub />} />
        <Route path="/contact" element={<ContactPage />} />
        <Route path="/investors" element={<Investor />} />
        <Route path="/investir" element={<Investor />} />
        <Route path="/solutions" element={<SiteHome />} />
        <Route path="/partners" element={<InstallerPage />} />
        <Route path="/devenir-partenaire" element={<InstallerPage />} />
        <Route path="/quote" element={<QuotePage />} />
        <Route path="/installers" element={<InstallerPage />} />
        <Route path="/become-installer" element={<InstallerPage />} />
        <Route path="/distributors" element={<DistributorPage />} />
        <Route path="/become-distributor" element={<DistributorPage />} />
        <Route path="/success-stories" element={<SuccessStoriesPage />} />
        <Route path="/stories" element={<SuccessStoriesPage />} />
        <Route path="/resources" element={<ResourcesPage />} />
        <Route path="/faq" element={<FaqPage />} />
        <Route path="/support" element={<SupportPage />} />
        <Route path="/academy-landing" element={<AcademyLandingPage />} />
        <Route path="/careers" element={<CareersPage />} />

        {/* Operator console */}
        <Route path="/cloud-platform" element={<KynetikCloudPlatform />} />
        <Route path="/kynetik-cloud" element={<KynetikCloudPlatform />} />
        <Route path="/phase-20" element={<KynetikCloudPlatform />} />
        <Route path="/saas" element={<KynetikCloudPlatform />} />
        <Route path="/console" element={<CloudDashboard />} />
        <Route path="/ocpp" element={<OcppCsmsConsole />} />
        <Route path="/ocpp-csms" element={<OcppCsmsConsole />} />
        <Route path="/csms" element={<CsmsDashboard />} />
        <Route path="/csms-dashboard" element={<CsmsDashboard />} />
        <Route path="/charge-station-management" element={<CsmsDashboard />} />
        <Route path="/csms/ops" element={<CsmsDashboard />} />
        <Route path="/phase-29" element={<CsmsDashboard />} />
        <Route path="/ocpp-console" element={<OcppCsmsConsole />} />
        <Route path="/phase-28" element={<OcppCsmsConsole />} />
        <Route path="/cloud-dashboard" element={<CloudDashboard />} />

        {/* AI surfaces */}
        <Route path="/ai-platform" element={<AIPlatform />} />
        <Route path="/ai/platform" element={<AIPlatform />} />
        <Route path="/kynetik-ai" element={<AIPlatform />} />
        <Route path="/ai" element={<AIPlatform />} />
        <Route path="/ai-dashboard" element={<AIDashboard />} />
        <Route path="/ai/dashboard" element={<AIDashboard />} />
        <Route path="/energy-advisor" element={<EnergyAdvisor />} />
        <Route path="/ai-energy" element={<EnergyAdvisor />} />
        <Route path="/ai/energy-advisor" element={<EnergyAdvisor />} />
        <Route path="/predictive-maintenance" element={<PredictiveMaintenance />} />
        <Route path="/ai/predictive-maintenance" element={<PredictiveMaintenance />} />
        <Route path="/maintenance" element={<Maintenance />} />
        <Route path="/ops/maintenance" element={<Maintenance />} />
        <Route path="/field/maintenance" element={<Maintenance />} />

        {/* Prototype / Handoff / Showcase / Production / Experience */}
        <Route path="/prototype" element={<Prototype />} />
        <Route path="/handoff" element={<Handoff />} />
        <Route path="/dev-handoff" element={<DeveloperHandoff />} />
        <Route path="/developer-handoff" element={<DeveloperHandoff />} />
        <Route path="/handoff/dev" element={<DeveloperHandoff />} />
        <Route path="/delivery" element={<DeliveryArchitecture />} />
        <Route path="/phases" element={<DeliveryArchitecture />} />
        <Route path="/digital-architecture" element={<DeliveryArchitecture />} />
        <Route path="/showcase" element={<Showcase />} />
        <Route path="/production" element={<ProductionAssets />} />
        <Route path="/assets" element={<ProductionAssets />} />

        {/* Design system hub */}
        <Route element={<Layout />}>
          <Route path="design-system" element={<Overview />} />
          <Route path="hub" element={<DesignSystemHub />} />
          <Route path="brand" element={<Brand />} />
          <Route path="catalog" element={<Products />} />
          <Route path="social" element={<Social />} />
          <Route path="app" element={<MobileApp />} />
          <Route path="website" element={<Website />} />
          <Route path="cloud-console" element={<Cloud />} />
          <Route path="academy" element={<Academy />} />
          <Route path="tokens" element={<UITokens />} />
          <Route path="ds-tokens" element={<DesignSystemTokens />} />
          <Route path="system-tokens" element={<DesignSystemTokens />} />
          <Route path="investor" element={<Investor />} />
          <Route path="stationery" element={<Stationery />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

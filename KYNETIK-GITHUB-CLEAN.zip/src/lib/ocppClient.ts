/**
 * KYNETIK OCPP data client for Dashboard + Mobile.
 * Talks to Supabase-backed OCPP tables (same schema as ocpp-csms CSMS).
 * Full WebSocket CSMS lives in /ocpp-csms (Node process).
 */

const url = import.meta.env.VITE_SUPABASE_URL || import.meta.env.NEXT_PUBLIC_SUPABASE_URL;
const key = import.meta.env.VITE_SUPABASE_ANON_KEY || import.meta.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

function headers(extra: Record<string, string> = {}) {
  return {
    apikey: key as string,
    Authorization: `Bearer ${key}`,
    'Content-Type': 'application/json',
    Prefer: 'return=representation',
    ...extra,
  };
}

async function rest<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`${url}/rest/v1/${path}`, {
    ...init,
    headers: { ...headers(), ...(init?.headers || {}) },
  });
  if (!res.ok) {
    const err = await res.text();
    throw new Error(err || res.statusText);
  }
  if (res.status === 204) return undefined as T;
  const text = await res.text();
  return (text ? JSON.parse(text) : null) as T;
}

export type OcppStation = {
  id?: number;
  charge_point_id: string;
  vendor?: string;
  model?: string;
  serial_number?: string;
  firmware_version?: string;
  status?: string;
  registration_status?: string;
  protocol?: string;
  connected?: boolean;
  site_name?: string;
  city?: string;
  last_heartbeat?: string;
  last_boot?: string;
  heartbeat_interval?: number;
  auth_key?: string;
  configuration?: Record<string, string>;
};

export type OcppConnector = {
  id?: number;
  charge_point_id: string;
  connector_id: number;
  status?: string;
  error_code?: string;
  availability?: string;
  power_kw?: number;
  meter_wh?: number;
  current_transaction_id?: number | null;
};

export type OcppTransaction = {
  id?: number;
  transaction_id: number;
  charge_point_id: string;
  connector_id?: number;
  id_tag?: string;
  meter_start?: number;
  meter_stop?: number;
  start_timestamp?: string;
  stop_timestamp?: string;
  stop_reason?: string;
  status?: string;
  energy_kwh?: number;
  cost?: number;
  currency?: string;
};

export const ocppClient = {
  async health() {
    const stations = await rest<OcppStation[]>('ocpp_stations?select=charge_point_id,connected,status');
    return {
      ok: true,
      service: 'kynetik-ocpp-api',
      protocol: 'OCPP 1.6J JSON',
      stations: stations.length,
      online: stations.filter((s) => s.connected || s.status === 'online' || s.status === 'charging').length,
      csms: 'ocpp-csms/',
      websocket: 'ws(s)://<csms-host>/ocpp/{chargePointId}',
      time: new Date().toISOString(),
    };
  },

  listStations() {
    return rest<OcppStation[]>('ocpp_stations?select=*&order=charge_point_id');
  },

  async getStation(chargePointId: string) {
    const stations = await rest<OcppStation[]>(
      `ocpp_stations?charge_point_id=eq.${encodeURIComponent(chargePointId)}&select=*`
    );
    const st = stations[0];
    if (!st) throw new Error('Station not found');
    const connectors = await rest<OcppConnector[]>(
      `ocpp_connectors?charge_point_id=eq.${encodeURIComponent(chargePointId)}&select=*&order=connector_id`
    );
    return { ...st, connectors };
  },

  async registerStation(body: Partial<OcppStation> & { charge_point_id: string; connectors?: number[] }) {
    const row = {
      charge_point_id: body.charge_point_id,
      vendor: body.vendor || 'KYNETIK',
      model: body.model || 'NOVA',
      serial_number: body.serial_number || null,
      firmware_version: body.firmware_version || '1.0.0',
      status: 'registered',
      registration_status: 'Accepted',
      protocol: 'ocpp1.6',
      auth_key: body.auth_key || null,
      site_name: body.site_name || null,
      city: body.city || null,
      connected: false,
      heartbeat_interval: body.heartbeat_interval || 60,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };
    const data = await rest<OcppStation[]>('ocpp_stations', { method: 'POST', body: JSON.stringify(row) });
    const connectors = body.connectors?.length ? body.connectors : [1];
    for (const c of connectors) {
      await rest('ocpp_connectors', {
        method: 'POST',
        body: JSON.stringify({
          charge_point_id: body.charge_point_id,
          connector_id: c,
          status: 'Available',
          error_code: 'NoError',
          availability: 'Operative',
          meter_wh: 0,
          power_kw: 0,
          updated_at: new Date().toISOString(),
        }),
      });
    }
    await ocppClient.audit('REGISTER_STATION', body.charge_point_id, body);
    return Array.isArray(data) ? data[0] : data;
  },

  listConnectors(chargePointId?: string) {
    const q = chargePointId
      ? `ocpp_connectors?charge_point_id=eq.${encodeURIComponent(chargePointId)}&select=*&order=connector_id`
      : 'ocpp_connectors?select=*&order=charge_point_id';
    return rest<OcppConnector[]>(q);
  },

  listTransactions(params: { charge_point_id?: string; status?: string; limit?: number } = {}) {
    const parts = ['select=*', 'order=start_timestamp.desc', `limit=${params.limit || 100}`];
    if (params.charge_point_id) parts.push(`charge_point_id=eq.${encodeURIComponent(params.charge_point_id)}`);
    if (params.status) parts.push(`status=eq.${encodeURIComponent(params.status)}`);
    return rest<OcppTransaction[]>(`ocpp_transactions?${parts.join('&')}`);
  },

  async energyReport(chargePointId?: string) {
    const list = await ocppClient.listTransactions({ charge_point_id: chargePointId, limit: 1000 });
    const completed = list.filter((r) => r.status === 'completed' || r.energy_kwh);
    const total_kwh = completed.reduce((s, r) => s + Number(r.energy_kwh || 0), 0);
    const total_cost = completed.reduce((s, r) => s + Number(r.cost || 0), 0);
    const by_station: Record<string, { charge_point_id: string; sessions: number; energy_kwh: number; cost: number }> = {};
    for (const r of completed) {
      const k = r.charge_point_id || 'unknown';
      if (!by_station[k]) by_station[k] = { charge_point_id: k, sessions: 0, energy_kwh: 0, cost: 0 };
      by_station[k].sessions += 1;
      by_station[k].energy_kwh += Number(r.energy_kwh || 0);
      by_station[k].cost += Number(r.cost || 0);
    }
    return {
      total_sessions: completed.length,
      total_kwh: Number(total_kwh.toFixed(3)),
      total_cost: Number(total_cost.toFixed(3)),
      currency: 'TND',
      by_station: Object.values(by_station),
      sessions: list.slice(0, 50),
    };
  },

  listIdTags() {
    return rest<{ id_tag: string; status?: string; label?: string; user_id?: string }[]>(
      'ocpp_id_tags?select=*&order=id_tag'
    );
  },

  async upsertIdTag(body: { id_tag: string; status?: string; label?: string; user_id?: string }) {
    return rest('ocpp_id_tags', {
      method: 'POST',
      headers: { Prefer: 'resolution=merge-duplicates,return=representation' },
      body: JSON.stringify({ ...body, created_at: new Date().toISOString() }),
    });
  },

  listUsers() {
    return rest('ocpp_users?select=*&order=created_at.desc');
  },

  listEvents(chargePointIdOrOpts?: string | { charge_point_id?: string; limit?: number }, limit = 50) {
    let chargePointId: string | undefined;
    let lim = limit;
    if (typeof chargePointIdOrOpts === 'object' && chargePointIdOrOpts) {
      chargePointId = chargePointIdOrOpts.charge_point_id;
      lim = chargePointIdOrOpts.limit ?? 50;
    } else {
      chargePointId = chargePointIdOrOpts;
    }
    const parts = ['select=*', 'order=created_at.desc', `limit=${lim}`];
    if (chargePointId) parts.push(`charge_point_id=eq.${encodeURIComponent(chargePointId)}`);
    return rest(`ocpp_event_logs?${parts.join('&')}`);
  },

  listAudit(limit = 50) {
    return rest(`ocpp_audit_logs?select=*&order=created_at.desc&limit=${limit}`);
  },

  listCommands(chargePointIdOrOpts?: string | { charge_point_id?: string; limit?: number }) {
    let chargePointId: string | undefined;
    let lim = 50;
    if (typeof chargePointIdOrOpts === 'object' && chargePointIdOrOpts) {
      chargePointId = chargePointIdOrOpts.charge_point_id;
      lim = chargePointIdOrOpts.limit ?? 50;
    } else {
      chargePointId = chargePointIdOrOpts;
    }
    const parts = ['select=*', 'order=created_at.desc', `limit=${lim}`];
    if (chargePointId) parts.push(`charge_point_id=eq.${encodeURIComponent(chargePointId)}`);
    return rest(`ocpp_pending_commands?${parts.join('&')}`);
  },

  listMeterValues(chargePointId?: string) {
    const parts = ['select=*', 'order=created_at.desc', 'limit=100'];
    if (chargePointId) parts.push(`charge_point_id=eq.${encodeURIComponent(chargePointId)}`);
    return rest(`ocpp_meter_values?${parts.join('&')}`);
  },

  async audit(action: string, resourceId: string, details: unknown) {
    return rest('ocpp_audit_logs', {
      method: 'POST',
      body: JSON.stringify({
        actor: 'dashboard',
        role: 'operator',
        action,
        resource: 'ocpp_stations',
        resource_id: resourceId,
        details,
        created_at: new Date().toISOString(),
      }),
    });
  },

  async logEvent(chargePointId: string, action: string, payload: unknown, direction = 'out') {
    return rest('ocpp_event_logs', {
      method: 'POST',
      body: JSON.stringify({
        charge_point_id: chargePointId,
        direction,
        action,
        message_id: `cmd_${Date.now()}`,
        message_type: 2,
        payload,
        created_at: new Date().toISOString(),
      }),
    });
  },

  /**
   * Queue CSMS command + apply optimistic DB effects for dashboard UX.
   * When ocpp-csms WS node is running, it executes the real OCPP CALL.
   */
  async command(chargePointId: string, action: string, payload: Record<string, unknown> = {}) {
    const command_id = `cmd_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    const ocppAction = action;
    await rest('ocpp_pending_commands', {
      method: 'POST',
      body: JSON.stringify({
        command_id,
        charge_point_id: chargePointId,
        action: ocppAction,
        payload,
        status: 'queued',
        requested_by: 'dashboard',
        created_at: new Date().toISOString(),
      }),
    });

    let result: Record<string, unknown> = {
      status: 'Accepted',
      note: 'Queued — execute via ocpp-csms WebSocket node when CP is online',
    };

    if (action === 'RemoteStartTransaction') {
      const txId = Math.floor(100000 + Math.random() * 800000);
      await rest('ocpp_transactions', {
        method: 'POST',
        body: JSON.stringify({
          transaction_id: txId,
          charge_point_id: chargePointId,
          connector_id: Number(payload.connectorId || 1),
          id_tag: payload.idTag || 'RFID-DEMO',
          meter_start: 0,
          start_timestamp: new Date().toISOString(),
          status: 'active',
          energy_kwh: 0,
          currency: 'TND',
          created_at: new Date().toISOString(),
        }),
      });
      await rest(
        `ocpp_connectors?charge_point_id=eq.${encodeURIComponent(chargePointId)}&connector_id=eq.${Number(payload.connectorId || 1)}`,
        {
          method: 'PATCH',
          body: JSON.stringify({
            status: 'Charging',
            current_transaction_id: txId,
            power_kw: 7.4,
            updated_at: new Date().toISOString(),
          }),
        }
      );
      await rest(`ocpp_stations?charge_point_id=eq.${encodeURIComponent(chargePointId)}`, {
        method: 'PATCH',
        body: JSON.stringify({ status: 'charging', updated_at: new Date().toISOString() }),
      });
      result = { status: 'Accepted', transactionId: txId };
    }

    if (action === 'RemoteStopTransaction') {
      const txId = Number(payload.transactionId);
      if (txId) {
        const txs = await rest<OcppTransaction[]>(`ocpp_transactions?transaction_id=eq.${txId}&select=*`);
        const tx = txs[0];
        const meterStop = Number(payload.meterStop || (tx?.meter_start || 0) + 12000);
        const energy = Math.max(0, (meterStop - Number(tx?.meter_start || 0)) / 1000);
        await rest(`ocpp_transactions?transaction_id=eq.${txId}`, {
          method: 'PATCH',
          body: JSON.stringify({
            status: 'completed',
            meter_stop: meterStop,
            stop_timestamp: new Date().toISOString(),
            stop_reason: 'Remote',
            energy_kwh: energy,
            cost: Number((energy * 0.45).toFixed(3)),
          }),
        });
      }
      await rest(`ocpp_connectors?charge_point_id=eq.${encodeURIComponent(chargePointId)}`, {
        method: 'PATCH',
        body: JSON.stringify({
          status: 'Available',
          current_transaction_id: null,
          power_kw: 0,
          updated_at: new Date().toISOString(),
        }),
      });
      await rest(`ocpp_stations?charge_point_id=eq.${encodeURIComponent(chargePointId)}`, {
        method: 'PATCH',
        body: JSON.stringify({ status: 'online', updated_at: new Date().toISOString() }),
      });
      result = { status: 'Accepted' };
    }

    if (action === 'Reset') {
      await rest(`ocpp_stations?charge_point_id=eq.${encodeURIComponent(chargePointId)}`, {
        method: 'PATCH',
        body: JSON.stringify({
          status: 'online',
          last_boot: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        }),
      });
    }

    if (action === 'UnlockConnector') {
      result = { status: 'Unlocked' };
    }

    if (action === 'ChangeConfiguration' && payload.key) {
      const st = await ocppClient.getStation(chargePointId);
      const conf = { ...(st.configuration || {}), [String(payload.key)]: String(payload.value) };
      await rest(`ocpp_stations?charge_point_id=eq.${encodeURIComponent(chargePointId)}`, {
        method: 'PATCH',
        body: JSON.stringify({ configuration: conf, updated_at: new Date().toISOString() }),
      });
      result = { status: 'Accepted' };
    }

    if (action === 'ChangeAvailability') {
      const connectorId = Number(payload.connectorId || 0);
      const type = String(payload.type || 'Operative');
      const status = type === 'Inoperative' ? 'Unavailable' : 'Available';
      if (connectorId > 0) {
        await rest(
          `ocpp_connectors?charge_point_id=eq.${encodeURIComponent(chargePointId)}&connector_id=eq.${connectorId}`,
          {
            method: 'PATCH',
            body: JSON.stringify({
              availability: type,
              status,
              updated_at: new Date().toISOString(),
            }),
          }
        );
      }
      result = { status: 'Accepted' };
    }

    if (action === 'ReserveNow') {
      await rest('ocpp_reservations', {
        method: 'POST',
        body: JSON.stringify({
          reservation_id: Math.floor(5000 + Math.random() * 9000),
          charge_point_id: chargePointId,
          connector_id: Number(payload.connectorId || 1),
          id_tag: payload.idTag,
          expiry_date: payload.expiryDate,
          status: 'accepted',
          created_at: new Date().toISOString(),
        }),
      });
      result = { status: 'Accepted' };
    }

    if (action === 'UpdateFirmware') {
      await rest('ocpp_firmware_jobs', {
        method: 'POST',
        body: JSON.stringify({
          job_id: command_id,
          charge_point_id: chargePointId,
          location: payload.location,
          retrieve_date: payload.retrieveDate || new Date().toISOString(),
          retries: payload.retries || 3,
          retry_interval: payload.retryInterval || 60,
          status: 'Pending',
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        }),
      });
    }

    if (action === 'SetChargingProfile') {
      const profile = (payload.csChargingProfiles || payload) as Record<string, unknown>;
      await rest('ocpp_charging_profiles', {
        method: 'POST',
        body: JSON.stringify({
          charging_profile_id: profile.chargingProfileId || 1,
          charge_point_id: chargePointId,
          connector_id: Number(payload.connectorId || 0),
          stack_level: profile.stackLevel || 0,
          charging_profile_purpose: profile.chargingProfilePurpose || 'TxDefaultProfile',
          charging_profile_kind: profile.chargingProfileKind || 'Absolute',
          charging_schedule: profile.chargingSchedule || {},
          status: 'active',
          created_at: new Date().toISOString(),
        }),
      });
      result = { status: 'Accepted' };
    }

    await rest(`ocpp_pending_commands?command_id=eq.${encodeURIComponent(command_id)}`, {
      method: 'PATCH',
      body: JSON.stringify({ status: 'completed', result, completed_at: new Date().toISOString() }),
    });
    await ocppClient.logEvent(chargePointId, ocppAction, payload);
    await ocppClient.audit(ocppAction, chargePointId, { payload, result, command_id });
    return { command_id, status: 'completed', result };
  },

  // ── CSMS dashboard extensions ──────────────────────────────────────
  async listAlerts(params: { status?: string; limit?: number } = {}) {
    let path = `csms_alerts?select=*&order=created_at.desc&limit=${params.limit || 100}`;
    if (params.status) path += `&status=eq.${encodeURIComponent(params.status)}`;
    return rest(path);
  },

  async resolveAlert(alertId: string) {
    return rest(`csms_alerts?alert_id=eq.${encodeURIComponent(alertId)}`, {
      method: 'PATCH',
      body: JSON.stringify({ status: 'resolved', resolved_at: new Date().toISOString() }),
    });
  },

  async listSessionsCsms(params: { status?: string; limit?: number } = {}) {
    let path = `csms_sessions?select=*&order=started_at.desc&limit=${params.limit || 100}`;
    if (params.status) path += `&status=eq.${encodeURIComponent(params.status)}`;
    return rest(path);
  },

  async listNotifications(userId?: string) {
    let path = `csms_notifications?select=*&order=created_at.desc&limit=50`;
    if (userId) path += `&or=(user_id.eq.${encodeURIComponent(userId)},user_id.eq.broadcast)`;
    return rest(path);
  },

  async listRoles() {
    return rest('csms_roles?select=*&order=sort_order.asc');
  },

  async listFavorites(userId: string) {
    return rest(`csms_favorites?select=*&user_id=eq.${encodeURIComponent(userId)}`);
  },

  async analyticsOverview() {
    const [stations, txs, alerts] = await Promise.all([
      this.listStations(),
      this.listTransactions({ limit: 500 }),
      this.listAlerts({ limit: 200 }),
    ]);
    const st = stations as any[];
    const tx = txs as any[];
    const al = alerts as any[];
    const active = tx.filter((t) => t.status === 'active');
    const completed = tx.filter((t) => t.status === 'completed');
    const energy = completed.reduce((s, t) => s + Number(t.energy_kwh || 0), 0);
    const revenue = completed.reduce((s, t) => s + Number(t.cost || 0), 0);
    return {
      stations_total: st.length,
      stations_online: st.filter((s) => s.connected).length,
      stations_charging: st.filter((s) => s.status === 'charging').length,
      active_sessions: active.length,
      completed_sessions: completed.length,
      energy_kwh: Number(energy.toFixed(3)),
      revenue: Number(revenue.toFixed(3)),
      currency: 'TND',
      open_alerts: al.filter((a) => a.status === 'open').length,
      critical_alerts: al.filter((a) => a.status === 'open' && a.severity === 'critical').length,
      utilization: st.length ? Number(((active.length / st.length) * 100).toFixed(1)) : 0,
      stations: st,
      transactions: tx,
      alerts: al,
    };
  },
};

export default ocppClient;

import { apiPost } from './utils';
import { supabaseBrowser } from './supabase';
import { track } from './analytics';

export type QuotePayload = {
  customer: Record<string, string>;
  project: { type: string };
  products: Array<Record<string, unknown>>;
  installation: Record<string, unknown>;
};

async function nextReferenceClient(): Promise<string> {
  const year = new Date().getFullYear();
  if (supabaseBrowser) {
    try {
      const { count } = await supabaseBrowser.from('quotes').select('*', { count: 'exact', head: true });
      const n = (count || 0) + 1;
      return `KY-${year}-${String(n).padStart(6, '0')}`;
    } catch {
      /* fall through */
    }
  }
  const seq = String(Date.now() % 1000000).padStart(6, '0');
  return `KY-${year}-${seq}`;
}

export async function submitQuote(payload: QuotePayload): Promise<{ status: string; reference: string }> {
  // 1) Preferred serverless route
  try {
    const res = await fetch('/api/quotes', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    if (res.ok) {
      const data = await res.json();
      return { status: 'success', reference: data.reference };
    }
    if (res.status !== 404) {
      const err = await res.json().catch(() => ({}));
      // continue to fallbacks unless validation error
      if (res.status >= 400 && res.status < 500 && res.status !== 404) {
        throw new Error(err.error || 'Validation failed');
      }
    }
  } catch (e: any) {
    if (e.message && e.message !== 'Failed to fetch' && !e.message.includes('fetch')) {
      // validation errors should bubble
      if (!String(e.message).toLowerCase().includes('network')) throw e;
    }
  }

  const reference = await nextReferenceClient();
  const c = payload.customer;
  const inst = payload.installation;

  // 2) Direct Supabase insert (anon key — works when RLS allows)
  if (supabaseBrowser) {
    try {
      const row = {
        reference,
        status: 'submitted',
        project_type: payload.project.type,
        customer_first_name: c.first_name,
        customer_last_name: c.last_name,
        customer_company: c.company || '',
        customer_email: c.email,
        customer_phone: c.phone,
        customer_address: c.address || '',
        preferred_language: c.language || 'fr',
        country: String(inst.country || ''),
        city: String(inst.city || ''),
        indoor_outdoor: String(inst.location || ''),
        parking_type: String(inst.parking_type || ''),
        chargers_count: Number(inst.chargers) || 1,
        electrical_phase: String(inst.phase || ''),
        desired_date: inst.desired_date ? String(inst.desired_date) : null,
        products_json: JSON.stringify(payload.products),
        project_json: JSON.stringify(payload.project),
        installation_json: JSON.stringify(payload.installation),
        customer_json: JSON.stringify(payload.customer),
        user_agent: typeof navigator !== 'undefined' ? navigator.userAgent : '',
      };
      const { error } = await supabaseBrowser.from('quotes').insert(row);
      if (!error) {
        await supabaseBrowser.from('marketing_leads').insert({
          type: 'quote',
          name: `${c.first_name} ${c.last_name}`.trim(),
          email: c.email,
          phone: c.phone,
          company: c.company || '',
          subject: `Quote ${reference} · ${payload.project.type}`,
          message: `Reference ${reference}`,
          payload: JSON.stringify({ reference, ...payload }),
          status: 'new',
        });
        await track('Quote Completed', { reference });
        return { status: 'success', reference };
      }
    } catch {
      /* fall through */
    }
  }

  // 3) Leads API fallback
  await apiPost('/api/leads', {
    type: 'quote',
    name: `${c.first_name} ${c.last_name}`.trim(),
    email: c.email,
    phone: c.phone,
    company: c.company || '',
    subject: `Quote ${reference} · ${payload.project.type}`,
    message: `Reference ${reference}`,
    payload: { reference, ...payload },
  });
  await track('Quote Completed', { reference });
  return { status: 'success', reference };
}

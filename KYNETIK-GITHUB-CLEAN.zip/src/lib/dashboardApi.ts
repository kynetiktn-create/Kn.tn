export async function apiGet<T = unknown>(path: string): Promise<T> {
  const res = await fetch(path);
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: res.statusText }));
    throw new Error(err.error || 'Request failed');
  }
  return res.json();
}

export async function apiSend<T = unknown>(path: string, method: string, body?: unknown): Promise<T> {
  const res = await fetch(path, {
    method,
    headers: { 'Content-Type': 'application/json' },
    body: body ? JSON.stringify(body) : undefined,
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: res.statusText }));
    throw new Error(err.error || 'Request failed');
  }
  return res.json();
}

export function cn(...classes: Array<string | false | null | undefined>) {
  return classes.filter(Boolean).join(' ');
}

export function statusColor(status: string) {
  const s = (status || '').toLowerCase();
  if (s === 'charging' || s === 'active' || s === 'online') return 'text-kyn-green bg-kyn-green/10 border-kyn-green/25';
  if (s === 'available' || s === 'completed' || s === 'success') return 'text-emerald-300 bg-emerald-500/10 border-emerald-500/25';
  if (s === 'offline' || s === 'fault' || s === 'error' || s === 'failed') return 'text-red-400 bg-red-500/10 border-red-500/25';
  if (s === 'maintenance' || s === 'warning' || s === 'pending') return 'text-amber-300 bg-amber-500/10 border-amber-500/25';
  return 'text-kyn-metal bg-white/5 border-white/10';
}

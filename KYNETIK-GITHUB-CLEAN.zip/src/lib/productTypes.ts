export interface ProductLine {
  id: number;
  slug: string;
  name: string;
  tagline: string;
  description: string;
  category: string;
  segment: string;
  powers: string;
  image_hero: string;
  image_gallery: string;
  specs: string;
  features: string;
  use_cases: string;
  vehicles: string;
  faq: string;
  downloads: string;
  install_steps: string;
  accent: string;
  sort_order: number;
}

export function parseJson<T>(raw: string | null | undefined, fallback: T): T {
  if (!raw) return fallback;
  try {
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

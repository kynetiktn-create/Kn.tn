import { supabaseBrowser } from './supabase';

export async function track(event: string, meta?: Record<string, unknown>) {
  const path = typeof window !== 'undefined' ? window.location.pathname : '';
  try {
    const res = await fetch('/api/analytics', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ event, path, meta }),
    });
    if (res.ok) return;
  } catch {
    /* fallback */
  }
  try {
    if (supabaseBrowser) {
      await supabaseBrowser.from('analytics_events').insert({
        event,
        path,
        meta: meta ? JSON.stringify(meta) : null,
        user_agent: typeof navigator !== 'undefined' ? navigator.userAgent : '',
      });
    }
  } catch {
    /* non-blocking */
  }
}

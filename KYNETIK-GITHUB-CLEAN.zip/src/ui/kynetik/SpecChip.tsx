import type { ReactNode } from 'react';
import { cn } from '../../lib/utils';

export function SpecChip({
  children,
  accent,
  className,
}: {
  children: ReactNode;
  accent?: boolean;
  className?: string;
}) {
  return (
    <span
      className={cn(
        'inline-flex items-center rounded-lg border px-2.5 py-1 font-mono text-[11px] tracking-tight',
        accent
          ? 'border-kyn-green/30 bg-kyn-green/10 text-kyn-green'
          : 'border-white/10 bg-white/[0.03] text-kyn-silver',
        className
      )}
    >
      {children}
    </span>
  );
}

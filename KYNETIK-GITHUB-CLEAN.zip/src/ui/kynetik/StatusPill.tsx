import type { ReactNode } from 'react';
import { cn } from '../../lib/utils';

export type StatusTone = 'online' | 'charging' | 'offline' | 'warning' | 'idle' | 'success' | 'info';

const tones: Record<StatusTone, string> = {
  online: 'text-kyn-green bg-kyn-green/10 border-kyn-green/25',
  charging: 'text-kyn-green-glow bg-kyn-green/15 border-kyn-green/35',
  offline: 'text-red-400 bg-red-500/10 border-red-500/25',
  warning: 'text-amber-300 bg-amber-500/10 border-amber-500/25',
  idle: 'text-kyn-metal bg-white/5 border-white/10',
  success: 'text-emerald-300 bg-emerald-500/10 border-emerald-500/25',
  info: 'text-sky-300 bg-sky-500/10 border-sky-500/25',
};

export function StatusPill({
  status = 'online',
  children,
  pulse,
  className,
}: {
  status?: StatusTone;
  children: ReactNode;
  pulse?: boolean;
  className?: string;
}) {
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[11px] font-semibold tracking-wide',
        tones[status],
        className
      )}
    >
      <span
        className={cn(
          'h-1.5 w-1.5 rounded-full bg-current',
          pulse || status === 'charging' || status === 'online' ? 'animate-pulse-glow' : ''
        )}
      />
      {children}
    </span>
  );
}

import type { ReactNode } from 'react';
import { cn } from '../../lib/utils';

export function GlassPanel({
  children,
  className,
  padding = true,
}: {
  children: ReactNode;
  className?: string;
  padding?: boolean;
}) {
  return (
    <div
      className={cn(
        'glass-card rounded-2xl',
        padding && 'p-5 md:p-6',
        className
      )}
    >
      {children}
    </div>
  );
}

export function ChargeRing({ percent = 75, label = 'Charging' }: { percent?: number; label?: string }) {
  const p = Math.max(0, Math.min(100, percent));
  return (
    <div
      className="relative w-36 h-36 rounded-full flex items-center justify-center"
      style={{ background: `conic-gradient(from 210deg, #00e676 0%, #00e676 ${p}%, #2a2a30 ${p}%, #2a2a30 100%)` }}
    >
      <div className="w-[78%] h-[78%] rounded-full bg-kyn-black flex flex-col items-center justify-center border border-white/5">
        <span className="font-display text-3xl font-bold text-kyn-green text-glow">{p}%</span>
        <span className="text-[10px] text-kyn-metal mt-1">{label}</span>
      </div>
    </div>
  );
}

import type { ReactNode } from 'react';

export function StatCard({
  label,
  value,
  delta,
  icon,
}: {
  label: string;
  value: string;
  delta?: string;
  icon?: ReactNode;
}) {
  return (
    <div className="rounded-2xl border border-white/8 bg-white/[0.03] p-4">
      <div className="flex items-center justify-between">
        <p className="text-[10px] uppercase tracking-wider text-kyn-metal">{label}</p>
        {icon}
      </div>
      <p className="font-display text-2xl font-bold text-white mt-2">{value}</p>
      {delta && <p className="text-[11px] text-kyn-green mt-1">{delta}</p>}
    </div>
  );
}

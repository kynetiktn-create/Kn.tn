import type { ReactNode } from 'react';
import { cn } from '../../lib/utils';

export function ProductStage({
  src,
  alt,
  accent = '#00e676',
  children,
  className,
  maxH = 420,
}: {
  src: string;
  alt: string;
  accent?: string;
  children?: ReactNode;
  className?: string;
  maxH?: number;
}) {
  return (
    <div
      className={cn(
        'relative flex min-h-[280px] items-center justify-center overflow-hidden rounded-3xl border border-white/8 bg-gradient-to-b from-white/[0.04] to-transparent',
        className
      )}
    >
      <div
        className="pointer-events-none absolute inset-0 opacity-90"
        style={{
          background: `radial-gradient(ellipse 55% 45% at 50% 58%, ${accent}33, transparent 70%)`,
        }}
      />
      <div className="pointer-events-none absolute inset-0 grid-bg opacity-30" />
      <img
        src={src}
        alt={alt}
        className="relative z-10 w-auto object-contain drop-shadow-[0_30px_60px_rgba(0,0,0,0.55)]"
        style={{ maxHeight: maxH }}
      />
      {children}
    </div>
  );
}

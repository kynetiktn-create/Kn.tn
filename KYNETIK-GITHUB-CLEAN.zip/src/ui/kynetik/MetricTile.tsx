import type { ComponentType, ReactNode } from 'react';
import { cn } from '../../lib/utils';

export function MetricTile({
  label,
  value,
  delta,
  icon: Icon,
  className,
}: {
  label: string;
  value: ReactNode;
  delta?: string;
  icon?: ComponentType<{ size?: number; className?: string }>;
  className?: string;
}) {
  return (
    <div
      className={cn(
        'rounded-2xl border border-white/8 bg-gradient-to-b from-white/[0.05] to-white/[0.015] p-5 backdrop-blur-xl',
        className
      )}
    >
      <div className="mb-3 flex items-center justify-between gap-2">
        <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-kyn-metal">{label}</p>
        {Icon && (
          <span className="flex h-8 w-8 items-center justify-center rounded-xl border border-kyn-green/20 bg-kyn-green/10 text-kyn-green">
            <Icon size={14} />
          </span>
        )}
      </div>
      <p className="font-display text-2xl font-bold tracking-tight text-white md:text-3xl">{value}</p>
      {delta && <p className="mt-2 text-xs font-medium text-kyn-green">{delta}</p>}
    </div>
  );
}

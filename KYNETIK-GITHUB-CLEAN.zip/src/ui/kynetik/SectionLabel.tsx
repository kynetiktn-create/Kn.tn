import type { ReactNode } from 'react';
import { cn } from '../../lib/utils';

export function SectionLabel({
  children,
  className,
}: {
  children: ReactNode;
  className?: string;
}) {
  return (
    <p
      className={cn(
        'mb-3 inline-flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.28em] text-kyn-green',
        className
      )}
    >
      <span className="h-px w-6 bg-kyn-green/70" />
      {children}
    </p>
  );
}

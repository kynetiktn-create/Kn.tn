import { CheckCircle2, Info, X } from 'lucide-react';
import { cn } from '../../lib/utils';

export function Toast({
  title,
  body,
  tone = 'success',
  onClose,
}: {
  title: string;
  body?: string;
  tone?: 'success' | 'info' | 'error';
  onClose?: () => void;
}) {
  const Icon = tone === 'error' ? Info : tone === 'info' ? Info : CheckCircle2;
  return (
    <div
      className={cn(
        'flex min-w-[280px] max-w-sm gap-3 rounded-2xl border bg-kyn-void/95 p-4 shadow-2xl backdrop-blur-xl',
        tone === 'success' && 'border-kyn-green/25',
        tone === 'info' && 'border-sky-500/25',
        tone === 'error' && 'border-red-500/25'
      )}
    >
      <Icon
        size={18}
        className={cn(
          'mt-0.5 shrink-0',
          tone === 'success' && 'text-kyn-green',
          tone === 'info' && 'text-sky-400',
          tone === 'error' && 'text-red-400'
        )}
      />
      <div className="flex-1">
        <p className="text-sm font-semibold text-white">{title}</p>
        {body && <p className="mt-0.5 text-xs text-kyn-metal leading-relaxed">{body}</p>}
      </div>
      {onClose && (
        <button type="button" onClick={onClose} className="text-kyn-metal hover:text-white">
          <X size={14} />
        </button>
      )}
    </div>
  );
}

import type { ReactNode } from 'react';
import { Button } from '../primitives/Button';

export function EmptyState({
  title,
  body,
  actionLabel,
  onAction,
  icon,
}: {
  title: string;
  body: string;
  actionLabel?: string;
  onAction?: () => void;
  icon?: ReactNode;
}) {
  return (
    <div className="rounded-2xl border border-white/8 bg-white/[0.02] px-8 py-12 text-center">
      {icon && <div className="mx-auto mb-4 text-kyn-green flex justify-center">{icon}</div>}
      <h3 className="font-display text-lg font-semibold text-white">{title}</h3>
      <p className="mt-2 text-sm text-kyn-metal max-w-sm mx-auto leading-relaxed">{body}</p>
      {actionLabel && onAction && (
        <div className="mt-6">
          <Button onClick={onAction}>{actionLabel}</Button>
        </div>
      )}
    </div>
  );
}

import type { ReactNode } from 'react';

export function FormField({
  label,
  children,
  required,
  hint,
}: {
  label: string;
  children: ReactNode;
  required?: boolean;
  hint?: string;
}) {
  return (
    <div className="space-y-1.5">
      <div className="flex items-center justify-between">
        <label className="text-[11px] font-semibold uppercase tracking-wider text-kyn-metal">
          {label}
          {required && <span className="ml-1 text-kyn-green">*</span>}
        </label>
        {hint && <span className="text-[10px] text-kyn-metal">{hint}</span>}
      </div>
      {children}
    </div>
  );
}

/** KYNETIK Design Bible — foundation tokens (React/Next ready) */
export const colors = {
  black: '#050505',
  void: '#0A0A0B',
  charcoal: '#121214',
  steel: '#1A1A1E',
  graphite: '#2A2A30',
  metal: '#8A8A96',
  silver: '#C8C8D0',
  white: '#F5F5F7',
  green: '#00E676',
  greenDim: '#00C853',
  greenGlow: '#39FF14',
  teal: '#2DD4BF',
  danger: '#F87171',
  warning: '#FBBF24',
} as const;

export const space = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 48,
  '2xl': 80,
  '3xl': 120,
} as const;

export const radius = {
  control: 12,
  card: 16,
  panel: 24,
  pill: 999,
  device: 32,
} as const;

export const motion = {
  fast: 180,
  base: 280,
  slow: 450,
  ease: [0.22, 1, 0.36, 1] as [number, number, number, number],
};

export const type = {
  display: "'Space Grotesk', 'Inter', system-ui, sans-serif",
  body: "'Inter', system-ui, sans-serif",
};

export const elevation = {
  card: '0 0 0 1px rgba(255,255,255,0.08)',
  glow: '0 0 40px rgba(0,230,118,0.18)',
  float: '0 24px 80px rgba(0,0,0,0.55)',
};

/** Surface recipes used across Web · App · Cloud */
export const surfaces = {
  page: 'bg-kyn-black text-kyn-white',
  panel: 'bg-kyn-void border border-white/8',
  glass: 'glass-card',
  elevated: 'bg-kyn-steel border border-white/10',
} as const;

export const focusRing = 'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-kyn-green/50 focus-visible:ring-offset-2 focus-visible:ring-offset-kyn-black';

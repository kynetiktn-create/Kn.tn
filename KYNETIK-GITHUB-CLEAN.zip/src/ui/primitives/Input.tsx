import type { InputHTMLAttributes, ReactNode } from 'react';
import { cn } from '../../lib/utils';

interface Props extends InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  hint?: string;
  error?: string;
  leftIcon?: ReactNode;
  rightIcon?: ReactNode;
}

export function Input({ label, hint, error, leftIcon, rightIcon, className, id, ...rest }: Props) {
  const inputId = id || rest.name;
  return (
    <label className="block w-full text-left">
      {label && (
        <span className="mb-1.5 block text-[11px] font-semibold uppercase tracking-wider text-kyn-metal">
          {label}
        </span>
      )}
      <div className="relative">
        {leftIcon && (
          <span className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-kyn-metal">
            {leftIcon}
          </span>
        )}
        <input
          id={inputId}
          className={cn(
            'w-full rounded-2xl border bg-kyn-steel/50 px-3.5 py-2.5 text-sm text-white outline-none transition-all placeholder:text-kyn-metal',
            'border-white/10 focus:border-kyn-green/50 focus:ring-2 focus:ring-kyn-green/15',
            'disabled:cursor-not-allowed disabled:opacity-40',
            error && 'border-red-500/50 focus:border-red-400 focus:ring-red-500/15',
            leftIcon ? 'pl-10' : undefined,
            rightIcon ? 'pr-10' : undefined,
            className
          )}
          {...rest}
        />
        {rightIcon && (
          <span className="absolute right-3 top-1/2 -translate-y-1/2 text-kyn-metal">{rightIcon}</span>
        )}
      </div>
      {(error || hint) && (
        <span className={cn('mt-1.5 block text-[11px]', error ? 'text-red-400' : 'text-kyn-metal')}>
          {error || hint}
        </span>
      )}
    </label>
  );
}

import type { ReactNode } from 'react';
import { AlertTriangle, CheckCircle2, Info, XCircle } from 'lucide-react';
import { cn } from '../../lib/utils';

type Tone = 'info' | 'success' | 'warning' | 'error';

const styles: Record<Tone, { wrap: string; icon: typeof Info }> = {
  info: { wrap: 'border-sky-500/25 bg-sky-500/10 text-sky-200', icon: Info },
  success: { wrap: 'border-kyn-green/25 bg-kyn-green/10 text-kyn-green', icon: CheckCircle2 },
  warning: { wrap: 'border-amber-500/25 bg-amber-500/10 text-amber-200', icon: AlertTriangle },
  error: { wrap: 'border-red-500/25 bg-red-500/10 text-red-300', icon: XCircle },
};

export function Alert({
  tone = 'info',
  title,
  children,
  className,
}: {
  tone?: Tone;
  title: string;
  children?: ReactNode;
  className?: string;
}) {
  const Icon = styles[tone].icon;
  return (
    <div className={cn('flex gap-3 rounded-2xl border px-4 py-3', styles[tone].wrap, className)}>
      <Icon size={16} className="mt-0.5 shrink-0" />
      <div>
        <p className="text-sm font-semibold text-white">{title}</p>
        {children && <div className="mt-1 text-xs opacity-90 leading-relaxed">{children}</div>}
      </div>
    </div>
  );
}

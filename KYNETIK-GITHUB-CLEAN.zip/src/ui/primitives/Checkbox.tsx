import type { InputHTMLAttributes } from 'react';
import { cn } from '../../lib/utils';

interface Props extends Omit<InputHTMLAttributes<HTMLInputElement>, 'type'> {
  label: string;
  description?: string;
}

export function Checkbox({ label, description, className, ...rest }: Props) {
  return (
    <label className={cn('flex cursor-pointer items-start gap-3', className)}>
      <input
        type="checkbox"
        className="mt-0.5 h-4 w-4 shrink-0 rounded border-white/20 bg-kyn-steel accent-kyn-green focus:ring-kyn-green/30"
        {...rest}
      />
      <span>
        <span className="block text-sm font-medium text-white">{label}</span>
        {description && <span className="mt-0.5 block text-xs text-kyn-metal">{description}</span>}
      </span>
    </label>
  );
}

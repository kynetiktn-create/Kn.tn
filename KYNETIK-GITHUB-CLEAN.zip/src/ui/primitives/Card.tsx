import type { ReactNode } from 'react';
import { cn } from '../../lib/utils';

export function Card({
  children,
  className,
  padding = 'md',
  interactive,
}: {
  children: ReactNode;
  className?: string;
  padding?: 'none' | 'sm' | 'md' | 'lg';
  interactive?: boolean;
}) {
  const pads = { none: '', sm: 'p-4', md: 'p-5', lg: 'p-7' };
  return (
    <div
      className={cn(
        'rounded-2xl border border-white/8 bg-white/[0.03] backdrop-blur-sm',
        pads[padding],
        interactive && 'transition-all hover:-translate-y-0.5 hover:border-kyn-green/30 cursor-pointer',
        className
      )}
    >
      {children}
    </div>
  );
}

export function CardHeader({
  title,
  subtitle,
  action,
}: {
  title: string;
  subtitle?: string;
  action?: ReactNode;
}) {
  return (
    <div className="mb-4 flex items-start justify-between gap-3">
      <div>
        <h3 className="font-display text-base font-semibold text-white">{title}</h3>
        {subtitle && <p className="mt-0.5 text-xs text-kyn-metal">{subtitle}</p>}
      </div>
      {action}
    </div>
  );
}

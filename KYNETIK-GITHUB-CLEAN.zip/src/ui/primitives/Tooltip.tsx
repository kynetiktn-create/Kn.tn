import type { ReactNode } from 'react';

export function Tooltip({ label, children }: { label: string; children: ReactNode }) {
  return (
    <span className="group relative inline-flex">
      {children}
      <span className="pointer-events-none absolute bottom-full left-1/2 z-20 mb-2 -translate-x-1/2 whitespace-nowrap rounded-lg border border-white/10 bg-kyn-charcoal px-2.5 py-1 text-[10px] font-medium text-kyn-silver opacity-0 shadow-xl transition-opacity group-hover:opacity-100">
        {label}
      </span>
    </span>
  );
}

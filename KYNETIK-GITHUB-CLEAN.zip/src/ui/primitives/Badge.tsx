import type { ReactNode } from 'react';
import { cn } from '../../lib/utils';

export function Badge({
  children,
  tone = 'green',
  className,
}: {
  children: ReactNode;
  tone?: 'green' | 'metal' | 'danger' | 'warning';
  className?: string;
}) {
  const tones = {
    green: 'text-kyn-green bg-kyn-green/10 border-kyn-green/25',
    metal: 'text-kyn-silver bg-white/5 border-white/10',
    danger: 'text-red-400 bg-red-500/10 border-red-500/25',
    warning: 'text-amber-300 bg-amber-500/10 border-amber-500/25',
  };
  return (
    <span className={cn('inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-semibold border', tones[tone], className)}>
      {children}
    </span>
  );
}

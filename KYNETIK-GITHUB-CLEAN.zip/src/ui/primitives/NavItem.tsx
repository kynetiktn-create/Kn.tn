import type { ReactNode } from 'react';
import { cn } from '../../lib/utils';

export function NavItem({
  icon,
  label,
  active,
  badge,
  onClick,
}: {
  icon?: ReactNode;
  label: string;
  active?: boolean;
  badge?: string | number;
  onClick?: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        'flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition-all',
        active
          ? 'border border-kyn-green/20 bg-kyn-green/10 text-kyn-green'
          : 'text-kyn-silver hover:bg-white/5 hover:text-white'
      )}
    >
      {icon && <span className="shrink-0">{icon}</span>}
      <span className="flex-1 text-left font-medium">{label}</span>
      {badge !== undefined && (
        <span className="rounded-full bg-kyn-green/15 px-2 py-0.5 text-[10px] font-bold text-kyn-green">
          {badge}
        </span>
      )}
    </button>
  );
}

export function Breadcrumb({ items }: { items: string[] }) {
  return (
    <nav className="flex flex-wrap items-center gap-1.5 text-xs text-kyn-metal">
      {items.map((item, i) => (
        <span key={item} className="inline-flex items-center gap-1.5">
          {i > 0 && <span className="text-white/20">/</span>}
          <span className={i === items.length - 1 ? 'font-semibold text-white' : 'hover:text-kyn-silver'}>
            {item}
          </span>
        </span>
      ))}
    </nav>
  );
}

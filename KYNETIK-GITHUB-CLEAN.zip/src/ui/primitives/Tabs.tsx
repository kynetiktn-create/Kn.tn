import { cn } from '../../lib/utils';

export function Tabs({
  items,
  value,
  onChange,
}: {
  items: { id: string; label: string }[];
  value: string;
  onChange: (id: string) => void;
}) {
  return (
    <div className="inline-flex flex-wrap gap-1 rounded-2xl border border-white/8 bg-kyn-steel/40 p-1">
      {items.map((item) => (
        <button
          key={item.id}
          type="button"
          onClick={() => onChange(item.id)}
          className={cn(
            'rounded-xl px-3.5 py-2 text-xs font-semibold transition-all',
            value === item.id
              ? 'bg-kyn-green text-kyn-black shadow-lg shadow-kyn-green/20'
              : 'text-kyn-silver hover:text-white'
          )}
        >
          {item.label}
        </button>
      ))}
    </div>
  );
}

export function UnderlineTabs({
  items,
  value,
  onChange,
}: {
  items: { id: string; label: string }[];
  value: string;
  onChange: (id: string) => void;
}) {
  return (
    <div className="flex gap-1 border-b border-white/8 overflow-x-auto">
      {items.map((item) => (
        <button
          key={item.id}
          type="button"
          onClick={() => onChange(item.id)}
          className={cn(
            'shrink-0 border-b-2 px-4 py-2.5 text-xs font-semibold transition-colors -mb-px',
            value === item.id
              ? 'border-kyn-green text-kyn-green'
              : 'border-transparent text-kyn-metal hover:text-white'
          )}
        >
          {item.label}
        </button>
      ))}
    </div>
  );
}

import type { TextareaHTMLAttributes } from 'react';
import { cn } from '../../lib/utils';

interface Props extends TextareaHTMLAttributes<HTMLTextAreaElement> {
  label?: string;
  hint?: string;
  error?: string;
}

export function Textarea({ label, hint, error, className, ...rest }: Props) {
  return (
    <label className="block w-full text-left">
      {label && (
        <span className="mb-1.5 block text-[11px] font-semibold uppercase tracking-wider text-kyn-metal">
          {label}
        </span>
      )}
      <textarea
        className={cn(
          'min-h-[100px] w-full resize-y rounded-2xl border border-white/10 bg-kyn-steel/50 px-3.5 py-2.5 text-sm text-white outline-none transition-all placeholder:text-kyn-metal',
          'focus:border-kyn-green/50 focus:ring-2 focus:ring-kyn-green/15',
          'disabled:cursor-not-allowed disabled:opacity-40',
          error && 'border-red-500/50',
          className
        )}
        {...rest}
      />
      {(error || hint) && (
        <span className={cn('mt-1.5 block text-[11px]', error ? 'text-red-400' : 'text-kyn-metal')}>
          {error || hint}
        </span>
      )}
    </label>
  );
}

import { cn } from '../../lib/utils';

export function Avatar({
  name,
  src,
  size = 'md',
  status,
}: {
  name: string;
  src?: string;
  size?: 'sm' | 'md' | 'lg';
  status?: 'online' | 'offline' | 'busy';
}) {
  const sizes = { sm: 'h-8 w-8 text-[10px]', md: 'h-10 w-10 text-xs', lg: 'h-14 w-14 text-sm' };
  const initials = name
    .split(' ')
    .map((p) => p[0])
    .join('')
    .slice(0, 2)
    .toUpperCase();
  const statusColor = { online: 'bg-kyn-green', offline: 'bg-kyn-metal', busy: 'bg-amber-400' };

  return (
    <div className="relative inline-flex shrink-0">
      {src ? (
        <img src={src} alt={name} className={cn('rounded-2xl object-cover', sizes[size])} />
      ) : (
        <div
          className={cn(
            'flex items-center justify-center rounded-2xl border border-kyn-green/25 bg-kyn-green/10 font-display font-bold text-kyn-green',
            sizes[size]
          )}
        >
          {initials}
        </div>
      )}
      {status && (
        <span
          className={cn(
            'absolute -bottom-0.5 -right-0.5 h-3 w-3 rounded-full border-2 border-kyn-black',
            statusColor[status]
          )}
        />
      )}
    </div>
  );
}

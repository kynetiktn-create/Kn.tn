import type { SelectHTMLAttributes } from 'react';
import { cn } from '../../lib/utils';

interface Props extends SelectHTMLAttributes<HTMLSelectElement> {
  label?: string;
  options: { value: string; label: string }[];
  error?: string;
}

export function Select({ label, options, error, className, ...rest }: Props) {
  return (
    <label className="block w-full text-left">
      {label && (
        <span className="mb-1.5 block text-[11px] font-semibold uppercase tracking-wider text-kyn-metal">
          {label}
        </span>
      )}
      <select
        className={cn(
          'w-full appearance-none rounded-2xl border border-white/10 bg-kyn-steel/50 px-3.5 py-2.5 text-sm text-white outline-none transition-all',
          'focus:border-kyn-green/50 focus:ring-2 focus:ring-kyn-green/15',
          'disabled:cursor-not-allowed disabled:opacity-40',
          error && 'border-red-500/50',
          className
        )}
        {...rest}
      >
        {options.map((o) => (
          <option key={o.value} value={o.value} className="bg-kyn-charcoal text-white">
            {o.label}
          </option>
        ))}
      </select>
      {error && <span className="mt-1.5 block text-[11px] text-red-400">{error}</span>}
    </label>
  );
}

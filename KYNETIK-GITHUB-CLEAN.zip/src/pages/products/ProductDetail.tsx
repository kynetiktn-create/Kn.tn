import { useEffect, useMemo, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  ArrowRight, Check, Download, FileText, Shield, Wifi, Bluetooth, Radio,
  Cable, Gauge, Thermometer, Award, HelpCircle, ChevronDown, Zap, Car,
  Wrench, ShoppingBag, UserPlus, Quote, Cloud, Smartphone, Package,
  GitCompare
} from 'lucide-react';
import ProductShell from '../../components/products/ProductShell';
import LoadingState from '../../components/LoadingState';
import ErrorState from '../../components/ErrorState';
import { apiGet, cn } from '../../lib/utils';
import { parseJson, type ProductLine } from '../../lib/productTypes';

type SpecMap = Record<string, string>;
type FaqItem = { q: string; a: string };
type DlItem = { label: string; type: string };

export default function ProductDetail() {
  const { slug = '' } = useParams();
  const [line, setLine] = useState<ProductLine | null>(null);
  const [all, setAll] = useState<ProductLine[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [power, setPower] = useState('');
  const [galleryIdx, setGalleryIdx] = useState(0);
  const [openFaq, setOpenFaq] = useState<number | null>(0);
  const [sticky, setSticky] = useState(false);

  useEffect(() => {
    setLoading(true);
    setError('');
    setGalleryIdx(0);
    Promise.all([
      apiGet<ProductLine>(`/api/product-lines?slug=${encodeURIComponent(slug)}`),
      apiGet<ProductLine[]>('/api/product-lines'),
    ])
      .then(([one, list]) => {
        setLine(one);
        setAll(list);
        const powers = parseJson<string[]>(one.powers, []);
        setPower(powers[0] || '');
      })
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, [slug]);

  useEffect(() => {
    const onScroll = () => setSticky(window.scrollY > 520);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const powers = useMemo(() => parseJson<string[]>(line?.powers, []), [line]);
  const gallery = useMemo(() => parseJson<string[]>(line?.image_gallery, []), [line]);
  const specs = useMemo(() => parseJson<SpecMap>(line?.specs, {}), [line]);
  const features = useMemo(() => parseJson<string[]>(line?.features, []), [line]);
  const useCases = useMemo(() => parseJson<string[]>(line?.use_cases, []), [line]);
  const vehicles = useMemo(() => parseJson<string[]>(line?.vehicles, []), [line]);
  const faq = useMemo(() => parseJson<FaqItem[]>(line?.faq, []), [line]);
  const downloads = useMemo(() => parseJson<DlItem[]>(line?.downloads, []), [line]);
  const install = useMemo(() => parseJson<string[]>(line?.install_steps, []), [line]);
  const related = useMemo(
    () => all.filter((p) => p.slug !== slug).slice(0, 3),
    [all, slug]
  );

  if (loading) {
    return (
      <div className="min-h-screen bg-kyn-black flex items-center justify-center">
        <LoadingState label="Loading product…" />
      </div>
    );
  }

  if (error || !line) {
    return (
      <div className="min-h-screen bg-kyn-black flex items-center justify-center p-8">
        <ErrorState message={error || 'Product not found'} />
      </div>
    );
  }

  const accent = line.accent || '#00e676';
  const heroImg = gallery[galleryIdx] || line.image_hero;

  const specRows: [string, string][] = [
    ['Power', power || specs.Power || '—'],
    ['Phase', specs.Phase || '—'],
    ['Voltage', specs.Voltage || '230 / 400 V AC'],
    ['Current', specs.Current || '—'],
    ['Connector', specs.Connector || 'Type 2'],
    ['WiFi', specs.WiFi || 'Yes'],
    ['Bluetooth', specs.Bluetooth || 'Yes'],
    ['Ethernet', specs.Ethernet || '—'],
    ['RFID', specs.RFID || 'Yes'],
    ['OCPP', specs.OCPP || specs.Protocol || 'OCPP 1.6J'],
    ['Dynamic Load Balancing', specs['Dynamic Load Balancing'] || specs['Load balancing'] || '—'],
    ['Cloud', specs.Cloud || 'Cloud Ready'],
    ['Mobile App', specs['Mobile App'] || 'Yes'],
    ['Protection', specs.Protection || 'RCD + MCB ready'],
    ['IP', specs.IP || specs['IP rating'] || 'IP54'],
    ['IK', specs.IK || specs['IK rating'] || 'IK08'],
    ['Energy meter', specs['Energy meter'] || 'MID-ready'],
    ['Operating temp.', specs['Operating temp.'] || '−25°C to +50°C'],
    ['Warranty', specs.Warranty || '3 years'],
  ];

  const boxItems =
    line.slug === 'go'
      ? ['GO control box', 'Type 2 cable', 'CEE or Schuko inlet cable', 'Travel pouch', 'Quick start guide', 'Warranty card']
      : ['Wall charger unit', 'Mounting bracket & hardware', 'RFID cards (×2)', 'Installation template', 'Quick start guide', 'Warranty & DoC pack'];

  return (
    <ProductShell ctaHref="#quote" ctaLabel="Request quote">
      {/* Sticky CTA bar */}
      <div
        className={cn(
          'fixed bottom-0 inset-x-0 z-40 transition-transform duration-300 md:bottom-6 md:px-6 pointer-events-none',
          sticky ? 'translate-y-0' : 'translate-y-[120%]'
        )}
      >
        <div className="max-w-4xl mx-auto pointer-events-auto rounded-none md:rounded-2xl border border-white/10 bg-kyn-void/95 backdrop-blur-xl px-4 py-3 md:px-5 flex flex-wrap items-center justify-between gap-3 shadow-2xl shadow-black/50">
          <div className="flex items-center gap-3 min-w-0">
            <img src={line.image_hero} alt="" className="h-10 w-auto object-contain hidden sm:block" />
            <div className="min-w-0">
              <p className="font-display font-semibold text-sm truncate">{line.name}</p>
              <p className="text-[11px] text-kyn-metal truncate">{power || line.tagline}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <a href="#quote" className="px-4 py-2 rounded-full text-[11px] font-bold text-kyn-black" style={{ background: accent }}>
              Request quote
            </a>
            <a href="#quote" className="px-4 py-2 rounded-full border border-white/15 text-[11px] font-semibold text-white">
              Buy now
            </a>
          </div>
        </div>
      </div>

      {/* HERO */}
      <section className="relative pt-24 md:pt-28 pb-16 md:pb-24 overflow-hidden">
        <div className="absolute inset-0 grid-bg opacity-30" />
        <div
          className="absolute inset-0"
          style={{ background: `radial-gradient(ellipse at 70% 40%, ${accent}22, transparent 55%)` }}
        />
        <div className="relative z-10 max-w-7xl mx-auto px-5 md:px-8">
          <div className="grid lg:grid-cols-2 gap-10 lg:gap-8 items-center">
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
              <p className="text-xs font-semibold tracking-[0.3em] uppercase mb-4" style={{ color: accent }}>
                0{line.sort_order} · {line.segment}
              </p>
              <h1 className="font-display text-4xl sm:text-5xl md:text-6xl font-bold tracking-tight leading-[1.05]">
                {line.name}
              </h1>
              <p className="mt-4 text-xl text-kyn-silver font-display">{line.tagline}</p>
              <p className="mt-5 text-kyn-metal leading-relaxed max-w-lg">{line.description}</p>

              {/* GO inlet configs */}
              {line.slug === 'go' && gallery.length >= 2 && (
                <div className="mt-8">
                  <p className="text-[10px] uppercase tracking-widest text-kyn-metal mb-2">Select inlet</p>
                  <div className="inline-flex flex-wrap p-1 rounded-full bg-kyn-steel/50 border border-white/10 gap-1">
                    {[
                      { i: 0, label: 'CEE 32A', hint: 'Industrial blue' },
                      { i: 1, label: 'Schuko', hint: 'Domestic socket' },
                    ].map((c) => (
                      <button
                        key={c.label}
                        type="button"
                        onClick={() => setGalleryIdx(c.i)}
                        className={cn(
                          'px-4 py-2 rounded-full text-xs font-semibold transition-all',
                          galleryIdx === c.i ? 'text-kyn-black' : 'text-kyn-silver hover:text-white'
                        )}
                        style={galleryIdx === c.i ? { background: accent } : undefined}
                      >
                        {c.label}
                        <span className={cn('ml-1.5 text-[10px]', galleryIdx === c.i ? 'text-kyn-black/70' : 'text-kyn-metal')}>
                          {c.hint}
                        </span>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {powers.length > 0 && (
                <div className="mt-8">
                  <p className="text-[10px] uppercase tracking-widest text-kyn-metal mb-2">Select power</p>
                  <div className="inline-flex flex-wrap p-1 rounded-full bg-kyn-steel/50 border border-white/10 gap-1">
                    {powers.map((p) => (
                      <button
                        key={p}
                        type="button"
                        onClick={() => setPower(p)}
                        className={cn(
                          'px-4 py-2 rounded-full text-xs font-semibold transition-all',
                          power === p ? 'text-kyn-black' : 'text-kyn-silver hover:text-white'
                        )}
                        style={power === p ? { background: accent } : undefined}
                      >
                        {p}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              <div className="mt-8 flex flex-wrap gap-3">
                <a
                  href="#quote"
                  className="inline-flex items-center gap-2 px-6 py-3.5 rounded-full text-sm font-bold text-kyn-black"
                  style={{ background: accent, boxShadow: `0 0 40px ${accent}44` }}
                >
                  Request quote <ArrowRight size={16} />
                </a>
                <a
                  href="#downloads"
                  className="inline-flex items-center gap-2 px-6 py-3.5 rounded-full border border-white/15 text-sm font-medium hover:border-white/30"
                >
                  <Download size={16} /> Download datasheet
                </a>
                <Link
                  to={`/products/compare?ids=${line.slug}`}
                  className="inline-flex items-center gap-2 px-6 py-3.5 rounded-full border border-white/15 text-sm font-medium hover:border-white/30"
                >
                  <GitCompare size={16} /> Compare
                </Link>
              </div>

              <div className="mt-10 flex flex-wrap gap-6 text-[11px] text-kyn-metal">
                {(line.slug === 'go'
                  ? ['Type 2 EVSE', 'LCD control box', 'CEE · Schuko', specs['IP rating'] || 'IP65']
                  : ['OCPP 1.6J', 'Wi-Fi · 4G', 'RFID', specs['IP rating'] || 'IP54']
                ).map((t) => (
                  <span key={t} className="inline-flex items-center gap-1.5">
                    <Check size={12} style={{ color: accent }} /> {t}
                  </span>
                ))}
              </div>
            </motion.div>

            {/* 45° hero stage */}
            <div className="relative min-h-[420px] md:min-h-[560px] flex items-center justify-center">
              <div
                className="absolute w-[320px] h-[320px] md:w-[460px] md:h-[460px] rounded-full blur-[100px]"
                style={{ background: `${accent}28` }}
              />
              <div className="absolute bottom-[14%] w-[65%] h-[18%] rounded-[100%] bg-black/50 blur-2xl" />
              <AnimatePresence mode="wait">
                <motion.img
                  key={heroImg}
                  src={heroImg}
                  alt={`${line.name} 45° hero`}
                  initial={{ opacity: 0, scale: 0.94, rotate: -2 }}
                  animate={{ opacity: 1, scale: 1, rotate: -6 }}
                  exit={{ opacity: 0, scale: 0.96 }}
                  transition={{ duration: 0.5 }}
                  className="relative z-10 w-full max-w-[460px] object-contain"
                  style={{ filter: `drop-shadow(0 40px 80px ${accent}33)` }}
                />
              </AnimatePresence>
              <p className="absolute bottom-4 left-1/2 -translate-x-1/2 text-[10px] tracking-[0.28em] uppercase text-kyn-metal">
                {line.slug === 'go'
                  ? galleryIdx === 1
                    ? 'Official 3D · GO Schuko'
                    : 'Official 3D · GO CEE 32A'
                  : 'Ultra-realistic 3D · 45° hero'}
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Gallery */}
      <section className="py-16 border-t border-white/5">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <p className="text-xs font-semibold tracking-[0.25em] uppercase text-kyn-metal mb-6">Product gallery</p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {(gallery.length ? gallery : [line.image_hero]).map((src, i) => (
              <button
                key={src + i}
                type="button"
                onClick={() => setGalleryIdx(i)}
                className={cn(
                  'aspect-square rounded-2xl border overflow-hidden bg-kyn-void flex items-center justify-center p-4 transition-all',
                  galleryIdx === i ? 'border-kyn-green/50' : 'border-white/8 hover:border-white/20'
                )}
              >
                <img src={src} alt="" className="max-h-full w-auto object-contain" />
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-20 md:py-28 bg-kyn-void border-y border-white/5">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <h2 className="font-display text-3xl md:text-4xl font-bold mb-10">Designed for daily excellence</h2>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {features.map((f, i) => (
              <motion.div
                key={f}
                initial={{ opacity: 0, y: 12 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.04 }}
                className="rounded-2xl border border-white/8 bg-black/30 p-5"
              >
                <div className="w-8 h-8 rounded-lg flex items-center justify-center mb-3" style={{ background: `${accent}18`, color: accent }}>
                  <Check size={14} />
                </div>
                <p className="text-sm text-kyn-silver leading-relaxed">{f}</p>
              </motion.div>
            ))}
          </div>

          <div className="mt-12 grid grid-cols-2 md:grid-cols-4 gap-3">
            {[
              { icon: Wifi, l: 'Wi-Fi' },
              { icon: Bluetooth, l: 'Bluetooth' },
              { icon: Cable, l: 'Ethernet' },
              { icon: Radio, l: '4G' },
              { icon: Shield, l: 'OCPP 1.6J' },
              { icon: Zap, l: 'RFID' },
              { icon: Gauge, l: 'Load Balancing' },
              { icon: Award, l: 'Energy Meter' },
            ].map(({ icon: Icon, l }) => (
              <div key={l} className="rounded-xl border border-white/8 px-4 py-3 flex items-center gap-2.5 bg-white/[0.02]">
                <Icon size={14} style={{ color: accent }} />
                <span className="text-xs font-medium text-kyn-silver">{l}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Specs table */}
      <section id="specs" className="py-20 md:py-28">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <div className="grid lg:grid-cols-[1fr_1.1fr] gap-12 items-start">
            <div>
              <p className="text-xs font-semibold tracking-[0.25em] uppercase mb-3" style={{ color: accent }}>
                Technical specifications
              </p>
              <h2 className="font-display text-3xl md:text-4xl font-bold">Engineering clarity</h2>
              <p className="mt-4 text-kyn-metal leading-relaxed">
                Investor and distributor ready datasheet values. Selected power: <span className="text-white font-medium">{power || '—'}</span>
              </p>
              <div className="mt-8 flex flex-wrap gap-3 text-xs text-kyn-metal">
                <span className="inline-flex items-center gap-1.5"><Thermometer size={13} style={{ color: accent }} /> {specs['Operating temp.'] || '−25°C to +50°C'}</span>
                <span className="inline-flex items-center gap-1.5"><Shield size={13} style={{ color: accent }} /> {specs['IP rating'] || 'IP54'} · {specs['IK rating'] || 'IK08'}</span>
              </div>
            </div>
            <div className="rounded-2xl border border-white/10 overflow-hidden">
              <table className="w-full text-sm">
                <tbody className="divide-y divide-white/5">
                  {specRows.map(([k, v]) => (
                    <tr key={k} className="hover:bg-white/[0.02]">
                      <td className="px-5 py-3.5 text-kyn-metal font-medium w-[42%]">{k}</td>
                      <td className="px-5 py-3.5 text-kyn-silver">{v}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </section>

      {/* App + Cloud */}
      <section className="py-20 md:py-28 border-t border-white/5">
        <div className="max-w-7xl mx-auto px-5 md:px-8 grid lg:grid-cols-2 gap-5">
          <div className="rounded-3xl border border-white/10 bg-gradient-to-br from-white/[0.04] to-transparent p-8 md:p-10 overflow-hidden relative">
            <div className="absolute -right-8 -top-8 w-40 h-40 rounded-full blur-3xl" style={{ background: `${accent}22` }} />
            <Smartphone size={22} style={{ color: accent }} />
            <h3 className="font-display text-2xl font-bold mt-4">KYNETIK Mobile App</h3>
            <p className="mt-3 text-sm text-kyn-metal leading-relaxed">
              Start and stop sessions, manage RFID users, smart scheduling and live energy insights — the same premium dark UI across every family.
            </p>
            <ul className="mt-6 space-y-2">
              {['Remote start / stop', 'Smart scheduling', 'Session history', 'Multi-user access'].map((t) => (
                <li key={t} className="flex items-center gap-2 text-sm text-kyn-silver">
                  <Check size={14} style={{ color: accent }} /> {t}
                </li>
              ))}
            </ul>
            <Link to="/kynetik-app" className="mt-8 inline-flex items-center gap-2 text-sm font-semibold" style={{ color: accent }}>
              Explore the app <ArrowRight size={14} />
            </Link>
          </div>
          <div className="rounded-3xl border border-white/10 bg-gradient-to-br from-[#0A2342]/50 to-transparent p-8 md:p-10 overflow-hidden relative">
            <div className="absolute -right-8 -bottom-8 w-40 h-40 rounded-full blur-3xl bg-[#3DDC84]/15" />
            <Cloud size={22} className="text-[#3DDC84]" />
            <h3 className="font-display text-2xl font-bold mt-4">KYNETIK Cloud Integration</h3>
            <p className="mt-3 text-sm text-kyn-metal leading-relaxed">
              OCPP-native supervision, dynamic load groups, remote diagnostics and investor-ready energy reports for single homes or multi-site portfolios.
            </p>
            <ul className="mt-6 space-y-2">
              {['OCPP 1.6J orchestration', 'Remote monitoring', 'Load management', 'Analytics & reports'].map((t) => (
                <li key={t} className="flex items-center gap-2 text-sm text-kyn-silver">
                  <Check size={14} className="text-[#3DDC84]" /> {t}
                </li>
              ))}
            </ul>
            <Link to="/cloud" className="mt-8 inline-flex items-center gap-2 text-sm font-semibold text-[#3DDC84]">
              Open Cloud platform <ArrowRight size={14} />
            </Link>
          </div>
        </div>
      </section>

      {/* Install + vehicles + use cases + box */}
      <section className="py-20 md:py-28 bg-kyn-void border-y border-white/5">
        <div className="max-w-7xl mx-auto px-5 md:px-8 grid lg:grid-cols-2 xl:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center gap-2 mb-5">
              <Wrench size={16} style={{ color: accent }} />
              <h3 className="font-display text-xl font-bold">Installation requirements</h3>
            </div>
            <ol className="space-y-3">
              {install.map((step, i) => (
                <li key={step} className="flex gap-3 text-sm text-kyn-silver">
                  <span className="w-6 h-6 rounded-full border border-white/10 flex items-center justify-center text-[10px] font-bold shrink-0" style={{ color: accent }}>
                    {i + 1}
                  </span>
                  {step}
                </li>
              ))}
            </ol>
          </div>
          <div>
            <div className="flex items-center gap-2 mb-5">
              <Car size={16} style={{ color: accent }} />
              <h3 className="font-display text-xl font-bold">Compatible vehicles</h3>
            </div>
            <div className="flex flex-wrap gap-2">
              {vehicles.map((v) => (
                <span key={v} className="px-3 py-1.5 rounded-full bg-black/40 border border-white/8 text-xs text-kyn-silver">{v}</span>
              ))}
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2 mb-5">
              <Zap size={16} style={{ color: accent }} />
              <h3 className="font-display text-xl font-bold">Recommended use</h3>
            </div>
            <ul className="space-y-2.5">
              {useCases.map((u) => (
                <li key={u} className="flex gap-2 text-sm text-kyn-silver">
                  <Check size={14} className="mt-0.5 shrink-0" style={{ color: accent }} /> {u}
                </li>
              ))}
            </ul>
          </div>
          <div>
            <div className="flex items-center gap-2 mb-5">
              <Package size={16} style={{ color: accent }} />
              <h3 className="font-display text-xl font-bold">What's in the box</h3>
            </div>
            <ul className="space-y-2.5">
              {boxItems.map((item) => (
                <li key={item} className="flex gap-2 text-sm text-kyn-silver">
                  <Check size={14} className="mt-0.5 shrink-0" style={{ color: accent }} /> {item}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      {/* Comparison */}
      <section className="py-20 md:py-28">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <h2 className="font-display text-3xl md:text-4xl font-bold mb-3">Compare the family</h2>
          <p className="text-kyn-metal text-sm mb-8">Position {line.name.replace('KYNETIK ', '')} against the complete KYNETIK range.</p>
          <div className="overflow-x-auto rounded-2xl border border-white/10">
            <table className="w-full text-left text-sm min-w-[800px]">
              <thead className="bg-white/[0.03] text-[10px] uppercase tracking-wider text-kyn-metal">
                <tr>
                  <th className="px-4 py-4 font-medium">Model</th>
                  <th className="px-4 py-4 font-medium">Segment</th>
                  <th className="px-4 py-4 font-medium">Power options</th>
                  <th className="px-4 py-4 font-medium">Best for</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {all.map((p) => {
                  const pPowers = parseJson<string[]>(p.powers, []);
                  const active = p.slug === slug;
                  return (
                    <tr key={p.id} className={active ? 'bg-kyn-green/5' : ''}>
                      <td className="px-4 py-3.5">
                        <Link to={`/products/${p.slug}`} className={cn('font-semibold hover:underline', active ? 'text-kyn-green' : 'text-white')}>
                          {p.name.replace('KYNETIK ', '')}
                        </Link>
                      </td>
                      <td className="px-4 py-3.5 text-kyn-metal">{p.segment}</td>
                      <td className="px-4 py-3.5 text-kyn-silver">{pPowers.join(' · ')}</td>
                      <td className="px-4 py-3.5 text-kyn-metal max-w-xs truncate">{p.tagline}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </section>

      {/* Downloads */}
      <section id="downloads" className="py-16 bg-kyn-void border-y border-white/5">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <h2 className="font-display text-2xl md:text-3xl font-bold mb-6">Downloads</h2>
          <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-3">
            {(downloads.length
              ? downloads
              : [
                  { label: 'Datasheet', type: 'datasheet' },
                  { label: 'Installation Guide', type: 'manual' },
                  { label: 'Warranty', type: 'warranty' },
                  { label: 'Declaration of Conformity', type: 'cert' },
                  { label: 'User Manual', type: 'manual' },
                ]
            ).map((d) => (
              <a
                key={d.label}
                href="#quote"
                className="rounded-2xl border border-white/8 bg-black/30 p-5 flex items-center gap-4 hover:border-[#3DDC84]/30 transition-colors"
              >
                <div className="w-10 h-10 rounded-xl bg-[#3DDC84]/10 border border-[#3DDC84]/20 flex items-center justify-center text-[#3DDC84]">
                  {d.type === 'cert' || d.type === 'warranty' ? <Shield size={16} /> : d.type === 'manual' ? <FileText size={16} /> : <Download size={16} />}
                </div>
                <div>
                  <p className="text-sm font-semibold">{d.label}</p>
                  <p className="text-[11px] text-kyn-metal mt-0.5">PDF · Request access</p>
                </div>
              </a>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-20 md:py-28">
        <div className="max-w-3xl mx-auto px-5 md:px-8">
          <div className="flex items-center gap-2 mb-8">
            <HelpCircle size={18} className="text-kyn-green" />
            <h2 className="font-display text-3xl font-bold">FAQ</h2>
          </div>
          <div className="space-y-2">
            {faq.map((item, i) => {
              const open = openFaq === i;
              return (
                <div key={item.q} className="rounded-2xl border border-white/8 overflow-hidden">
                  <button
                    type="button"
                    onClick={() => setOpenFaq(open ? null : i)}
                    className="w-full flex items-center justify-between gap-4 px-5 py-4 text-left"
                  >
                    <span className="text-sm font-medium text-kyn-silver">{item.q}</span>
                    <ChevronDown size={16} className={cn('text-kyn-metal shrink-0 transition-transform', open && 'rotate-180')} />
                  </button>
                  {open && <div className="px-5 pb-4 text-sm text-kyn-metal leading-relaxed">{item.a}</div>}
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Related */}
      <section className="py-16 border-t border-white/5 bg-kyn-void">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <h2 className="font-display text-2xl font-bold mb-6">Related products</h2>
          <div className="grid md:grid-cols-3 gap-4">
            {related.map((p) => (
              <Link
                key={p.id}
                to={`/products/${p.slug}`}
                className="group rounded-2xl border border-white/8 bg-black/30 p-5 hover:border-kyn-green/30 transition-all"
              >
                <div className="h-40 flex items-center justify-center mb-4 rounded-xl" style={{ background: `radial-gradient(circle, ${p.accent}18, transparent 70%)` }}>
                  <img src={p.image_hero} alt={p.name} className="max-h-full w-auto object-contain p-3 group-hover:scale-105 transition-transform" />
                </div>
                <p className="font-display font-bold">{p.name}</p>
                <p className="text-xs text-kyn-metal mt-1 line-clamp-2">{p.tagline}</p>
                <span className="mt-3 inline-flex items-center gap-1 text-xs text-kyn-green">View <ArrowRight size={12} /></span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Quote / CTAs */}
      <section id="quote" className="py-24 md:py-32 relative">
        <div className="absolute inset-0" style={{ background: `radial-gradient(ellipse at center, ${accent}18, transparent 55%)` }} />
        <div className="relative z-10 max-w-4xl mx-auto px-5 md:px-8 text-center">
          <Quote className="mx-auto mb-6 opacity-40" size={28} style={{ color: accent }} />
          <h2 className="font-display text-3xl md:text-5xl font-bold leading-tight">
            Ready for {line.name.replace('KYNETIK ', '')}?
          </h2>
          <p className="mt-4 text-kyn-silver max-w-xl mx-auto">
            Investors, distributors and end customers — one premium path from quote to installation.
          </p>
          <div className="mt-10 flex flex-wrap justify-center gap-3">
            <a
              href="mailto:sales@kynetik.tn?subject=Quote%20"
              className="inline-flex items-center gap-2 px-7 py-3.5 rounded-full text-sm font-bold text-kyn-black"
              style={{ background: accent, boxShadow: `0 0 40px ${accent}40` }}
            >
              <ShoppingBag size={16} /> Request quote
            </a>
            <a href="mailto:sales@kynetik.tn?subject=Buy%20" className="inline-flex items-center gap-2 px-7 py-3.5 rounded-full border border-white/15 text-sm font-semibold">
              Buy now
            </a>
            <Link to="/academy" className="inline-flex items-center gap-2 px-7 py-3.5 rounded-full border border-white/15 text-sm font-semibold">
              <UserPlus size={16} /> Become installer
            </Link>
          </div>
          <p className="mt-8 text-[11px] text-kyn-metal">Selected configuration · {power || 'Standard'} · sales@kynetik.tn</p>
        </div>
      </section>

      <div className="h-16 md:h-10" />
    </ProductShell>
  );
}

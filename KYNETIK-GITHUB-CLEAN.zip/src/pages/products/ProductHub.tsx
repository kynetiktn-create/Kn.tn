import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowRight, Zap } from 'lucide-react';
import ProductShell from '../../components/products/ProductShell';
import LoadingState from '../../components/LoadingState';
import ErrorState from '../../components/ErrorState';
import { apiGet } from '../../lib/utils';
import { parseJson, type ProductLine } from '../../lib/productTypes';

export default function ProductHub() {
  const [lines, setLines] = useState<ProductLine[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    apiGet<ProductLine[]>('/api/product-lines')
      .then(setLines)
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-kyn-black flex items-center justify-center">
        <LoadingState label="Loading product system…" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-kyn-black flex items-center justify-center p-8">
        <ErrorState message={error} />
      </div>
    );
  }

  return (
    <ProductShell>
      <section className="relative pt-28 md:pt-36 pb-20 overflow-hidden">
        <div className="absolute inset-0 grid-bg opacity-40" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(0,230,118,0.12),transparent_55%)]" />
        <div className="relative z-10 max-w-7xl mx-auto px-5 md:px-8 text-center">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
            <p className="text-kyn-green text-xs font-semibold tracking-[0.35em] uppercase mb-5">Product System</p>
            <h1 className="font-display text-4xl sm:text-5xl md:text-7xl font-bold tracking-tight leading-[1.05]">
              Six chargers.
              <br />
              <span className="text-kyn-green text-glow">One language.</span>
            </h1>
            <p className="mt-6 text-kyn-silver text-lg max-w-2xl mx-auto leading-relaxed">
              From portable travel power to enterprise dual-output — a complete AC family designed with Tesla restraint and industrial precision.
            </p>
            <Link
              to="/configurator"
              className="mt-8 inline-flex items-center gap-2 px-6 py-3 rounded-full bg-kyn-green text-kyn-black text-sm font-bold glow-green"
            >
              Open Product Configurator <ArrowRight size={16} />
            </Link>
          </motion.div>
        </div>
      </section>

      <section className="pb-28">
        <div className="max-w-7xl mx-auto px-5 md:px-8 space-y-6">
          {lines.map((line, i) => {
            const powers = parseJson<string[]>(line.powers, []);
            const reverse = i % 2 === 1;
            return (
              <motion.div
                key={line.id}
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-40px' }}
                transition={{ duration: 0.55, delay: i * 0.04 }}
              >
                <Link
                  to={`/products/${line.slug}`}
                  className="group grid lg:grid-cols-2 gap-0 rounded-[2rem] border border-white/8 overflow-hidden bg-gradient-to-b from-white/[0.03] to-transparent hover:border-kyn-green/30 transition-all"
                >
                  <div className={`relative min-h-[320px] md:min-h-[420px] flex items-center justify-center p-10 ${reverse ? 'lg:order-2' : ''}`}>
                    <div
                      className="absolute inset-0 opacity-80"
                      style={{
                        background: `radial-gradient(circle at center, ${line.accent}22, transparent 60%)`,
                      }}
                    />
                    <img
                      src={line.image_hero}
                      alt={line.name}
                      className="relative z-10 max-h-[340px] w-auto object-contain transition-transform duration-700 group-hover:scale-105 drop-shadow-[0_30px_80px_rgba(0,0,0,0.45)]"
                    />
                  </div>
                  <div className={`p-8 md:p-12 flex flex-col justify-center ${reverse ? 'lg:order-1' : ''}`}>
                    <div className="flex items-center gap-2 mb-3">
                      <span className="text-[10px] font-semibold tracking-[0.25em] uppercase" style={{ color: line.accent }}>
                        0{line.sort_order} · {line.segment}
                      </span>
                    </div>
                    <h2 className="font-display text-3xl md:text-4xl font-bold">{line.name}</h2>
                    <p className="mt-3 text-kyn-silver leading-relaxed max-w-md">{line.tagline}</p>
                    <div className="mt-6 flex flex-wrap gap-2">
                      {powers.map((p) => (
                        <span key={p} className="px-3 py-1.5 rounded-full border border-white/10 bg-white/[0.03] text-xs font-medium text-kyn-silver">
                          {p}
                        </span>
                      ))}
                    </div>
                    <p className="mt-6 text-sm text-kyn-metal line-clamp-2">{line.description}</p>
                    <span className="mt-8 inline-flex items-center gap-2 text-sm font-semibold text-kyn-green group-hover:gap-3 transition-all">
                      Explore {line.name.replace('KYNETIK ', '')} <ArrowRight size={16} />
                    </span>
                  </div>
                </Link>
              </motion.div>
            );
          })}
        </div>
      </section>

      <section className="py-20 border-t border-white/5 bg-kyn-void">
        <div className="max-w-7xl mx-auto px-5 md:px-8 grid md:grid-cols-3 gap-6">
          {[
            { t: 'One Cloud', d: 'Every charger connects to KYNETIK Cloud for OCPP, billing and smart load.' },
            { t: 'One Design System', d: 'Shared materials, LED language and UI — investor-ready consistency.' },
            { t: 'One Installer Network', d: 'Academy-certified deployment from home wallboxes to dual-output PRO.' },
          ].map((item) => (
            <div key={item.t} className="rounded-2xl border border-white/8 p-6 bg-black/30">
              <Zap className="text-kyn-green mb-4" size={18} />
              <h3 className="font-display font-semibold text-lg">{item.t}</h3>
              <p className="text-sm text-kyn-metal mt-2 leading-relaxed">{item.d}</p>
            </div>
          ))}
        </div>
      </section>
    </ProductShell>
  );
}

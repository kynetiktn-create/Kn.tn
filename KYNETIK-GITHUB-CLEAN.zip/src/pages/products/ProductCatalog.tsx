import { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  ArrowRight, Download, GitCompare, FileText, Check, Zap, Wifi, Shield, Cloud,
  Smartphone, Filter
} from 'lucide-react';
import ProductShell from '../../components/products/ProductShell';
import LoadingState from '../../components/LoadingState';
import ErrorState from '../../components/ErrorState';
import { apiGet, cn } from '../../lib/utils';
import { parseJson, type ProductLine } from '../../lib/productTypes';
import { track } from '../../lib/analytics';

const POWER_FILTERS = ['3.7', '7', '11', '14', '22', '44'];
const USAGE_FILTERS = ['Home', 'Business', 'Fleet', 'Public'];
const FEATURE_FILTERS = ['WiFi', 'Bluetooth', 'RFID', 'OCPP', 'Dynamic Load Balancing', 'Cloud'];

const FAMILY_ORDER = ['go', 'flex', 'nova', 'prime', 'edge', 'pro'];

function lineBlob(line: ProductLine) {
  return `${line.name} ${line.segment} ${line.category} ${line.tagline} ${line.description} ${line.powers} ${line.features} ${line.specs}`.toLowerCase();
}

function matchesPower(line: ProductLine, power: string) {
  return lineBlob(line).includes(power.toLowerCase());
}

function matchesUsage(line: ProductLine, usage: string) {
  const b = lineBlob(line);
  if (usage === 'Home') return /home|residential|apartment|villa|flex|go|nova|prime|smart home/.test(b);
  if (usage === 'Business') return /business|workplace|hotel|hospitality|prime|edge|commercial|sme|retail/.test(b);
  if (usage === 'Fleet') return /fleet|depot|pro|industrial|dealer/.test(b);
  if (usage === 'Public') return /public|urban|pro|edge|shared|parking|municipal/.test(b);
  return true;
}

function matchesFeature(line: ProductLine, feature: string) {
  return lineBlob(line).includes(feature.toLowerCase());
}

export default function ProductCatalog() {
  const [lines, setLines] = useState<ProductLine[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [power, setPower] = useState<string[]>([]);
  const [usage, setUsage] = useState<string[]>([]);
  const [features, setFeatures] = useState<string[]>([]);
  const [compare, setCompare] = useState<string[]>([]);

  useEffect(() => {
    apiGet<ProductLine[]>('/api/product-lines')
      .then((data) => {
        const sorted = [...data].sort((a, b) => {
          const ai = FAMILY_ORDER.indexOf(a.slug);
          const bi = FAMILY_ORDER.indexOf(b.slug);
          return (ai === -1 ? 99 : ai) - (bi === -1 ? 99 : bi);
        });
        setLines(sorted);
      })
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, []);

  const filtered = useMemo(() => {
    return lines.filter((line) => {
      if (power.length && !power.some((p) => matchesPower(line, p))) return false;
      if (usage.length && !usage.some((u) => matchesUsage(line, u))) return false;
      if (features.length && !features.every((f) => matchesFeature(line, f))) return false;
      return true;
    });
  }, [lines, power, usage, features]);

  const toggle = (list: string[], value: string, set: (v: string[]) => void) => {
    set(list.includes(value) ? list.filter((x) => x !== value) : [...list, value]);
  };

  const toggleCompare = (slug: string) => {
    setCompare((prev) => {
      if (prev.includes(slug)) return prev.filter((x) => x !== slug);
      if (prev.length >= 3) return [...prev.slice(1), slug];
      return [...prev, slug];
    });
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#05070c] flex items-center justify-center">
        <LoadingState label="Loading product experience…" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-[#05070c] flex items-center justify-center p-8">
        <ErrorState message={error} />
      </div>
    );
  }

  return (
    <ProductShell>
      {/* Hero */}
      <section className="relative pt-28 md:pt-36 pb-16 md:pb-24 overflow-hidden">
        <div className="absolute inset-0 bg-[#05070c]" />
        <div className="absolute inset-0 opacity-[0.35] grid-bg" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_20%_0%,rgba(61,220,132,0.16),transparent_50%)]" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_90%_20%,rgba(10,35,66,0.55),transparent_45%)]" />
        <div className="relative z-10 max-w-7xl mx-auto px-5 md:px-8">
          <motion.div initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7 }}>
            <p className="text-[#3DDC84] text-[11px] font-semibold tracking-[0.4em] uppercase mb-6">Product Experience</p>
            <h1 className="font-display text-4xl sm:text-6xl md:text-7xl lg:text-8xl font-bold tracking-tight leading-[0.98] max-w-5xl">
              Six families.
              <br />
              <span className="text-[#3DDC84]">One charging standard.</span>
            </h1>
            <p className="mt-7 text-base md:text-xl text-white/65 max-w-2xl leading-relaxed">
              From essential home charging to enterprise fleet power — a Tesla-grade product system with
              Apple-level clarity and ABB industrial trust.
            </p>
            <div className="mt-10 flex flex-wrap gap-3">
              <a href="#families" className="inline-flex items-center gap-2 px-7 py-3.5 rounded-full bg-[#3DDC84] text-[#0A2342] text-sm font-bold shadow-[0_0_40px_rgba(61,220,132,0.35)]">
                Explore families <ArrowRight size={16} />
              </a>
              <Link to="/products/compare" className="inline-flex items-center gap-2 px-7 py-3.5 rounded-full border border-white/15 text-sm font-semibold hover:border-[#3DDC84]/40">
                <GitCompare size={16} /> Compare products
              </Link>
              <Link to="/quote" className="inline-flex items-center gap-2 px-7 py-3.5 rounded-full border border-white/15 text-sm font-semibold hover:bg-white/5">
                Request a quote
              </Link>
            </div>
            <div className="mt-14 grid grid-cols-2 md:grid-cols-4 gap-3 max-w-3xl">
              {[
                { l: 'Families', v: '6' },
                { l: 'Power ladder', v: '3.7–44 kW' },
                { l: 'Protocol', v: 'OCPP 1.6J' },
                { l: 'Platform', v: 'Cloud + App' },
              ].map((s) => (
                <div key={s.l} className="rounded-2xl border border-white/10 bg-white/[0.03] backdrop-blur p-4">
                  <p className="text-[10px] uppercase tracking-wider text-white/40">{s.l}</p>
                  <p className="font-display text-lg font-bold mt-1">{s.v}</p>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* Family strip */}
      <section className="border-y border-white/5 bg-[#0A2342]/40">
        <div className="max-w-7xl mx-auto px-5 md:px-8 py-5 flex gap-2 overflow-x-auto">
          {lines.map((line) => (
            <a
              key={line.slug}
              href={`#family-${line.slug}`}
              className="shrink-0 px-4 py-2 rounded-full border border-white/10 text-xs font-semibold text-white/70 hover:text-white hover:border-[#3DDC84]/40 transition-colors"
            >
              {line.name.replace('KYNETIK ', '')}
            </a>
          ))}
        </div>
      </section>

      {/* Filters */}
      <section className="py-10">
        <div className="max-w-7xl mx-auto px-5 md:px-8 space-y-4">
          <div className="flex items-center gap-2 text-xs text-white/40 font-semibold uppercase tracking-wider">
            <Filter size={14} className="text-[#3DDC84]" /> Filters
          </div>
          <FilterRow label="Power" items={POWER_FILTERS.map((p) => `${p} kW`)} active={power.map((p) => `${p} kW`)} onToggle={(v) => toggle(power, v.replace(' kW', ''), setPower)} />
          <FilterRow label="Usage" items={USAGE_FILTERS} active={usage} onToggle={(v) => toggle(usage, v, setUsage)} />
          <FilterRow label="Features" items={FEATURE_FILTERS} active={features} onToggle={(v) => toggle(features, v, setFeatures)} />
          {(power.length > 0 || usage.length > 0 || features.length > 0) && (
            <button type="button" onClick={() => { setPower([]); setUsage([]); setFeatures([]); }} className="text-xs text-white/45 hover:text-white">
              Clear filters · {filtered.length} result(s)
            </button>
          )}
        </div>
      </section>

      {/* Families */}
      <section id="families" className="pb-24">
        <div className="max-w-7xl mx-auto px-5 md:px-8 space-y-8">
          {filtered.map((line, i) => {
            const powers = parseJson<string[]>(line.powers, []);
            const feats = parseJson<string[]>(line.features, []);
            const inCompare = compare.includes(line.slug);
            return (
              <motion.article
                key={line.id}
                id={`family-${line.slug}`}
                initial={{ opacity: 0, y: 28 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-40px' }}
                transition={{ delay: Math.min(i * 0.04, 0.2), duration: 0.55 }}
                className="group rounded-[2rem] border border-white/10 overflow-hidden bg-gradient-to-br from-white/[0.04] via-transparent to-[#0A2342]/30 hover:border-[#3DDC84]/25 transition-colors"
              >
                <div className="grid lg:grid-cols-[1.05fr_1fr]">
                  <div
                    className="relative min-h-[300px] lg:min-h-[420px] flex items-center justify-center p-8 md:p-12"
                    style={{ background: `radial-gradient(circle at 50% 45%, ${line.accent}26, transparent 62%)` }}
                  >
                    <div className="absolute inset-0 opacity-30 grid-bg" />
                    <motion.img
                      whileHover={{ y: -8, scale: 1.03 }}
                      transition={{ type: 'spring', stiffness: 200, damping: 18 }}
                      src={line.image_hero}
                      alt={line.name}
                      className="relative z-10 max-h-[320px] w-auto object-contain drop-shadow-[0_30px_80px_rgba(0,0,0,0.45)]"
                      loading="lazy"
                    />
                    <div className="absolute top-6 left-6 px-3 py-1 rounded-full text-[10px] font-bold tracking-[0.2em] uppercase border border-white/10 bg-black/40 backdrop-blur" style={{ color: line.accent }}>
                      {line.category}
                    </div>
                  </div>
                  <div className="p-8 md:p-12 flex flex-col border-t lg:border-t-0 lg:border-l border-white/5">
                    <p className="text-[11px] uppercase tracking-[0.25em] text-white/40 font-semibold">{line.segment}</p>
                    <h2 className="font-display text-3xl md:text-4xl font-bold mt-2 tracking-tight">{line.name.replace('KYNETIK ', '')}</h2>
                    <p className="mt-3 text-lg font-display" style={{ color: line.accent }}>{line.tagline}</p>
                    <p className="mt-4 text-sm text-white/55 leading-relaxed">{line.description}</p>
                    <div className="mt-5 flex flex-wrap gap-2">
                      {powers.map((p) => (
                        <span key={p} className="text-[11px] px-3 py-1.5 rounded-full bg-white/5 border border-white/10 font-semibold text-white/80">{p}</span>
                      ))}
                    </div>
                    <div className="mt-6 flex flex-wrap gap-2">
                      {feats.slice(0, 8).map((f) => (
                        <span key={f} className="inline-flex items-center gap-1 text-[10px] px-2.5 py-1 rounded-md bg-black/30 border border-white/8 text-white/50">
                          <Check size={10} style={{ color: line.accent }} /> {f}
                        </span>
                      ))}
                    </div>
                    <div className="mt-auto pt-8 flex flex-wrap gap-2">
                      <Link
                        to={`/products/${line.slug}`}
                        onClick={() => track('Product Clicked', { slug: line.slug })}
                        className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full text-xs font-bold text-[#0A2342]"
                        style={{ background: line.accent || '#3DDC84' }}
                      >
                        View product <ArrowRight size={14} />
                      </Link>
                      <button
                        type="button"
                        onClick={() => toggleCompare(line.slug)}
                        className={cn(
                          'inline-flex items-center gap-2 px-5 py-2.5 rounded-full border text-xs font-semibold',
                          inCompare ? 'border-[#3DDC84]/50 text-[#3DDC84]' : 'border-white/15 text-white/70'
                        )}
                      >
                        <GitCompare size={13} /> {inCompare ? 'Selected' : 'Compare'}
                      </button>
                      <Link to="/quote" className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full border border-white/15 text-xs font-semibold text-white/70">
                        Request quote
                      </Link>
                      <button
                        type="button"
                        onClick={() => track('Datasheet Downloaded', { product: line.slug })}
                        className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full border border-white/15 text-xs font-semibold text-white/70"
                      >
                        <Download size={13} /> Datasheet
                      </button>
                    </div>
                  </div>
                </div>
              </motion.article>
            );
          })}
          {!filtered.length && (
            <p className="text-center text-white/40 py-16">No products match these filters.</p>
          )}
        </div>
      </section>

      {/* Compare bar */}
      {compare.length > 0 && (
        <div className="fixed bottom-0 inset-x-0 z-40 p-4 md:p-6 pointer-events-none">
          <div className="max-w-4xl mx-auto pointer-events-auto rounded-2xl border border-[#3DDC84]/30 bg-[#0A2342]/95 backdrop-blur-xl px-5 py-4 flex flex-wrap items-center justify-between gap-3 shadow-2xl">
            <div>
              <p className="text-sm font-semibold">{compare.length}/3 selected</p>
              <p className="text-[11px] text-white/50">{compare.map((s) => s.toUpperCase()).join(' · ')}</p>
            </div>
            <div className="flex gap-2">
              <button type="button" onClick={() => setCompare([])} className="px-4 py-2 rounded-full border border-white/15 text-xs font-semibold">Clear</button>
              <Link
                to={`/products/compare?ids=${compare.join(',')}`}
                className="inline-flex items-center gap-2 px-5 py-2 rounded-full bg-[#3DDC84] text-[#0A2342] text-xs font-bold"
              >
                Open comparison <ArrowRight size={14} />
              </Link>
            </div>
          </div>
        </div>
      )}

      {/* Platform band */}
      <section className="py-20 border-t border-white/5 bg-[#0A2342]/25">
        <div className="max-w-7xl mx-auto px-5 md:px-8 grid md:grid-cols-3 gap-4">
          {[
            { icon: Smartphone, t: 'KYNETIK App', d: 'Start/stop, scheduling, RFID and live sessions.', to: '/kynetik-app' },
            { icon: Cloud, t: 'KYNETIK Cloud', d: 'OCPP orchestration, analytics and multi-site control.', to: '/cloud' },
            { icon: Shield, t: 'Enterprise trust', d: 'IP/IK rated hardware with certified installation paths.', to: '/support' },
          ].map(({ icon: Icon, t, d, to }) => (
            <Link key={t} to={to} className="rounded-3xl border border-white/10 bg-black/20 p-6 hover:border-[#3DDC84]/30 transition-colors">
              <Icon className="text-[#3DDC84] mb-4" size={22} />
              <p className="font-display text-xl font-bold">{t}</p>
              <p className="text-sm text-white/50 mt-2">{d}</p>
            </Link>
          ))}
        </div>
      </section>

      {/* Downloads */}
      <section className="py-16 border-t border-white/5">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <h2 className="font-display text-2xl md:text-3xl font-bold mb-6">Downloads</h2>
          <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-3">
            {['Datasheet', 'Installation Guide', 'Warranty', 'Declaration of Conformity', 'User Manual'].map((doc) => (
              <button
                key={doc}
                type="button"
                onClick={() => track('Datasheet Downloaded', { file: doc })}
                className="rounded-2xl border border-white/10 bg-white/[0.02] p-5 text-left hover:border-[#3DDC84]/30 transition-colors"
              >
                <FileText className="text-[#3DDC84] mb-3" size={18} />
                <p className="font-semibold text-sm">{doc}</p>
                <p className="text-xs text-white/40 mt-1">PDF pack</p>
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-24 relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(61,220,132,0.12),transparent_55%)]" />
        <div className="relative z-10 max-w-3xl mx-auto px-5 text-center">
          <Zap className="mx-auto text-[#3DDC84] mb-5" size={28} />
          <h2 className="font-display text-3xl md:text-5xl font-bold tracking-tight">Choose your power.</h2>
          <p className="mt-4 text-white/55">Request a formal quotation with installation options for any family.</p>
          <div className="mt-8 flex flex-wrap justify-center gap-3">
            <Link to="/quote" className="inline-flex items-center gap-2 px-8 py-3.5 rounded-full bg-[#3DDC84] text-[#0A2342] text-sm font-bold">
              Request a Quote <ArrowRight size={16} />
            </Link>
            <Link to="/configurator" className="inline-flex items-center gap-2 px-8 py-3.5 rounded-full border border-white/15 text-sm font-semibold">
              Open Configurator
            </Link>
          </div>
        </div>
      </section>
    </ProductShell>
  );
}

function FilterRow({
  label,
  items,
  active,
  onToggle,
}: {
  label: string;
  items: string[];
  active: string[];
  onToggle: (v: string) => void;
}) {
  return (
    <div className="flex flex-wrap items-center gap-2">
      <span className="text-[10px] uppercase tracking-wider text-white/35 font-semibold w-16">{label}</span>
      {items.map((item) => {
        const on = active.includes(item);
        return (
          <button
            key={item}
            type="button"
            onClick={() => onToggle(item)}
            className={cn(
              'px-3 py-1.5 rounded-full text-xs font-semibold border transition-colors',
              on ? 'bg-[#3DDC84] text-[#0A2342] border-[#3DDC84]' : 'border-white/12 text-white/65 hover:border-white/25'
            )}
          >
            {item}
          </button>
        );
      })}
    </div>
  );
}

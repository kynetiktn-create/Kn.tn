import { useEffect, useMemo, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { motion, AnimatePresence, useMotionValue, useTransform, animate } from 'framer-motion';
import {
  ArrowRight, Check, GitCompare, Minus, X, Zap, Wifi, Bluetooth, Network,
  Radio, Cloud, Smartphone, Shield, Gauge, Award, Home, Building2,
  Truck, MapPin, Sparkles, ChevronDown
} from 'lucide-react';
import ProductShell from '../../components/products/ProductShell';
import LoadingState from '../../components/LoadingState';
import ErrorState from '../../components/ErrorState';
import { apiGet, cn } from '../../lib/utils';
import { parseJson, type ProductLine } from '../../lib/productTypes';

type SpecMap = Record<string, string>;

interface SpecRow {
  key: string;
  label: string;
  group: 'power' | 'connectivity' | 'platform' | 'protection' | 'usage';
  icon?: typeof Zap;
  fallback?: (l: ProductLine, specs: SpecMap) => string;
}

const SPEC_ROWS: SpecRow[] = [
  {
    key: 'Power',
    label: 'Power',
    group: 'power',
    icon: Zap,
    fallback: (l) => parseJson<string[]>(l.powers, []).join(' · ') || l.powers || '—',
  },
  { key: 'Phase', label: 'Phase', group: 'power', icon: Gauge },
  { key: 'Current', label: 'Current', group: 'power', icon: Zap },
  { key: 'WiFi', label: 'WiFi', group: 'connectivity', icon: Wifi },
  { key: 'Bluetooth', label: 'Bluetooth', group: 'connectivity', icon: Bluetooth },
  { key: 'Ethernet', label: 'Ethernet', group: 'connectivity', icon: Network },
  { key: 'RFID', label: 'RFID', group: 'connectivity', icon: Radio },
  { key: 'OCPP', label: 'OCPP', group: 'platform', icon: Network },
  { key: 'Dynamic Load Balancing', label: 'Dynamic Load Balancing', group: 'platform', icon: Gauge },
  { key: 'Cloud', label: 'Cloud', group: 'platform', icon: Cloud },
  { key: 'Mobile App', label: 'Mobile App', group: 'platform', icon: Smartphone },
  { key: 'Protection', label: 'Protection', group: 'protection', icon: Shield },
  {
    key: 'IP',
    label: 'IP',
    group: 'protection',
    icon: Shield,
    fallback: (_l, s) => s.IP || s['IP rating'] || '—',
  },
  {
    key: 'IK',
    label: 'IK',
    group: 'protection',
    icon: Shield,
    fallback: (_l, s) => s.IK || s['IK rating'] || '—',
  },
  { key: 'Warranty', label: 'Warranty', group: 'protection', icon: Award },
  {
    key: 'Recommended Usage',
    label: 'Recommended Usage',
    group: 'usage',
    icon: Home,
    fallback: (l) => {
      const cases = parseJson<string[]>(l.use_cases, []);
      if (cases.length) return cases.slice(0, 3).join(' · ');
      return l.segment || l.category || '—';
    },
  },
];

const GROUP_META: Record<SpecRow['group'], { title: string; subtitle: string }> = {
  power: { title: 'Power & electrical', subtitle: 'Output, phases and current envelope' },
  connectivity: { title: 'Connectivity', subtitle: 'Local networks and access hardware' },
  platform: { title: 'Intelligence platform', subtitle: 'Cloud, OCPP, app and load control' },
  protection: { title: 'Safety & durability', subtitle: 'Protection class, ratings and warranty' },
  usage: { title: 'Recommended usage', subtitle: 'Where each product delivers the most value' },
};

const FAMILY_ORDER = ['go', 'flex', 'nova', 'prime', 'edge', 'pro'];

function cellValue(line: ProductLine, row: SpecRow) {
  const specs = parseJson<SpecMap>(line.specs, {});
  if (row.fallback) {
    const v = specs[row.key];
    if (v && v !== '—') return v;
    return row.fallback(line, specs);
  }
  return specs[row.key] || specs[row.label] || '—';
}

function scoreValue(v: string): 'yes' | 'partial' | 'no' | 'text' {
  const t = v.toLowerCase().trim();
  if (!t || t === '—' || t === '-' || t === 'no' || t === 'n/a') return 'no';
  if (
    t === 'yes' ||
    t.includes('cloud') ||
    t.startsWith('ocpp') ||
    t.includes('ready') ||
    t.includes('integration') ||
    t === 'app + cloud ready'
  )
    return 'yes';
  if (t.includes('optional') || t.includes('smart scheduling') || t.includes('enterprise')) return 'partial';
  return 'text';
}

function extractKw(line: ProductLine): number {
  const specs = parseJson<SpecMap>(line.specs, {});
  const blob = `${specs.Power || ''} ${line.powers || ''}`;
  const nums = [...blob.matchAll(/(\d+(?:\.\d+)?)\s*kW/gi)].map((m) => parseFloat(m[1]));
  if (nums.length) return Math.max(...nums);
  const plain = [...blob.matchAll(/(\d+(?:\.\d+)?)/g)].map((m) => parseFloat(m[1]));
  return plain.length ? Math.max(...plain) : 0;
}

function warrantyYears(line: ProductLine): number {
  const specs = parseJson<SpecMap>(line.specs, {});
  const m = (specs.Warranty || '').match(/(\d+)/);
  return m ? parseInt(m[1], 10) : 0;
}

function AnimatedNumber({ value, suffix = '' }: { value: number; suffix?: string }) {
  const mv = useMotionValue(0);
  const rounded = useTransform(mv, (v) => (Number.isInteger(value) ? Math.round(v) : v.toFixed(1)));
  const [display, setDisplay] = useState('0');

  useEffect(() => {
    const controls = animate(mv, value, { duration: 1.1, ease: 'easeOut' });
    const unsub = rounded.on('change', (v) => setDisplay(String(v)));
    return () => {
      controls.stop();
      unsub();
    };
  }, [value, mv, rounded]);

  return (
    <span>
      {display}
      {suffix}
    </span>
  );
}

function StatusCell({ value }: { value: string }) {
  const kind = scoreValue(value);
  if (kind === 'yes') {
    return (
      <span className="inline-flex items-center gap-2 text-[#3DDC84] font-medium">
        <span className="w-6 h-6 rounded-full bg-[#3DDC84]/15 border border-[#3DDC84]/30 flex items-center justify-center">
          <Check size={13} strokeWidth={2.5} />
        </span>
        {value === 'Yes' ? 'Included' : value}
      </span>
    );
  }
  if (kind === 'partial') {
    return (
      <span className="inline-flex items-center gap-2 text-amber-300/90 font-medium">
        <span className="w-6 h-6 rounded-full bg-amber-400/10 border border-amber-300/25 flex items-center justify-center text-[10px] font-bold">
          ~
        </span>
        {value}
      </span>
    );
  }
  if (kind === 'no') {
    return (
      <span className="inline-flex items-center gap-2 text-white/30">
        <span className="w-6 h-6 rounded-full bg-white/5 border border-white/10 flex items-center justify-center">
          <Minus size={12} />
        </span>
        —
      </span>
    );
  }
  return <span className="text-white/85 leading-snug">{value}</span>;
}

function UsageIcon({ text }: { text: string }) {
  const t = text.toLowerCase();
  if (/fleet|depot|industrial|dealer/.test(t)) return <Truck size={14} />;
  if (/hotel|business|parking|retail|public|commercial/.test(t)) return <Building2 size={14} />;
  if (/travel|urban|shared/.test(t)) return <MapPin size={14} />;
  return <Home size={14} />;
}

export default function ProductCompare() {
  const [params, setParams] = useSearchParams();
  const [lines, setLines] = useState<ProductLine[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [selected, setSelected] = useState<string[]>([]);
  const [openGroup, setOpenGroup] = useState<Record<string, boolean>>({
    power: true,
    connectivity: true,
    platform: true,
    protection: true,
    usage: true,
  });

  useEffect(() => {
    apiGet<ProductLine[]>('/api/product-lines')
      .then((data) => {
        const sorted = [...data].sort((a, b) => {
          const ai = FAMILY_ORDER.indexOf(a.slug);
          const bi = FAMILY_ORDER.indexOf(b.slug);
          return (ai === -1 ? 99 : ai) - (bi === -1 ? 99 : bi);
        });
        setLines(sorted);
        const fromQuery = (params.get('ids') || '')
          .split(',')
          .map((s) => s.trim())
          .filter(Boolean);
        if (fromQuery.length) setSelected(fromQuery.slice(0, 3));
        else {
          const defaults = ['nova', 'prime', 'pro'].filter((s) => sorted.some((l) => l.slug === s));
          setSelected(defaults.length ? defaults : sorted.slice(0, 3).map((d) => d.slug));
        }
      })
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, []);

  const compared = useMemo(
    () => selected.map((slug) => lines.find((l) => l.slug === slug)).filter(Boolean) as ProductLine[],
    [selected, lines]
  );

  const stats = useMemo(() => {
    if (!compared.length) return { maxKw: 0, avgWarranty: 0, cloudReady: 0 };
    const maxKw = Math.max(...compared.map(extractKw));
    const warranties = compared.map(warrantyYears).filter(Boolean);
    const avgWarranty = warranties.length
      ? warranties.reduce((a, b) => a + b, 0) / warranties.length
      : 0;
    const cloudReady = compared.filter((c) => {
      const v = cellValue(c, SPEC_ROWS.find((r) => r.key === 'Cloud')!);
      return scoreValue(v) === 'yes';
    }).length;
    return { maxKw, avgWarranty, cloudReady };
  }, [compared]);

  const toggle = (slug: string) => {
    setSelected((prev) => {
      let next: string[];
      if (prev.includes(slug)) next = prev.filter((s) => s !== slug);
      else if (prev.length >= 3) next = [...prev.slice(1), slug];
      else next = [...prev, slug];
      setParams(next.length ? { ids: next.join(',') } : {});
      return next;
    });
  };

  const clearAll = () => {
    setSelected([]);
    setParams({});
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#05070c] flex items-center justify-center">
        <LoadingState label="Loading comparison matrix…" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-[#05070c] flex items-center justify-center p-8">
        <ErrorState message={error} />
      </div>
    );
  }

  const groups = (['power', 'connectivity', 'platform', 'protection', 'usage'] as const).map((g) => ({
    id: g,
    ...GROUP_META[g],
    rows: SPEC_ROWS.filter((r) => r.group === g),
  }));

  return (
    <ProductShell ctaHref="/quote" ctaLabel="Request quote">
      {/* HERO */}
      <section className="pt-28 md:pt-36 pb-10 relative overflow-hidden">
        <div className="absolute inset-0">
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_20%_0%,rgba(61,220,132,0.16),transparent_45%)]" />
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_90%_20%,rgba(45,212,191,0.08),transparent_40%)]" />
          <div
            className="absolute inset-0 opacity-[0.35]"
            style={{
              backgroundImage:
                'linear-gradient(rgba(255,255,255,0.03) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.03) 1px, transparent 1px)',
              backgroundSize: '64px 64px',
            }}
          />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-5 md:px-8">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-[#3DDC84]/30 bg-[#3DDC84]/10 text-[#3DDC84] text-[11px] font-semibold tracking-[0.2em] uppercase mb-6">
              <GitCompare size={13} /> Product intelligence
            </div>
            <h1 className="font-display text-4xl sm:text-5xl md:text-6xl lg:text-[4rem] font-bold tracking-tight leading-[1.05] max-w-4xl">
              Compare the KYNETIK
              <br />
              <span className="text-[#3DDC84]">charging family</span>
            </h1>
            <p className="mt-5 text-base md:text-lg text-white/55 max-w-2xl leading-relaxed">
              Side-by-side specifications for power, connectivity, Cloud intelligence and protection —
              engineered like a European premium EV brand, presented like an Apple product matrix.
            </p>
          </motion.div>

          {/* Animated stats */}
          <div className="mt-12 grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4">
            {[
              {
                label: 'Products in view',
                node: <AnimatedNumber value={compared.length} />,
                sub: 'max 3',
              },
              {
                label: 'Peak power',
                node: (
                  <>
                    <AnimatedNumber value={stats.maxKw || 0} />
                    <span className="text-lg md:text-xl text-white/50 ml-1">kW</span>
                  </>
                ),
                sub: 'among selection',
              },
              {
                label: 'Avg. warranty',
                node: (
                  <>
                    <AnimatedNumber value={Number(stats.avgWarranty.toFixed(1))} />
                    <span className="text-lg md:text-xl text-white/50 ml-1">yrs</span>
                  </>
                ),
                sub: 'selected set',
              },
              {
                label: 'Cloud-ready',
                node: (
                  <>
                    <AnimatedNumber value={stats.cloudReady} />
                    <span className="text-lg md:text-xl text-white/50 ml-1">/{compared.length || 0}</span>
                  </>
                ),
                sub: 'platform linked',
              },
            ].map((s, i) => (
              <motion.div
                key={s.label}
                initial={{ opacity: 0, y: 14 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 + i * 0.06 }}
                className="rounded-2xl border border-white/10 bg-white/[0.03] backdrop-blur-xl p-5 md:p-6"
              >
                <p className="text-[10px] uppercase tracking-[0.2em] text-white/40 font-semibold">{s.label}</p>
                <p className="mt-2 font-display text-3xl md:text-4xl font-bold text-white">{s.node}</p>
                <p className="mt-1 text-xs text-white/35">{s.sub}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* PICKER */}
      <section className="pb-8">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <div className="flex flex-wrap items-end justify-between gap-4 mb-5">
            <div>
              <p className="text-[11px] uppercase tracking-[0.25em] text-white/40 font-semibold">Select products</p>
              <p className="text-sm text-white/55 mt-1">Choose up to 3 models · click again to remove</p>
            </div>
            <div className="flex items-center gap-3 text-xs">
              <span className="text-white/40">{selected.length}/3 selected</span>
              {selected.length > 0 && (
                <button type="button" onClick={clearAll} className="text-white/50 hover:text-white underline-offset-2 hover:underline">
                  Clear all
                </button>
              )}
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
            {lines.map((line, i) => {
              const on = selected.includes(line.slug);
              const disabled = !on && selected.length >= 3;
              return (
                <motion.button
                  key={line.slug}
                  type="button"
                  disabled={disabled}
                  onClick={() => toggle(line.slug)}
                  initial={{ opacity: 0, y: 12 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.04 }}
                  className={cn(
                    'relative text-left rounded-2xl border p-4 transition-all duration-300 group overflow-hidden',
                    on
                      ? 'border-[#3DDC84]/45 bg-[#3DDC84]/[0.07] shadow-[0_0_40px_rgba(61,220,132,0.12)]'
                      : 'border-white/10 bg-white/[0.02] hover:border-white/20 hover:bg-white/[0.04]',
                    disabled && 'opacity-40 cursor-not-allowed'
                  )}
                >
                  <div
                    className="h-28 md:h-32 flex items-center justify-center mb-3 rounded-xl"
                    style={{
                      background: `radial-gradient(circle at 50% 60%, ${line.accent}33, transparent 68%)`,
                    }}
                  >
                    <img
                      src={line.image_hero}
                      alt={line.name}
                      className="max-h-[90%] w-auto object-contain drop-shadow-[0_18px_30px_rgba(0,0,0,0.45)] transition-transform duration-500 group-hover:scale-105"
                    />
                  </div>
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <p className="font-display font-bold text-sm" style={{ color: on ? '#3DDC84' : line.accent }}>
                        {line.name.replace('KYNETIK ', '')}
                      </p>
                      <p className="text-[10px] text-white/40 mt-0.5 line-clamp-1">{line.segment}</p>
                    </div>
                    <span
                      className={cn(
                        'w-6 h-6 rounded-full border flex items-center justify-center shrink-0',
                        on ? 'bg-[#3DDC84] border-[#3DDC84] text-[#0A2342]' : 'border-white/15 text-white/30'
                      )}
                    >
                      {on ? <Check size={12} strokeWidth={3} /> : <Minus size={12} />}
                    </span>
                  </div>
                </motion.button>
              );
            })}
          </div>
        </div>
      </section>

      {/* COMPARISON STAGE */}
      <section className="pb-10">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <AnimatePresence mode="wait">
            {compared.length === 0 ? (
              <motion.div
                key="empty"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="rounded-[2rem] border border-dashed border-white/15 bg-white/[0.02] p-16 text-center"
              >
                <Sparkles className="mx-auto text-[#3DDC84] mb-4" size={28} />
                <p className="font-display text-xl font-semibold">Select products to begin</p>
                <p className="text-sm text-white/45 mt-2">Pick 2–3 chargers to unlock the full specification matrix.</p>
              </motion.div>
            ) : (
              <motion.div
                key={selected.join('-')}
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.45 }}
              >
                {/* Hero product cards */}
                <div
                  className={cn(
                    'grid gap-4 md:gap-5 mb-10',
                    compared.length === 1 && 'md:grid-cols-1 max-w-md mx-auto',
                    compared.length === 2 && 'md:grid-cols-2',
                    compared.length === 3 && 'md:grid-cols-3'
                  )}
                >
                  {compared.map((c, idx) => {
                    const kw = extractKw(c);
                    const specs = parseJson<SpecMap>(c.specs, {});
                    return (
                      <motion.div
                        key={c.id}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: idx * 0.08 }}
                        className="relative rounded-[1.75rem] border border-white/10 bg-gradient-to-b from-white/[0.06] to-white/[0.015] overflow-hidden backdrop-blur-xl"
                      >
                        <div
                          className="absolute inset-0 opacity-80 pointer-events-none"
                          style={{
                            background: `radial-gradient(ellipse at 50% 20%, ${c.accent}22, transparent 55%)`,
                          }}
                        />
                        <button
                          type="button"
                          onClick={() => toggle(c.slug)}
                          className="absolute top-4 right-4 z-20 w-8 h-8 rounded-full bg-black/40 border border-white/10 flex items-center justify-center text-white/50 hover:text-white hover:border-white/25 transition-colors"
                          aria-label={`Remove ${c.name}`}
                        >
                          <X size={14} />
                        </button>

                        <div className="relative z-10 p-6 md:p-8">
                          <p className="text-[10px] uppercase tracking-[0.25em] text-white/40 font-semibold">
                            {c.category}
                          </p>
                          <h2 className="font-display text-2xl md:text-3xl font-bold mt-1" style={{ color: c.accent }}>
                            {c.name.replace('KYNETIK ', '')}
                          </h2>
                          <p className="text-sm text-white/50 mt-2 line-clamp-2 min-h-[2.5rem]">{c.tagline}</p>

                          <div className="mt-6 h-52 md:h-60 flex items-center justify-center">
                            <img
                              src={c.image_hero}
                              alt={c.name}
                              className="max-h-full w-auto object-contain drop-shadow-[0_30px_60px_rgba(0,0,0,0.55)]"
                            />
                          </div>

                          <div className="mt-4 grid grid-cols-3 gap-2">
                            {[
                              { l: 'Peak', v: kw ? `${kw} kW` : '—' },
                              { l: 'IP', v: specs.IP || '—' },
                              { l: 'Cover', v: specs.Warranty?.split('·')[0]?.trim() || '—' },
                            ].map((chip) => (
                              <div key={chip.l} className="rounded-xl bg-black/35 border border-white/8 px-2.5 py-2.5 text-center">
                                <p className="text-[9px] uppercase tracking-wider text-white/35">{chip.l}</p>
                                <p className="text-xs font-semibold text-white mt-0.5 truncate">{chip.v}</p>
                              </div>
                            ))}
                          </div>

                          <div className="mt-5 flex flex-wrap gap-2">
                            <Link
                              to={`/products/${c.slug}`}
                              className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-full text-xs font-bold text-[#0A2342]"
                              style={{ background: c.accent }}
                            >
                              View product <ArrowRight size={12} />
                            </Link>
                            <Link
                              to="/quote"
                              className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-full text-xs font-semibold border border-white/15 text-white/80 hover:bg-white/5"
                            >
                              Quote
                            </Link>
                          </div>
                        </div>
                      </motion.div>
                    );
                  })}
                </div>

                {/* Spec matrix */}
                <div className="rounded-[2rem] border border-white/10 overflow-hidden bg-[#070a10]/90 backdrop-blur-xl shadow-[0_40px_120px_rgba(0,0,0,0.45)]">
                  <div className="px-5 md:px-8 py-6 border-b border-white/8 flex flex-wrap items-center justify-between gap-3 bg-white/[0.02]">
                    <div>
                      <p className="font-display text-xl font-bold">Specification matrix</p>
                      <p className="text-xs text-white/40 mt-1">Power · Connectivity · Platform · Protection · Usage</p>
                    </div>
                    <div className="hidden md:flex items-center gap-4 text-[10px] uppercase tracking-wider text-white/35">
                      <span className="inline-flex items-center gap-1.5">
                        <span className="w-2 h-2 rounded-full bg-[#3DDC84]" /> Included
                      </span>
                      <span className="inline-flex items-center gap-1.5">
                        <span className="w-2 h-2 rounded-full bg-amber-300" /> Partial / optional
                      </span>
                      <span className="inline-flex items-center gap-1.5">
                        <span className="w-2 h-2 rounded-full bg-white/20" /> Not available
                      </span>
                    </div>
                  </div>

                  {/* Sticky header row on desktop */}
                  <div className="overflow-x-auto">
                    <div className="min-w-[720px]">
                      <div
                        className="grid border-b border-white/8 bg-[#0a0e16]/95 sticky top-0 z-10"
                        style={{ gridTemplateColumns: `220px repeat(${compared.length}, minmax(180px, 1fr))` }}
                      >
                        <div className="px-5 md:px-6 py-4 text-[10px] uppercase tracking-[0.2em] text-white/35 font-semibold flex items-center">
                          Specification
                        </div>
                        {compared.map((c) => (
                          <div key={c.id} className="px-5 py-4 border-l border-white/5">
                            <p className="font-display font-bold text-sm" style={{ color: c.accent }}>
                              {c.name.replace('KYNETIK ', '')}
                            </p>
                            <p className="text-[10px] text-white/35 mt-0.5 truncate">{c.segment}</p>
                          </div>
                        ))}
                      </div>

                      {groups.map((group) => (
                        <div key={group.id} className="border-b border-white/6 last:border-b-0">
                          <button
                            type="button"
                            onClick={() => setOpenGroup((g) => ({ ...g, [group.id]: !g[group.id] }))}
                            className="w-full flex items-center justify-between gap-3 px-5 md:px-6 py-4 bg-white/[0.015] hover:bg-white/[0.03] transition-colors text-left"
                          >
                            <div>
                              <p className="text-sm font-semibold text-white">{group.title}</p>
                              <p className="text-[11px] text-white/35 mt-0.5">{group.subtitle}</p>
                            </div>
                            <ChevronDown
                              size={16}
                              className={cn('text-white/40 transition-transform', openGroup[group.id] && 'rotate-180')}
                            />
                          </button>

                          <AnimatePresence initial={false}>
                            {openGroup[group.id] && (
                              <motion.div
                                initial={{ height: 0, opacity: 0 }}
                                animate={{ height: 'auto', opacity: 1 }}
                                exit={{ height: 0, opacity: 0 }}
                                transition={{ duration: 0.28 }}
                                className="overflow-hidden"
                              >
                                {group.rows.map((row, ri) => {
                                  const Icon = row.icon || Zap;
                                  return (
                                    <div
                                      key={row.key}
                                      className={cn(
                                        'grid items-center',
                                        ri % 2 === 0 ? 'bg-transparent' : 'bg-white/[0.015]'
                                      )}
                                      style={{
                                        gridTemplateColumns: `220px repeat(${compared.length}, minmax(180px, 1fr))`,
                                      }}
                                    >
                                      <div className="px-5 md:px-6 py-4 flex items-center gap-2.5 text-white/50 text-sm">
                                        <Icon size={14} className="text-[#3DDC84]/80 shrink-0" />
                                        <span className="font-medium">{row.label}</span>
                                      </div>
                                      {compared.map((c) => {
                                        const v = cellValue(c, row);
                                        return (
                                          <div key={c.id + row.key} className="px-5 py-4 border-l border-white/5 text-sm">
                                            {row.key === 'Recommended Usage' ? (
                                              <span className="inline-flex items-start gap-2 text-white/80">
                                                <span className="mt-0.5 text-[#3DDC84]">
                                                  <UsageIcon text={v} />
                                                </span>
                                                <span className="leading-snug">{v}</span>
                                              </span>
                                            ) : (
                                              <StatusCell value={v} />
                                            )}
                                          </div>
                                        );
                                      })}
                                    </div>
                                  );
                                })}
                              </motion.div>
                            )}
                          </AnimatePresence>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Insight cards */}
                <div className="mt-10 grid md:grid-cols-3 gap-4">
                  {[
                    {
                      icon: Sparkles,
                      title: 'European-grade craft',
                      body: 'IP/IK ratings, RCD protection and MID-ready metering language across the portfolio.',
                    },
                    {
                      icon: Cloud,
                      title: 'One Cloud ecosystem',
                      body: 'OCPP, dynamic load balancing and mobile control keep every SKU inside the same KYNETIK stack.',
                    },
                    {
                      icon: Gauge,
                      title: 'Right power, right site',
                      body: 'From portable GO to dual-output PRO — match feeder capacity to usage without overbuying.',
                    },
                  ].map((card, i) => (
                    <motion.div
                      key={card.title}
                      initial={{ opacity: 0, y: 12 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      viewport={{ once: true }}
                      transition={{ delay: i * 0.06 }}
                      className="rounded-2xl border border-white/10 bg-white/[0.03] p-6"
                    >
                      <card.icon className="text-[#3DDC84] mb-4" size={20} />
                      <p className="font-display font-semibold text-lg">{card.title}</p>
                      <p className="text-sm text-white/45 mt-2 leading-relaxed">{card.body}</p>
                    </motion.div>
                  ))}
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* CTA */}
          <div className="mt-14 rounded-[2rem] border border-[#3DDC84]/20 bg-gradient-to-br from-[#3DDC84]/10 via-transparent to-transparent p-8 md:p-12 text-center relative overflow-hidden">
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(61,220,132,0.12),transparent_60%)]" />
            <div className="relative z-10">
              <h3 className="font-display text-2xl md:text-4xl font-bold">
                Ready to specify the right charger?
              </h3>
              <p className="mt-3 text-white/55 max-w-xl mx-auto text-sm md:text-base">
                Share your site type and feeder capacity — KYNETIK will recommend the optimal configuration.
              </p>
              <div className="mt-8 flex flex-wrap justify-center gap-3">
                <Link
                  to="/quote"
                  className="inline-flex items-center gap-2 px-8 py-3.5 rounded-full bg-[#3DDC84] text-[#0A2342] text-sm font-bold shadow-[0_0_40px_rgba(61,220,132,0.25)]"
                >
                  Request a quote <ArrowRight size={16} />
                </Link>
                <Link
                  to="/products"
                  className="inline-flex items-center gap-2 px-8 py-3.5 rounded-full border border-white/15 text-sm font-semibold hover:bg-white/5"
                >
                  Browse all products
                </Link>
                <Link
                  to="/configurator"
                  className="inline-flex items-center gap-2 px-8 py-3.5 rounded-full border border-white/15 text-sm font-semibold hover:bg-white/5"
                >
                  Open configurator
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>
    </ProductShell>
  );
}

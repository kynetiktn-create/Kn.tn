import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  ArrowRight, BookOpen, Component, Copy, Check, Layers, Type, Palette,
  Box, Zap, Smartphone, Cloud, LayoutGrid
} from 'lucide-react';
import SectionHeader from '../components/SectionHeader';
import PhoneFrame from '../components/PhoneFrame';
import { DesignTokensMini } from '../components/mobile/screens';
import {
  Button, Badge, Input, StatusPill, SpecChip, ProductStage, SectionLabel,
  MetricTile, GlassPanel, ChargeRing, colors, space, radius, motion as motionTokens, type as typeTokens
} from '../ui';
import { useState } from 'react';
import { cn } from '../lib/utils';

const brandColors = [
  { name: 'KYNETIK Green', token: 'kyn-green', value: colors.green, use: 'Primary accent, CTAs, status online' },
  { name: 'Green Glow', token: 'kyn-green-glow', value: colors.greenGlow, use: 'Charging pulse / focus rings' },
  { name: 'Green Dim', token: 'kyn-green-dim', value: colors.greenDim, use: 'Pressed / secondary fill' },
  { name: 'Deep Black', token: 'kyn-black', value: colors.black, use: 'App & web page background' },
  { name: 'Void', token: 'kyn-void', value: colors.void, use: 'Sidebars, elevated chrome' },
  { name: 'Charcoal', token: 'kyn-charcoal', value: colors.charcoal, use: 'Nested panels' },
  { name: 'Steel', token: 'kyn-steel', value: colors.steel, use: 'Cards, inputs' },
  { name: 'Graphite', token: 'kyn-graphite', value: colors.graphite, use: 'Borders, muted chips' },
  { name: 'Metal', token: 'kyn-metal', value: colors.metal, use: 'Labels, captions' },
  { name: 'Silver', token: 'kyn-silver', value: colors.silver, use: 'Body secondary text' },
  { name: 'White', token: 'kyn-white', value: colors.white, use: 'Primary typography' },
  { name: 'Teal', token: 'teal', value: colors.teal, use: 'Series accent (PRIME)' },
];

const typeScale = [
  { name: 'Display XL', sample: "L'énergie en mouvement", className: 'font-display text-4xl md:text-5xl font-bold tracking-tight' },
  { name: 'Display LG', sample: 'KYNETIK Product System', className: 'font-display text-3xl font-bold' },
  { name: 'Title', sample: 'Cloud operator console', className: 'font-display text-xl font-semibold' },
  { name: 'Body', sample: 'Premium European EV charging — smart, sustainable, professional.', className: 'text-base text-kyn-silver leading-relaxed' },
  { name: 'Caption', sample: 'OCPP 1.6J · IP54 · 3-year warranty', className: 'text-xs text-kyn-metal tracking-wide' },
  { name: 'Mono Spec', sample: '22 kW · 32 A · Type 2', className: 'font-mono text-sm text-kyn-green' },
];

function TokenCopy({ value }: { value: string }) {
  const [ok, setOk] = useState(false);
  return (
    <button
      type="button"
      onClick={() => {
        navigator.clipboard?.writeText(value).catch(() => undefined);
        setOk(true);
        setTimeout(() => setOk(false), 1000);
      }}
      className="inline-flex items-center gap-1 font-mono text-[11px] text-kyn-green hover:text-kyn-green-glow"
    >
      {value}
      {ok ? <Check size={11} /> : <Copy size={11} className="opacity-50" />}
    </button>
  );
}

export default function DesignSystemTokens() {
  return (
    <div className="max-w-6xl mx-auto px-6 md:px-10 py-12 md:py-16">
      <SectionHeader
        eyebrow="Design System · Extended Tokens"
        title="KYNETIK digital language"
        description="Canonical colors, type, radius, spacing and domain components — same brand identity across Web, App and Cloud. Extend the system; never redesign the brand."
      />

      <div className="mb-10 flex flex-wrap gap-3">
        <Link to="/ui-library" className="inline-flex items-center gap-2 rounded-full bg-kyn-green px-4 py-2 text-xs font-bold text-kyn-black">
          Component library <ArrowRight size={14} />
        </Link>
        <Link to="/design-bible" className="inline-flex items-center gap-2 rounded-full border border-white/15 px-4 py-2 text-xs font-semibold text-kyn-silver hover:text-white">
          <BookOpen size={14} /> Design Bible
        </Link>
        <Link to="/design-system" className="inline-flex items-center gap-2 rounded-full border border-white/15 px-4 py-2 text-xs font-semibold text-kyn-silver hover:text-white">
          System overview
        </Link>
        <Link to="/tokens" className="inline-flex items-center gap-2 rounded-full border border-white/15 px-4 py-2 text-xs font-semibold text-kyn-silver hover:text-white">
          Classic tokens
        </Link>
      </div>

      <div className="grid lg:grid-cols-[280px_1fr] gap-10">
        <div className="space-y-6">
          <PhoneFrame label="Token reference">
            <DesignTokensMini />
          </PhoneFrame>
          <GlassPanel className="space-y-3">
            <SectionLabel>Surfaces</SectionLabel>
            {[
              { icon: LayoutGrid, t: 'Marketing Web' },
              { icon: Smartphone, t: 'Driver App' },
              { icon: Cloud, t: 'Operator Cloud' },
            ].map(({ icon: Icon, t }) => (
              <div key={t} className="flex items-center gap-3 text-sm text-kyn-silver">
                <span className="flex h-8 w-8 items-center justify-center rounded-lg border border-kyn-green/20 bg-kyn-green/10 text-kyn-green">
                  <Icon size={14} />
                </span>
                {t}
              </div>
            ))}
          </GlassPanel>
          <GlassPanel>
            <SectionLabel>Brand lock</SectionLabel>
            <ul className="mt-2 space-y-2 text-xs text-kyn-silver">
              <li>• Accent stays #00E676</li>
              <li>• Space Grotesk + Inter only</li>
              <li>• Dark-first UI always</li>
              <li>• No new brand palettes</li>
            </ul>
          </GlassPanel>
        </div>

        <div className="space-y-14">
          <section id="colors">
            <div className="mb-5 flex items-center gap-2">
              <Palette size={16} className="text-kyn-green" />
              <h2 className="font-display text-xl font-semibold">Color tokens</h2>
            </div>
            <p className="mb-5 text-sm text-kyn-metal max-w-xl">
              One electric accent. Neutrals stay cool graphite. Never introduce competing brand hues on product surfaces.
            </p>
            <div className="grid sm:grid-cols-2 xl:grid-cols-3 gap-3">
              {brandColors.map((c, i) => (
                <motion.div
                  key={c.value + c.name}
                  initial={{ opacity: 0, y: 10 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.02 }}
                  className="glass-card overflow-hidden rounded-2xl"
                >
                  <div className="h-16 border-b border-white/5" style={{ background: c.value }} />
                  <div className="p-3">
                    <p className="text-sm font-semibold text-white">{c.name}</p>
                    <TokenCopy value={c.value} />
                    <p className="mt-1 font-mono text-[10px] text-kyn-metal">--color-{c.token}</p>
                    <p className="mt-1.5 text-[11px] text-kyn-metal leading-snug">{c.use}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </section>

          <section id="type">
            <div className="mb-5 flex items-center gap-2">
              <Type size={16} className="text-kyn-green" />
              <h2 className="font-display text-xl font-semibold">Typography</h2>
            </div>
            <div className="grid md:grid-cols-2 gap-4 mb-4">
              <GlassPanel>
                <p className="text-[10px] uppercase tracking-widest text-kyn-metal mb-2">Display</p>
                <p className="font-display text-2xl font-bold">Space Grotesk</p>
                <p className="mt-2 font-mono text-[11px] text-kyn-green break-all">{typeTokens.display}</p>
              </GlassPanel>
              <GlassPanel>
                <p className="text-[10px] uppercase tracking-widest text-kyn-metal mb-2">Body / UI</p>
                <p className="text-2xl font-semibold">Inter</p>
                <p className="mt-2 font-mono text-[11px] text-kyn-green break-all">{typeTokens.body}</p>
              </GlassPanel>
            </div>
            <div className="space-y-3">
              {typeScale.map((t) => (
                <div key={t.name} className="rounded-2xl border border-white/8 bg-kyn-void/80 px-5 py-4">
                  <p className="mb-2 text-[10px] uppercase tracking-wider text-kyn-metal">{t.name}</p>
                  <p className={t.className}>{t.sample}</p>
                </div>
              ))}
            </div>
          </section>

          <section id="space">
            <div className="mb-5 flex items-center gap-2">
              <Layers size={16} className="text-kyn-green" />
              <h2 className="font-display text-xl font-semibold">Spacing & radius</h2>
            </div>
            <div className="grid md:grid-cols-2 gap-4">
              <GlassPanel>
                <p className="text-xs font-semibold text-kyn-metal mb-4">Space scale (px)</p>
                <div className="space-y-3">
                  {Object.entries(space).map(([k, v]) => (
                    <div key={k} className="flex items-center gap-3">
                      <span className="w-10 font-mono text-[11px] text-kyn-green">{k}</span>
                      <div className="h-2 rounded-full bg-kyn-green/80" style={{ width: Math.min(Number(v) * 2, 200) }} />
                      <span className="font-mono text-[11px] text-kyn-metal">{v}</span>
                    </div>
                  ))}
                </div>
              </GlassPanel>
              <GlassPanel>
                <p className="text-xs font-semibold text-kyn-metal mb-4">Radius</p>
                <div className="grid grid-cols-2 gap-3">
                  {Object.entries(radius).map(([k, v]) => (
                    <div key={k} className="rounded-xl border border-white/8 bg-black/30 p-4 text-center">
                      <div
                        className="mx-auto mb-3 h-14 w-full max-w-[100px] border border-kyn-green/40 bg-kyn-green/10"
                        style={{ borderRadius: Number(v) === 999 ? 999 : Number(v) }}
                      />
                      <p className="font-mono text-[11px] text-kyn-green">{k}</p>
                      <p className="text-[10px] text-kyn-metal">{v}px</p>
                    </div>
                  ))}
                </div>
                <p className="mt-4 text-xs text-kyn-metal">
                  Default card radius: <span className="text-kyn-green">16px</span> · Controls: 12px · Pills: full
                </p>
              </GlassPanel>
            </div>
          </section>

          <section id="motion">
            <div className="mb-5 flex items-center gap-2">
              <Zap size={16} className="text-kyn-green" />
              <h2 className="font-display text-xl font-semibold">Motion</h2>
            </div>
            <div className="grid sm:grid-cols-3 gap-3">
              {[
                { k: 'fast', v: motionTokens.fast, d: 'Hover, toggles' },
                { k: 'base', v: motionTokens.base, d: 'Panels, tabs' },
                { k: 'slow', v: motionTokens.slow, d: 'Page reveals' },
              ].map((m) => (
                <GlassPanel key={m.k}>
                  <p className="font-mono text-kyn-green text-sm">{m.k}</p>
                  <p className="font-display text-2xl font-bold mt-1">{m.v}ms</p>
                  <p className="text-xs text-kyn-metal mt-2">{m.d}</p>
                </GlassPanel>
              ))}
            </div>
            <p className="mt-3 text-xs text-kyn-metal">
              Easing: cubic-bezier(0.22, 1, 0.36, 1) — short energy pulses, no bounce.
            </p>
          </section>

          <section id="components">
            <div className="mb-5 flex items-center gap-2">
              <Component size={16} className="text-kyn-green" />
              <h2 className="font-display text-xl font-semibold">Core components</h2>
            </div>
            <div className="grid md:grid-cols-2 gap-4">
              <GlassPanel className="space-y-3">
                <p className="text-xs text-kyn-metal mb-1">Buttons</p>
                <Button className="w-full">Primary CTA</Button>
                <Button variant="secondary" className="w-full">Secondary</Button>
                <Button variant="ghost" className="w-full">Ghost</Button>
                <div className="flex flex-wrap gap-2 pt-2">
                  <Badge tone="metal">Default</Badge>
                  <Badge tone="green">Online</Badge>
                  <Badge tone="warning">Maintenance</Badge>
                  <Badge tone="danger">Fault</Badge>
                </div>
              </GlassPanel>
              <GlassPanel className="space-y-3">
                <p className="text-xs text-kyn-metal mb-1">Inputs & status</p>
                <Input placeholder="email@company.com" />
                <div className="flex flex-wrap gap-2">
                  <StatusPill status="online">Online</StatusPill>
                  <StatusPill status="charging" pulse>Charging</StatusPill>
                  <StatusPill status="warning">Warning</StatusPill>
                  <StatusPill status="offline">Offline</StatusPill>
                </div>
                <div className="flex flex-wrap gap-2">
                  <SpecChip accent>22 kW</SpecChip>
                  <SpecChip>OCPP 1.6J</SpecChip>
                  <SpecChip>IP54</SpecChip>
                  <SpecChip>WiFi + 4G</SpecChip>
                </div>
              </GlassPanel>
            </div>
          </section>

          <section id="domain">
            <div className="mb-5 flex items-center gap-2">
              <Box size={16} className="text-kyn-green" />
              <h2 className="font-display text-xl font-semibold">KYNETIK domain extensions</h2>
            </div>
            <p className="mb-5 text-sm text-kyn-metal max-w-2xl">
              Product-specific building blocks that inherit brand tokens — prefer these over one-off styles.
            </p>
            <div className="grid lg:grid-cols-2 gap-4 mb-4">
              <ProductStage
                src="/images/products/nova-tethered.png"
                alt="NOVA"
                accent="#00e676"
                maxH={280}
                className="min-h-[300px]"
              />
              <div className="grid sm:grid-cols-2 gap-3 content-start">
                <MetricTile label="Sessions today" value="1,284" delta="+12% vs yesterday" icon={Zap} />
                <MetricTile label="Uptime" value="99.7%" delta="Fleet average" icon={Cloud} />
                <div className="sm:col-span-2 flex items-center justify-center rounded-2xl border border-white/8 bg-kyn-void p-6">
                  <ChargeRing percent={78} label="SOC" />
                </div>
              </div>
            </div>
            <div className="rounded-2xl border border-kyn-green/20 bg-kyn-green/5 p-5 text-sm text-kyn-silver">
              <p className="font-semibold text-white mb-2">Import path</p>
              <code className="font-mono text-[12px] text-kyn-green break-all">
                {"import { StatusPill, SpecChip, ProductStage, MetricTile, GlassPanel, SectionLabel } from '../ui';"}
              </code>
            </div>
          </section>

          <section className="glass-card rounded-2xl p-6 md:p-8">
            <h2 className="font-display text-lg font-semibold mb-4">Layout & brand rules</h2>
            <ul className="grid md:grid-cols-2 gap-2.5 text-sm text-kyn-silver">
              {[
                'Corner radius default: 16px (cards) / 12px (controls)',
                'One electric green accent per focal region',
                'Mobile bottom nav: max 5 destinations',
                'Specs always mono or SpecChip — never free-form',
                'Icons: lucide minimal stroke 1.5–2px',
                'Motion: short energy pulses, no bounce',
                'Do not introduce new brand colors',
                'Glass cards use metal border + blur, not heavy fill',
                'Dark-first; light mode is not part of core system',
                'Product photography on radial stage glow',
              ].map((rule) => (
                <li key={rule} className="flex gap-2">
                  <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-kyn-green" />
                  {rule}
                </li>
              ))}
            </ul>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link
                to="/ui-library"
                className={cn(
                  'inline-flex items-center gap-2 rounded-full bg-kyn-green px-5 py-2.5 text-xs font-bold text-kyn-black glow-green'
                )}
              >
                Open UI library <ArrowRight size={14} />
              </Link>
              <Link
                to="/brand"
                className="inline-flex items-center gap-2 rounded-full border border-white/15 px-5 py-2.5 text-xs font-semibold"
              >
                Brand foundation
              </Link>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}

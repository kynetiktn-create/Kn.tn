import { useEffect, useState, type ComponentType, type ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { motion, useScroll, useTransform } from 'framer-motion';
import {
  ArrowRight, Cloud, Shield, Lock, Server, Cpu, Smartphone, Globe2,
  Building2, Hotel, Car, Landmark, Home, Zap, Activity, BarChart3,
  Webhook, KeyRound, Layers, CheckCircle2, Quote, Menu, X,
  Gauge, BellRing, Wallet, Leaf, Network, ShoppingBag,
  TrendingUp, Users, Clock, Sparkles
} from 'lucide-react';
import BrandLogo from '../components/BrandLogo';
import EnterpriseDashboard from '../components/cloud/EnterpriseDashboard';
import LoadingState from '../components/LoadingState';
import { apiGet, cn } from '../lib/utils';

interface LandingItem {
  id: number;
  type: string;
  title: string;
  subtitle: string;
  body: string;
  meta: string | null;
  icon: string | null;
  sort_order: number;
}

interface Metric {
  id: number;
  label: string;
  value: string;
  delta: string;
}

const iconMap: Record<string, ComponentType<{ size?: number; className?: string }>> = {
  zap: Zap, activity: Activity, chart: BarChart3, shield: Shield, lock: Lock,
  server: Server, cpu: Cpu, phone: Smartphone, globe: Globe2, network: Network,
  gauge: Gauge, bell: BellRing, wallet: Wallet, leaf: Leaf, webhook: Webhook,
  key: KeyRound, layers: Layers, cloud: Cloud,
};

function FadeIn({
  children, className, delay = 0,
}: { children: ReactNode; className?: string; delay?: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 28 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-50px' }}
      transition={{ duration: 0.65, delay, ease: [0.22, 1, 0.36, 1] }}
      className={className}
    >
      {children}
    </motion.div>
  );
}

function SectionLabel({ children }: { children: ReactNode }) {
  return (
    <p className="inline-flex items-center gap-2 text-[#00e676] text-[11px] font-semibold tracking-[0.28em] uppercase mb-4">
      <span className="w-6 h-px bg-[#00e676]/70" />
      {children}
    </p>
  );
}

export default function CloudSaaS() {
  const [items, setItems] = useState<LandingItem[]>([]);
  const [metrics, setMetrics] = useState<Metric[]>([]);
  const [loading, setLoading] = useState(true);
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const { scrollY } = useScroll();
  const heroOpacity = useTransform(scrollY, [0, 420], [1, 0.25]);
  const heroY = useTransform(scrollY, [0, 420], [0, 70]);

  useEffect(() => {
    Promise.all([
      apiGet<LandingItem[]>('/api/cloud-landing'),
      apiGet<Metric[]>('/api/cloud-metrics'),
    ])
      .then(([landing, m]) => {
        setItems(landing);
        setMetrics(m);
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 32);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const byType = (t: string) =>
    items.filter((i) => i.type === t).sort((a, b) => a.sort_order - b.sort_order);

  const features = byType('feature');
  const industries = byType('industry');
  const security = byType('security');
  const integrations = byType('integration');
  const benefits = byType('benefit');
  const testimonials = byType('testimonial');
  const overview = byType('overview')[0];

  const navLinks = [
    { href: '#platform', label: 'Platform' },
    { href: '#dashboard', label: 'Dashboard' },
    { href: '#features', label: 'Features' },
    { href: '#analytics', label: 'Analytics' },
    { href: '#security', label: 'Security' },
    { href: '#api', label: 'API' },
  ];

  const metricCards = metrics.map((m) => ({
    label: m.label,
    value: m.value,
    delta: m.delta,
  }));

  if (loading) {
    return (
      <div className="min-h-screen bg-[#050505] flex items-center justify-center">
        <LoadingState label="Loading KYNETIK Cloud…" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#050505] text-white overflow-x-hidden antialiased selection:bg-[#00e676]/30">
      {/* NAV */}
      <header
        className={cn(
          'fixed top-0 inset-x-0 z-50 transition-all duration-300',
          scrolled
            ? 'bg-[#050505]/85 backdrop-blur-2xl border-b border-white/5 shadow-lg shadow-black/40'
            : 'bg-transparent'
        )}
      >
        <div className="max-w-7xl mx-auto px-5 md:px-8 h-16 md:h-[4.5rem] flex items-center justify-between">
          <a href="#top" className="flex items-center gap-3">
            <BrandLogo height={30} />
            <span className="hidden sm:inline text-[10px] font-semibold tracking-[0.22em] uppercase text-[#00e676] border border-[#00e676]/30 rounded-full px-2.5 py-0.5 bg-[#00e676]/5">
              Cloud
            </span>
          </a>

          <nav className="hidden lg:flex items-center gap-8">
            {navLinks.map((l) => (
              <a
                key={l.href}
                href={l.href}
                className="text-[12px] font-medium text-zinc-400 hover:text-white transition-colors"
              >
                {l.label}
              </a>
            ))}
          </nav>

          <div className="flex items-center gap-3">
            <Link to="/product-system" className="hidden md:inline text-[12px] text-zinc-500 hover:text-white">
              Hardware
            </Link>
            <a
              href="#contact"
              className="hidden sm:inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#00e676] text-black text-[12px] font-bold hover:bg-[#39ff14] transition-colors shadow-lg shadow-[#00e676]/25"
            >
              Request demo <ArrowRight size={13} />
            </a>
            <button
              type="button"
              className="lg:hidden p-2 text-zinc-400"
              onClick={() => setMenuOpen(!menuOpen)}
              aria-label="Menu"
            >
              {menuOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </div>

        {menuOpen && (
          <div className="lg:hidden border-t border-white/5 bg-[#0a0a0b]/98 backdrop-blur-xl px-5 py-4 space-y-1">
            {navLinks.map((l) => (
              <a
                key={l.href}
                href={l.href}
                onClick={() => setMenuOpen(false)}
                className="block py-2.5 text-sm text-zinc-400"
              >
                {l.label}
              </a>
            ))}
            <a
              href="#contact"
              onClick={() => setMenuOpen(false)}
              className="block mt-3 text-center rounded-full bg-emerald-400 text-black text-xs font-bold py-3"
            >
              Request demo
            </a>
          </div>
        )}
      </header>

      {/* 1. HERO — 100vh split-screen */}
      <section id="top" className="relative min-h-[100svh] flex items-center pt-20 pb-16">
        <div className="absolute inset-0">
          <img
            src="/images/cloud-datacenter.jpg"
            alt=""
            className="w-full h-full object-cover opacity-20"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-[#050505] via-[#050505]/90 to-[#050505]" />
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_20%_30%,rgba(0,230,118,0.16),transparent_50%)]" />
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_85%_60%,rgba(0,230,118,0.06),transparent_45%)]" />
          <div
            className="absolute inset-0 opacity-50"
            style={{
              backgroundImage:
                'linear-gradient(rgba(0,230,118,0.035) 1px, transparent 1px), linear-gradient(90deg, rgba(0,230,118,0.035) 1px, transparent 1px)',
              backgroundSize: '72px 72px',
              maskImage: 'radial-gradient(ellipse at center, black 20%, transparent 75%)',
            }}
          />
        </div>

        <motion.div
          style={{ opacity: heroOpacity, y: heroY }}
          className="relative z-10 max-w-7xl mx-auto px-5 md:px-8 py-10 md:py-16 w-full"
        >
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
            <div>
              <motion.div
                initial={{ opacity: 0, y: 22 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.7 }}
              >
                <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-[#00e676]/30 bg-[#00e676]/10 text-[#00e676] text-[11px] font-semibold mb-7">
                  <Sparkles size={12} />
                  Enterprise EV Charging OS
                </div>
                <h1 className="font-display text-4xl sm:text-5xl md:text-6xl lg:text-[3.75rem] font-bold leading-[1.04] tracking-tight">
                  The intelligent cloud
                  <br />
                  for{' '}
                  <span className="text-[#00e676] text-glow">
                    every kilowatt
                  </span>
                </h1>
                <p className="mt-6 text-base md:text-lg text-zinc-400 max-w-xl leading-relaxed">
                  KYNETIK Cloud connects chargers, drivers, energy and billing into one
                  control plane — Tesla-grade simplicity, ABB-class industrial reliability,
                  Stripe-level product polish.
                </p>
                <div className="mt-9 flex flex-wrap gap-3">
                  <a
                    href="#contact"
                    className="inline-flex items-center gap-2 px-6 py-3.5 rounded-2xl bg-[#00e676] text-black text-sm font-bold hover:bg-[#39ff14] transition-colors shadow-xl shadow-[#00e676]/25"
                  >
                    Book a live demo <ArrowRight size={16} />
                  </a>
                  <a
                    href="#dashboard"
                    className="inline-flex items-center gap-2 px-6 py-3.5 rounded-2xl border border-white/12 text-sm font-medium hover:border-[#00e676]/40 hover:bg-white/5 transition-colors"
                  >
                    Explore the platform
                  </a>
                </div>
                <div className="mt-12 grid grid-cols-3 gap-3 max-w-md">
                  {[
                    { v: '99.95%', l: 'Platform SLA' },
                    { v: 'OCPP', l: '1.6J & 2.0.1' },
                    { v: '<800ms', l: 'Cmd latency' },
                  ].map((s) => (
                    <div key={s.l} className="rounded-2xl border border-white/8 bg-white/[0.03] backdrop-blur-sm p-3.5">
                      <p className="font-display text-lg md:text-xl font-bold text-white tracking-tight">{s.v}</p>
                      <p className="text-[10px] text-zinc-500 mt-0.5 uppercase tracking-wider">{s.l}</p>
                    </div>
                  ))}
                </div>
              </motion.div>
            </div>

            <motion.div
              initial={{ opacity: 0, scale: 0.96, y: 28 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              transition={{ duration: 0.85, delay: 0.12 }}
              className="relative"
            >
              <div className="absolute -inset-8 bg-[#00e676]/12 blur-[60px] rounded-full" />
              <motion.div
                animate={{ y: [0, -10, 0] }}
                transition={{ duration: 6, repeat: Infinity, ease: 'easeInOut' }}
                className="relative"
              >
                <div className="absolute -top-4 -right-4 w-28 h-28 border border-[#00e676]/20 rounded-2xl rotate-6 hidden md:block" />
                <div className="absolute -bottom-5 -left-5 w-20 h-20 border border-[#00e676]/15 rounded-xl -rotate-12 hidden md:block" />
                <div className="absolute top-1/3 -left-6 px-3 py-2 rounded-xl border border-white/10 bg-[#0a0b0f]/90 backdrop-blur-md text-[10px] hidden xl:block shadow-xl">
                  <p className="text-zinc-500">Active sessions</p>
                  <p className="font-display font-bold text-[#00e676] text-sm">1,284</p>
                </div>
                <div className="absolute bottom-1/4 -right-4 px-3 py-2 rounded-xl border border-white/10 bg-[#0a0b0f]/90 backdrop-blur-md text-[10px] hidden xl:block shadow-xl">
                  <p className="text-zinc-500">Uptime</p>
                  <p className="font-display font-bold text-white text-sm">99.95%</p>
                </div>
                <EnterpriseDashboard metrics={metricCards} />
              </motion.div>
            </motion.div>
          </div>
        </motion.div>

        <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-zinc-600">
          <span className="text-[9px] tracking-[0.35em] uppercase">Scroll</span>
          <div className="w-px h-10 bg-gradient-to-b from-[#00e676] to-transparent" />
        </div>
      </section>

      {/* Trust bar */}
      <section className="border-y border-white/5 bg-[#08090c]">
        <div className="max-w-7xl mx-auto px-5 md:px-8 py-6 flex flex-wrap items-center justify-between gap-4">
          <p className="text-[11px] text-zinc-500 uppercase tracking-[0.2em]">Trusted architecture inspired by</p>
          <div className="flex flex-wrap gap-x-8 gap-y-2 text-[12px] font-medium text-zinc-400">
            {['Tesla Energy', 'ABB Ability™', 'ChargePoint', 'Siemens Grid', 'Stripe-grade UI'].map((b) => (
              <span key={b} className="hover:text-emerald-400 transition-colors">{b}</span>
            ))}
          </div>
        </div>
      </section>

      {/* 2. PLATFORM OVERVIEW + ECOSYSTEM */}
      <section id="platform" className="relative py-24 md:py-32">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <FadeIn>
            <SectionLabel>Platform overview</SectionLabel>
            <h2 className="font-display text-3xl md:text-5xl font-bold max-w-3xl leading-tight tracking-tight">
              {overview?.title || 'One cloud. Every charger. Total control.'}
            </h2>
            <p className="mt-5 text-zinc-400 text-lg max-w-2xl leading-relaxed">
              {overview?.body ||
                'From a single wallbox to national corridors — unify hardware, sessions, tariffs and operator workflows.'}
            </p>
          </FadeIn>

          <div className="mt-14 grid md:grid-cols-3 gap-4">
            {[
              { t: 'Operate', d: 'Remote start/stop, OTA firmware, multi-tenant sites and 24/7 monitoring.', i: Server },
              { t: 'Optimize', d: 'Smart load balancing, peak shaving, solar-aware charging schedules.', i: Gauge },
              { t: 'Monetize', d: 'Roaming-ready billing, wallets, invoices and fleet cost centers.', i: Wallet },
            ].map(({ t, d, i: Icon }, idx) => (
              <FadeIn key={t} delay={idx * 0.08}>
                <div className="h-full rounded-2xl border border-white/8 bg-gradient-to-b from-white/[0.04] to-transparent p-7 hover:border-emerald-400/30 transition-colors group">
                  <div className="w-11 h-11 rounded-xl bg-emerald-400/10 border border-emerald-400/20 flex items-center justify-center text-emerald-400 mb-5 group-hover:shadow-[0_0_24px_rgba(0,230,118,0.25)] transition-shadow">
                    <Icon size={20} />
                  </div>
                  <h3 className="text-xl font-semibold tracking-tight">{t}</h3>
                  <p className="mt-3 text-sm text-zinc-500 leading-relaxed">{d}</p>
                </div>
              </FadeIn>
            ))}
          </div>

          {/* Connected ecosystem */}
          <FadeIn className="mt-20">
            <div className="relative rounded-3xl border border-[#00e676]/20 bg-[#0a0b0f]/85 backdrop-blur-xl p-8 md:p-12 overflow-hidden">
              <div className="absolute inset-0 opacity-25">
                <img src="/images/tech-abstract.jpg" alt="" className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-[#0a0b0f]/88" />
              </div>
              <div className="relative z-10">
                <p className="text-center text-[#00e676] text-[11px] font-semibold tracking-[0.28em] uppercase mb-3">
                  Connected ecosystem
                </p>
                <h3 className="font-display text-center text-2xl md:text-3xl font-bold mb-4">
                  Hardware, cloud and apps — one nervous system
                </h3>
                <p className="text-center text-sm text-zinc-500 max-w-lg mx-auto mb-12">
                  Luminous data flows from vehicle to enterprise systems through KYNETIK Cloud.
                </p>

                {/* Animated flow line */}
                <div className="hidden md:block relative h-1 mb-[-2.75rem] mx-[10%]">
                  <div className="absolute inset-0 bg-gradient-to-r from-transparent via-[#00e676]/35 to-transparent rounded-full" />
                  <motion.div
                    className="absolute top-1/2 -translate-y-1/2 h-2 w-2 rounded-full bg-[#00e676] shadow-[0_0_16px_#00e676]"
                    animate={{ left: ['0%', '100%'] }}
                    transition={{ duration: 3.2, repeat: Infinity, ease: 'linear' }}
                  />
                </div>

                <div className="grid grid-cols-2 md:grid-cols-5 gap-6 md:gap-3 relative pt-4">
                  {[
                    { l: 'Vehicle', s: 'SoC · Session', icon: Car },
                    { l: 'Charger', s: 'NOVA · PRIME · GO', icon: Zap },
                    { l: 'KYNETIK Cloud', s: 'OCPP · Orchestration', icon: Cloud, hi: true },
                    { l: 'Mobile App', s: 'Driver experience', icon: Smartphone },
                    { l: 'Enterprise', s: 'Fleet · Billing · API', icon: Building2 },
                  ].map(({ l, s, icon: Icon, hi }, idx) => (
                    <motion.div
                      key={l}
                      initial={{ opacity: 0, y: 12 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      viewport={{ once: true }}
                      transition={{ delay: idx * 0.08 }}
                      className="flex flex-col items-center text-center"
                    >
                      <div
                        className={cn(
                          'w-16 h-16 md:w-[4.5rem] md:h-[4.5rem] rounded-2xl border flex items-center justify-center mb-3 transition-shadow',
                          hi
                            ? 'bg-[#00e676]/15 border-[#00e676]/50 text-[#00e676] shadow-[0_0_40px_rgba(0,230,118,0.28)]'
                            : 'bg-white/[0.03] border-white/10 text-zinc-400'
                        )}
                      >
                        <Icon size={hi ? 26 : 20} />
                      </div>
                      <p className={cn('font-display font-semibold text-sm', hi && 'text-[#00e676]')}>{l}</p>
                      <p className="text-[10px] text-zinc-500 mt-1">{s}</p>
                    </motion.div>
                  ))}
                </div>
              </div>
            </div>
          </FadeIn>
        </div>
      </section>

      {/* 3. LIVE DASHBOARD */}
      <section id="dashboard" className="py-24 md:py-32 bg-[#08090c] border-y border-white/5">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
            <FadeIn>
              <SectionLabel>Real-time operations</SectionLabel>
              <h2 className="font-display text-3xl md:text-4xl font-bold leading-tight tracking-tight">
                Command your network like a grid operator
              </h2>
              <p className="mt-5 text-zinc-400 leading-relaxed">
                A cinematic NOC console for field teams and control rooms — sessions, faults,
                energy curves and station health in one glass interface.
              </p>
              <ul className="mt-8 space-y-3">
                {[
                  'Multi-site hierarchy & role-based access',
                  'Live session table with remote interventions',
                  'Energy, revenue and uptime KPIs',
                  'Alerting with severity routing',
                ].map((item) => (
                  <li key={item} className="flex items-start gap-3 text-sm text-zinc-300">
                    <CheckCircle2 size={16} className="text-emerald-400 mt-0.5 shrink-0" />
                    {item}
                  </li>
                ))}
              </ul>
              <Link
                to="/cloud"
                className="mt-8 inline-flex items-center gap-2 text-sm font-semibold text-emerald-400 hover:gap-3 transition-all"
              >
                Open operator console UX <ArrowRight size={15} />
              </Link>
            </FadeIn>
            <FadeIn delay={0.1}>
              <EnterpriseDashboard metrics={metricCards} />
            </FadeIn>
          </div>
        </div>
      </section>

      {/* 4. SMART FEATURES */}
      <section id="features" className="py-24 md:py-28">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <FadeIn className="mb-14">
            <SectionLabel>Smart platform features</SectionLabel>
            <h2 className="font-display text-3xl md:text-4xl font-bold tracking-tight">Everything an EV network needs</h2>
          </FadeIn>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {features.map((f, i) => {
              const Icon = iconMap[f.icon || 'zap'] || Zap;
              return (
                <FadeIn key={f.id} delay={i * 0.05}>
                  <div className="group h-full rounded-2xl border border-white/8 bg-[#0a0b0f] p-6 hover:border-[#00e676]/30 hover:bg-[rgba(0,230,118,0.03)] transition-all">
                    <div className="w-10 h-10 rounded-xl bg-[#00e676]/10 border border-[#00e676]/20 flex items-center justify-center text-[#00e676] mb-4 group-hover:shadow-[0_0_20px_rgba(0,230,118,0.3)] transition-shadow">
                      <Icon size={18} />
                    </div>
                    <h3 className="font-display font-semibold text-lg tracking-tight">{f.title}</h3>
                    <p className="mt-2 text-sm text-zinc-500 leading-relaxed">{f.body}</p>
                  </div>
                </FadeIn>
              );
            })}
          </div>
        </div>
      </section>

      {/* 5. MOBILE APP */}
      <section className="py-24 md:py-32 relative overflow-hidden bg-[#08090c] border-y border-white/5">
        <div className="absolute right-0 top-0 w-1/2 h-full opacity-15 pointer-events-none hidden lg:block">
          <img src="/images/ev-network.jpg" alt="" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-l from-transparent to-[#08090c]" />
        </div>
        <div className="max-w-7xl mx-auto px-5 md:px-8 relative z-10">
          <div className="grid lg:grid-cols-2 gap-14 items-center">
            <FadeIn>
              <SectionLabel>Mobile application</SectionLabel>
              <h2 className="font-display text-3xl md:text-4xl font-bold tracking-tight">
                Drivers and operators, same ecosystem
              </h2>
              <p className="mt-5 text-zinc-400 leading-relaxed max-w-lg">
                The KYNETIK app mirrors Cloud intelligence — live charging rings, station maps,
                wallets and analytics with the same dark premium language.
              </p>
              <div className="mt-8 grid grid-cols-2 gap-3">
                {['Start / stop charge', 'Find DC & AC', 'Wallet & invoices', 'Energy insights'].map((t) => (
                  <div
                    key={t}
                    className="rounded-xl border border-white/8 bg-white/[0.03] px-4 py-3 text-sm text-zinc-300 flex items-center gap-2"
                  >
                    <CheckCircle2 size={14} className="text-emerald-400 shrink-0" /> {t}
                  </div>
                ))}
              </div>
              <Link
                to="/app"
                className="mt-8 inline-flex items-center gap-2 text-sm font-semibold text-emerald-400 hover:gap-3 transition-all"
              >
                Explore full app UX <ArrowRight size={15} />
              </Link>
            </FadeIn>

            <FadeIn delay={0.1} className="flex justify-center items-end gap-3 md:gap-5">
              {[
                { kind: 'dash' as const, label: 'Home' },
                { kind: 'charge' as const, label: 'Charging' },
                { kind: 'map' as const, label: 'Map' },
              ].map((p, idx) => (
                <motion.div
                  key={p.kind}
                  animate={{ y: [0, idx === 1 ? -12 : -6, 0] }}
                  transition={{ duration: 5 + idx, repeat: Infinity, ease: 'easeInOut' }}
                  className={cn(
                    'w-[130px] sm:w-[160px] h-[270px] sm:h-[340px] rounded-[2rem] p-2 border border-white/10 bg-gradient-to-b from-zinc-800 to-black shadow-2xl shadow-black/50',
                    idx === 1 && 'sm:h-[360px] sm:w-[170px] z-10'
                  )}
                >
                  <div className="w-full h-full rounded-[1.55rem] bg-[#0a0a0b] overflow-hidden relative flex flex-col items-center justify-center p-3">
                    <div className="absolute top-0 left-1/2 -translate-x-1/2 w-16 h-4 bg-black rounded-b-xl z-20" />
                    <div
                      className="absolute inset-0 opacity-40"
                      style={{
                        backgroundImage:
                          'linear-gradient(rgba(0,230,118,0.06) 1px, transparent 1px), linear-gradient(90deg, rgba(0,230,118,0.06) 1px, transparent 1px)',
                        backgroundSize: '20px 20px',
                      }}
                    />
                    {p.kind === 'charge' && (
                      <div
                        className="relative w-24 h-24 rounded-full flex items-center justify-center"
                        style={{ background: 'conic-gradient(from 200deg, #00e676 0%, #00e676 75%, #2a2a30 75%)' }}
                      >
                        <div className="w-[78%] h-[78%] rounded-full bg-[#0a0a0b] flex flex-col items-center justify-center">
                          <span className="font-display text-2xl font-bold text-[#00e676]">75%</span>
                        </div>
                      </div>
                    )}
                    {p.kind === 'map' && (
                      <div className="relative w-full h-full flex flex-col pt-6">
                        <div className="flex-1 relative">
                          {[30, 50, 45].map((t, i) => (
                            <div
                              key={i}
                              className="absolute w-6 h-6 rounded-full border-2 border-[#00e676] bg-[#00e676]/20 flex items-center justify-center"
                              style={{ top: `${20 + i * 22}%`, left: `${25 + i * 18}%` }}
                            >
                              <Zap size={10} className="text-[#00e676]" />
                            </div>
                          ))}
                        </div>
                        <div className="rounded-xl bg-black/60 border border-white/10 p-2.5">
                          <p className="text-[10px] font-semibold">Hub Lac 2</p>
                          <p className="text-[8px] text-zinc-500">1.2 km · Available</p>
                        </div>
                      </div>
                    )}
                    {p.kind === 'dash' && (
                      <div className="relative w-full space-y-2 pt-6 px-1">
                        <div className="rounded-xl border border-[#00e676]/25 bg-[#00e676]/10 p-2.5">
                          <p className="text-[8px] text-zinc-500">NOVA Home</p>
                          <p className="text-[11px] font-semibold text-[#00e676]">Online</p>
                        </div>
                        <div className="grid grid-cols-2 gap-1.5">
                          {['11 kW', '18 kWh'].map((v) => (
                            <div key={v} className="rounded-lg bg-white/5 border border-white/8 p-2 text-center text-[10px] font-semibold">{v}</div>
                          ))}
                        </div>
                      </div>
                    )}
                    <p className="relative mt-auto pt-3 text-[9px] text-zinc-500">{p.label}</p>
                  </div>
                </motion.div>
              ))}
            </FadeIn>
          </div>
        </div>
      </section>

      {/* 6. ENERGY ANALYTICS */}
      <section id="analytics" className="py-24 md:py-32">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <FadeIn className="mb-14 max-w-2xl">
            <SectionLabel>Energy analytics & KPIs</SectionLabel>
            <h2 className="font-display text-3xl md:text-4xl font-bold tracking-tight">
              Numbers investors and operators trust
            </h2>
          </FadeIn>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            {(metrics.length ? metrics : []).slice(0, 8).map((m, i) => (
              <FadeIn key={m.id} delay={i * 0.04}>
                <div className="rounded-2xl border border-white/8 bg-gradient-to-b from-white/[0.04] to-transparent p-5">
                  <p className="text-[10px] uppercase tracking-wider text-zinc-500">{m.label}</p>
                  <p className="font-display text-2xl md:text-3xl font-bold mt-2 tracking-tight">{m.value}</p>
                  <p className="text-xs text-[#00e676] mt-1 flex items-center gap-1">
                    <TrendingUp size={12} /> {m.delta}
                  </p>
                </div>
              </FadeIn>
            ))}
          </div>

          <FadeIn>
            <div className="rounded-2xl border border-white/8 bg-[#0a0b0f] p-6 md:p-8">
              <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
                <div>
                  <p className="font-semibold">Network utilization · 30 days</p>
                  <p className="text-xs text-zinc-500 mt-1">Holographic energy density across sites</p>
                </div>
                <div className="flex gap-4 text-xs text-zinc-500">
                  <span className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-emerald-400" /> kWh</span>
                  <span className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-emerald-400/40" /> Sessions</span>
                </div>
              </div>
              <div className="h-40 md:h-48 flex items-end gap-1 md:gap-1.5 relative">
                <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom,rgba(0,230,118,0.08),transparent_60%)]" />
                {Array.from({ length: 30 }).map((_, i) => {
                  const h = 30 + Math.abs(Math.sin(i * 0.7) * 50) + (i % 5) * 4;
                  return (
                    <motion.div
                      key={i}
                      initial={{ height: 0 }}
                      whileInView={{ height: `${h}%` }}
                      viewport={{ once: true }}
                      transition={{ duration: 0.7, delay: i * 0.02 }}
                      className="flex-1 rounded-t-sm bg-gradient-to-t from-[#00a844]/50 via-[#00e676]/80 to-[#6effb0] relative z-10"
                    />
                  );
                })}
              </div>
            </div>
          </FadeIn>
        </div>
      </section>

      {/* 7. API */}
      <section id="api" className="py-24 md:py-28 bg-[#08090c] border-y border-white/5">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <FadeIn>
              <SectionLabel>API & integrations</SectionLabel>
              <h2 className="font-display text-3xl md:text-4xl font-bold tracking-tight">Open platform. Partner-ready.</h2>
              <p className="mt-5 text-zinc-400 leading-relaxed">
                REST APIs, webhooks and OCPP-native connectivity — integrate ERP, TMS, roaming hubs
                and energy utilities without friction.
              </p>
              <div className="mt-8 space-y-3">
                {integrations.map((item) => {
                  const Icon = iconMap[item.icon || 'webhook'] || Webhook;
                  return (
                    <div key={item.id} className="flex items-center gap-3 text-sm text-zinc-300">
                      <div className="w-9 h-9 rounded-lg bg-emerald-400/10 border border-emerald-400/20 flex items-center justify-center">
                        <Icon size={15} className="text-emerald-400" />
                      </div>
                      <div>
                        <p className="font-medium text-white">{item.title}</p>
                        <p className="text-xs text-zinc-500">{item.body}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </FadeIn>

            <FadeIn delay={0.1}>
              <div className="rounded-2xl border border-white/10 bg-[#0c0e12] overflow-hidden font-mono text-[11px] md:text-xs shadow-2xl">
                <div className="flex items-center gap-2 px-4 py-3 border-b border-white/5 bg-white/[0.02]">
                  <span className="w-2.5 h-2.5 rounded-full bg-red-500/70" />
                  <span className="w-2.5 h-2.5 rounded-full bg-yellow-500/70" />
                  <span className="w-2.5 h-2.5 rounded-full bg-green-500/70" />
                  <span className="ml-2 text-zinc-500">POST /v1/sessions/remote-start</span>
                </div>
                <pre className="p-5 text-zinc-400 leading-relaxed overflow-x-auto">{`{
  "station_id": "TN-LAC2-PRIME-01",
  "connector_id": 2,
  "id_tag": "USR-ENTERPRISE",
  "profile": {
    "max_kw": 22,
    "smart_charging": true
  }
}

// → 200 OK  ·  612ms
{
  "session_id": "K-88421",
  "status": "Accepted",
  "cloud": "kynetik-eu-1"
}`}</pre>
              </div>
            </FadeIn>
          </div>
        </div>
      </section>

      {/* 8. SECURITY */}
      <section id="security" className="py-24 md:py-32">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-start">
            <FadeIn>
              <SectionLabel>Security & reliability</SectionLabel>
              <h2 className="font-display text-3xl md:text-4xl font-bold leading-tight tracking-tight">
                Enterprise trust, by design
              </h2>
              <p className="mt-5 text-zinc-400 leading-relaxed">
                Defense-in-depth security with operational resilience for critical energy infrastructure —
                suitable for governments, utilities and large enterprises.
              </p>
              <div className="mt-8 grid grid-cols-2 gap-4">
                {[
                  { v: '99.95%', l: 'Uptime SLA' },
                  { v: 'TLS 1.3', l: 'In transit' },
                  { v: 'RBAC', l: 'Access control' },
                  { v: '24/7', l: 'Monitoring' },
                ].map((s) => (
                  <div key={s.l} className="rounded-2xl border border-white/8 bg-white/[0.02] p-5">
                    <p className="font-display text-2xl font-bold text-[#00e676]">{s.v}</p>
                    <p className="text-xs text-zinc-500 mt-1">{s.l}</p>
                  </div>
                ))}
              </div>
            </FadeIn>
            <div className="space-y-3">
              {security.map((s, i) => {
                const Icon = iconMap[s.icon || 'shield'] || Shield;
                return (
                  <FadeIn key={s.id} delay={i * 0.06}>
                    <div className="flex gap-4 rounded-2xl border border-white/8 bg-[#0a0b0f] p-5">
                      <div className="w-10 h-10 rounded-xl bg-emerald-400/10 border border-emerald-400/20 flex items-center justify-center text-emerald-400 shrink-0">
                        <Icon size={18} />
                      </div>
                      <div>
                        <h3 className="font-semibold">{s.title}</h3>
                        <p className="text-sm text-zinc-500 mt-1 leading-relaxed">{s.body}</p>
                      </div>
                    </div>
                  </FadeIn>
                );
              })}
            </div>
          </div>
        </div>
      </section>

      {/* 9. INDUSTRIES */}
      <section className="py-24 md:py-28 bg-[#08090c] border-y border-white/5">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <FadeIn className="text-center mb-14">
            <SectionLabel>Industries served</SectionLabel>
            <h2 className="font-display text-3xl md:text-4xl font-bold tracking-tight">Built for every charging context</h2>
          </FadeIn>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
            {industries.map((ind, i) => {
              const industryIcons: Record<string, ComponentType<{ size?: number; className?: string }>> = {
                home: Home,
                building: Building2,
                hotel: Hotel,
                landmark: Landmark,
                car: Car,
                globe: ShoppingBag,
              };
              const Icon = industryIcons[ind.icon || ''] || Building2;
              return (
                <FadeIn key={ind.id} delay={i * 0.04}>
                  <div className="rounded-2xl border border-white/8 bg-black/40 p-5 text-center h-full hover:border-emerald-400/30 transition-colors">
                    <div className="w-10 h-10 mx-auto rounded-xl bg-emerald-400/10 border border-emerald-400/20 flex items-center justify-center text-emerald-400 mb-3">
                      <Icon size={18} />
                    </div>
                    <p className="font-semibold text-sm">{ind.title}</p>
                    <p className="text-[11px] text-zinc-500 mt-1">{ind.body}</p>
                  </div>
                </FadeIn>
              );
            })}
          </div>
        </div>
      </section>

      {/* 10. BUSINESS BENEFITS */}
      <section className="py-24 md:py-32">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <FadeIn className="mb-14 max-w-2xl">
            <SectionLabel>Business benefits</SectionLabel>
            <h2 className="font-display text-3xl md:text-4xl font-bold tracking-tight">
              Outcomes boards and ministries care about
            </h2>
          </FadeIn>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
            {benefits.map((b, i) => (
              <FadeIn key={b.id} delay={i * 0.05}>
                <div className="rounded-2xl border border-white/8 bg-gradient-to-b from-zinc-900/80 to-transparent p-6 h-full">
                  <p className="font-display text-3xl font-bold text-[#00e676] text-glow">
                    {b.meta || '—'}
                  </p>
                  <h3 className="font-semibold mt-3">{b.title}</h3>
                  <p className="text-sm text-zinc-500 mt-2 leading-relaxed">{b.body}</p>
                </div>
              </FadeIn>
            ))}
          </div>
        </div>
      </section>

      {/* 11. TESTIMONIAL */}
      <section className="py-24 md:py-28 relative overflow-hidden">
        <div className="absolute inset-0">
          <img src="/images/presentation.jpg" alt="" className="w-full h-full object-cover opacity-12" />
          <div className="absolute inset-0 bg-gradient-to-r from-[#050505] via-[#050505]/95 to-[#050505]/85" />
        </div>
        <div className="relative z-10 max-w-4xl mx-auto px-5 md:px-8 text-center">
          {testimonials.map((t) => (
            <FadeIn key={t.id}>
              <Quote className="mx-auto text-[#00e676] mb-8" size={36} />
              <blockquote className="font-display text-2xl md:text-4xl font-medium leading-snug text-white tracking-tight">
                “{t.body}”
              </blockquote>
              <div className="mt-10">
                <p className="font-semibold">{t.title}</p>
                <p className="text-sm text-zinc-500 mt-1">{t.subtitle}</p>
              </div>
            </FadeIn>
          ))}
        </div>
      </section>

      {/* 12. FINAL CTA */}
      <section id="contact" className="py-24 md:py-32 relative">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(0,230,118,0.12),transparent_60%)]" />
        <div className="relative z-10 max-w-4xl mx-auto px-5 md:px-8 text-center">
          <FadeIn>
            <BrandLogo height={40} className="mx-auto justify-center" />
            <h2 className="mt-8 font-display text-3xl md:text-5xl font-bold leading-tight tracking-tight">
              Ready to run charging
              <br />
              <span className="text-[#00e676] text-glow">
                at enterprise scale?
              </span>
            </h2>
            <p className="mt-5 text-zinc-400 max-w-xl mx-auto leading-relaxed">
              Join operators, governments and fleets building the regional EV backbone on KYNETIK Cloud —
              hardware, software and Academy, unified.
            </p>
            <div className="mt-10 flex flex-wrap justify-center gap-3">
              <a
                href="mailto:cloud@kynetik.tn"
                className="inline-flex items-center gap-2 px-8 py-4 rounded-2xl bg-[#00e676] text-black text-sm font-bold shadow-xl shadow-[#00e676]/25 hover:bg-[#39ff14] transition-colors"
              >
                Request enterprise demo <ArrowRight size={16} />
              </a>
              <Link
                to="/product-system"
                className="inline-flex items-center gap-2 px-8 py-4 rounded-2xl border border-white/15 text-sm font-medium hover:bg-white/5 transition-colors"
              >
                View hardware
              </Link>
            </div>
            <div className="mt-12 flex flex-wrap justify-center gap-6 text-[11px] text-zinc-500">
              {[
                { icon: Shield, t: 'OCPP certified stack' },
                { icon: Users, t: 'Tunisia-based support' },
                { icon: Clock, t: 'Investor-ready reporting' },
              ].map(({ icon: Icon, t }) => (
                <span key={t} className="inline-flex items-center gap-1.5">
                  <Icon size={12} className="text-emerald-400" /> {t}
                </span>
              ))}
            </div>
          </FadeIn>
        </div>
      </section>

      {/* 13. ENTERPRISE FOOTER */}
      <footer className="border-t border-white/5 bg-[#08090c]">
        <div className="max-w-7xl mx-auto px-5 md:px-8 py-14">
          <div className="grid md:grid-cols-2 lg:grid-cols-5 gap-10">
            <div className="lg:col-span-2">
              <BrandLogo height={32} />
              <p className="mt-4 text-sm text-zinc-500 max-w-xs leading-relaxed">
                L'énergie en mouvement — intelligent charging infrastructure and cloud platform for Tunisia and beyond.
              </p>
              <p className="mt-4 text-xs text-emerald-400/80 font-medium tracking-wide">
                cloud@kynetik.tn · Tunis, Tunisia
              </p>
            </div>
            {[
              {
                h: 'Platform',
                links: [
                  { l: 'Cloud overview', href: '#platform' },
                  { l: 'Dashboard', href: '#dashboard' },
                  { l: 'API', href: '#api' },
                  { l: 'Security', href: '#security' },
                ],
              },
              {
                h: 'Products',
                links: [
                  { l: 'NOVA Series', href: '/product-system' },
                  { l: 'PRIME Series', href: '/product-system' },
                  { l: 'Mobile App', href: '/app' },
                  { l: 'Academy', href: '/academy' },
                ],
              },
              {
                h: 'Company',
                links: [
                  { l: 'Design System', href: '/design-system' },
                  { l: 'Investor deck', href: '/investor' },
                  { l: 'Contact', href: '#contact' },
                  { l: 'Request demo', href: 'mailto:cloud@kynetik.tn' },
                ],
              },
            ].map((col) => (
              <div key={col.h}>
                <p className="text-[11px] font-semibold uppercase tracking-[0.2em] text-zinc-500 mb-4">{col.h}</p>
                <ul className="space-y-2.5">
                  {col.links.map((link) =>
                    link.href.startsWith('/') ? (
                      <li key={link.l}>
                        <Link to={link.href} className="text-sm text-zinc-400 hover:text-white transition-colors">
                          {link.l}
                        </Link>
                      </li>
                    ) : (
                      <li key={link.l}>
                        <a href={link.href} className="text-sm text-zinc-400 hover:text-white transition-colors">
                          {link.l}
                        </a>
                      </li>
                    )
                  )}
                </ul>
              </div>
            ))}
          </div>
          <div className="mt-12 pt-8 border-t border-white/5 flex flex-wrap items-center justify-between gap-4">
            <p className="text-[11px] text-zinc-600">
              © {new Date().getFullYear()} KYNETIK Cloud — Enterprise EV Charging Platform
            </p>
            <div className="flex gap-4 text-[11px] text-zinc-600">
              <span>Privacy</span>
              <span>Terms</span>
              <span>Security</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

import { useEffect, useMemo, useState, type ComponentType, type ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Activity, AlertTriangle, ArrowRight, BarChart3, Bell, Brain, CheckCircle2,
  ChevronRight, Cloud, Cpu, Download, FileSpreadsheet, FileText, Gauge,
  Leaf, Menu, MessageSquare, Network, Radio, RefreshCw, Route, Shield,
  Sparkles, Target, Truck, Wrench, X, Zap, Home, Building2, Bot, Send,
  CircleDot, Layers, TrendingUp, Lock,
} from 'lucide-react';
import BrandLogo from '../components/BrandLogo';
import LoadingState from '../components/LoadingState';
import { apiGet, cn } from '../lib/utils';

interface AIItem {
  id: number;
  module: string;
  type: string;
  title: string;
  subtitle: string;
  body: string;
  value: string | null;
  meta: string | null;
  severity: string | null;
  score: number | null;
  sort_order: number;
}

type ModuleId =
  | 'command'
  | 'energy'
  | 'maintenance'
  | 'installation'
  | 'fleet'
  | 'reports'
  | 'chat'
  | 'security'
  | 'sustainability'
  | 'executive';

const modules: {
  id: ModuleId;
  label: string;
  short: string;
  icon: ComponentType<{ size?: number; className?: string }>;
  blurb: string;
}[] = [
  { id: 'command', label: 'AI Command Center', short: 'Command', icon: Brain, blurb: 'Live network intelligence' },
  { id: 'energy', label: 'Energy Advisor', short: 'Energy', icon: Zap, blurb: 'Tariffs, peaks, solar' },
  { id: 'maintenance', label: 'Predictive Maintenance', short: 'Maintain', icon: Wrench, blurb: 'Failure foresight' },
  { id: 'installation', label: 'Smart Installation', short: 'Install', icon: Building2, blurb: 'Site → BOM assistant' },
  { id: 'fleet', label: 'Fleet Intelligence', short: 'Fleet', icon: Truck, blurb: 'Dispatch & readiness' },
  { id: 'reports', label: 'AI Reports', short: 'Reports', icon: FileText, blurb: 'PDF & Excel packs' },
  { id: 'chat', label: 'AI Chat Assistant', short: 'Chat', icon: MessageSquare, blurb: 'Natural language ops' },
  { id: 'security', label: 'AI Security Center', short: 'Security', icon: Shield, blurb: 'Threat & identity' },
  { id: 'sustainability', label: 'Sustainability', short: 'Planet', icon: Leaf, blurb: 'CO₂ & green mix' },
  { id: 'executive', label: 'Executive Summary', short: 'Exec', icon: Target, blurb: 'Board-ready brief' },
];

function sev(s?: string | null) {
  const v = (s || '').toLowerCase();
  if (v === 'critical') return 'text-red-400 bg-red-500/10 border-red-500/30';
  if (v === 'warning') return 'text-amber-300 bg-amber-500/10 border-amber-500/30';
  if (v === 'success') return 'text-kyn-green bg-kyn-green/10 border-kyn-green/30';
  return 'text-sky-300 bg-sky-500/10 border-sky-500/25';
}

function Glass({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <div
      className={cn(
        'rounded-2xl border border-white/10 bg-white/[0.03] backdrop-blur-xl shadow-[0_0_0_1px_rgba(0,230,118,0.04)]',
        className
      )}
    >
      {children}
    </div>
  );
}

function PulseDot({ color = 'bg-kyn-green' }: { color?: string }) {
  return (
    <span className="relative flex h-2 w-2">
      <span className={cn('animate-ping absolute inline-flex h-full w-full rounded-full opacity-60', color)} />
      <span className={cn('relative inline-flex rounded-full h-2 w-2', color)} />
    </span>
  );
}

function Confidence({ score }: { score?: number | null }) {
  if (score == null) return null;
  return (
    <div className="flex items-center gap-2">
      <div className="flex-1 h-1 rounded-full bg-white/10 overflow-hidden min-w-[64px]">
        <div
          className="h-full rounded-full bg-gradient-to-r from-kyn-green-dim to-kyn-green"
          style={{ width: `${Math.min(100, Math.max(0, score))}%` }}
        />
      </div>
      <span className="text-[10px] font-mono text-kyn-green">{Math.round(score)}%</span>
    </div>
  );
}

function NeuralBg() {
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(0,230,118,0.12),transparent_50%)]" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom_right,rgba(56,189,248,0.08),transparent_45%)]" />
      <div className="absolute inset-0 opacity-[0.15] grid-bg" />
      <motion.div
        className="absolute -top-24 left-1/4 w-96 h-96 rounded-full bg-kyn-green/10 blur-3xl"
        animate={{ x: [0, 30, -20, 0], y: [0, 20, 10, 0] }}
        transition={{ duration: 12, repeat: Infinity, ease: 'easeInOut' }}
      />
      <motion.div
        className="absolute bottom-0 right-1/5 w-80 h-80 rounded-full bg-cyan-400/10 blur-3xl"
        animate={{ x: [0, -25, 15, 0], y: [0, -15, 5, 0] }}
        transition={{ duration: 14, repeat: Infinity, ease: 'easeInOut' }}
      />
    </div>
  );
}

function ProcessingBadge({ label = 'AI processing' }: { label?: string }) {
  return (
    <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-kyn-green/30 bg-kyn-green/10 text-[11px] text-kyn-green font-medium">
      <motion.span
        animate={{ rotate: 360 }}
        transition={{ duration: 2.5, repeat: Infinity, ease: 'linear' }}
        className="inline-flex"
      >
        <Sparkles size={12} />
      </motion.span>
      {label}
      <PulseDot />
    </div>
  );
}

function MiniBars({ values, accent = '#00e676' }: { values: number[]; accent?: string }) {
  return (
    <div className="flex items-end gap-1 h-16">
      {values.map((v, i) => (
        <motion.div
          key={i}
          initial={{ height: 0 }}
          animate={{ height: `${v}%` }}
          transition={{ delay: i * 0.03, duration: 0.5 }}
          className="flex-1 rounded-t-sm opacity-80"
          style={{ background: `linear-gradient(to top, ${accent}55, ${accent})` }}
        />
      ))}
    </div>
  );
}

function Ring({ value, label }: { value: number; label: string }) {
  const r = 54;
  const c = 2 * Math.PI * r;
  const offset = c - (value / 100) * c;
  return (
    <div className="relative w-36 h-36 mx-auto">
      <svg className="w-full h-full -rotate-90" viewBox="0 0 140 140">
        <circle cx="70" cy="70" r={r} fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth="8" />
        <circle
          cx="70"
          cy="70"
          r={r}
          fill="none"
          stroke="url(#aiRing)"
          strokeWidth="8"
          strokeLinecap="round"
          strokeDasharray={c}
          strokeDashoffset={offset}
          className="drop-shadow-[0_0_14px_rgba(0,230,118,0.5)]"
        />
        <defs>
          <linearGradient id="aiRing" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#00c853" />
            <stop offset="50%" stopColor="#39ff14" />
            <stop offset="100%" stopColor="#22d3ee" />
          </linearGradient>
        </defs>
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="font-display text-3xl font-bold text-white">{value}</span>
        <span className="text-[9px] uppercase tracking-[0.2em] text-kyn-metal">{label}</span>
      </div>
    </div>
  );
}

export default function AIPlatform() {
  const [items, setItems] = useState<AIItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [module, setModule] = useState<ModuleId>('command');
  const [menuOpen, setMenuOpen] = useState(false);
  const [chatInput, setChatInput] = useState('');
  const [localChat, setLocalChat] = useState<{ role: 'user' | 'ai'; text: string }[]>([]);
  const [thinking, setThinking] = useState(false);
  const [exporting, setExporting] = useState<string | null>(null);

  const load = () => {
    setLoading(true);
    apiGet<AIItem[]>('/api/ai-insights?source=platform')
      .then(setItems)
      .catch((e) => setError(e.message || 'Failed to load AI platform'))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    load();
  }, []);

  const byModule = useMemo(
    () => items.filter((i) => i.module === module).sort((a, b) => a.sort_order - b.sort_order),
    [items, module]
  );

  const kpis = byModule.filter((i) => i.type === 'kpi');
  const activeMeta = modules.find((m) => m.id === module)!;

  const sendChat = () => {
    const text = chatInput.trim();
    if (!text) return;
    setLocalChat((prev) => [...prev, { role: 'user', text }]);
    setChatInput('');
    setThinking(true);
    window.setTimeout(() => {
      setLocalChat((prev) => [
        ...prev,
        {
          role: 'ai',
          text:
            'Analyzed live telemetry. Recommended action queued with 91% confidence. Open Command Center → Interventions to approve automated load caps and technician dispatch.',
        },
      ]);
      setThinking(false);
    }, 1200);
  };

  const fakeExport = (kind: string) => {
    setExporting(kind);
    window.setTimeout(() => setExporting(null), 1400);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-kyn-black flex items-center justify-center">
        <LoadingState label="Initializing KYNETIK AI…" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-kyn-black flex items-center justify-center p-8 text-center">
        <div>
          <p className="text-red-400 mb-3">{error}</p>
          <button type="button" onClick={load} className="px-4 py-2 rounded-full bg-kyn-green text-kyn-black text-sm font-bold">
            Retry
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#050507] text-white relative overflow-x-hidden">
      <NeuralBg />

      {/* Top bar */}
      <header className="sticky top-0 z-50 border-b border-white/5 bg-black/50 backdrop-blur-2xl">
        <div className="max-w-[1440px] mx-auto px-4 md:px-6 h-16 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <BrandLogo height={28} />
            <div className="hidden sm:flex items-center gap-2 pl-3 border-l border-white/10">
              <Brain size={14} className="text-kyn-green" />
              <span className="text-xs font-semibold tracking-[0.18em] uppercase text-kyn-silver">
                AI Platform
              </span>
            </div>
          </div>

          <div className="hidden lg:flex items-center gap-2">
            <ProcessingBadge label="Models live" />
            <span className="text-[11px] text-kyn-metal font-mono">latency 42ms</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={load}
              className="p-2 rounded-xl border border-white/10 text-kyn-silver hover:text-white hover:border-kyn-green/30"
              aria-label="Refresh"
            >
              <RefreshCw size={15} />
            </button>
            <Link
              to="/console"
              className="hidden md:inline-flex items-center gap-1.5 px-3 py-2 rounded-full border border-white/10 text-xs text-kyn-silver hover:text-white"
            >
              <Cloud size={13} /> Console
            </Link>
            <Link
              to="/home"
              className="hidden sm:inline-flex items-center gap-1.5 px-3 py-2 rounded-full bg-kyn-green text-kyn-black text-xs font-bold"
            >
              Ecosystem <ArrowRight size={12} />
            </Link>
            <button type="button" className="lg:hidden p-2 text-kyn-silver" onClick={() => setMenuOpen(!menuOpen)}>
              {menuOpen ? <X size={18} /> : <Menu size={18} />}
            </button>
          </div>
        </div>
      </header>

      <div className="relative z-10 max-w-[1440px] mx-auto px-4 md:px-6 py-6 md:py-8">
        <div className="grid lg:grid-cols-[260px_1fr] gap-6">
          {/* Sidebar */}
          <aside className={cn('lg:block', menuOpen ? 'block' : 'hidden')}>
            <Glass className="p-3 lg:sticky lg:top-24">
              <p className="px-3 pt-2 pb-3 text-[10px] uppercase tracking-[0.25em] text-kyn-metal">Modules</p>
              <nav className="space-y-1 max-h-[70vh] overflow-y-auto pr-1">
                {modules.map((m) => {
                  const Icon = m.icon;
                  const active = module === m.id;
                  return (
                    <button
                      key={m.id}
                      type="button"
                      onClick={() => {
                        setModule(m.id);
                        setMenuOpen(false);
                      }}
                      className={cn(
                        'w-full flex items-start gap-3 px-3 py-2.5 rounded-xl text-left transition-all',
                        active
                          ? 'bg-kyn-green/15 border border-kyn-green/30 text-white'
                          : 'border border-transparent text-kyn-silver hover:bg-white/5 hover:text-white'
                      )}
                    >
                      <Icon size={16} className={active ? 'text-kyn-green mt-0.5' : 'text-kyn-metal mt-0.5'} />
                      <span className="min-w-0">
                        <span className="block text-sm font-medium leading-tight">{m.short}</span>
                        <span className="block text-[10px] text-kyn-metal mt-0.5 truncate">{m.blurb}</span>
                      </span>
                    </button>
                  );
                })}
              </nav>
              <div className="mt-4 p-3 rounded-xl bg-gradient-to-br from-kyn-green/10 to-cyan-500/5 border border-white/5">
                <div className="flex items-center gap-2 text-kyn-green text-xs font-semibold mb-1">
                  <Bot size={14} /> KYNETIK Copilot
                </div>
                <p className="text-[11px] text-kyn-metal leading-relaxed">
                  Enterprise AI for charging ops — energy, maintenance, fleet & security in one glass cockpit.
                </p>
              </div>
            </Glass>
          </aside>

          {/* Main */}
          <main className="min-w-0 space-y-6">
            <div className="flex flex-wrap items-end justify-between gap-4">
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <activeMeta.icon size={16} className="text-kyn-green" />
                  <span className="text-[11px] uppercase tracking-[0.25em] text-kyn-green font-semibold">
                    {activeMeta.label}
                  </span>
                </div>
                <h1 className="font-display text-3xl md:text-4xl font-bold tracking-tight">
                  {activeMeta.label}
                </h1>
                <p className="mt-2 text-sm text-kyn-metal max-w-xl">{activeMeta.blurb} · OpenAI / Tesla AI / DeepMind-inspired UX language</p>
              </div>
              <ProcessingBadge />
            </div>

            <AnimatePresence mode="wait">
              <motion.div
                key={module}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
                transition={{ duration: 0.35 }}
                className="space-y-6"
              >
                {/* KPI row */}
                {kpis.length > 0 && (
                  <div className="grid grid-cols-2 xl:grid-cols-4 gap-3">
                    {kpis.map((k, i) => (
                      <Glass key={k.id} className="p-4 relative overflow-hidden">
                        <div className="absolute inset-0 bg-gradient-to-br from-kyn-green/5 to-transparent" />
                        <div className="relative">
                          <p className="text-[10px] uppercase tracking-wider text-kyn-metal">{k.title}</p>
                          <p className="font-display text-2xl md:text-3xl font-bold mt-1 text-white">{k.value}</p>
                          <div className="mt-2 flex items-center justify-between gap-2">
                            <span className={cn('text-[10px] px-2 py-0.5 rounded-full border', sev(k.severity))}>
                              {k.meta || k.subtitle}
                            </span>
                            <TrendingUp size={12} className="text-kyn-green" />
                          </div>
                        </div>
                      </Glass>
                    ))}
                  </div>
                )}

                {/* COMMAND */}
                {module === 'command' && (
                  <div className="grid lg:grid-cols-3 gap-4">
                    <Glass className="lg:col-span-1 p-6 flex flex-col items-center justify-center">
                      <Ring value={95} label="Health" />
                      <p className="mt-4 text-sm text-kyn-silver text-center">Composite AI network score</p>
                      <div className="mt-4 w-full">
                        <MiniBars values={[40, 55, 48, 70, 62, 80, 75, 88, 82, 90, 86, 94]} />
                      </div>
                    </Glass>
                    <div className="lg:col-span-2 space-y-3">
                      {byModule
                        .filter((i) => i.type === 'signal')
                        .map((s) => (
                          <Glass key={s.id} className="p-4 md:p-5">
                            <div className="flex flex-wrap items-start justify-between gap-3">
                              <div className="min-w-0">
                                <div className="flex items-center gap-2 mb-1">
                                  <span className={cn('text-[10px] px-2 py-0.5 rounded-full border capitalize', sev(s.severity))}>
                                    {s.severity}
                                  </span>
                                  <span className="text-[10px] text-kyn-metal">{s.subtitle}</span>
                                </div>
                                <h3 className="font-display font-semibold text-lg">{s.title}</h3>
                                <p className="text-sm text-kyn-metal mt-1 leading-relaxed">{s.body}</p>
                              </div>
                              <div className="text-right shrink-0">
                                <p className="font-display text-xl font-bold text-kyn-green">{s.value}</p>
                                <p className="text-[10px] text-kyn-metal mt-1">{s.meta}</p>
                              </div>
                            </div>
                            <div className="mt-3">
                              <Confidence score={s.score} />
                            </div>
                          </Glass>
                        ))}
                    </div>
                  </div>
                )}

                {/* ENERGY */}
                {module === 'energy' && (
                  <div className="grid lg:grid-cols-5 gap-4">
                    <Glass className="lg:col-span-2 p-5">
                      <div className="flex items-center justify-between mb-4">
                        <p className="text-sm font-semibold">Load vs tariff intelligence</p>
                        <Gauge size={16} className="text-kyn-green" />
                      </div>
                      <MiniBars values={[30, 45, 50, 80, 95, 88, 70, 55, 40, 35, 48, 60, 72, 90, 85, 60, 42, 38, 55, 68, 75, 82, 58, 44]} />
                      <div className="mt-4 grid grid-cols-3 gap-2 text-center">
                        {['Off-peak', 'Shoulder', 'Peak'].map((t, i) => (
                          <div key={t} className="rounded-xl bg-black/30 border border-white/5 p-2">
                            <p className="text-[9px] text-kyn-metal uppercase">{t}</p>
                            <p className="text-sm font-semibold text-kyn-green">{[ '62%', '24%', '14%' ][i]}</p>
                          </div>
                        ))}
                      </div>
                    </Glass>
                    <div className="lg:col-span-3 space-y-3">
                      {byModule
                        .filter((i) => i.type === 'advice')
                        .map((a) => (
                          <Glass key={a.id} className="p-5">
                            <div className="flex items-start gap-3">
                              <div className="w-10 h-10 rounded-xl bg-kyn-green/10 border border-kyn-green/25 flex items-center justify-center text-kyn-green shrink-0">
                                <Zap size={18} />
                              </div>
                              <div className="min-w-0 flex-1">
                                <div className="flex flex-wrap justify-between gap-2">
                                  <h3 className="font-display font-semibold">{a.title}</h3>
                                  <span className="text-kyn-green font-display font-bold">{a.value}</span>
                                </div>
                                <p className="text-xs text-kyn-metal mt-0.5">{a.subtitle}</p>
                                <p className="text-sm text-kyn-silver mt-2 leading-relaxed">{a.body}</p>
                                <div className="mt-3 flex flex-wrap items-center justify-between gap-3">
                                  <Confidence score={a.score} />
                                  <button
                                    type="button"
                                    className="text-xs font-semibold text-kyn-black bg-kyn-green px-3 py-1.5 rounded-full"
                                  >
                                    Apply optimization
                                  </button>
                                </div>
                              </div>
                            </div>
                          </Glass>
                        ))}
                    </div>
                  </div>
                )}

                {/* MAINTENANCE */}
                {module === 'maintenance' && (
                  <div className="space-y-3">
                    <div className="flex flex-wrap gap-2 mb-2">
                      <Link to="/predictive-maintenance" className="text-xs text-kyn-green inline-flex items-center gap-1">
                        Open dedicated PM console <ChevronRight size={12} />
                      </Link>
                    </div>
                    {byModule
                      .filter((i) => i.type === 'alert')
                      .map((a) => (
                        <Glass key={a.id} className="p-5">
                          <div className="flex flex-wrap gap-4 items-start">
                            <div className={cn('w-11 h-11 rounded-xl border flex items-center justify-center shrink-0', sev(a.severity))}>
                              <AlertTriangle size={18} />
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="flex flex-wrap items-center gap-2 mb-1">
                                <h3 className="font-display font-semibold text-lg">{a.title}</h3>
                                <span className={cn('text-[10px] px-2 py-0.5 rounded-full border capitalize', sev(a.severity))}>
                                  {a.severity}
                                </span>
                              </div>
                              <p className="text-xs text-kyn-metal">{a.subtitle}</p>
                              <p className="text-sm text-kyn-silver mt-2">{a.body}</p>
                              <div className="mt-3 flex flex-wrap items-center gap-4">
                                <span className="text-sm font-semibold text-white">ETA window: {a.value}</span>
                                <Confidence score={a.score} />
                              </div>
                            </div>
                            <button type="button" className="px-3 py-2 rounded-xl border border-white/10 text-xs font-medium hover:border-kyn-green/40">
                              Create work order
                            </button>
                          </div>
                        </Glass>
                      ))}
                  </div>
                )}

                {/* INSTALLATION */}
                {module === 'installation' && (
                  <div className="grid lg:grid-cols-2 gap-4">
                    <Glass className="p-6">
                      <p className="text-xs uppercase tracking-[0.2em] text-kyn-green font-semibold mb-4">Pipeline</p>
                      <div className="space-y-4">
                        {byModule
                          .filter((i) => i.type === 'step')
                          .map((s, idx) => (
                            <div key={s.id} className="flex gap-4">
                              <div className="flex flex-col items-center">
                                <div className="w-8 h-8 rounded-full bg-kyn-green/15 border border-kyn-green/40 text-kyn-green text-xs font-bold flex items-center justify-center">
                                  {idx + 1}
                                </div>
                                {idx < 2 && <div className="w-px flex-1 bg-gradient-to-b from-kyn-green/50 to-transparent my-1" />}
                              </div>
                              <div className="pb-4">
                                <p className="font-semibold">{s.title}</p>
                                <p className="text-sm text-kyn-metal mt-1">{s.body}</p>
                              </div>
                            </div>
                          ))}
                      </div>
                      <Link to="/installation-details" className="inline-flex items-center gap-1 text-xs text-kyn-green mt-2">
                        Open installer workflow <ArrowRight size={12} />
                      </Link>
                    </Glass>
                    <div className="space-y-3">
                      {byModule
                        .filter((i) => i.type === 'recommendation')
                        .map((r) => (
                          <Glass key={r.id} className="p-6 relative overflow-hidden">
                            <div className="absolute inset-0 bg-gradient-to-br from-teal-400/10 to-kyn-green/5" />
                            <div className="relative">
                              <p className="text-xs text-teal-300 uppercase tracking-wider font-semibold">{r.subtitle}</p>
                              <h3 className="font-display text-2xl font-bold mt-2">{r.title}</h3>
                              <p className="text-kyn-green font-display text-xl mt-2">{r.value}</p>
                              <p className="text-sm text-kyn-silver mt-3 leading-relaxed">{r.body}</p>
                              <div className="mt-4">
                                <Confidence score={r.score} />
                              </div>
                              <div className="mt-5 flex gap-2">
                                <Link to="/configurator" className="px-4 py-2 rounded-full bg-kyn-green text-kyn-black text-xs font-bold">
                                  Configure product
                                </Link>
                                <Link to="/quote" className="px-4 py-2 rounded-full border border-white/15 text-xs font-medium">
                                  Generate quote
                                </Link>
                              </div>
                            </div>
                          </Glass>
                        ))}
                      <Glass className="p-5">
                        <p className="text-sm font-semibold mb-3">Estimated project impact</p>
                        <div className="grid grid-cols-3 gap-2">
                          {[
                            { l: 'Install time', v: '−22%' },
                            { l: 'First-time OK', v: '96%' },
                            { l: 'BOM accuracy', v: '98%' },
                          ].map((x) => (
                            <div key={x.l} className="rounded-xl bg-black/30 border border-white/5 p-3 text-center">
                              <p className="text-kyn-green font-display font-bold">{x.v}</p>
                              <p className="text-[10px] text-kyn-metal mt-1">{x.l}</p>
                            </div>
                          ))}
                        </div>
                      </Glass>
                    </div>
                  </div>
                )}

                {/* FLEET */}
                {module === 'fleet' && (
                  <div className="grid lg:grid-cols-3 gap-4">
                    <Glass className="lg:col-span-2 p-5">
                      <div className="flex items-center justify-between mb-4">
                        <p className="font-semibold text-sm">Depot charge timeline</p>
                        <Route size={16} className="text-kyn-green" />
                      </div>
                      <div className="space-y-3">
                        {['Van 12 · PRO A', 'Van 07 · PRO B', 'Van 19 · GO buffer', 'Van 03 · PRIME hub'].map((row, i) => (
                          <div key={row} className="flex items-center gap-3">
                            <span className="w-28 text-[11px] text-kyn-metal truncate">{row}</span>
                            <div className="flex-1 h-3 rounded-full bg-white/5 overflow-hidden relative">
                              <motion.div
                                className="absolute inset-y-0 left-0 rounded-full bg-gradient-to-r from-kyn-green/50 to-kyn-green"
                                initial={{ width: 0 }}
                                animate={{ width: `${55 + i * 10}%` }}
                                transition={{ duration: 0.8, delay: i * 0.1 }}
                              />
                            </div>
                            <span className="text-[11px] text-kyn-green font-mono w-12 text-right">{80 + i * 4}%</span>
                          </div>
                        ))}
                      </div>
                    </Glass>
                    <div className="space-y-3">
                      {byModule
                        .filter((i) => i.type === 'route')
                        .map((r) => (
                          <Glass key={r.id} className="p-4">
                            <p className="text-[10px] uppercase tracking-wider text-kyn-metal">{r.subtitle}</p>
                            <h3 className="font-semibold mt-1">{r.title}</h3>
                            <p className="text-sm text-kyn-metal mt-2">{r.body}</p>
                            <div className="mt-3 flex items-center justify-between">
                              <span className="text-kyn-green font-display font-bold">{r.value}</span>
                              <Confidence score={r.score} />
                            </div>
                          </Glass>
                        ))}
                    </div>
                  </div>
                )}

                {/* REPORTS */}
                {module === 'reports' && (
                  <div className="grid md:grid-cols-3 gap-4">
                    {byModule
                      .filter((i) => i.type === 'report')
                      .map((r) => (
                        <Glass key={r.id} className="p-6 flex flex-col">
                          <div className="w-12 h-12 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center mb-4">
                            {r.value === 'XLSX' ? (
                              <FileSpreadsheet className="text-kyn-green" size={22} />
                            ) : (
                              <FileText className="text-kyn-green" size={22} />
                            )}
                          </div>
                          <h3 className="font-display font-semibold text-lg">{r.title}</h3>
                          <p className="text-sm text-kyn-metal mt-2 flex-1">{r.body}</p>
                          <div className="mt-4 flex items-center justify-between">
                            <span className="text-[10px] uppercase tracking-wider text-kyn-metal">{r.meta}</span>
                            <button
                              type="button"
                              onClick={() => fakeExport(r.value || 'file')}
                              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-full bg-kyn-green text-kyn-black text-xs font-bold"
                            >
                              <Download size={12} />
                              {exporting === r.value ? 'Generating…' : `Export ${r.value}`}
                            </button>
                          </div>
                        </Glass>
                      ))}
                    <Glass className="md:col-span-3 p-5">
                      <div className="flex flex-wrap items-center justify-between gap-3">
                        <div>
                          <p className="font-semibold">Live report composer</p>
                          <p className="text-sm text-kyn-metal mt-1">Select KPIs, date range, sites — AI writes narrative + charts.</p>
                        </div>
                        <div className="flex gap-2">
                          <button type="button" onClick={() => fakeExport('PDF')} className="px-4 py-2 rounded-full border border-white/15 text-xs">
                            PDF pack
                          </button>
                          <button type="button" onClick={() => fakeExport('XLSX')} className="px-4 py-2 rounded-full border border-white/15 text-xs">
                            Excel pack
                          </button>
                        </div>
                      </div>
                      {exporting && (
                        <div className="mt-4 flex items-center gap-2 text-kyn-green text-sm">
                          <ProcessingBadge label={`Building ${exporting}`} />
                        </div>
                      )}
                    </Glass>
                  </div>
                )}

                {/* CHAT */}
                {module === 'chat' && (
                  <Glass className="overflow-hidden flex flex-col min-h-[520px]">
                    <div className="px-5 py-4 border-b border-white/5 flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="w-9 h-9 rounded-xl bg-kyn-green/15 border border-kyn-green/30 flex items-center justify-center">
                          <Bot size={18} className="text-kyn-green" />
                        </div>
                        <div>
                          <p className="font-semibold text-sm">KYNETIK AI Assistant</p>
                          <p className="text-[10px] text-kyn-metal">Ops · Energy · Security context aware</p>
                        </div>
                      </div>
                      <PulseDot />
                    </div>
                    <div className="flex-1 p-5 space-y-3 overflow-y-auto max-h-[420px]">
                      {byModule
                        .filter((i) => i.type === 'message')
                        .map((m) => {
                          const isUser = m.value === 'user';
                          return (
                            <div key={m.id} className={cn('flex', isUser ? 'justify-end' : 'justify-start')}>
                              <div
                                className={cn(
                                  'max-w-[85%] rounded-2xl px-4 py-3 text-sm leading-relaxed',
                                  isUser
                                    ? 'bg-kyn-green text-kyn-black rounded-br-md'
                                    : 'bg-white/5 border border-white/10 text-kyn-silver rounded-bl-md'
                                )}
                              >
                                {!isUser && <p className="text-[10px] text-kyn-green mb-1 font-semibold">KYNETIK AI</p>}
                                {m.body}
                                {!isUser && m.meta && (
                                  <p className="text-[10px] text-kyn-metal mt-2">{m.meta}</p>
                                )}
                              </div>
                            </div>
                          );
                        })}
                      {localChat.map((m, idx) => (
                        <div key={idx} className={cn('flex', m.role === 'user' ? 'justify-end' : 'justify-start')}>
                          <div
                            className={cn(
                              'max-w-[85%] rounded-2xl px-4 py-3 text-sm',
                              m.role === 'user'
                                ? 'bg-kyn-green text-kyn-black rounded-br-md'
                                : 'bg-white/5 border border-white/10 text-kyn-silver rounded-bl-md'
                            )}
                          >
                            {m.text}
                          </div>
                        </div>
                      ))}
                      {thinking && (
                        <div className="flex justify-start">
                          <div className="rounded-2xl px-4 py-3 bg-white/5 border border-white/10">
                            <ProcessingBadge label="Thinking" />
                          </div>
                        </div>
                      )}
                    </div>
                    <div className="p-4 border-t border-white/5 flex gap-2">
                      <input
                        value={chatInput}
                        onChange={(e) => setChatInput(e.target.value)}
                        onKeyDown={(e) => e.key === 'Enter' && sendChat()}
                        placeholder="Ask about load, faults, fleets, savings…"
                        className="flex-1 rounded-xl bg-black/40 border border-white/10 px-4 py-3 text-sm outline-none focus:border-kyn-green/40"
                      />
                      <button
                        type="button"
                        onClick={sendChat}
                        className="px-4 rounded-xl bg-kyn-green text-kyn-black font-bold"
                        aria-label="Send"
                      >
                        <Send size={16} />
                      </button>
                    </div>
                  </Glass>
                )}

                {/* SECURITY */}
                {module === 'security' && (
                  <div className="grid lg:grid-cols-3 gap-4">
                    <Glass className="p-6 flex flex-col items-center justify-center">
                      <Lock className="text-kyn-green mb-3" size={28} />
                      <Ring value={18} label="Risk" />
                      <p className="mt-3 text-sm text-kyn-silver">Global threat posture</p>
                    </Glass>
                    <div className="lg:col-span-2 space-y-3">
                      {byModule
                        .filter((i) => i.type === 'event')
                        .map((e) => (
                          <Glass key={e.id} className="p-4 flex gap-3 items-start">
                            <div className={cn('w-10 h-10 rounded-xl border flex items-center justify-center shrink-0', sev(e.severity))}>
                              <Shield size={16} />
                            </div>
                            <div className="min-w-0 flex-1">
                              <div className="flex flex-wrap justify-between gap-2">
                                <h3 className="font-semibold">{e.title}</h3>
                                <span className="text-xs text-kyn-green font-medium">{e.value}</span>
                              </div>
                              <p className="text-xs text-kyn-metal mt-0.5">{e.subtitle}</p>
                              <p className="text-sm text-kyn-silver mt-2">{e.body}</p>
                              <div className="mt-2">
                                <Confidence score={e.score} />
                              </div>
                            </div>
                          </Glass>
                        ))}
                    </div>
                  </div>
                )}

                {/* SUSTAINABILITY */}
                {module === 'sustainability' && (
                  <div className="grid lg:grid-cols-2 gap-4">
                    <Glass className="p-6">
                      <div className="flex items-center gap-2 mb-4">
                        <Leaf className="text-kyn-green" size={18} />
                        <p className="font-semibold">Carbon trajectory</p>
                      </div>
                      <MiniBars values={[20, 28, 35, 42, 48, 55, 60, 68, 72, 78, 85, 90]} accent="#4ade80" />
                      <p className="text-xs text-kyn-metal mt-3">Monthly CO₂ avoided index (AI-normalized)</p>
                    </Glass>
                    <div className="space-y-3">
                      {byModule
                        .filter((i) => i.type !== 'kpi')
                        .map((g) => (
                          <Glass key={g.id} className="p-5">
                            <p className="text-[10px] uppercase tracking-wider text-kyn-metal">{g.subtitle}</p>
                            <h3 className="font-display font-semibold text-lg mt-1">{g.title}</h3>
                            <p className="text-sm text-kyn-silver mt-2">{g.body}</p>
                            <div className="mt-3 flex items-center justify-between">
                              <span className="text-kyn-green font-bold">{g.value}</span>
                              <Confidence score={g.score} />
                            </div>
                          </Glass>
                        ))}
                    </div>
                  </div>
                )}

                {/* EXECUTIVE */}
                {module === 'executive' && (
                  <div className="space-y-4">
                    {byModule
                      .filter((i) => i.type === 'summary')
                      .map((s) => (
                        <Glass key={s.id} className="p-6 md:p-8 relative overflow-hidden">
                          <div className="absolute inset-0 bg-gradient-to-r from-kyn-green/10 via-transparent to-cyan-500/10" />
                          <div className="relative">
                            <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
                              <p className="text-xs uppercase tracking-[0.25em] text-kyn-green font-semibold">
                                {s.subtitle}
                              </p>
                              <span className="text-[11px] text-kyn-metal">{s.value} · {s.meta}</span>
                            </div>
                            <h2 className="font-display text-2xl md:text-3xl font-bold max-w-3xl leading-snug">
                              {s.title}
                            </h2>
                            <p className="mt-4 text-kyn-silver leading-relaxed max-w-3xl">{s.body}</p>
                            <div className="mt-6 flex flex-wrap gap-2">
                              <button
                                type="button"
                                onClick={() => fakeExport('Exec PDF')}
                                className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-kyn-green text-kyn-black text-xs font-bold"
                              >
                                <Download size={14} /> Download board PDF
                              </button>
                              <button type="button" className="px-4 py-2 rounded-full border border-white/15 text-xs">
                                Share with investors
                              </button>
                            </div>
                          </div>
                        </Glass>
                      ))}
                    <div className="grid md:grid-cols-3 gap-3">
                      {byModule
                        .filter((i) => i.type === 'highlight')
                        .map((h) => (
                          <Glass key={h.id} className="p-5">
                            <p className="text-[10px] uppercase tracking-wider text-kyn-metal">{h.subtitle}</p>
                            <p className="font-display text-3xl font-bold text-kyn-green mt-2">{h.value}</p>
                            <h3 className="font-semibold mt-2">{h.title}</h3>
                            <p className="text-sm text-kyn-metal mt-2">{h.body}</p>
                          </Glass>
                        ))}
                    </div>
                  </div>
                )}

                {/* Cross-links */}
                <Glass className="p-5">
                  <div className="flex flex-wrap gap-3 items-center justify-between">
                    <div className="flex items-center gap-2 text-sm text-kyn-silver">
                      <Layers size={16} className="text-kyn-green" />
                      Connected ecosystem surfaces
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {[
                        ['/energy-advisor', 'Energy Advisor'],
                        ['/predictive-maintenance', 'Predictive PM'],
                        ['/console', 'Cloud Console'],
                        ['/ai', 'AI Dashboard'],
                      ].map(([to, label]) => (
                        <Link
                          key={to}
                          to={to}
                          className="px-3 py-1.5 rounded-full border border-white/10 text-[11px] text-kyn-silver hover:border-kyn-green/40 hover:text-white"
                        >
                          {label}
                        </Link>
                      ))}
                    </div>
                  </div>
                </Glass>
              </motion.div>
            </AnimatePresence>
          </main>
        </div>
      </div>
    </div>
  );
}

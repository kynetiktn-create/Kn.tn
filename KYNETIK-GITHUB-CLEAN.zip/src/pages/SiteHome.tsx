import { useEffect, useState, type ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  ArrowRight, Menu, X, Zap, Cloud, Leaf, Shield, Building2, Home, Hotel,
  Landmark, Car, CheckCircle2, GraduationCap, Handshake, TrendingUp,
  Activity, Smartphone, Wrench, Wifi, Bluetooth, Radio, ChevronRight,
  Linkedin, Facebook, Instagram, Sparkles, Globe2, Users, Server
} from 'lucide-react';
import BrandLogo from '../components/BrandLogo';
import LoadingState from '../components/LoadingState';
import { apiGet, cn } from '../lib/utils';
import { track } from '../lib/analytics';

interface Product {
  id: number;
  name: string;
  power: string;
  image_url: string;
  category: string;
  accent: string;
  tagline?: string;
}

function Fade({
  children,
  className,
  delay = 0,
}: {
  children: ReactNode;
  className?: string;
  delay?: number;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 28 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-60px' }}
      transition={{ duration: 0.65, delay, ease: [0.22, 1, 0.36, 1] }}
      className={className}
    >
      {children}
    </motion.div>
  );
}

const nav = [
  { label: 'Produits', href: '#produits' },
  { label: 'Cloud', href: '#cloud' },
  { label: 'Solutions', href: '#solutions' },
  { label: 'Academy', href: '#academy' },
  { label: 'Partenaires', href: '#partenaires' },
  { label: 'Investisseurs', href: '/investors' },
  { label: 'Contact', href: '/contact' },
];

const series = [
  {
    slug: 'go',
    name: 'GO',
    title: 'La recharge intelligente accessible',
    power: '3.7 kW / 7 kW',
    target: 'Maison · Appartement · Petite entreprise',
    image: '/images/products/go-cee.png',
    accent: '#60a5fa',
    features: ['Portable', 'Type 2', 'CEE / Schuko'],
  },
  {
    slug: 'flex',
    name: 'FLEX',
    title: 'Flexibilité et simplicité',
    power: '7 kW',
    target: 'Résidentiel premium · Villas · PME',
    image: '/images/products/flex-socket.png',
    accent: '#a78bfa',
    features: ['Wallbox', 'App', 'Installation rapide'],
  },
  {
    slug: 'nova',
    name: 'NOVA',
    title: 'Performance connectée',
    power: '7 / 11 / 22 kW',
    target: 'Résidentiel & smart home',
    image: '/images/products/nova-tethered.png',
    accent: '#00e676',
    features: ['WiFi', 'Bluetooth', 'OCPP', 'App KYNETIK'],
  },
  {
    slug: 'prime',
    name: 'PRIME',
    title: 'La solution professionnelle',
    power: '7 / 11 / 22 kW',
    target: 'Entreprises · Hôtels · Parkings',
    image: '/images/products/prime-hero.png',
    accent: '#2dd4bf',
    features: ['RFID', 'Cloud', 'Design premium'],
  },
  {
    slug: 'edge',
    name: 'EDGE',
    title: 'Design et puissance',
    power: '7 / 11 / 22 kW',
    target: 'Sites premium · Immobilier',
    image: '/images/products/edge-pedestal.png',
    accent: '#38bdf8',
    features: ['Pedestal / wall', 'OCPP', 'Brandable'],
  },
  {
    slug: 'pro',
    name: 'PRO',
    title: 'Recharge haute puissance',
    power: '22 / 44 kW',
    target: 'Stations publiques · Flottes · Centres commerciaux',
    image: '/images/products/pro-tethered.png',
    accent: '#fbbf24',
    features: ['Dual output', 'Fleet ready', 'Haute dispo'],
  },
];

const visionCards = [
  {
    icon: Zap,
    t: 'Smart Charging',
    d: 'Load balancing, planification et puissance optimisée pour chaque site.',
  },
  {
    icon: Leaf,
    t: 'Sustainable Energy',
    d: 'Réduction CO₂ mesurable et trajectoire vers une mobilité bas carbone.',
  },
  {
    icon: Cloud,
    t: 'Connected Platform',
    d: 'Cloud OCPP, app mobile et supervision temps réel sur un même stack.',
  },
];

const why = [
  {
    icon: Radio,
    t: 'Technologie',
    d: 'OCPP + IoT + Cloud — interopérabilité et télémétrie native.',
  },
  {
    icon: Wrench,
    t: 'Expertise',
    d: 'Installation et maintenance locale, techniciens certifiés Academy.',
  },
  {
    icon: LayersIcon,
    t: 'Écosystème',
    d: 'Chargeurs + Application + Plateforme — un seul langage produit.',
  },
  {
    icon: Users,
    t: 'Accompagnement',
    d: 'De l’étude de site jusqu’à l’exploitation et le support 24/7.',
  },
];

// fix Layers import - use Layers from lucide - I'll use Server as fallback in map below

const solutions = [
  {
    icon: Building2,
    t: 'Entreprises',
    d: 'Solutions flotte électrique, billing et contrôle multi-sites.',
    to: '/quote',
  },
  {
    icon: Home,
    t: 'Immobilier',
    d: 'Résidences intelligentes et bornes pour copropriétés.',
    to: '/quote',
  },
  {
    icon: Hotel,
    t: 'Hôtels',
    d: 'Recharge clients premium, guest experience et reporting.',
    to: '/success-stories',
  },
  {
    icon: Landmark,
    t: 'Collectivités',
    d: 'Infrastructure publique, disponibilité et supervision réseau.',
    to: '/cloud-platform',
  },
];

const partnerTypes = [
  'Installateur',
  'Revendeur',
  'Promoteur immobilier',
  'Entreprise',
];

export default function SiteHome() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [partnerForm, setPartnerForm] = useState({
    name: '',
    company: '',
    phone: '',
    email: '',
    project: '',
    type: partnerTypes[0],
  });
  const [partnerSent, setPartnerSent] = useState(false);
  const [partnerLoading, setPartnerLoading] = useState(false);
  const [partnerError, setPartnerError] = useState('');

  useEffect(() => {
    track('Website View', { page: 'home-premium' });
    apiGet<Product[]>('/api/products')
      .then((data) =>
        setProducts((data || []).filter((p) => p.name && !String(p.name).startsWith('_')))
      )
      .catch(() => setProducts([]))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const submitPartner = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!partnerForm.email.includes('@') || !partnerForm.name.trim()) {
      setPartnerError('Nom et email valides requis');
      return;
    }
    setPartnerLoading(true);
    setPartnerError('');
    try {
      await fetch('/api/leads', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type: 'partner',
          name: partnerForm.name,
          email: partnerForm.email,
          phone: partnerForm.phone,
          company: partnerForm.company,
          subject: `Partenariat · ${partnerForm.type}`,
          message: partnerForm.project,
          payload: partnerForm,
        }),
      });
      setPartnerSent(true);
      track('Partner Lead', { type: partnerForm.type });
    } catch {
      setPartnerError('Envoi impossible — réessayez ou contactez-nous.');
    } finally {
      setPartnerLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-kyn-black flex items-center justify-center">
        <LoadingState label="Chargement KYNETIK…" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-kyn-black text-white overflow-x-hidden">
      {/* NAV */}
      <header
        className={cn(
          'fixed top-0 inset-x-0 z-50 transition-all duration-300',
          scrolled ? 'bg-kyn-black/90 backdrop-blur-xl border-b border-white/5' : 'bg-transparent'
        )}
      >
        <div className="max-w-7xl mx-auto px-5 md:px-8 h-16 md:h-[72px] flex items-center justify-between gap-4">
          <Link to="/" className="shrink-0" aria-label="KYNETIK home">
            <BrandLogo height={32} />
          </Link>
          <nav className="hidden lg:flex items-center gap-6">
            {nav.map((item) =>
              item.href.startsWith('#') ? (
                <a
                  key={item.label}
                  href={item.href}
                  className="text-xs font-medium text-kyn-silver hover:text-white transition-colors"
                >
                  {item.label}
                </a>
              ) : (
                <Link
                  key={item.label}
                  to={item.href}
                  className="text-xs font-medium text-kyn-silver hover:text-white transition-colors"
                >
                  {item.label}
                </Link>
              )
            )}
          </nav>
          <div className="flex items-center gap-2 sm:gap-3">
            <Link
              to="/quote"
              className="hidden sm:inline-flex items-center gap-2 px-4 py-2.5 rounded-full bg-kyn-green text-kyn-black text-xs font-bold hover:bg-kyn-green-glow transition-colors"
            >
              Demander un devis <ArrowRight size={13} />
            </Link>
            <button
              type="button"
              className="lg:hidden p-2 text-kyn-silver"
              onClick={() => setMenuOpen(!menuOpen)}
              aria-label="Menu"
            >
              {menuOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </div>
        {menuOpen && (
          <div className="lg:hidden border-t border-white/5 bg-kyn-black/95 backdrop-blur-xl px-5 py-4 space-y-2">
            {nav.map((item) =>
              item.href.startsWith('#') ? (
                <a
                  key={item.label}
                  href={item.href}
                  onClick={() => setMenuOpen(false)}
                  className="block py-2.5 text-sm text-kyn-silver"
                >
                  {item.label}
                </a>
              ) : (
                <Link
                  key={item.label}
                  to={item.href}
                  onClick={() => setMenuOpen(false)}
                  className="block py-2.5 text-sm text-kyn-silver"
                >
                  {item.label}
                </Link>
              )
            )}
            <Link
              to="/quote"
              onClick={() => setMenuOpen(false)}
              className="block text-center mt-2 py-3 rounded-full bg-kyn-green text-kyn-black text-sm font-bold"
            >
              Demander un devis
            </Link>
          </div>
        )}
      </header>

      {/* HERO */}
      <section className="relative min-h-[100svh] flex items-end md:items-center pt-24 pb-16 overflow-hidden">
        <img
          src="/images/hero-city.jpg"
          alt=""
          className="absolute inset-0 w-full h-full object-cover opacity-40"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-kyn-black via-kyn-black/90 to-kyn-black/40" />
        <div className="absolute inset-0 bg-gradient-to-t from-kyn-black via-transparent to-kyn-black/50" />
        <div className="absolute top-1/3 right-0 w-[50%] h-[50%] bg-[radial-gradient(ellipse,rgba(0,230,118,0.14),transparent_60%)] pointer-events-none" />

        <div className="relative z-10 max-w-7xl mx-auto px-5 md:px-8 w-full grid lg:grid-cols-[1.15fr_0.85fr] gap-12 items-center">
          <Fade>
            <p className="inline-flex items-center gap-2 text-kyn-green text-[11px] font-semibold tracking-[0.28em] uppercase mb-5">
              <span className="w-6 h-px bg-kyn-green" />
              Tunisie · Afrique · Mobilité électrique
            </p>
            <h1 className="font-display text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold tracking-tight leading-[1.05]">
              L&apos;énergie
              <br />
              <span className="text-kyn-green text-glow">en mouvement</span>
            </h1>
            <p className="mt-6 text-base md:text-lg text-kyn-silver max-w-xl leading-relaxed">
              KYNETIK développe des solutions intelligentes de recharge électrique pour accélérer
              la transition vers une mobilité durable en Tunisie et en Afrique.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <a
                href="#produits"
                className="inline-flex items-center gap-2 px-6 py-3.5 rounded-full bg-kyn-green text-kyn-black text-sm font-bold glow-green"
              >
                <Zap size={16} /> Découvrir nos solutions
              </a>
              <a
                href="#partenaires"
                className="inline-flex items-center gap-2 px-6 py-3.5 rounded-full border border-white/15 text-sm font-semibold hover:border-kyn-green/40 transition-colors"
              >
                <Handshake size={16} /> Devenir partenaire
              </a>
            </div>
            <div className="mt-10 flex flex-wrap gap-6 text-[11px] text-kyn-metal uppercase tracking-wider">
              <span className="inline-flex items-center gap-1.5">
                <CheckCircle2 size={14} className="text-kyn-green" /> OCPP ready
              </span>
              <span className="inline-flex items-center gap-1.5">
                <CheckCircle2 size={14} className="text-kyn-green" /> Cloud + App
              </span>
              <span className="inline-flex items-center gap-1.5">
                <CheckCircle2 size={14} className="text-kyn-green" /> Made for Tunisia
              </span>
            </div>
          </Fade>

          <Fade delay={0.12} className="relative hidden md:block">
            <div className="relative rounded-[2rem] border border-white/10 bg-white/[0.03] backdrop-blur-xl p-6 overflow-hidden">
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_30%,rgba(0,230,118,0.12),transparent_55%)]" />
              <div className="relative grid grid-cols-2 gap-3">
                <div className="col-span-2 rounded-2xl border border-white/8 bg-black/40 p-4 flex items-center justify-center min-h-[200px]">
                  <img
                    src="/images/products/prime-hero.png"
                    alt="KYNETIK PRIME"
                    className="h-48 w-auto object-contain drop-shadow-[0_20px_60px_rgba(0,230,118,0.25)]"
                  />
                </div>
                <div className="rounded-2xl border border-white/8 bg-black/40 p-4 flex items-center justify-center">
                  <img src="/images/products/nova-tethered.png" alt="NOVA" className="h-28 object-contain" />
                </div>
                <div className="rounded-2xl border border-white/8 bg-black/40 p-4 space-y-2">
                  <p className="text-[10px] uppercase tracking-wider text-kyn-green">Réseau intelligent</p>
                  <div className="flex items-center gap-2 text-xs text-kyn-silver">
                    <Activity size={14} className="text-kyn-green" /> Live OCPP
                  </div>
                  <div className="flex items-center gap-2 text-xs text-kyn-silver">
                    <Smartphone size={14} className="text-kyn-green" /> App mobile
                  </div>
                  <div className="flex items-center gap-2 text-xs text-kyn-silver">
                    <Server size={14} className="text-kyn-green" /> Cloud B2B
                  </div>
                </div>
              </div>
            </div>
          </Fade>
        </div>
      </section>

      {/* VISION */}
      <section id="vision" className="py-20 md:py-28 border-t border-white/5 relative">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(0,230,118,0.06),transparent_50%)]" />
        <div className="relative z-10 max-w-7xl mx-auto px-5 md:px-8">
          <Fade className="max-w-3xl">
            <p className="text-kyn-green text-xs font-semibold tracking-[0.3em] uppercase mb-4">Notre vision</p>
            <h2 className="font-display text-3xl md:text-5xl font-bold leading-tight">
              La mobilité de demain commence aujourd&apos;hui
            </h2>
            <p className="mt-5 text-kyn-silver text-lg leading-relaxed">
              KYNETIK accompagne particuliers, entreprises et collectivités avec une infrastructure
              de recharge fiable, connectée et évolutive.
            </p>
          </Fade>
          <div className="mt-12 grid md:grid-cols-3 gap-4">
            {visionCards.map(({ icon: Icon, t, d }, i) => (
              <Fade key={t} delay={i * 0.08}>
                <div className="h-full rounded-3xl border border-white/10 bg-kyn-void p-6 md:p-8 hover:border-kyn-green/30 transition-colors">
                  <div className="w-11 h-11 rounded-2xl bg-kyn-green/10 border border-kyn-green/25 flex items-center justify-center text-kyn-green mb-5">
                    <Icon size={20} />
                  </div>
                  <h3 className="font-display text-xl font-semibold">{t}</h3>
                  <p className="mt-3 text-sm text-kyn-metal leading-relaxed">{d}</p>
                </div>
              </Fade>
            ))}
          </div>
        </div>
      </section>

      {/* PRODUCTS */}
      <section id="produits" className="py-20 md:py-28 border-t border-white/5 bg-kyn-void/40">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <Fade className="flex flex-wrap items-end justify-between gap-4 mb-12">
            <div>
              <p className="text-kyn-green text-xs font-semibold tracking-[0.3em] uppercase mb-4">Produits</p>
              <h2 className="font-display text-3xl md:text-5xl font-bold">Nos solutions de recharge</h2>
              <p className="mt-3 text-kyn-silver max-w-xl">
                Six séries — du portable au haute puissance — un seul langage design et Cloud.
              </p>
            </div>
            <Link
              to="/products"
              className="inline-flex items-center gap-2 text-sm font-semibold text-kyn-green"
            >
              Catalogue complet <ArrowRight size={16} />
            </Link>
          </Fade>

          <div className="grid sm:grid-cols-2 xl:grid-cols-3 gap-4 md:gap-5">
            {series.map((s, i) => (
              <Fade key={s.slug} delay={i * 0.05}>
                <Link
                  to={`/products/${s.slug}`}
                  className="group flex flex-col h-full rounded-3xl border border-white/10 bg-kyn-black/60 overflow-hidden hover:border-kyn-green/35 transition-all"
                >
                  <div
                    className="relative h-48 flex items-center justify-center"
                    style={{
                      background: `radial-gradient(circle at center, ${s.accent}22, transparent 65%)`,
                    }}
                  >
                    <img
                      src={s.image}
                      alt={`KYNETIK ${s.name}`}
                      className="relative z-10 max-h-[85%] w-auto object-contain transition-transform duration-500 group-hover:scale-105"
                    />
                  </div>
                  <div className="p-5 md:p-6 border-t border-white/5 flex-1 flex flex-col">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <p className="font-display text-2xl font-bold" style={{ color: s.accent }}>
                          {s.name}
                        </p>
                        <p className="text-sm text-kyn-silver mt-1">{s.title}</p>
                      </div>
                      <span className="text-xs font-semibold text-white shrink-0">{s.power}</span>
                    </div>
                    <p className="mt-3 text-xs text-kyn-metal">{s.target}</p>
                    <div className="mt-4 flex flex-wrap gap-1.5">
                      {s.features.map((f) => (
                        <span
                          key={f}
                          className="text-[10px] px-2 py-1 rounded-md bg-white/5 border border-white/8 text-kyn-metal"
                        >
                          {f}
                        </span>
                      ))}
                    </div>
                    <span className="mt-5 inline-flex items-center gap-1 text-xs font-semibold text-kyn-green">
                      Voir le produit <ChevronRight size={14} />
                    </span>
                  </div>
                </Link>
              </Fade>
            ))}
          </div>

          {products.length > 0 && (
            <Fade>
              <p className="mt-10 text-center text-[11px] text-kyn-metal">
                {products.length} références actives en catalogue · données Cloud synchronisées
              </p>
            </Fade>
          )}
        </div>
      </section>

      {/* CLOUD */}
      <section id="cloud" className="py-20 md:py-28 border-t border-white/5 relative overflow-hidden">
        <img
          src="/images/cloud-datacenter.jpg"
          alt=""
          className="absolute inset-0 w-full h-full object-cover opacity-20"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-kyn-black via-kyn-black/95 to-kyn-black/80" />
        <div className="relative z-10 max-w-7xl mx-auto px-5 md:px-8 grid lg:grid-cols-2 gap-12 items-center">
          <Fade>
            <p className="text-kyn-green text-xs font-semibold tracking-[0.3em] uppercase mb-4">
              KYNETIK Cloud
            </p>
            <h2 className="font-display text-3xl md:text-5xl font-bold leading-tight">
              Une plateforme intelligente pour piloter votre énergie
            </h2>
            <p className="mt-5 text-kyn-silver leading-relaxed">
              Supervision OCPP, flottes, facturation et maintenance prédictive — pour opérateurs,
              hôtels, parkings et collectivités.
            </p>
            <div className="mt-8 grid sm:grid-cols-2 gap-3">
              {[
                { icon: Activity, t: 'Monitoring temps réel' },
                { icon: TrendingUp, t: 'Analytics' },
                { icon: Wrench, t: 'Maintenance prédictive' },
                { icon: WalletIcon, t: 'Gestion des paiements' },
                { icon: Smartphone, t: 'Application mobile' },
                { icon: Shield, t: 'Rôles & sécurité' },
              ].map(({ icon: Icon, t }) => (
                <div
                  key={t}
                  className="flex items-center gap-3 rounded-2xl border border-white/10 bg-black/40 px-4 py-3"
                >
                  <Icon size={16} className="text-kyn-green shrink-0" />
                  <span className="text-sm font-medium">{t}</span>
                </div>
              ))}
            </div>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link
                to="/cloud-platform"
                className="inline-flex items-center gap-2 px-6 py-3.5 rounded-full bg-kyn-green text-kyn-black text-sm font-bold"
              >
                Découvrir KYNETIK Cloud <ArrowRight size={16} />
              </Link>
              <Link
                to="/console"
                className="inline-flex items-center gap-2 px-6 py-3.5 rounded-full border border-white/15 text-sm font-semibold"
              >
                Ouvrir la console
              </Link>
            </div>
          </Fade>
          <Fade delay={0.1}>
            <div className="rounded-3xl border border-white/10 bg-kyn-void/90 p-6 shadow-2xl shadow-kyn-green/5">
              <div className="flex items-center justify-between mb-5">
                <div className="flex items-center gap-2">
                  <BrandLogo height={22} markOnly />
                  <span className="text-xs font-semibold tracking-wider text-kyn-green">CLOUD LIVE</span>
                </div>
                <span className="text-[10px] text-kyn-green flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-kyn-green animate-pulse" /> Online
                </span>
              </div>
              <div className="grid grid-cols-2 gap-3 mb-4">
                {[
                  ['Stations', '248'],
                  ['Online', '91%'],
                  ['MWh / mois', '154.8'],
                  ['Revenue', '48.5k DT'],
                ].map(([l, v]) => (
                  <div key={l} className="rounded-xl border border-white/8 bg-black/40 p-3">
                    <p className="text-[10px] text-kyn-metal uppercase tracking-wider">{l}</p>
                    <p className="font-display text-xl font-bold text-kyn-green mt-1">{v}</p>
                  </div>
                ))}
              </div>
              <div className="rounded-xl border border-white/8 bg-black/30 p-4 space-y-2">
                {['Tunis Centre · Charging 22 kW', 'La Marsa · Available', 'Sousse · Maintenance'].map(
                  (row) => (
                    <div key={row} className="flex items-center justify-between text-xs">
                      <span className="text-kyn-silver">{row}</span>
                      <span className="text-kyn-green">OCPP</span>
                    </div>
                  )
                )}
              </div>
            </div>
          </Fade>
        </div>
      </section>

      {/* WHY */}
      <section className="py-20 md:py-28 border-t border-white/5">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <Fade className="text-center max-w-2xl mx-auto mb-12">
            <p className="text-kyn-green text-xs font-semibold tracking-[0.3em] uppercase mb-4">
              Confiance
            </p>
            <h2 className="font-display text-3xl md:text-5xl font-bold">Pourquoi choisir KYNETIK ?</h2>
          </Fade>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              {
                icon: Radio,
                t: 'Technologie',
                d: 'OCPP + IoT + Cloud — interopérabilité et télémétrie native.',
              },
              {
                icon: Wrench,
                t: 'Expertise',
                d: 'Installation et maintenance locale, techniciens certifiés Academy.',
              },
              {
                icon: Sparkles,
                t: 'Écosystème',
                d: 'Chargeurs + Application + Plateforme — un seul langage produit.',
              },
              {
                icon: Users,
                t: 'Accompagnement',
                d: "De l'étude de site jusqu'à l'exploitation et le support 24/7.",
              },
            ].map(({ icon: Icon, t, d }, i) => (
              <Fade key={t} delay={i * 0.06}>
                <div className="h-full rounded-3xl border border-white/10 bg-kyn-void p-6 text-center">
                  <div className="w-12 h-12 mx-auto rounded-2xl bg-kyn-green/10 border border-kyn-green/25 flex items-center justify-center text-kyn-green mb-4">
                    <Icon size={20} />
                  </div>
                  <h3 className="font-display font-semibold text-lg">{t}</h3>
                  <p className="mt-2 text-sm text-kyn-metal leading-relaxed">{d}</p>
                </div>
              </Fade>
            ))}
          </div>
          <div className="mt-10 flex flex-wrap justify-center gap-4 text-xs text-kyn-metal">
            <span className="inline-flex items-center gap-1.5">
              <Wifi size={14} className="text-kyn-green" /> WiFi
            </span>
            <span className="inline-flex items-center gap-1.5">
              <Bluetooth size={14} className="text-kyn-green" /> Bluetooth
            </span>
            <span className="inline-flex items-center gap-1.5">
              <Radio size={14} className="text-kyn-green" /> OCPP 1.6J
            </span>
            <span className="inline-flex items-center gap-1.5">
              <Cloud size={14} className="text-kyn-green" /> Cloud Ready
            </span>
          </div>
        </div>
      </section>

      {/* ACADEMY */}
      <section id="academy" className="py-20 md:py-28 border-t border-white/5 relative overflow-hidden">
        <img
          src="/images/academy.jpg"
          alt=""
          className="absolute inset-0 w-full h-full object-cover opacity-25"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-kyn-black via-kyn-black/90 to-kyn-black/70" />
        <div className="relative z-10 max-w-7xl mx-auto px-5 md:px-8 grid lg:grid-cols-2 gap-10 items-center">
          <Fade>
            <p className="text-kyn-green text-xs font-semibold tracking-[0.3em] uppercase mb-4">
              KYNETIK Academy
            </p>
            <h2 className="font-display text-3xl md:text-5xl font-bold">
              Former les experts de demain
            </h2>
            <p className="mt-5 text-kyn-silver leading-relaxed">
              Programmes pour installateurs, techniciens électriques et partenaires réseau —
              certification officielle KYNETIK.
            </p>
            <ul className="mt-6 space-y-3">
              {[
                'Formation installateurs',
                'Certification KYNETIK',
                'Formation électrique',
                'Maintenance bornes',
              ].map((item) => (
                <li key={item} className="flex items-center gap-2 text-sm text-kyn-silver">
                  <GraduationCap size={16} className="text-kyn-green" /> {item}
                </li>
              ))}
            </ul>
            <Link
              to="/academy-landing"
              className="mt-8 inline-flex items-center gap-2 px-6 py-3.5 rounded-full bg-kyn-green text-kyn-black text-sm font-bold"
            >
              Découvrir Academy <ArrowRight size={16} />
            </Link>
          </Fade>
          <Fade delay={0.1}>
            <div className="rounded-3xl border border-white/10 bg-black/50 backdrop-blur p-8">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 rounded-2xl bg-kyn-green/15 border border-kyn-green/30 flex items-center justify-center">
                  <GraduationCap className="text-kyn-green" size={22} />
                </div>
                <div>
                  <p className="font-display font-bold text-lg">Parcours certifiant</p>
                  <p className="text-xs text-kyn-metal">Théorie · Atelier · Mise en service</p>
                </div>
              </div>
              <div className="space-y-3">
                {['Apply', 'Train', 'Certify', 'Deploy'].map((step, i) => (
                  <div
                    key={step}
                    className="flex items-center gap-3 rounded-xl border border-white/8 bg-white/[0.03] px-4 py-3"
                  >
                    <span className="w-7 h-7 rounded-full bg-kyn-green/15 text-kyn-green text-xs font-bold flex items-center justify-center">
                      {i + 1}
                    </span>
                    <span className="text-sm font-semibold">{step}</span>
                  </div>
                ))}
              </div>
            </div>
          </Fade>
        </div>
      </section>

      {/* BUSINESS SOLUTIONS */}
      <section id="solutions" className="py-20 md:py-28 border-t border-white/5 bg-kyn-void/30">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <Fade className="mb-12">
            <p className="text-kyn-green text-xs font-semibold tracking-[0.3em] uppercase mb-4">
              Business solutions
            </p>
            <h2 className="font-display text-3xl md:text-5xl font-bold">Des offres par secteur</h2>
          </Fade>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {solutions.map(({ icon: Icon, t, d, to }, i) => (
              <Fade key={t} delay={i * 0.06}>
                <Link
                  to={to}
                  className="group h-full rounded-3xl border border-white/10 bg-kyn-black/50 p-6 hover:border-kyn-green/35 transition-all flex flex-col"
                >
                  <Icon className="text-kyn-green mb-4" size={22} />
                  <h3 className="font-display text-lg font-semibold group-hover:text-kyn-green transition-colors">
                    {t}
                  </h3>
                  <p className="mt-2 text-sm text-kyn-metal flex-1 leading-relaxed">{d}</p>
                  <span className="mt-4 inline-flex items-center gap-1 text-xs font-semibold text-kyn-green">
                    En savoir plus <ChevronRight size={14} />
                  </span>
                </Link>
              </Fade>
            ))}
          </div>
        </div>
      </section>

      {/* PARTNERS */}
      <section id="partenaires" className="py-20 md:py-28 border-t border-white/5">
        <div className="max-w-7xl mx-auto px-5 md:px-8 grid lg:grid-cols-2 gap-12 items-start">
          <Fade>
            <p className="text-kyn-green text-xs font-semibold tracking-[0.3em] uppercase mb-4">
              Become partner
            </p>
            <h2 className="font-display text-3xl md:text-5xl font-bold">Devenir partenaire KYNETIK</h2>
            <p className="mt-5 text-kyn-silver leading-relaxed">
              Rejoignez le réseau d&apos;installateurs, revendeurs et promoteurs qui déploient la
              mobilité électrique en Tunisie et en Afrique du Nord.
            </p>
            <div className="mt-6 flex flex-wrap gap-2">
              {partnerTypes.map((t) => (
                <span
                  key={t}
                  className="px-3 py-1.5 rounded-full border border-white/10 bg-white/[0.03] text-xs font-semibold text-kyn-silver"
                >
                  {t}
                </span>
              ))}
            </div>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link
                to="/installers"
                className="inline-flex items-center gap-2 text-sm font-semibold text-kyn-green"
              >
                Programme installateur <ArrowRight size={14} />
              </Link>
              <Link
                to="/distributors"
                className="inline-flex items-center gap-2 text-sm font-semibold text-kyn-silver hover:text-white"
              >
                Distribution
              </Link>
            </div>
          </Fade>

          <Fade delay={0.1}>
            <div className="rounded-3xl border border-white/10 bg-kyn-void p-6 md:p-8">
              {partnerSent ? (
                <div className="text-center py-10">
                  <CheckCircle2 className="mx-auto text-kyn-green mb-4" size={40} />
                  <h3 className="font-display text-xl font-bold">Demande envoyée</h3>
                  <p className="mt-2 text-sm text-kyn-silver">
                    Notre équipe partenariats vous recontacte sous 48h.
                  </p>
                </div>
              ) : (
                <form onSubmit={submitPartner} className="space-y-4">
                  <h3 className="font-display font-semibold text-lg mb-2">Formulaire partenariat</h3>
                  <div className="grid sm:grid-cols-2 gap-3">
                    <Field label="Nom">
                      <input
                        className={inputCls}
                        value={partnerForm.name}
                        onChange={(e) => setPartnerForm({ ...partnerForm, name: e.target.value })}
                        required
                      />
                    </Field>
                    <Field label="Entreprise">
                      <input
                        className={inputCls}
                        value={partnerForm.company}
                        onChange={(e) => setPartnerForm({ ...partnerForm, company: e.target.value })}
                      />
                    </Field>
                    <Field label="Téléphone">
                      <input
                        className={inputCls}
                        value={partnerForm.phone}
                        onChange={(e) => setPartnerForm({ ...partnerForm, phone: e.target.value })}
                      />
                    </Field>
                    <Field label="Email">
                      <input
                        type="email"
                        className={inputCls}
                        value={partnerForm.email}
                        onChange={(e) => setPartnerForm({ ...partnerForm, email: e.target.value })}
                        required
                      />
                    </Field>
                  </div>
                  <Field label="Type de partenariat">
                    <select
                      className={inputCls}
                      value={partnerForm.type}
                      onChange={(e) => setPartnerForm({ ...partnerForm, type: e.target.value })}
                    >
                      {partnerTypes.map((t) => (
                        <option key={t} value={t}>
                          {t}
                        </option>
                      ))}
                    </select>
                  </Field>
                  <Field label="Projet">
                    <textarea
                      className={cn(inputCls, 'min-h-[90px]')}
                      value={partnerForm.project}
                      onChange={(e) => setPartnerForm({ ...partnerForm, project: e.target.value })}
                      placeholder="Territoire, volume, timeline…"
                    />
                  </Field>
                  {partnerError && <p className="text-sm text-red-400">{partnerError}</p>}
                  <button
                    type="submit"
                    disabled={partnerLoading}
                    className="w-full py-3.5 rounded-full bg-kyn-green text-kyn-black text-sm font-bold disabled:opacity-60"
                  >
                    {partnerLoading ? 'Envoi…' : 'Envoyer la demande'}
                  </button>
                </form>
              )}
            </div>
          </Fade>
        </div>
      </section>

      {/* INVESTORS */}
      <section id="investisseurs" className="py-20 md:py-28 border-t border-white/5 relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(0,230,118,0.08),transparent_55%)]" />
        <div className="relative z-10 max-w-7xl mx-auto px-5 md:px-8">
          <Fade className="max-w-3xl">
            <p className="text-kyn-green text-xs font-semibold tracking-[0.3em] uppercase mb-4">
              Investors
            </p>
            <h2 className="font-display text-3xl md:text-5xl font-bold">
              Investir dans la mobilité électrique
            </h2>
            <p className="mt-5 text-kyn-silver text-lg leading-relaxed">
              Hardware premium, Cloud SaaS et réseau partenaires — une plateforme prête pour le
              marché tunisien et l&apos;expansion Afrique du Nord.
            </p>
          </Fade>
          <div className="mt-10 grid sm:grid-cols-2 lg:grid-cols-5 gap-3">
            {[
              { t: 'Vision 2036', d: 'Leader régional de la recharge connectée' },
              { t: 'Marché tunisien', d: 'Adoption EV accélérée, infrastructure à construire' },
              { t: 'Afrique du Nord', d: 'Corridor export & partenariats distributeurs' },
              { t: 'Business model', d: 'Hardware + Cloud + Services + Academy' },
              { t: 'Growth', d: 'B2C, B2B, flottes, public, franchise installateurs' },
            ].map((c, i) => (
              <Fade key={c.t} delay={i * 0.05}>
                <div className="h-full rounded-2xl border border-white/10 bg-kyn-void p-5">
                  <Globe2 className="text-kyn-green mb-3" size={18} />
                  <p className="font-semibold text-sm">{c.t}</p>
                  <p className="text-xs text-kyn-metal mt-2 leading-relaxed">{c.d}</p>
                </div>
              </Fade>
            ))}
          </div>
          <Fade>
            <div className="mt-10 flex flex-wrap gap-3">
              <Link
                to="/investors"
                className="inline-flex items-center gap-2 px-6 py-3.5 rounded-full bg-kyn-green text-kyn-black text-sm font-bold"
              >
                Dossier investisseurs <ArrowRight size={16} />
              </Link>
              <Link
                to="/sales"
                className="inline-flex items-center gap-2 px-6 py-3.5 rounded-full border border-white/15 text-sm font-semibold"
              >
                Sales System
              </Link>
              <Link
                to="/ops"
                className="inline-flex items-center gap-2 px-6 py-3.5 rounded-full border border-white/15 text-sm font-semibold"
              >
                Ops Blueprint
              </Link>
              <Link
                to="/architecture"
                className="inline-flex items-center gap-2 px-6 py-3.5 rounded-full border border-white/15 text-sm font-semibold"
              >
                Architecture
              </Link>
              <Link
                to="/brand-launch"
                className="inline-flex items-center gap-2 px-6 py-3.5 rounded-full border border-white/15 text-sm font-semibold"
              >
                Brand Launch
              </Link>
              <Link
                to="/contact"
                className="inline-flex items-center gap-2 px-6 py-3.5 rounded-full border border-white/15 text-sm font-semibold"
              >
                Contacter l&apos;équipe
              </Link>
            </div>
          </Fade>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 border-t border-white/5">
        <div className="max-w-5xl mx-auto px-5 md:px-8 rounded-[2rem] border border-kyn-green/25 bg-gradient-to-br from-kyn-green/10 via-kyn-void to-kyn-black p-8 md:p-12 text-center">
          <Fade>
            <h2 className="font-display text-3xl md:text-4xl font-bold">
              Prêt à électrifier votre site ?
            </h2>
            <p className="mt-3 text-kyn-silver max-w-xl mx-auto">
              Devis, étude technique, installation certifiée et activation Cloud en un parcours.
            </p>
            <div className="mt-8 flex flex-wrap justify-center gap-3">
              <Link
                to="/quote"
                className="inline-flex items-center gap-2 px-7 py-3.5 rounded-full bg-kyn-green text-kyn-black text-sm font-bold"
              >
                Demander un devis <ArrowRight size={16} />
              </Link>
              <Link
                to="/kynetik-app"
                className="inline-flex items-center gap-2 px-7 py-3.5 rounded-full border border-white/15 text-sm font-semibold"
              >
                Voir l&apos;app
              </Link>
              <Link
                to="/delivery"
                className="inline-flex items-center gap-2 px-7 py-3.5 rounded-full border border-white/15 text-sm font-semibold"
              >
                Architecture produit
              </Link>
            </div>
          </Fade>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="border-t border-white/5 pt-14 pb-10">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <div className="grid md:grid-cols-2 lg:grid-cols-6 gap-10">
            <div className="lg:col-span-2">
              <BrandLogo height={32} />
              <p className="mt-4 text-sm text-kyn-metal max-w-xs leading-relaxed">
                L&apos;énergie en mouvement — infrastructure de recharge intelligente pour la
                Tunisie et l&apos;Afrique.
              </p>
              <div className="mt-5 flex gap-2">
                {[
                  { Icon: Linkedin, href: 'https://linkedin.com' },
                  { Icon: Facebook, href: 'https://facebook.com' },
                  { Icon: Instagram, href: 'https://instagram.com' },
                ].map(({ Icon, href }) => (
                  <a
                    key={href}
                    href={href}
                    target="_blank"
                    rel="noreferrer"
                    className="w-9 h-9 rounded-full border border-white/10 flex items-center justify-center text-kyn-metal hover:text-kyn-green hover:border-kyn-green/40 transition-colors"
                  >
                    <Icon size={14} />
                  </a>
                ))}
              </div>
            </div>
            {[
              {
                t: 'Products',
                links: [
                  { l: 'GO', to: '/products/go' },
                  { l: 'FLEX', to: '/products/flex' },
                  { l: 'PRD', to: '/prd' },
                  { l: 'NOVA', to: '/products/nova' },
                  { l: 'PRIME', to: '/products/prime' },
                  { l: 'EDGE', to: '/products/edge' },
                  { l: 'PRO', to: '/products/pro' },
                ],
              },
              {
                t: 'Solutions',
                links: [
                  { l: 'Entreprises', to: '#solutions' },
                  { l: 'Immobilier', to: '#solutions' },
                  { l: 'Hôtels', to: '#solutions' },
                  { l: 'Collectivités', to: '#solutions' },
                ],
              },
              {
                t: 'Platform',
                links: [
                  { l: 'Cloud', to: '/cloud-platform' },
                  { l: 'App', to: '/kynetik-app' },
                  { l: 'Academy', to: '/academy-landing' },
                  { l: 'Partners', to: '#partenaires' },
                ],
              },
              {
                t: 'Company',
                links: [
                  { l: 'About KYNETIK', to: '#vision' },
                  { l: 'Investors', to: '/investors' },
                  { l: 'Contact', to: '/contact' },
                  { l: 'Support', to: '/support' },
                ],
              },
            ].map((col) => (
              <div key={col.t}>
                <p className="text-[11px] font-semibold uppercase tracking-wider text-kyn-green mb-4">
                  {col.t}
                </p>
                <ul className="space-y-2">
                  {col.links.map((link) =>
                    link.to.startsWith('#') ? (
                      <li key={link.l}>
                        <a href={link.to} className="text-sm text-kyn-metal hover:text-white transition-colors">
                          {link.l}
                        </a>
                      </li>
                    ) : (
                      <li key={link.l}>
                        <Link to={link.to} className="text-sm text-kyn-metal hover:text-white transition-colors">
                          {link.l}
                        </Link>
                      </li>
                    )
                  )}
                </ul>
              </div>
            ))}
          </div>
          <div className="mt-12 pt-6 border-t border-white/5 flex flex-wrap justify-between gap-3 items-center">
            <p className="text-[11px] text-kyn-metal">
              © {new Date().getFullYear()} KYNETIK · Phase 21 Website Premium
            </p>
            <div className="flex flex-wrap gap-4 text-[11px] text-kyn-metal">
              <Link to="/faq" className="hover:text-white">
                FAQ
              </Link>
              <Link to="/delivery" className="hover:text-white">
                Delivery
              </Link>
              <Link to="/design-system" className="hover:text-white">
                Design System
              </Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <label className="block">
      <span className="text-[11px] uppercase tracking-wider text-kyn-metal font-medium">{label}</span>
      <div className="mt-1.5">{children}</div>
    </label>
  );
}

const inputCls =
  'w-full rounded-xl bg-kyn-steel/50 border border-white/10 px-3.5 py-3 text-sm text-white placeholder:text-kyn-metal focus:outline-none focus:border-kyn-green/50 focus:ring-1 focus:ring-kyn-green/30 transition-colors';

// Alias to avoid unused import issues if Wallet missing - define local
function WalletIcon(props: { size?: number; className?: string }) {
  return <Activity {...props} />;
}

function LayersIcon(props: { size?: number; className?: string }) {
  return <Sparkles {...props} />;
}

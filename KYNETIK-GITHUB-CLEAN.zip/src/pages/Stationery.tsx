import { useEffect, useState } from 'react';
import { QrCode, Mail, Phone, Globe, MapPin } from 'lucide-react';
import SectionHeader from '../components/SectionHeader';
import LoadingState from '../components/LoadingState';
import ErrorState from '../components/ErrorState';
import Logo from '../components/Logo';
import { apiGet } from '../lib/utils';

interface Asset {
  id: number;
  title: string;
  category: string;
  description: string;
  meta: string | null;
}

export default function Stationery() {
  const [assets, setAssets] = useState<Asset[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    apiGet<Asset[]>('/api/design-assets?category=stationery')
      .then(setAssets)
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <div className="p-10"><LoadingState /></div>;
  if (error) return <div className="p-10"><ErrorState message={error} /></div>;

  return (
    <div className="max-w-6xl mx-auto px-6 md:px-10 py-12 md:py-16">
      <SectionHeader
        eyebrow="09 · Corporate Stationery"
        title="Brand assets"
        description="Matte black finishes, electric green metallic foils, and precise typography for executive and field presence."
      />

      {/* Business cards */}
      <h2 className="font-display text-xl font-semibold mb-6">Business cards</h2>
      <div className="grid md:grid-cols-2 gap-8 mb-14">
        {/* Front */}
        <div>
          <p className="text-xs text-kyn-metal mb-3 uppercase tracking-wider">Front</p>
          <div className="aspect-[1.75/1] rounded-2xl bg-gradient-to-br from-kyn-charcoal via-kyn-black to-black border border-white/10 p-8 flex flex-col justify-between poster-shadow relative overflow-hidden">
            <div className="absolute -right-8 -bottom-8 w-40 h-40 rounded-full bg-kyn-green/10 blur-2xl" />
            <div className="absolute top-0 right-0 w-1 h-full bg-gradient-to-b from-kyn-green via-kyn-green/40 to-transparent" />
            <Logo size="md" glowing />
            <div>
              <p className="font-display text-xl font-bold">Khalifa Ben Ali</p>
              <p className="text-kyn-green text-sm mt-1">Founder & CEO</p>
            </div>
          </div>
        </div>
        {/* Back */}
        <div>
          <p className="text-xs text-kyn-metal mb-3 uppercase tracking-wider">Back</p>
          <div className="aspect-[1.75/1] rounded-2xl bg-kyn-black border border-white/10 p-8 flex justify-between items-end poster-shadow relative overflow-hidden">
            <div className="absolute inset-0 grid-bg opacity-40" />
            <div className="relative z-10 space-y-2 text-sm text-kyn-silver">
              <p className="flex items-center gap-2"><Mail size={12} className="text-kyn-green" /> khalifa@kynetik.tn</p>
              <p className="flex items-center gap-2"><Phone size={12} className="text-kyn-green" /> +216 00 000 000</p>
              <p className="flex items-center gap-2"><Globe size={12} className="text-kyn-green" /> www.kynetik.tn</p>
              <p className="flex items-center gap-2"><MapPin size={12} className="text-kyn-green" /> Tunis, Tunisie</p>
            </div>
            <div className="relative z-10 w-16 h-16 rounded-lg border border-kyn-green/30 flex items-center justify-center bg-kyn-void">
              <QrCode className="text-kyn-green" size={32} />
            </div>
          </div>
        </div>
      </div>

      {/* Letterhead */}
      <h2 className="font-display text-xl font-semibold mb-6">Letterhead</h2>
      <div className="rounded-2xl bg-white text-kyn-black p-10 md:p-14 poster-shadow mb-14 min-h-[480px] flex flex-col relative overflow-hidden">
        <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-kyn-green via-kyn-green-dim to-transparent" />
        <div className="flex justify-between items-start">
          <div className="[&_span]:text-kyn-black">
            <Logo size="md" />
          </div>
          <div className="text-right text-[10px] text-kyn-graphite leading-relaxed">
            KYNETIK SAS<br />
            Les Berges du Lac, Tunis<br />
            contact@kynetik.tn
          </div>
        </div>
        <div className="mt-16 flex-1">
          <p className="text-xs text-kyn-graphite mb-6">Tunis, le 15 Mars 2026</p>
          <p className="text-sm leading-relaxed text-kyn-graphite max-w-lg">
            Objet : Proposition d'installation — borne KYNETIK NOVA 22kW
          </p>
          <div className="mt-8 space-y-2">
            {[100, 95, 88, 92, 70].map((w, i) => (
              <div key={i} className="h-2 rounded-full bg-black/5" style={{ width: `${w}%` }} />
            ))}
          </div>
        </div>
        <div className="mt-auto pt-10 flex justify-between items-end border-t border-black/5">
          <p className="text-[10px] text-kyn-graphite">www.kynetik.tn · L'énergie en mouvement</p>
          <div className="text-right">
            <p className="font-display font-semibold text-sm">Khalifa Ben Ali</p>
            <p className="text-[10px] text-kyn-green font-medium">Founder & CEO</p>
          </div>
        </div>
      </div>

      {/* Envelope + folder mock */}
      <div className="grid md:grid-cols-2 gap-6 mb-12">
        <div className="rounded-2xl bg-gradient-to-br from-kyn-charcoal to-kyn-black border border-white/10 p-8 aspect-[1.6/1] flex flex-col justify-between poster-shadow">
          <Logo size="sm" glowing />
          <div>
            <p className="text-xs text-kyn-metal uppercase tracking-widest mb-2">Envelope</p>
            <p className="font-display font-semibold">KYNETIK · Tunis</p>
            <div className="mt-3 h-px w-24 bg-kyn-green" />
          </div>
        </div>
        <div className="rounded-2xl bg-gradient-to-br from-kyn-steel to-kyn-void border border-kyn-green/20 p-8 aspect-[1.6/1] flex flex-col justify-between poster-shadow relative overflow-hidden">
          <div className="absolute right-0 top-0 bottom-0 w-2 bg-kyn-green" />
          <p className="text-xs text-kyn-metal uppercase tracking-widest">Presentation Folder</p>
          <div>
            <Logo size="lg" glowing />
            <p className="mt-4 text-sm text-kyn-silver">Corporate dossier · Matte black + green foil</p>
          </div>
        </div>
      </div>

      <div className="grid md:grid-cols-3 gap-4">
        {assets.map((a) => (
          <div key={a.id} className="glass-card rounded-2xl p-6">
            <h3 className="font-display font-semibold">{a.title}</h3>
            <p className="text-sm text-kyn-metal mt-2">{a.description}</p>
            {a.meta && <p className="mt-3 text-xs text-kyn-green">{a.meta}</p>}
          </div>
        ))}
      </div>
    </div>
  );
}

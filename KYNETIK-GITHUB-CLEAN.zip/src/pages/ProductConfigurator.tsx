import { useEffect, useMemo, useState, type ComponentType, type ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import {
  ArrowLeft, ArrowRight, Building2, Cable, Car, Check, CheckCircle2,
  ChevronRight, Cloud, Download, Factory, FileText, Gauge, Home, Hotel,
  Landmark, Layers, Loader2, MapPin, Radio, Shield, Smartphone,
  Sparkles, Timer, Wallet, Wifi, Zap, Menu, X
} from 'lucide-react';
import BrandLogo from '../components/BrandLogo';
import LoadingState from '../components/LoadingState';
import ErrorState from '../components/ErrorState';
import { apiGet, apiPost, cn } from '../lib/utils';

interface ProductLine {
  id: number;
  slug: string;
  name: string;
  tagline: string;
  description: string;
  category: string;
  segment: string;
  powers: string;
  image_hero: string;
  accent: string;
  sort_order: number;
}

interface ConfigOption {
  id: number;
  type: string;
  category: string;
  title: string;
  subtitle: string;
  body: string;
  meta: string | null;
  image_url: string | null;
  sort_order: number;
}

type StepId = 1 | 2 | 3 | 4 | 5 | 6;

const STEPS: { id: StepId; label: string; title: string }[] = [
  { id: 1, label: 'Environment', title: 'Where will you charge?' },
  { id: 2, label: 'Charger', title: 'Choose your charger' },
  { id: 3, label: 'Power', title: 'Select power output' },
  { id: 4, label: 'Accessories', title: 'Add smart accessories' },
  { id: 5, label: 'Installation', title: 'Installation setup' },
  { id: 6, label: 'Summary', title: 'Your configuration' },
];

const ENV_ICONS: Record<string, ComponentType<{ size?: number; className?: string }>> = {
  home: Home,
  apartment: Building2,
  company: Factory,
  hotel: Hotel,
  fleet: Car,
  public: Landmark,
};

const ACC_ICONS: Record<string, ComponentType<{ size?: number; className?: string }>> = {
  cable_holder: Cable,
  pedestal: Layers,
  rfid: Radio,
  '4g': Wifi,
  load_balancing: Gauge,
  smart_meter: Zap,
};

function parsePowers(raw: string): number[] {
  try {
    const arr = JSON.parse(raw) as string[];
    return arr
      .map((s) => {
        const m = String(s).match(/(\d+(?:\.\d+)?)/);
        return m ? Number(m[1]) : NaN;
      })
      .filter((n) => !Number.isNaN(n));
  } catch {
    return [];
  }
}

function parseMeta(meta: string | null): Record<string, string> {
  if (!meta) return {};
  try {
    return JSON.parse(meta);
  } catch {
    const out: Record<string, string> = {};
    meta.split('|').forEach((part) => {
      const [k, ...rest] = part.split(':');
      if (k && rest.length) out[k.trim()] = rest.join(':').trim();
    });
    return out;
  }
}

function formatTND(n: number) {
  return new Intl.NumberFormat('fr-TN', {
    style: 'currency',
    currency: 'TND',
    maximumFractionDigits: 0,
  }).format(n);
}

function Fade({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 18 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -12 }}
      transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
      className={className}
    >
      {children}
    </motion.div>
  );
}

export default function ProductConfigurator() {
  const [lines, setLines] = useState<ProductLine[]>([]);
  const [options, setOptions] = useState<ConfigOption[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [step, setStep] = useState<StepId>(1);
  const [menuOpen, setMenuOpen] = useState(false);

  const [environment, setEnvironment] = useState('');
  const [chargerSlug, setChargerSlug] = useState('');
  const [powerKw, setPowerKw] = useState<number | null>(null);
  const [accessories, setAccessories] = useState<string[]>([]);
  const [installPlace, setInstallPlace] = useState<'indoor' | 'outdoor' | ''>('');
  const [installMount, setInstallMount] = useState<'wall' | 'pedestal' | ''>('');

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [company, setCompany] = useState('');
  const [message, setMessage] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [submitError, setSubmitError] = useState('');

  useEffect(() => {
    Promise.all([
      apiGet<ProductLine[]>('/api/product-lines'),
      apiGet<ConfigOption[]>('/api/marketing-content?type=configurator'),
    ])
      .then(([productLines, opts]) => {
        setLines((productLines || []).sort((a, b) => (a.sort_order ?? 0) - (b.sort_order ?? 0)));
        setOptions(opts || []);
      })
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, []);

  const envs = useMemo(
    () => options.filter((o) => o.category === 'environment').sort((a, b) => a.sort_order - b.sort_order),
    [options]
  );
  const powers = useMemo(
    () => options.filter((o) => o.category === 'power').sort((a, b) => a.sort_order - b.sort_order),
    [options]
  );
  const accessoriesOpts = useMemo(
    () => options.filter((o) => o.category === 'accessory').sort((a, b) => a.sort_order - b.sort_order),
    [options]
  );
  const installOpts = useMemo(
    () => options.filter((o) => o.category === 'installation').sort((a, b) => a.sort_order - b.sort_order),
    [options]
  );

  const selectedEnv = envs.find((e) => e.title.toLowerCase() === environment || parseMeta(e.meta).key === environment);
  const selectedLine = lines.find((l) => l.slug === chargerSlug) || null;

  const recommendedSlugs = useMemo(() => {
    const meta = selectedEnv ? parseMeta(selectedEnv.meta) : {};
    if (meta.recommend) return meta.recommend.split(',').map((s) => s.trim().toLowerCase());
    return lines.map((l) => l.slug);
  }, [selectedEnv, lines]);

  const availablePowers = useMemo(() => {
    if (!selectedLine) return powers;
    const linePowers = parsePowers(selectedLine.powers);
    if (!linePowers.length) return powers;
    return powers.filter((p) => {
      const kw = Number(parseMeta(p.meta).kw || p.title.replace(/[^\d.]/g, ''));
      // allow dual 44 for PRO even if listed as dual output
      if (kw === 44 && selectedLine.slug === 'pro') return true;
      return linePowers.some((lp) => Math.abs(lp - kw) < 0.1 || (kw === 44 && lp >= 22));
    });
  }, [selectedLine, powers]);

  // Pricing engine
  const estimate = useMemo(() => {
    const envMeta = selectedEnv ? parseMeta(selectedEnv.meta) : {};
    const base = selectedLine
      ? Number(parseMeta(
          options.find((o) => o.category === 'charger_base' && o.title.toLowerCase() === selectedLine.slug)?.meta || null
        ).price || 0)
      : 0;

    // Fallback base prices if not in CMS
    const fallbackBase: Record<string, number> = {
      go: 890,
      flex: 1890,
      prime: 2490,
      nova: 2290,
      edge: 2790,
      pro: 4590,
    };
    let total = base || (selectedLine ? fallbackBase[selectedLine.slug] || 2000 : 0);

    if (powerKw != null) {
      const pOpt = powers.find((p) => Number(parseMeta(p.meta).kw || p.title) === powerKw);
      const pAdd = Number(parseMeta(pOpt?.meta || null).add || 0);
      const fallbackPowerAdd: Record<number, number> = {
        3.7: 0,
        7.4: 120,
        11: 280,
        22: 520,
        44: 980,
      };
      total += pAdd || fallbackPowerAdd[powerKw] || 0;
    }

    accessories.forEach((key) => {
      const opt = accessoriesOpts.find((a) => parseMeta(a.meta).key === key || a.title === key);
      const add = Number(parseMeta(opt?.meta || null).price || 0);
      const fallbackAcc: Record<string, number> = {
        cable_holder: 120,
        pedestal: 650,
        rfid: 90,
        '4g': 180,
        load_balancing: 320,
        smart_meter: 280,
      };
      total += add || fallbackAcc[key] || 0;
    });

    if (installMount === 'pedestal') total += 420;
    if (installPlace === 'outdoor') total += 150;

    const envFactor = Number(envMeta.factor || 1);
    total = Math.round(total * (envFactor || 1));

    let days = 1;
    if (selectedLine?.slug === 'pro' || powerKw === 44) days = 3;
    else if (selectedLine?.slug === 'edge' || installMount === 'pedestal') days = 2;
    else if (selectedLine?.slug === 'go') days = 0.5;
    if (accessories.includes('load_balancing') || accessories.includes('smart_meter')) days += 0.5;
    if (environment === 'fleet' || environment === 'public') days += 1;

    return { total, days };
  }, [
    selectedEnv,
    selectedLine,
    powerKw,
    accessories,
    installMount,
    installPlace,
    powers,
    accessoriesOpts,
    options,
    environment,
  ]);

  const canNext = useMemo(() => {
    if (step === 1) return !!environment;
    if (step === 2) return !!chargerSlug;
    if (step === 3) return powerKw != null;
    if (step === 4) return true;
    if (step === 5) return !!installPlace && !!installMount;
    return true;
  }, [step, environment, chargerSlug, powerKw, installPlace, installMount]);

  const goNext = () => {
    if (!canNext || step >= 6) return;
    setStep((s) => (s + 1) as StepId);
  };
  const goBack = () => {
    if (step <= 1) return;
    setStep((s) => (s - 1) as StepId);
  };

  const toggleAccessory = (key: string) => {
    setAccessories((prev) => (prev.includes(key) ? prev.filter((k) => k !== key) : [...prev, key]));
  };

  // Smart defaults when environment changes
  useEffect(() => {
    if (!selectedEnv) return;
    const meta = parseMeta(selectedEnv.meta);
    if (meta.default_charger && !chargerSlug) {
      const slug = meta.default_charger;
      if (lines.some((l) => l.slug === slug)) setChargerSlug(slug);
    }
    if (meta.default_power && powerKw == null) {
      setPowerKw(Number(meta.default_power));
    }
    if (meta.default_mount && !installMount) {
      setInstallMount(meta.default_mount as 'wall' | 'pedestal');
    }
    if (meta.default_place && !installPlace) {
      setInstallPlace(meta.default_place as 'indoor' | 'outdoor');
    }
  }, [selectedEnv?.id]); // eslint-disable-line react-hooks/exhaustive-deps

  // Clamp power when charger changes
  useEffect(() => {
    if (!selectedLine || powerKw == null) return;
    const ok = availablePowers.some((p) => Number(parseMeta(p.meta).kw || p.title) === powerKw);
    if (!ok) {
      const first = availablePowers[0];
      setPowerKw(first ? Number(parseMeta(first.meta).kw || first.title) : null);
    }
  }, [selectedLine?.slug]); // eslint-disable-line react-hooks/exhaustive-deps

  const submitQuote = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitError('');
    if (!email && !name) {
      setSubmitError('Please enter your name or email.');
      return;
    }
    setSubmitting(true);
    try {
      await apiPost('/api/leads', {
        type: 'configurator_quote',
        name,
        email,
        phone,
        company,
        subject: `Configurator · ${selectedLine?.name || chargerSlug} · ${powerKw} kW`,
        message:
          message ||
          `Environment: ${environment}; Charger: ${chargerSlug}; Power: ${powerKw} kW; Accessories: ${accessories.join(
            ', '
          ) || 'none'}; Install: ${installPlace}/${installMount}; Estimate: ${estimate.total} TND`,
        payload: {
          environment,
          charger: chargerSlug,
          power_kw: powerKw,
          accessories,
          installation: { place: installPlace, mount: installMount },
          estimated_price: estimate.total,
          install_days: estimate.days,
          recommended: selectedLine?.name,
        },
      });
      setSubmitted(true);
    } catch (err) {
      setSubmitError(err instanceof Error ? err.message : 'Submission failed');
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-kyn-black flex items-center justify-center">
        <LoadingState label="Loading configurator…" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-kyn-black flex items-center justify-center p-8">
        <ErrorState message={error} />
      </div>
    );
  }

  const accent = selectedLine?.accent || '#00e676';

  return (
    <div className="min-h-screen bg-kyn-black text-white">
      {/* Top bar */}
      <header className="sticky top-0 z-50 border-b border-white/5 bg-kyn-black/85 backdrop-blur-xl">
        <div className="max-w-7xl mx-auto px-4 md:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Link to="/">
              <BrandLogo height={28} />
            </Link>
            <span className="hidden sm:inline text-[10px] font-semibold tracking-[0.2em] uppercase text-kyn-green border border-kyn-green/30 rounded-full px-2 py-0.5">
              Configurator
            </span>
          </div>
          <nav className="hidden lg:flex items-center gap-6 text-xs text-kyn-silver">
            <Link to="/products" className="hover:text-white">
              Products
            </Link>
            <Link to="/cloud" className="hover:text-white">
              Cloud
            </Link>
            <Link to="/quote" className="hover:text-white">
              Quote
            </Link>
          </nav>
          <div className="flex items-center gap-2">
            <span className="hidden md:inline text-[11px] text-kyn-metal">
              Step {step} / {STEPS.length}
            </span>
            <button type="button" className="lg:hidden p-2 text-kyn-silver" onClick={() => setMenuOpen(!menuOpen)}>
              {menuOpen ? <X size={18} /> : <Menu size={18} />}
            </button>
          </div>
        </div>
        {menuOpen && (
          <div className="lg:hidden border-t border-white/5 px-4 py-3 space-y-2 bg-kyn-void">
            <Link to="/products" className="block text-sm text-kyn-silver" onClick={() => setMenuOpen(false)}>
              Products
            </Link>
            <Link to="/cloud" className="block text-sm text-kyn-silver" onClick={() => setMenuOpen(false)}>
              Cloud
            </Link>
          </div>
        )}
        {/* Progress */}
        <div className="h-1 bg-white/5">
          <motion.div
            className="h-full bg-gradient-to-r from-kyn-green-dim to-kyn-green"
            initial={false}
            animate={{ width: `${(step / STEPS.length) * 100}%` }}
            transition={{ duration: 0.4 }}
          />
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 md:px-8 py-8 md:py-12">
        {/* Step chips */}
        <div className="flex gap-2 overflow-x-auto pb-6 mb-2">
          {STEPS.map((s) => (
            <button
              key={s.id}
              type="button"
              onClick={() => {
                if (s.id < step) setStep(s.id);
              }}
              className={cn(
                'shrink-0 px-3 py-1.5 rounded-full text-[11px] font-semibold border transition-all',
                step === s.id
                  ? 'bg-kyn-green text-kyn-black border-kyn-green'
                  : step > s.id
                    ? 'border-kyn-green/40 text-kyn-green bg-kyn-green/10'
                    : 'border-white/10 text-kyn-metal'
              )}
            >
              {s.id}. {s.label}
            </button>
          ))}
        </div>

        <div className="grid lg:grid-cols-[1fr_380px] gap-8 items-start">
          {/* Main wizard */}
          <div className="min-w-0">
            <AnimatePresence mode="wait">
              <Fade key={step}>
                <p className="text-kyn-green text-xs font-semibold tracking-[0.25em] uppercase mb-2">
                  Step 0{step}
                </p>
                <h1 className="font-display text-3xl md:text-4xl font-bold mb-2">
                  {STEPS[step - 1].title}
                </h1>
                <p className="text-kyn-metal text-sm mb-8 max-w-xl">
                  Configure your KYNETIK system with live pricing and installation guidance.
                </p>

                {/* STEP 1 — Environment */}
                {step === 1 && (
                  <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
                    {envs.map((env) => {
                      const key = parseMeta(env.meta).key || env.title.toLowerCase();
                      const Icon = ENV_ICONS[key] || MapPin;
                      const active = environment === key;
                      return (
                        <button
                          key={env.id}
                          type="button"
                          onClick={() => setEnvironment(key)}
                          className={cn(
                            'text-left rounded-2xl border p-5 transition-all hover:-translate-y-0.5',
                            active
                              ? 'border-kyn-green/50 bg-kyn-green/10 glow-green'
                              : 'border-white/10 bg-white/[0.02] hover:border-white/25'
                          )}
                        >
                          <div
                            className={cn(
                              'w-11 h-11 rounded-xl border flex items-center justify-center mb-4',
                              active ? 'border-kyn-green/40 bg-kyn-green/15 text-kyn-green' : 'border-white/10 text-kyn-silver'
                            )}
                          >
                            <Icon size={20} />
                          </div>
                          <p className="font-display font-semibold text-lg">{env.title}</p>
                          <p className="text-xs text-kyn-metal mt-1.5 leading-relaxed">{env.body || env.subtitle}</p>
                        </button>
                      );
                    })}
                  </div>
                )}

                {/* STEP 2 — Charger */}
                {step === 2 && (
                  <div className="grid sm:grid-cols-2 gap-4">
                    {lines.map((line) => {
                      const recommended = recommendedSlugs.includes(line.slug);
                      const active = chargerSlug === line.slug;
                      return (
                        <motion.button
                          key={line.id}
                          type="button"
                          layout
                          onClick={() => setChargerSlug(line.slug)}
                          className={cn(
                            'relative text-left rounded-2xl border overflow-hidden transition-all group',
                            active ? 'border-kyn-green/50 bg-gradient-to-b from-kyn-green/10 to-transparent' : 'border-white/10 bg-kyn-void hover:border-white/25',
                            !recommended && environment ? 'opacity-70' : ''
                          )}
                        >
                          {recommended && environment && (
                            <span className="absolute top-3 right-3 z-10 text-[9px] font-bold uppercase tracking-wider px-2 py-1 rounded-full bg-kyn-green text-kyn-black">
                              Recommended
                            </span>
                          )}
                          <div className="h-40 flex items-center justify-center bg-[radial-gradient(circle_at_center,rgba(0,230,118,0.1),transparent_65%)] p-4">
                            <img
                              src={line.image_hero}
                              alt={line.name}
                              className="max-h-full w-auto object-contain transition-transform duration-500 group-hover:scale-105"
                            />
                          </div>
                          <div className="p-5 border-t border-white/5">
                            <div className="flex items-start justify-between gap-2">
                              <div>
                                <p className="font-display font-bold text-lg" style={{ color: line.accent }}>
                                  {line.name.replace('KYNETIK ', '')}
                                </p>
                                <p className="text-[11px] text-kyn-metal mt-0.5">{line.segment}</p>
                              </div>
                              {active && <CheckCircle2 size={18} className="text-kyn-green shrink-0" />}
                            </div>
                            <p className="text-sm text-kyn-silver mt-2 line-clamp-2">{line.tagline}</p>
                            <div className="mt-3 flex flex-wrap gap-1.5">
                              {parsePowers(line.powers).slice(0, 3).map((p) => (
                                <span key={p} className="text-[10px] px-2 py-0.5 rounded-md bg-white/5 border border-white/10 text-kyn-metal">
                                  {p} kW
                                </span>
                              ))}
                            </div>
                          </div>
                        </motion.button>
                      );
                    })}
                  </div>
                )}

                {/* STEP 3 — Power */}
                {step === 3 && (
                  <div className="space-y-4">
                    {!selectedLine && (
                      <p className="text-sm text-amber-300">Select a charger first to see compatible power levels.</p>
                    )}
                    <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
                      {(availablePowers.length ? availablePowers : powers).map((p) => {
                        const kw = Number(parseMeta(p.meta).kw || p.title.replace(/[^\d.]/g, ''));
                        const active = powerKw === kw;
                        const phase = parseMeta(p.meta).phase || p.subtitle;
                        return (
                          <button
                            key={p.id}
                            type="button"
                            onClick={() => setPowerKw(kw)}
                            className={cn(
                              'rounded-2xl border p-5 text-left transition-all',
                              active
                                ? 'border-kyn-green/50 bg-kyn-green/10 glow-green'
                                : 'border-white/10 bg-white/[0.02] hover:border-white/25'
                            )}
                          >
                            <p className="font-display text-3xl font-bold" style={{ color: active ? accent : '#fff' }}>
                              {kw}
                              <span className="text-base text-kyn-metal ml-1">kW</span>
                            </p>
                            <p className="text-xs text-kyn-metal mt-2">{phase || p.body}</p>
                            {p.body && <p className="text-[11px] text-kyn-silver mt-2 leading-relaxed">{p.subtitle || ''}</p>}
                          </button>
                        );
                      })}
                    </div>
                    {selectedLine && (
                      <p className="text-xs text-kyn-metal">
                        Showing powers compatible with <span className="text-kyn-green">{selectedLine.name}</span>
                      </p>
                    )}
                  </div>
                )}

                {/* STEP 4 — Accessories */}
                {step === 4 && (
                  <div className="grid sm:grid-cols-2 gap-3">
                    {accessoriesOpts.map((acc) => {
                      const key = parseMeta(acc.meta).key || acc.title.toLowerCase().replace(/\s+/g, '_');
                      const Icon = ACC_ICONS[key] || Sparkles;
                      const active = accessories.includes(key);
                      const price = Number(parseMeta(acc.meta).price || 0);
                      return (
                        <button
                          key={acc.id}
                          type="button"
                          onClick={() => toggleAccessory(key)}
                          className={cn(
                            'flex gap-4 items-start rounded-2xl border p-5 text-left transition-all',
                            active
                              ? 'border-kyn-green/50 bg-kyn-green/10'
                              : 'border-white/10 bg-white/[0.02] hover:border-white/25'
                          )}
                        >
                          <div
                            className={cn(
                              'w-10 h-10 rounded-xl border flex items-center justify-center shrink-0',
                              active ? 'border-kyn-green/40 text-kyn-green bg-kyn-green/15' : 'border-white/10 text-kyn-silver'
                            )}
                          >
                            <Icon size={18} />
                          </div>
                          <div className="min-w-0 flex-1">
                            <div className="flex items-center justify-between gap-2">
                              <p className="font-semibold">{acc.title}</p>
                              {active && <Check size={16} className="text-kyn-green" />}
                            </div>
                            <p className="text-xs text-kyn-metal mt-1 leading-relaxed">{acc.body || acc.subtitle}</p>
                            {price > 0 && (
                              <p className="text-[11px] text-kyn-green mt-2 font-medium">+ {formatTND(price)}</p>
                            )}
                          </div>
                        </button>
                      );
                    })}
                  </div>
                )}

                {/* STEP 5 — Installation */}
                {step === 5 && (
                  <div className="space-y-8">
                    <div>
                      <p className="text-xs uppercase tracking-widest text-kyn-metal mb-3">Location</p>
                      <div className="grid sm:grid-cols-2 gap-3">
                        {installOpts
                          .filter((o) => parseMeta(o.meta).group === 'place')
                          .map((o) => {
                            const key = parseMeta(o.meta).key as 'indoor' | 'outdoor';
                            const active = installPlace === key;
                            return (
                              <button
                                key={o.id}
                                type="button"
                                onClick={() => setInstallPlace(key)}
                                className={cn(
                                  'rounded-2xl border p-5 text-left transition-all',
                                  active ? 'border-kyn-green/50 bg-kyn-green/10' : 'border-white/10 bg-white/[0.02]'
                                )}
                              >
                                <p className="font-display font-semibold text-lg">{o.title}</p>
                                <p className="text-xs text-kyn-metal mt-1">{o.body}</p>
                              </button>
                            );
                          })}
                      </div>
                    </div>
                    <div>
                      <p className="text-xs uppercase tracking-widest text-kyn-metal mb-3">Mounting</p>
                      <div className="grid sm:grid-cols-2 gap-3">
                        {installOpts
                          .filter((o) => parseMeta(o.meta).group === 'mount')
                          .map((o) => {
                            const key = parseMeta(o.meta).key as 'wall' | 'pedestal';
                            const active = installMount === key;
                            const disabled = selectedLine?.slug === 'go' && key === 'pedestal';
                            return (
                              <button
                                key={o.id}
                                type="button"
                                disabled={disabled}
                                onClick={() => setInstallMount(key)}
                                className={cn(
                                  'rounded-2xl border p-5 text-left transition-all',
                                  disabled && 'opacity-40 cursor-not-allowed',
                                  active ? 'border-kyn-green/50 bg-kyn-green/10' : 'border-white/10 bg-white/[0.02]'
                                )}
                              >
                                <p className="font-display font-semibold text-lg">{o.title}</p>
                                <p className="text-xs text-kyn-metal mt-1">{o.body}</p>
                              </button>
                            );
                          })}
                      </div>
                    </div>
                  </div>
                )}

                {/* STEP 6 — Summary */}
                {step === 6 && (
                  <div className="space-y-6">
                    {submitted ? (
                      <div className="rounded-3xl border border-kyn-green/30 bg-kyn-green/10 p-8 text-center">
                        <CheckCircle2 className="mx-auto text-kyn-green mb-4" size={40} />
                        <h2 className="font-display text-2xl font-bold">Quotation request sent</h2>
                        <p className="text-kyn-silver mt-2 text-sm max-w-md mx-auto">
                          Our team will contact you shortly with a formal offer, datasheet and installation plan.
                        </p>
                        <div className="mt-6 flex flex-wrap justify-center gap-3">
                          <Link
                            to="/products"
                            className="px-5 py-2.5 rounded-full bg-kyn-green text-kyn-black text-xs font-bold"
                          >
                            Browse products
                          </Link>
                          <button
                            type="button"
                            onClick={() => {
                              setSubmitted(false);
                              setStep(1);
                              setEnvironment('');
                              setChargerSlug('');
                              setPowerKw(null);
                              setAccessories([]);
                              setInstallPlace('');
                              setInstallMount('');
                            }}
                            className="px-5 py-2.5 rounded-full border border-white/15 text-xs font-semibold"
                          >
                            New configuration
                          </button>
                        </div>
                      </div>
                    ) : (
                      <>
                        <div className="rounded-3xl border border-white/10 overflow-hidden bg-gradient-to-br from-kyn-charcoal to-kyn-black">
                          <div className="grid md:grid-cols-2">
                            <div className="relative min-h-[260px] flex items-center justify-center p-8">
                              <div
                                className="absolute inset-0"
                                style={{
                                  background: `radial-gradient(circle at center, ${accent}33, transparent 55%)`,
                                }}
                              />
                              {selectedLine && (
                                <motion.img
                                  key={selectedLine.slug + powerKw}
                                  initial={{ scale: 0.9, opacity: 0 }}
                                  animate={{ scale: 1, opacity: 1 }}
                                  src={selectedLine.image_hero}
                                  alt={selectedLine.name}
                                  className="relative z-10 max-h-[280px] w-auto object-contain"
                                />
                              )}
                            </div>
                            <div className="p-6 md:p-8 border-t md:border-t-0 md:border-l border-white/5">
                              <p className="text-xs uppercase tracking-widest text-kyn-metal">Recommended charger</p>
                              <h2 className="font-display text-2xl font-bold mt-1" style={{ color: accent }}>
                                {selectedLine?.name || '—'}
                              </h2>
                              <p className="text-sm text-kyn-silver mt-2">{selectedLine?.tagline}</p>

                              <div className="mt-6 space-y-2 text-sm">
                                {[
                                  ['Environment', environment || '—'],
                                  ['Power', powerKw != null ? `${powerKw} kW` : '—'],
                                  ['Accessories', accessories.length ? accessories.join(', ') : 'None'],
                                  ['Installation', `${installPlace || '—'} · ${installMount || '—'}`],
                                  ['Install time', `~ ${estimate.days} day${estimate.days > 1 ? 's' : ''}`],
                                ].map(([k, v]) => (
                                  <div key={k} className="flex justify-between gap-3 border-b border-white/5 py-2">
                                    <span className="text-kyn-metal">{k}</span>
                                    <span className="text-right font-medium capitalize">{v}</span>
                                  </div>
                                ))}
                              </div>

                              <div className="mt-6 flex items-end justify-between">
                                <div>
                                  <p className="text-[10px] uppercase tracking-wider text-kyn-metal">Price estimation</p>
                                  <p className="font-display text-3xl font-bold text-kyn-green text-glow">
                                    {formatTND(estimate.total)}
                                  </p>
                                  <p className="text-[11px] text-kyn-metal mt-1">Indicative · excl. site works</p>
                                </div>
                                <div className="flex flex-col gap-2">
                                  <Link
                                    to={selectedLine ? `/products/${selectedLine.slug}` : '/products'}
                                    className="inline-flex items-center gap-1.5 text-xs text-kyn-green font-semibold"
                                  >
                                    <FileText size={13} /> Technical sheet
                                  </Link>
                                  <a
                                    href="/products"
                                    className="inline-flex items-center gap-1.5 text-xs text-kyn-metal hover:text-white"
                                  >
                                    <Download size={13} /> Datasheet pack
                                  </a>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>

                        <form onSubmit={submitQuote} className="rounded-2xl border border-white/10 bg-kyn-void p-6 md:p-8 space-y-4">
                          <div className="flex items-center gap-2 mb-2">
                            <Wallet size={16} className="text-kyn-green" />
                            <h3 className="font-display font-semibold text-lg">Request quotation</h3>
                          </div>
                          <div className="grid sm:grid-cols-2 gap-3">
                            <input
                              className="rounded-xl bg-black/40 border border-white/10 px-4 py-3 text-sm outline-none focus:border-kyn-green/50"
                              placeholder="Full name"
                              value={name}
                              onChange={(e) => setName(e.target.value)}
                            />
                            <input
                              type="email"
                              className="rounded-xl bg-black/40 border border-white/10 px-4 py-3 text-sm outline-none focus:border-kyn-green/50"
                              placeholder="Email"
                              value={email}
                              onChange={(e) => setEmail(e.target.value)}
                            />
                            <input
                              className="rounded-xl bg-black/40 border border-white/10 px-4 py-3 text-sm outline-none focus:border-kyn-green/50"
                              placeholder="Phone"
                              value={phone}
                              onChange={(e) => setPhone(e.target.value)}
                            />
                            <input
                              className="rounded-xl bg-black/40 border border-white/10 px-4 py-3 text-sm outline-none focus:border-kyn-green/50"
                              placeholder="Company (optional)"
                              value={company}
                              onChange={(e) => setCompany(e.target.value)}
                            />
                          </div>
                          <textarea
                            className="w-full rounded-xl bg-black/40 border border-white/10 px-4 py-3 text-sm outline-none focus:border-kyn-green/50 min-h-[90px]"
                            placeholder="Project notes, site address, timeline…"
                            value={message}
                            onChange={(e) => setMessage(e.target.value)}
                          />
                          {submitError && <p className="text-sm text-red-400">{submitError}</p>}
                          <button
                            type="submit"
                            disabled={submitting}
                            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-8 py-3.5 rounded-full bg-kyn-green text-kyn-black text-sm font-bold glow-green disabled:opacity-60"
                          >
                            {submitting ? (
                              <>
                                <Loader2 size={16} className="animate-spin" /> Sending…
                              </>
                            ) : (
                              <>
                                Request quotation <ArrowRight size={16} />
                              </>
                            )}
                          </button>
                        </form>
                      </>
                    )}
                  </div>
                )}

                {/* Nav buttons */}
                {step < 6 && (
                  <div className="mt-10 flex items-center justify-between gap-3">
                    <button
                      type="button"
                      onClick={goBack}
                      disabled={step === 1}
                      className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full border border-white/15 text-sm font-medium disabled:opacity-30"
                    >
                      <ArrowLeft size={16} /> Back
                    </button>
                    <button
                      type="button"
                      onClick={goNext}
                      disabled={!canNext}
                      className="inline-flex items-center gap-2 px-6 py-2.5 rounded-full bg-kyn-green text-kyn-black text-sm font-bold disabled:opacity-40 glow-green"
                    >
                      Continue <ArrowRight size={16} />
                    </button>
                  </div>
                )}
                {step === 6 && !submitted && (
                  <div className="mt-6">
                    <button
                      type="button"
                      onClick={goBack}
                      className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full border border-white/15 text-sm font-medium"
                    >
                      <ArrowLeft size={16} /> Edit configuration
                    </button>
                  </div>
                )}
              </Fade>
            </AnimatePresence>
          </div>

          {/* Live preview rail */}
          <aside className="lg:sticky lg:top-24 space-y-4">
            <div className="rounded-3xl border border-white/10 bg-gradient-to-b from-kyn-charcoal to-kyn-black overflow-hidden poster-shadow">
              <div className="px-5 py-3 border-b border-white/5 flex items-center justify-between">
                <span className="text-[11px] font-semibold text-kyn-silver">Live preview</span>
                <span className="text-[10px] text-kyn-green flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-kyn-green animate-pulse" /> Real-time
                </span>
              </div>
              <div className="relative h-64 flex items-center justify-center p-6">
                <div
                  className="absolute inset-0 opacity-80"
                  style={{
                    background: `radial-gradient(circle at 50% 45%, ${accent}28, transparent 55%)`,
                  }}
                />
                <div className="absolute inset-0 grid-bg opacity-30" />
                <AnimatePresence mode="wait">
                  <motion.img
                    key={selectedLine?.image_hero || 'empty'}
                    src={selectedLine?.image_hero || '/images/products/nova-socket.png'}
                    alt={selectedLine?.name || 'Charger preview'}
                    initial={{ opacity: 0, scale: 0.88, y: 12 }}
                    animate={{ opacity: selectedLine ? 1 : 0.25, scale: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.92 }}
                    transition={{ duration: 0.4 }}
                    className="relative z-10 max-h-full w-auto object-contain drop-shadow-[0_20px_50px_rgba(0,230,118,0.2)]"
                  />
                </AnimatePresence>
                {!selectedLine && (
                  <p className="absolute bottom-4 text-[10px] text-kyn-metal tracking-wider uppercase">
                    Select a charger
                  </p>
                )}
              </div>
              <div className="p-5 border-t border-white/5 space-y-3">
                <div>
                  <p className="text-[10px] uppercase tracking-wider text-kyn-metal">Configuration</p>
                  <p className="font-display font-bold text-lg mt-0.5">
                    {selectedLine?.name.replace('KYNETIK ', '') || '—'}
                    {powerKw != null && (
                      <span className="text-kyn-green"> · {powerKw} kW</span>
                    )}
                  </p>
                  <p className="text-xs text-kyn-metal capitalize mt-1">
                    {[environment, installPlace, installMount].filter(Boolean).join(' · ') || 'Build your system'}
                  </p>
                </div>

                {accessories.length > 0 && (
                  <div className="flex flex-wrap gap-1.5">
                    {accessories.map((a) => (
                      <span key={a} className="text-[9px] px-2 py-1 rounded-md bg-kyn-green/10 text-kyn-green border border-kyn-green/20 capitalize">
                        {a.replace(/_/g, ' ')}
                      </span>
                    ))}
                  </div>
                )}

                <div className="grid grid-cols-2 gap-2 pt-2">
                  <div className="rounded-xl bg-black/40 border border-white/8 p-3">
                    <p className="text-[9px] text-kyn-metal uppercase">Estimate</p>
                    <p className="font-display font-bold text-kyn-green text-lg">{formatTND(estimate.total)}</p>
                  </div>
                  <div className="rounded-xl bg-black/40 border border-white/8 p-3">
                    <p className="text-[9px] text-kyn-metal uppercase flex items-center gap-1">
                      <Timer size={10} /> Install
                    </p>
                    <p className="font-display font-bold text-lg">~{estimate.days}d</p>
                  </div>
                </div>

                <div className="flex items-center gap-2 text-[10px] text-kyn-metal pt-1">
                  <Shield size={12} className="text-kyn-green" /> Certified installers · KYNETIK Academy
                </div>
              </div>
            </div>

            <div className="rounded-2xl border border-white/8 bg-kyn-void p-4 space-y-3">
              {[
                { icon: Cloud, t: 'Cloud ready', d: 'OCPP supervision included on wall/pedestal lines' },
                { icon: Smartphone, t: 'App control', d: 'Start, stop, history & wallet' },
                { icon: Sparkles, t: 'Smart match', d: 'Recommendations adapt to your environment' },
              ].map(({ icon: Icon, t, d }) => (
                <div key={t} className="flex gap-3">
                  <div className="w-8 h-8 rounded-lg bg-kyn-green/10 border border-kyn-green/20 flex items-center justify-center text-kyn-green shrink-0">
                    <Icon size={14} />
                  </div>
                  <div>
                    <p className="text-xs font-semibold">{t}</p>
                    <p className="text-[11px] text-kyn-metal">{d}</p>
                  </div>
                </div>
              ))}
            </div>

            <Link
              to="/product-system"
              className="flex items-center justify-between rounded-2xl border border-white/8 bg-white/[0.02] px-4 py-3 text-sm hover:border-kyn-green/30 transition-colors"
            >
              <span className="text-kyn-silver">Explore full product system</span>
              <ChevronRight size={16} className="text-kyn-green" />
            </Link>
          </aside>
        </div>
      </div>
    </div>
  );
}

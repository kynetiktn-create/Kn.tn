import { useEffect, useState, type ComponentType, type ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { motion, useScroll, useTransform } from 'framer-motion';
import {
  ArrowRight, Cloud, Shield, Lock, Server, Cpu, Smartphone, Globe2,
  Building2, Hotel, Car, Landmark, Home, Zap, Activity, BarChart3,
  Webhook, KeyRound, Layers, CheckCircle2, Quote, Menu, X,
  Gauge, BellRing, Route, Wallet, Leaf, Network
} from 'lucide-react';
import BrandLogo from '../components/BrandLogo';
import AppDownloadCTA from '../components/AppDownloadCTA';
import LiveDashboard from '../components/cloud/LiveDashboard';
import LoadingState from '../components/LoadingState';
import { apiGet, cn } from '../lib/utils';

interface LandingItem {
  id: number;
  type: string;
  title: string;
  subtitle: string;
  body: string;
  meta: string | null;
  icon: string | null;
  sort_order: number;
}

interface Metric {
  id: number;
  label: string;
  value: string;
  delta: string;
}

const iconMap: Record<string, ComponentType<{ size?: number; className?: string }>> = {
  zap: Zap,
  activity: Activity,
  chart: BarChart3,
  shield: Shield,
  lock: Lock,
  server: Server,
  cpu: Cpu,
  phone: Smartphone,
  globe: Globe2,
  network: Network,
  gauge: Gauge,
  bell: BellRing,
  route: Route,
  wallet: Wallet,
  leaf: Leaf,
  webhook: Webhook,
  key: KeyRound,
  layers: Layers,
  cloud: Cloud,
};

function FadeIn({ children, className, delay = 0 }: { children: ReactNode; className?: string; delay?: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 28 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-60px' }}
      transition={{ duration: 0.6, delay, ease: [0.22, 1, 0.36, 1] }}
      className={className}
    >
      {children}
    </motion.div>
  );
}

export default function CloudLanding() {
  const [items, setItems] = useState<LandingItem[]>([]);
  const [metrics, setMetrics] = useState<Metric[]>([]);
  const [loading, setLoading] = useState(true);
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const { scrollY } = useScroll();
  const heroOpacity = useTransform(scrollY, [0, 400], [1, 0.3]);
  const heroY = useTransform(scrollY, [0, 400], [0, 80]);

  useEffect(() => {
    Promise.all([
      apiGet<LandingItem[]>('/api/cloud-landing'),
      apiGet<Metric[]>('/api/cloud-metrics'),
    ])
      .then(([landing, m]) => {
        setItems(landing);
        setMetrics(m);
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const byType = (t: string) => items.filter((i) => i.type === t).sort((a, b) => a.sort_order - b.sort_order);
  const features = byType('feature');
  const industries = byType('industry');
  const security = byType('security');
  const integrations = byType('integration');
  const benefits = byType('benefit');
  const testimonials = byType('testimonial');
  const overview = byType('overview')[0];

  const navLinks = [
    { href: '#platform', label: 'Platform' },
    { href: '#dashboard', label: 'Dashboard' },
    { href: '#features', label: 'Features' },
    { href: '#security', label: 'Security' },
    { href: '#api', label: 'API' },
    { href: '#contact', label: 'Contact' },
  ];

  if (loading) {
    return (
      <div className="min-h-screen bg-kyn-black flex items-center justify-center">
        <LoadingState label="Loading KYNETIK Cloud…" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-kyn-black text-white overflow-x-hidden">
      {/* Nav */}
      <header
        className={cn(
          'fixed top-0 inset-x-0 z-50 transition-all duration-300',
          scrolled ? 'bg-kyn-black/80 backdrop-blur-xl border-b border-white/5' : 'bg-transparent'
        )}
      >
        <div className="max-w-7xl mx-auto px-5 md:px-8 h-16 md:h-20 flex items-center justify-between">
          <a href="#top" className="flex items-center gap-3">
            <BrandLogo height={32} />
            <span className="hidden sm:inline text-[10px] font-semibold tracking-[0.25em] uppercase text-kyn-green border border-kyn-green/30 rounded-full px-2 py-0.5">
              Cloud
            </span>
          </a>

          <nav className="hidden lg:flex items-center gap-8">
            {navLinks.map((l) => (
              <a key={l.href} href={l.href} className="text-xs font-medium text-kyn-silver hover:text-white transition-colors">
                {l.label}
              </a>
            ))}
          </nav>

          <div className="flex items-center gap-3">
            <Link to="/cloud" className="hidden md:inline text-xs text-kyn-metal hover:text-white">
              Console UX
            </Link>
            <a
              href="#contact"
              className="hidden sm:inline-flex items-center gap-2 px-4 py-2 rounded-full bg-kyn-green text-kyn-black text-xs font-bold hover:bg-kyn-green-glow transition-colors"
            >
              Request demo <ArrowRight size={13} />
            </a>
            <button type="button" className="lg:hidden p-2 text-kyn-silver" onClick={() => setMenuOpen(!menuOpen)} aria-label="Menu">
              {menuOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </div>

        {menuOpen && (
          <div className="lg:hidden border-t border-white/5 bg-kyn-void/95 backdrop-blur-xl px-5 py-4 space-y-2">
            {navLinks.map((l) => (
              <a key={l.href} href={l.href} onClick={() => setMenuOpen(false)} className="block py-2 text-sm text-kyn-silver">
                {l.label}
              </a>
            ))}
            <a href="#contact" onClick={() => setMenuOpen(false)} className="block mt-2 text-center rounded-full bg-kyn-green text-kyn-black text-xs font-bold py-3">
              Request demo
            </a>
          </div>
        )}
      </header>

      {/* 1. HERO */}
      <section id="top" className="relative min-h-screen flex items-center pt-20">
        <div className="absolute inset-0">
          <img src="/images/cloud-datacenter.jpg" alt="" className="w-full h-full object-cover opacity-35" />
          <div className="absolute inset-0 bg-gradient-to-b from-kyn-black via-kyn-black/85 to-kyn-black" />
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(0,230,118,0.12),transparent_55%)]" />
          <div className="absolute inset-0 grid-bg opacity-40" />
        </div>

        <motion.div style={{ opacity: heroOpacity, y: heroY }} className="relative z-10 max-w-7xl mx-auto px-5 md:px-8 py-20 w-full">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
            <div>
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.7 }}
              >
                <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-kyn-green/30 bg-kyn-green/10 text-kyn-green text-[11px] font-semibold mb-7">
                  <Cloud size={13} /> Intelligent EV Charging OS
                </div>
                <h1 className="font-display text-4xl sm:text-5xl md:text-6xl lg:text-[3.75rem] font-bold leading-[1.05] tracking-tight">
                  Orchestrate every
                  <br />
                  <span className="text-kyn-green text-glow">kilowatt</span> in the cloud
                </h1>
                <p className="mt-6 text-base md:text-lg text-kyn-silver max-w-xl leading-relaxed">
                  KYNETIK Cloud is the enterprise platform that connects chargers, drivers, energy and billing —
                  with Tesla-grade reliability and ABB-class industrial control.
                </p>
                <div className="mt-9 flex flex-wrap gap-3">
                  <a href="#contact" className="inline-flex items-center gap-2 px-6 py-3.5 rounded-full bg-kyn-green text-kyn-black text-sm font-bold glow-green hover:bg-kyn-green-glow transition-colors">
                    Book a live demo <ArrowRight size={16} />
                  </a>
                  <a href="#dashboard" className="inline-flex items-center gap-2 px-6 py-3.5 rounded-full border border-white/15 text-sm font-medium hover:border-kyn-green/40 hover:bg-white/5 transition-colors">
                    See the dashboard
                  </a>
                </div>
                <div className="mt-12 flex flex-wrap gap-8">
                  {[
                    { v: '99.95%', l: 'Platform SLA' },
                    { v: 'OCPP', l: '1.6J & 2.0.1' },
                    { v: '<800ms', l: 'Command latency' },
                  ].map((s) => (
                    <div key={s.l}>
                      <p className="font-display text-2xl font-bold text-white">{s.v}</p>
                      <p className="text-[11px] text-kyn-metal mt-0.5 uppercase tracking-wider">{s.l}</p>
                    </div>
                  ))}
                </div>
              </motion.div>
            </div>

            <motion.div
              initial={{ opacity: 0, scale: 0.96, y: 24 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.15 }}
              className="relative"
            >
              <div className="absolute -inset-4 bg-kyn-green/10 blur-3xl rounded-full" />
              <LiveDashboard metrics={metrics.map((m) => ({ label: m.label, value: m.value, delta: m.delta }))} />
            </motion.div>
          </div>
        </motion.div>

        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-kyn-metal">
          <span className="text-[10px] tracking-[0.3em] uppercase">Scroll</span>
          <div className="w-px h-10 bg-gradient-to-b from-kyn-green to-transparent" />
        </div>
      </section>

      {/* 2. PLATFORM OVERVIEW */}
      <section id="platform" className="relative py-24 md:py-32 border-t border-white/5">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <FadeIn>
            <p className="text-kyn-green text-xs font-semibold tracking-[0.3em] uppercase mb-4">Platform overview</p>
            <h2 className="font-display text-3xl md:text-5xl font-bold max-w-3xl leading-tight">
              {overview?.title || 'One cloud. Every charger. Total control.'}
            </h2>
            <p className="mt-5 text-kyn-silver text-lg max-w-2xl leading-relaxed">
              {overview?.body ||
                'From a single NOVA wallbox to national DC corridors — KYNETIK Cloud unifies hardware, sessions, energy tariffs and operator workflows.'}
            </p>
          </FadeIn>

          <div className="mt-14 grid md:grid-cols-3 gap-4">
            {[
              { t: 'Operate', d: 'Remote start/stop, firmware OTA, multi-tenant sites and 24/7 monitoring.', i: Server },
              { t: 'Optimize', d: 'Smart load balancing, peak shaving, solar-aware charging schedules.', i: Gauge },
              { t: 'Monetize', d: 'Roaming-ready billing, wallets, invoices and fleet cost centers.', i: Wallet },
            ].map(({ t, d, i: Icon }, idx) => (
              <FadeIn key={t} delay={idx * 0.08}>
                <div className="h-full rounded-2xl border border-white/8 bg-gradient-to-b from-white/[0.04] to-transparent p-7 hover:border-kyn-green/25 transition-colors">
                  <div className="w-11 h-11 rounded-xl bg-kyn-green/10 border border-kyn-green/20 flex items-center justify-center text-kyn-green mb-5">
                    <Icon size={20} />
                  </div>
                  <h3 className="font-display text-xl font-semibold">{t}</h3>
                  <p className="mt-3 text-sm text-kyn-metal leading-relaxed">{d}</p>
                </div>
              </FadeIn>
            ))}
          </div>
        </div>
      </section>

      {/* 3. CONNECTED ECOSYSTEM */}
      <section className="relative py-24 md:py-28 bg-kyn-void border-y border-white/5 overflow-hidden">
        <div className="absolute inset-0 opacity-30">
          <img src="/images/tech-abstract.jpg" alt="" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-kyn-void/80" />
        </div>
        <div className="relative z-10 max-w-7xl mx-auto px-5 md:px-8">
          <FadeIn className="text-center max-w-2xl mx-auto mb-14">
            <p className="text-kyn-green text-xs font-semibold tracking-[0.3em] uppercase mb-4">Connected ecosystem</p>
            <h2 className="font-display text-3xl md:text-4xl font-bold">Hardware, cloud and apps — one nervous system</h2>
          </FadeIn>

          <FadeIn>
            <div className="relative rounded-3xl border border-kyn-green/20 bg-black/50 backdrop-blur-xl p-8 md:p-12">
              <div className="absolute top-1/2 left-[10%] right-[10%] h-px bg-gradient-to-r from-transparent via-kyn-green/50 to-transparent hidden md:block" />
              <div className="grid grid-cols-2 md:grid-cols-5 gap-6 md:gap-4 relative">
                {[
                  { l: 'Vehicle', s: 'SoC · Session', icon: Car },
                  { l: 'Charger', s: 'NOVA · PRIME · PRO', icon: Zap },
                  { l: 'KYNETIK Cloud', s: 'OCPP · Orchestration', icon: Cloud, highlight: true },
                  { l: 'Mobile App', s: 'Driver experience', icon: Smartphone },
                  { l: 'Enterprise', s: 'Fleet · Billing · API', icon: Building2 },
                ].map(({ l, s, icon: Icon, highlight }) => (
                  <div key={l} className="flex flex-col items-center text-center">
                    <div
                      className={cn(
                        'w-16 h-16 md:w-20 md:h-20 rounded-2xl border flex items-center justify-center mb-3 transition-shadow',
                        highlight
                          ? 'bg-kyn-green/15 border-kyn-green/50 text-kyn-green glow-green'
                          : 'bg-white/[0.03] border-white/10 text-kyn-silver'
                      )}
                    >
                      <Icon size={highlight ? 28 : 22} />
                    </div>
                    <p className={cn('font-display font-semibold text-sm', highlight && 'text-kyn-green')}>{l}</p>
                    <p className="text-[10px] text-kyn-metal mt-1">{s}</p>
                  </div>
                ))}
              </div>
              <p className="mt-10 text-center text-sm text-kyn-metal max-w-xl mx-auto">
                Bidirectional data plane · secure command channel · real-time telemetry · open APIs for partners
              </p>
            </div>
          </FadeIn>
        </div>
      </section>

      {/* 4. LIVE DASHBOARD PREVIEW */}
      <section id="dashboard" className="py-24 md:py-32">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <FadeIn>
              <p className="text-kyn-green text-xs font-semibold tracking-[0.3em] uppercase mb-4">Live dashboard</p>
              <h2 className="font-display text-3xl md:text-4xl font-bold leading-tight">
                Command your network like a grid operator
              </h2>
              <p className="mt-5 text-kyn-silver leading-relaxed">
                A cinematic operations console built for NOCs and field teams — sessions, faults, energy curves and
                station health in one glass interface.
              </p>
              <ul className="mt-8 space-y-3">
                {[
                  'Multi-site hierarchy & role-based access',
                  'Live session table with remote interventions',
                  'Energy, revenue and uptime KPIs',
                  'Alerting with severity routing',
                ].map((item) => (
                  <li key={item} className="flex items-start gap-3 text-sm text-kyn-silver">
                    <CheckCircle2 size={16} className="text-kyn-green mt-0.5 shrink-0" />
                    {item}
                  </li>
                ))}
              </ul>
            </FadeIn>
            <FadeIn delay={0.1}>
              <LiveDashboard metrics={metrics.map((m) => ({ label: m.label, value: m.value, delta: m.delta }))} />
            </FadeIn>
          </div>
        </div>
      </section>

      {/* 5. SMART FEATURES */}
      <section id="features" className="py-24 md:py-28 bg-kyn-void border-y border-white/5">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <FadeIn className="mb-14">
            <p className="text-kyn-green text-xs font-semibold tracking-[0.3em] uppercase mb-4">Smart features</p>
            <h2 className="font-display text-3xl md:text-4xl font-bold">Everything an EV network needs</h2>
          </FadeIn>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {features.map((f, i) => {
              const Icon = iconMap[f.icon || 'zap'] || Zap;
              return (
                <FadeIn key={f.id} delay={i * 0.05}>
                  <div className="group h-full rounded-2xl border border-white/8 bg-black/30 p-6 hover:border-kyn-green/30 hover:bg-kyn-green/[0.03] transition-all">
                    <div className="w-10 h-10 rounded-xl bg-kyn-green/10 border border-kyn-green/20 flex items-center justify-center text-kyn-green mb-4 group-hover:glow-green transition-shadow">
                      <Icon size={18} />
                    </div>
                    <h3 className="font-display font-semibold text-lg">{f.title}</h3>
                    <p className="mt-2 text-sm text-kyn-metal leading-relaxed">{f.body}</p>
                  </div>
                </FadeIn>
              );
            })}
          </div>
        </div>
      </section>

      {/* 6. MOBILE APP SHOWCASE */}
      <section className="py-24 md:py-32 relative overflow-hidden">
        <div className="absolute right-0 top-0 w-1/2 h-full opacity-20 pointer-events-none hidden lg:block">
          <img src="/images/ev-network.jpg" alt="" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-l from-transparent to-kyn-black" />
        </div>
        <div className="max-w-7xl mx-auto px-5 md:px-8 relative z-10">
          <div className="grid lg:grid-cols-2 gap-14 items-center">
            <FadeIn>
              <p className="text-kyn-green text-xs font-semibold tracking-[0.3em] uppercase mb-4">Mobile experience</p>
              <h2 className="font-display text-3xl md:text-4xl font-bold">Drivers and operators, same ecosystem</h2>
              <p className="mt-5 text-kyn-silver leading-relaxed max-w-lg">
                The KYNETIK app mirrors Cloud intelligence — live charging rings, station maps, wallets and analytics
                with the identical dark premium language.
              </p>
              <div className="mt-8 grid grid-cols-2 gap-3">
                {['Start / stop charge', 'Find DC & AC', 'Wallet & invoices', 'Energy insights'].map((t) => (
                  <div key={t} className="rounded-xl border border-white/8 bg-white/[0.03] px-4 py-3 text-sm text-kyn-silver flex items-center gap-2">
                    <CheckCircle2 size={14} className="text-kyn-green shrink-0" /> {t}
                  </div>
                ))}
              </div>
              <Link to="/app" className="mt-8 inline-flex items-center gap-2 text-sm font-semibold text-kyn-green hover:gap-3 transition-all">
                Explore full app UX <ArrowRight size={15} />
              </Link>
            </FadeIn>

            <FadeIn delay={0.1} className="flex justify-center gap-4 md:gap-6">
              {/* Mini phone mockups */}
              {[
                { title: '75%', sub: 'Charging', accent: true },
                { title: 'Map', sub: 'Stations near you', accent: false },
              ].map((p, idx) => (
                <div
                  key={p.title}
                  className={cn(
                    'phone-frame w-[150px] sm:w-[180px] h-[310px] sm:h-[370px] rounded-[2rem] p-2',
                    idx === 1 && 'mt-10'
                  )}
                >
                  <div className="w-full h-full rounded-[1.6rem] bg-kyn-void border border-white/5 overflow-hidden relative flex flex-col items-center justify-center p-4">
                    <div className="absolute inset-0 grid-bg opacity-50" />
                    {p.accent ? (
                      <div className="relative w-24 h-24 rounded-full flex items-center justify-center" style={{
                        background: 'conic-gradient(from 200deg, #00e676 0%, #00e676 75%, #2a2a30 75%)',
                      }}>
                        <div className="w-[78%] h-[78%] rounded-full bg-kyn-void flex flex-col items-center justify-center">
                          <span className="font-display text-2xl font-bold text-kyn-green">75%</span>
                        </div>
                      </div>
                    ) : (
                      <div className="relative w-full h-full flex flex-col">
                        <div className="flex-1 relative">
                          {[30, 50, 45].map((t, i) => (
                            <div key={i} className="absolute w-6 h-6 rounded-full border-2 border-kyn-green bg-kyn-green/20 flex items-center justify-center" style={{ top: `${20 + i * 22}%`, left: `${25 + i * 18}%` }}>
                              <Zap size={10} className="text-kyn-green" />
                            </div>
                          ))}
                        </div>
                        <div className="rounded-xl bg-black/60 border border-white/10 p-2.5">
                          <p className="text-[10px] font-semibold">Hub Lac 2</p>
                          <p className="text-[8px] text-kyn-metal">1.2 km · Available</p>
                        </div>
                      </div>
                    )}
                    <p className="relative mt-4 text-[10px] text-kyn-metal">{p.sub}</p>
                  </div>
                </div>
              ))}
            </FadeIn>
          </div>
        </div>
      </section>

      {/* 7. INDUSTRIES */}
      <section className="py-24 md:py-28 bg-kyn-void border-y border-white/5">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <FadeIn className="text-center mb-14">
            <p className="text-kyn-green text-xs font-semibold tracking-[0.3em] uppercase mb-4">Industries served</p>
            <h2 className="font-display text-3xl md:text-4xl font-bold">Built for every charging context</h2>
          </FadeIn>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
            {(industries.length
              ? industries
              : [
                  { id: 1, title: 'Residential', body: 'Homes & residences', icon: 'home' },
                  { id: 2, title: 'Corporate', body: 'Workplaces', icon: 'building' },
                  { id: 3, title: 'Hospitality', body: 'Hotels & venues', icon: 'hotel' },
                  { id: 4, title: 'Public', body: 'Cities & municipalities', icon: 'landmark' },
                  { id: 5, title: 'Fleets', body: 'Depots & logistics', icon: 'car' },
                  { id: 6, title: 'Retail', body: 'Malls & destinations', icon: 'globe' },
                ] as LandingItem[]
            ).map((ind, i) => {
              const industryIcons: Record<string, ComponentType<{ size?: number; className?: string }>> = {
                home: Home, building: Building2, hotel: Hotel, landmark: Landmark, car: Car, globe: Globe2,
              };
              const Icon = industryIcons[ind.icon || ''] || Building2;
              return (
                <FadeIn key={ind.id || ind.title} delay={i * 0.04}>
                  <div className="rounded-2xl border border-white/8 bg-black/40 p-5 text-center h-full hover:border-kyn-green/30 transition-colors">
                    <div className="w-10 h-10 mx-auto rounded-xl bg-kyn-green/10 border border-kyn-green/20 flex items-center justify-center text-kyn-green mb-3">
                      <Icon size={18} />
                    </div>
                    <p className="font-display font-semibold text-sm">{ind.title}</p>
                    <p className="text-[11px] text-kyn-metal mt-1">{ind.body}</p>
                  </div>
                </FadeIn>
              );
            })}
          </div>
        </div>
      </section>

      {/* 8. SECURITY */}
      <section id="security" className="py-24 md:py-32">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-start">
            <FadeIn>
              <p className="text-kyn-green text-xs font-semibold tracking-[0.3em] uppercase mb-4">Security & reliability</p>
              <h2 className="font-display text-3xl md:text-4xl font-bold leading-tight">
                Enterprise trust, by design
              </h2>
              <p className="mt-5 text-kyn-silver leading-relaxed">
                Inspired by Siemens Grid Software and ABB Ability™ — defense-in-depth security with operational resilience for critical energy infrastructure.
              </p>
              <div className="mt-8 grid grid-cols-2 gap-4">
                {[
                  { v: '99.95%', l: 'Uptime SLA' },
                  { v: 'TLS 1.3', l: 'In transit' },
                  { v: 'RBAC', l: 'Access control' },
                  { v: '24/7', l: 'Monitoring' },
                ].map((s) => (
                  <div key={s.l} className="rounded-2xl border border-white/8 bg-white/[0.02] p-5">
                    <p className="font-display text-2xl font-bold text-kyn-green">{s.v}</p>
                    <p className="text-xs text-kyn-metal mt-1">{s.l}</p>
                  </div>
                ))}
              </div>
            </FadeIn>
            <div className="space-y-3">
              {security.map((s, i) => {
                const Icon = iconMap[s.icon || 'shield'] || Shield;
                return (
                  <FadeIn key={s.id} delay={i * 0.06}>
                    <div className="flex gap-4 rounded-2xl border border-white/8 bg-kyn-void/80 p-5">
                      <div className="w-10 h-10 rounded-xl bg-kyn-green/10 border border-kyn-green/20 flex items-center justify-center text-kyn-green shrink-0">
                        <Icon size={18} />
                      </div>
                      <div>
                        <h3 className="font-semibold">{s.title}</h3>
                        <p className="text-sm text-kyn-metal mt-1 leading-relaxed">{s.body}</p>
                      </div>
                    </div>
                  </FadeIn>
                );
              })}
            </div>
          </div>
        </div>
      </section>

      {/* 9. API & INTEGRATIONS */}
      <section id="api" className="py-24 md:py-28 bg-kyn-void border-y border-white/5">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <FadeIn>
              <p className="text-kyn-green text-xs font-semibold tracking-[0.3em] uppercase mb-4">API & integrations</p>
              <h2 className="font-display text-3xl md:text-4xl font-bold">Open platform. Partner-ready.</h2>
              <p className="mt-5 text-kyn-silver leading-relaxed">
                REST APIs, webhooks and OCPP-native connectivity — integrate ERP, TMS, roaming hubs and energy utilities without friction.
              </p>
              <div className="mt-8 space-y-3">
                {integrations.map((item) => {
                  const Icon = iconMap[item.icon || 'webhook'] || Webhook;
                  return (
                    <div key={item.id} className="flex items-center gap-3 text-sm text-kyn-silver">
                      <div className="w-8 h-8 rounded-lg bg-kyn-green/10 border border-kyn-green/20 flex items-center justify-center">
                        <Icon size={14} className="text-kyn-green" />
                      </div>
                      <div>
                        <p className="font-medium text-white">{item.title}</p>
                        <p className="text-xs text-kyn-metal">{item.body}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </FadeIn>

            <FadeIn delay={0.1}>
              <div className="rounded-2xl border border-white/10 bg-[#0c0e12] overflow-hidden font-mono text-[11px] md:text-xs shadow-2xl">
                <div className="flex items-center gap-2 px-4 py-3 border-b border-white/5 bg-white/[0.02]">
                  <span className="w-2.5 h-2.5 rounded-full bg-red-500/70" />
                  <span className="w-2.5 h-2.5 rounded-full bg-yellow-500/70" />
                  <span className="w-2.5 h-2.5 rounded-full bg-green-500/70" />
                  <span className="ml-2 text-kyn-metal">POST /v1/sessions/remote-start</span>
                </div>
                <pre className="p-5 text-kyn-silver leading-relaxed overflow-x-auto">
{`{
  "station_id": "TN-LAC2-PRIME-01",
  "connector_id": 2,
  "id_tag": "USR-KHALIFA",
  "profile": {
    "max_kw": 120,
    "smart_charging": true
  }
}

// → 200 OK
{
  "session_id": "K-88421",
  "status": "Accepted",
  "latency_ms": 612
}`}
                </pre>
              </div>
            </FadeIn>
          </div>
        </div>
      </section>

      {/* 10. BUSINESS BENEFITS */}
      <section className="py-24 md:py-32">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <FadeIn className="mb-14 max-w-2xl">
            <p className="text-kyn-green text-xs font-semibold tracking-[0.3em] uppercase mb-4">Business benefits</p>
            <h2 className="font-display text-3xl md:text-4xl font-bold">Outcomes investors and operators care about</h2>
          </FadeIn>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
            {benefits.map((b, i) => (
              <FadeIn key={b.id} delay={i * 0.05}>
                <div className="rounded-2xl border border-white/8 bg-gradient-to-b from-kyn-steel/40 to-transparent p-6 h-full">
                  <p className="font-display text-3xl font-bold text-kyn-green text-glow">{b.meta || '—'}</p>
                  <h3 className="font-semibold mt-3">{b.title}</h3>
                  <p className="text-sm text-kyn-metal mt-2 leading-relaxed">{b.body}</p>
                </div>
              </FadeIn>
            ))}
          </div>
        </div>
      </section>

      {/* 11. TESTIMONIAL */}
      <section className="py-24 md:py-28 relative overflow-hidden">
        <div className="absolute inset-0">
          <img src="/images/presentation.jpg" alt="" className="w-full h-full object-cover opacity-15" />
          <div className="absolute inset-0 bg-gradient-to-r from-kyn-black via-kyn-black/95 to-kyn-black/80" />
        </div>
        <div className="relative z-10 max-w-4xl mx-auto px-5 md:px-8 text-center">
          {testimonials.map((t) => (
            <FadeIn key={t.id}>
              <Quote className="mx-auto text-kyn-green mb-8" size={36} />
              <blockquote className="font-display text-2xl md:text-4xl font-medium leading-snug text-white">
                “{t.body}”
              </blockquote>
              <div className="mt-10">
                <p className="font-semibold">{t.title}</p>
                <p className="text-sm text-kyn-metal mt-1">{t.subtitle}</p>
              </div>
            </FadeIn>
          ))}
        </div>
      </section>

      {/* App download */}
      <AppDownloadCTA accent="#00e676" />

      {/* 12. FINAL CTA */}
      <section id="contact" className="py-24 md:py-32 relative">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(0,230,118,0.12),transparent_60%)]" />
        <div className="relative z-10 max-w-4xl mx-auto px-5 md:px-8 text-center">
          <FadeIn>
            <BrandLogo height={40} className="mx-auto justify-center" />
            <h2 className="mt-8 font-display text-3xl md:text-5xl font-bold leading-tight">
              Ready to run charging
              <br />
              <span className="text-kyn-green text-glow">at enterprise scale?</span>
            </h2>
            <p className="mt-5 text-kyn-silver max-w-xl mx-auto leading-relaxed">
              Join operators building the Tunisian and regional EV backbone on KYNETIK Cloud —
              hardware, software and Academy, unified.
            </p>
            <div className="mt-10 flex flex-wrap justify-center gap-3">
              <a href="mailto:cloud@kynetik.tn" className="inline-flex items-center gap-2 px-8 py-4 rounded-full bg-kyn-green text-kyn-black text-sm font-bold glow-green hover:bg-kyn-green-glow transition-colors">
                Request enterprise demo <ArrowRight size={16} />
              </a>
              <Link to="/" className="inline-flex items-center gap-2 px-8 py-4 rounded-full border border-white/15 text-sm font-medium hover:bg-white/5 transition-colors">
                Back to Design System
              </Link>
            </div>
            <div className="mt-12 flex flex-wrap justify-center gap-6 text-[11px] text-kyn-metal">
              {['OCPP certified stack', 'Tunisia-based support', 'Investor-ready reporting'].map((t) => (
                <span key={t} className="inline-flex items-center gap-1.5">
                  <CheckCircle2 size={12} className="text-kyn-green" /> {t}
                </span>
              ))}
            </div>
          </FadeIn>
        </div>
      </section>

      <footer className="border-t border-white/5 py-10">
        <div className="max-w-7xl mx-auto px-5 md:px-8 flex flex-wrap items-center justify-between gap-4">
          <BrandLogo height={28} />
          <p className="text-[11px] text-kyn-metal">© KYNETIK Cloud — L'énergie en mouvement · Tunisie</p>
          <div className="flex gap-4 text-[11px] text-kyn-metal">
            <Link to="/cloud" className="hover:text-white">Console UX</Link>
            <Link to="/app" className="hover:text-white">Mobile</Link>
            <Link to="/academy" className="hover:text-white">Academy</Link>
          </div>
        </div>
      </footer>
    </div>
  );
}

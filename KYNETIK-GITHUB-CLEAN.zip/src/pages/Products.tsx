import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Zap, Wifi, Radio, Cpu, Check, ArrowRight, Cable, Plug, MapPin } from 'lucide-react';
import SectionHeader from '../components/SectionHeader';
import LoadingState from '../components/LoadingState';
import ErrorState from '../components/ErrorState';
import { apiGet, cn } from '../lib/utils';

interface Product {
  id: number;
  name: string;
  tagline: string;
  power: string;
  specs: string;
  features: string;
  category: string;
  image_url: string;
  accent: string;
  sort_order: number;
}

function parseList(s: string | null | undefined): string[] {
  if (!s) return [];
  try {
    const v = JSON.parse(s);
    return Array.isArray(v) ? v : [];
  } catch {
    return s.split(',').map((x) => x.trim()).filter(Boolean);
  }
}

export default function Products() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [active, setActive] = useState<Product | null>(null);

  useEffect(() => {
    apiGet<Product[]>('/api/products')
      .then((data) => {
        const clean = data
          .filter((p) => p.name && !String(p.name).startsWith('_'))
          .sort((a, b) => (a.sort_order ?? 0) - (b.sort_order ?? 0));
        setProducts(clean);
        setActive(clean[0] || null);
      })
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <div className="p-10"><LoadingState /></div>;
  if (error) return <div className="p-10"><ErrorState message={error} /></div>;

  const isLifestyle = (url: string) => url?.includes('lifestyle');

  return (
    <div className="max-w-6xl mx-auto px-6 md:px-10 py-12 md:py-16">
      <div className="flex flex-wrap items-start justify-between gap-4 mb-2">
        <SectionHeader
          eyebrow="02 · Product System"
          title="Hardware family"
          description="Official KYNETIK hardware: NOVA · PRIME wall, GO portable, EDGE urban, and PRO commercial pedestal — all Cloud-ready."
          className="mb-0"
        />
        <Link
          to="/product-system"
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-kyn-green text-kyn-black text-xs font-bold shrink-0 mt-2"
        >
          Full product page <ArrowRight size={14} />
        </Link>
      </div>

      {/* Featured showcase with real renders */}
      {active && (
        <div className="glass-card rounded-3xl overflow-hidden mb-10 poster-shadow mt-10">
          <div className="grid lg:grid-cols-2">
            <div className={cn(
              'relative min-h-[380px] bg-gradient-to-br from-kyn-charcoal to-kyn-black flex items-center justify-center',
              isLifestyle(active.image_url) ? 'p-0 overflow-hidden' : 'p-8'
            )}>
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(0,230,118,0.12),transparent_55%)]" />
              <motion.img
                key={active.id}
                initial={{ opacity: 0, scale: 0.94 }}
                animate={{ opacity: 1, scale: 1 }}
                src={active.image_url}
                alt={active.name}
                className={cn(
                  'relative z-10',
                  isLifestyle(active.image_url)
                    ? 'w-full h-full min-h-[380px] object-cover'
                    : 'max-h-[340px] w-auto object-contain drop-shadow-[0_25px_60px_rgba(0,230,118,0.2)]'
                )}
              />
            </div>
            <div className="p-8 md:p-10 flex flex-col justify-center">
              <p className="text-kyn-green text-xs font-semibold tracking-[0.2em] uppercase">{active.category}</p>
              <h2 className="font-display text-3xl md:text-4xl font-bold mt-2">{active.name}</h2>
              <p className="text-kyn-silver mt-3 text-lg">{active.tagline}</p>
              <p className="mt-3 font-display text-kyn-green text-xl">{active.power}</p>
              <div className="mt-6 flex flex-wrap gap-2">
                {parseList(active.specs).map((spec) => (
                  <span key={spec} className="px-3 py-1.5 rounded-lg bg-kyn-steel border border-white/8 text-xs font-medium">
                    {spec}
                  </span>
                ))}
              </div>
              <ul className="mt-8 space-y-3">
                {parseList(active.features).map((f) => (
                  <li key={f} className="flex items-start gap-3 text-sm text-kyn-silver">
                    <Check size={16} className="text-kyn-green mt-0.5 shrink-0" />
                    {f}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      )}

      {/* Series highlights */}
      {['NOVA', 'PRIME', 'GO', 'EDGE', 'PRO'].map((series) => {
        const line = products.filter((p) => p.name.toUpperCase().includes(series));
        if (!line.length) return null;
        const accent =
          series === 'PRIME' ? '#2dd4bf' :
          series === 'GO' ? '#60a5fa' :
          series === 'EDGE' ? '#a3e635' :
          series === 'PRO' ? '#4ade80' : '#00e676';
        return (
          <div key={series} className="mb-8">
            <div className="flex items-center gap-2 mb-3">
              <span className="text-xs font-semibold tracking-[0.2em] uppercase" style={{ color: accent }}>{series} Series</span>
              <div className="h-px flex-1 bg-white/10" />
            </div>
            <div className="grid md:grid-cols-2 gap-4">
              {line.map((p) => (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => setActive(p)}
                  className={cn(
                    'text-left rounded-2xl border p-5 transition-all flex gap-4 items-center',
                    active?.id === p.id ? 'bg-white/[0.03]' : 'border-white/8 glass-card hover:border-white/20'
                  )}
                  style={active?.id === p.id ? { borderColor: `${accent}66`, boxShadow: `0 0 24px ${accent}22` } : undefined}
                >
                  <div className="w-28 h-36 shrink-0 flex items-center justify-center overflow-hidden rounded-xl">
                    <img
                      src={p.image_url}
                      alt={p.name}
                      className={cn(
                        isLifestyle(p.image_url) ? 'h-full w-full object-cover' : 'max-h-full w-auto object-contain'
                      )}
                    />
                  </div>
                  <div>
                    <div className="flex items-center gap-2 mb-1" style={{ color: accent }}>
                      {p.name.toLowerCase().includes('go')
                        ? <MapPin size={14} />
                        : p.name.toLowerCase().includes('socket') || p.name.toLowerCase().includes('schuko') || p.name.toLowerCase().includes('wall')
                        ? <Plug size={14} />
                        : <Cable size={14} />}
                      <span className="text-[10px] uppercase tracking-wider font-semibold">
                        {p.name.toLowerCase().includes('cee')
                          ? 'CEE 32A'
                          : p.name.toLowerCase().includes('schuko')
                            ? 'Schuko'
                            : 'Configuration'}
                      </span>
                    </div>
                    <p className="font-display font-bold text-lg">{p.name}</p>
                    <p className="text-xs text-kyn-metal mt-1 line-clamp-2">{p.tagline}</p>
                  </div>
                </button>
              ))}
            </div>
          </div>
        );
      })}

      {/* All product cards */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {products.map((p, i) => (
          <motion.button
            key={p.id}
            type="button"
            onClick={() => setActive(p)}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.06 }}
            className={cn(
              'text-left glass-card rounded-2xl p-5 transition-all hover:-translate-y-1',
              active?.id === p.id ? 'border-kyn-green/40 glow-green' : ''
            )}
          >
            <div className="h-40 rounded-xl mb-4 flex items-center justify-center overflow-hidden bg-[radial-gradient(circle,rgba(0,230,118,0.1),transparent_70%)]">
              <img
                src={p.image_url}
                alt={p.name}
                className={cn(
                  isLifestyle(p.image_url) ? 'h-full w-full object-cover' : 'max-h-full w-auto object-contain p-2'
                )}
              />
            </div>
            <p className="text-xs text-kyn-metal uppercase tracking-wider">{p.category}</p>
            <p className="font-semibold mt-1" style={{ color: p.accent || '#00e676' }}>{p.name}</p>
            <p className="text-sm text-white mt-0.5">{p.power}</p>
            <p className="text-sm text-kyn-metal mt-2 line-clamp-2">{p.tagline}</p>
          </motion.button>
        ))}
      </div>

      <div className="mt-12 grid md:grid-cols-4 gap-4">
        {[
          { icon: Zap, label: 'Power Range', value: '7–180 kW' },
          { icon: Wifi, label: 'Connectivity', value: 'WiFi · 4G · OCPP' },
          { icon: Radio, label: 'Protocol', value: 'OCPP 1.6J / 2.0.1' },
          { icon: Cpu, label: 'Intelligence', value: 'Smart Load Balance' },
        ].map(({ icon: Icon, label, value }) => (
          <div key={label} className="glass-card rounded-xl p-5">
            <Icon size={18} className="text-kyn-green mb-3" />
            <p className="text-xs text-kyn-metal uppercase tracking-wider">{label}</p>
            <p className="font-display font-semibold mt-1">{value}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

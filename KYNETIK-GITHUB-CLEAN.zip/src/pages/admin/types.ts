export type AdminSection =
  | 'dashboard'
  | 'customers'
  | 'installers'
  | 'products'
  | 'cloud'
  | 'analytics'
  | 'support'
  | 'cms'
  | 'notifications'
  | 'security'
  | 'billing'
  | 'reports';

export interface Kpi {
  id: number;
  key: string;
  label: string;
  value: string;
  delta: string;
  period: string;
  sort_order: number;
}

export interface Customer {
  id: number;
  name: string;
  company: string;
  email: string;
  country: string;
  subscription: string;
  chargers: number;
  status: string;
  last_activity: string;
}

export interface Installer {
  id: number;
  name: string;
  company: string;
  country: string;
  projects: number;
  certifications: string;
  score: number;
  reviews: number;
  response_time: string;
  status: string;
}

export interface AdminProduct {
  id: number;
  name: string;
  line: string;
  power: string;
  price: string;
  firmware: string;
  availability: string;
  image_url: string;
  specs: string;
  sort_order: number;
}

export interface InfraItem {
  id: number;
  type: string;
  name: string;
  status: string;
  detail: string;
  latency: string;
  sort_order: number;
}

export interface Ticket {
  id: number;
  subject: string;
  customer: string;
  priority: string;
  status: string;
  assignee: string;
  sla: string;
  created_at: string;
}

export interface CmsItem {
  id: number;
  type: string;
  title: string;
  status: string;
  locale: string;
  updated_at: string;
  sort_order: number;
}

export interface NotifItem {
  id: number;
  channel: string;
  title: string;
  audience: string;
  status: string;
  created_at: string;
}

export interface SecurityItem {
  id: number;
  type: string;
  name: string;
  detail: string;
  status: string;
  sort_order: number;
}

export interface BillingItem {
  id: number;
  type: string;
  label: string;
  amount: string;
  status: string;
  meta: string;
  sort_order: number;
}

export interface AnalyticsPoint {
  id: number;
  series: string;
  label: string;
  value: number;
  sort_order: number;
}

import type { ReactNode } from 'react';
import { cn } from '../../lib/utils';

export function StatCard({
  label,
  value,
  delta,
  accent = false,
}: {
  label: string;
  value: string;
  delta?: string;
  accent?: boolean;
}) {
  return (
    <div className="rounded-2xl border border-white/8 bg-gradient-to-b from-white/[0.04] to-transparent p-4 md:p-5 hover:border-kyn-green/25 transition-all group">
      <p className="text-[10px] uppercase tracking-wider text-kyn-metal font-medium">{label}</p>
      <p className={cn('font-display text-2xl md:text-3xl font-bold mt-2 tabular-nums', accent && 'text-kyn-green text-glow')}>
        {value}
      </p>
      {delta && (
        <p className={cn('text-[11px] mt-1.5', delta.startsWith('-') ? 'text-red-400' : 'text-kyn-green')}>
          {delta}
        </p>
      )}
    </div>
  );
}

export function Panel({
  title,
  action,
  children,
  className,
}: {
  title?: string;
  action?: ReactNode;
  children: ReactNode;
  className?: string;
}) {
  return (
    <div className={cn('rounded-2xl border border-white/8 bg-kyn-void/80 overflow-hidden', className)}>
      {(title || action) && (
        <div className="flex items-center justify-between gap-3 px-4 md:px-5 py-3.5 border-b border-white/5">
          {title && <h3 className="font-display font-semibold text-sm">{title}</h3>}
          {action}
        </div>
      )}
      <div className="p-4 md:p-5">{children}</div>
    </div>
  );
}

export function Badge({ children, tone = 'neutral' }: { children: ReactNode; tone?: 'ok' | 'warn' | 'bad' | 'neutral' | 'info' }) {
  const styles = {
    ok: 'bg-kyn-green/10 text-kyn-green border-kyn-green/20',
    warn: 'bg-amber-500/10 text-amber-300 border-amber-500/20',
    bad: 'bg-red-500/10 text-red-400 border-red-500/20',
    info: 'bg-sky-500/10 text-sky-300 border-sky-500/20',
    neutral: 'bg-white/5 text-kyn-metal border-white/10',
  };
  return (
    <span className={cn('inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold border', styles[tone])}>
      {children}
    </span>
  );
}

export function statusTone(status: string): 'ok' | 'warn' | 'bad' | 'neutral' | 'info' {
  const s = (status || '').toLowerCase();
  if (['active', 'online', 'healthy', 'paid', 'published', 'resolved', 'operational', 'sent'].some((x) => s.includes(x))) return 'ok';
  if (['pending', 'degraded', 'open', 'medium', 'trial', 'draft', 'scheduled'].some((x) => s.includes(x))) return 'warn';
  if (['suspended', 'offline', 'critical', 'failed', 'high', 'overdue', 'down'].some((x) => s.includes(x))) return 'bad';
  if (['low', 'info'].some((x) => s.includes(x))) return 'info';
  return 'neutral';
}

export function MiniBars({ values, color = '#00e676' }: { values: number[]; color?: string }) {
  const max = Math.max(...values, 1);
  return (
    <div className="h-28 flex items-end gap-1">
      {values.map((v, i) => (
        <div
          key={i}
          className="flex-1 rounded-t-sm transition-all hover:opacity-100 opacity-80"
          style={{
            height: `${(v / max) * 100}%`,
            background: `linear-gradient(to top, ${color}55, ${color})`,
          }}
        />
      ))}
    </div>
  );
}

export function DataTable({
  columns,
  rows,
}: {
  columns: string[];
  rows: ReactNode[][];
}) {
  return (
    <div className="overflow-x-auto -mx-1">
      <table className="w-full text-left text-sm min-w-[720px]">
        <thead>
          <tr className="text-[10px] uppercase tracking-wider text-kyn-metal border-b border-white/5">
            {columns.map((c) => (
              <th key={c} className="pb-3 font-medium px-2 first:pl-0 last:pr-0">{c}</th>
            ))}
          </tr>
        </thead>
        <tbody className="divide-y divide-white/5">
          {rows.map((row, i) => (
            <tr key={i} className="hover:bg-white/[0.02] transition-colors">
              {row.map((cell, j) => (
                <td key={j} className="py-3 px-2 first:pl-0 last:pr-0 text-kyn-silver align-middle">
                  {cell}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export function Toolbar({
  children,
  className,
}: {
  children: ReactNode;
  className?: string;
}) {
  return <div className={cn('flex flex-wrap items-center gap-2 mb-4', className)}>{children}</div>;
}

export function Btn({
  children,
  onClick,
  variant = 'ghost',
  type = 'button',
  disabled,
}: {
  children: ReactNode;
  onClick?: () => void;
  variant?: 'primary' | 'ghost' | 'danger';
  type?: 'button' | 'submit';
  disabled?: boolean;
}) {
  return (
    <button
      type={type}
      disabled={disabled}
      onClick={onClick}
      className={cn(
        'inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all disabled:opacity-40',
        variant === 'primary' && 'bg-kyn-green text-kyn-black hover:bg-kyn-green-glow',
        variant === 'ghost' && 'border border-white/10 text-kyn-silver hover:text-white hover:border-white/20',
        variant === 'danger' && 'border border-red-500/30 text-red-400 hover:bg-red-500/10'
      )}
    >
      {children}
    </button>
  );
}

export function SearchInput({
  value,
  onChange,
  placeholder,
}: {
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
}) {
  return (
    <input
      value={value}
      onChange={(e) => onChange(e.target.value)}
      placeholder={placeholder || 'Search…'}
      className="bg-kyn-steel/50 border border-white/10 rounded-xl px-3 py-2 text-xs text-white placeholder:text-kyn-metal outline-none focus:border-kyn-green/40 min-w-[180px]"
    />
  );
}

export function SectionTitle({ eyebrow, title, desc }: { eyebrow?: string; title: string; desc?: string }) {
  return (
    <div className="mb-6">
      {eyebrow && <p className="text-kyn-green text-[10px] font-semibold tracking-[0.25em] uppercase mb-2">{eyebrow}</p>}
      <h1 className="font-display text-2xl md:text-3xl font-bold">{title}</h1>
      {desc && <p className="text-sm text-kyn-metal mt-2 max-w-2xl">{desc}</p>}
    </div>
  );
}

export function Empty({ label }: { label: string }) {
  return <p className="text-sm text-kyn-metal py-8 text-center">{label}</p>;
}

export function LiveDot() {
  return (
    <span className="inline-flex items-center gap-1.5 text-[10px] text-kyn-green font-semibold">
      <span className="w-1.5 h-1.5 rounded-full bg-kyn-green animate-pulse" /> LIVE
    </span>
  );
}

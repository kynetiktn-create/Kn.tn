import { useEffect, useMemo, useState } from 'react';
import {
  Download, Eye, Pencil, Ban, Trash2, Plus, RefreshCw, Send, FileText,
  Shield, KeyRound, Users, CheckCircle2, AlertTriangle, Server, Database,
  Activity, Radio, Bell, Mail, Smartphone
} from 'lucide-react';
import { apiGet, cn } from '../../lib/utils';
import type {
  Kpi, Customer, Installer, AdminProduct, InfraItem, Ticket,
  CmsItem, NotifItem, SecurityItem, BillingItem, AnalyticsPoint
} from './types';
import {
  StatCard, Panel, Badge, statusTone, MiniBars, DataTable, Toolbar, Btn,
  SearchInput, SectionTitle, Empty, LiveDot
} from './ui';

async function mutate(path: string, method: string, body: unknown) {
  const res = await fetch(path, {
    method,
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
}

export function DashboardView() {
  const [kpis, setKpis] = useState<Kpi[]>([]);
  const [analytics, setAnalytics] = useState<AnalyticsPoint[]>([]);
  const [period, setPeriod] = useState('monthly');
  const [loading, setLoading] = useState(true);

  const load = () => {
    setLoading(true);
    Promise.all([
      apiGet<Kpi[]>(`/api/admin-kpis?period=${period}`),
      apiGet<AnalyticsPoint[]>('/api/admin-analytics'),
    ])
      .then(([k, a]) => {
        setKpis(k);
        setAnalytics(a);
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, [period]);

  const revenue = analytics.filter((a) => a.series === 'revenue').map((a) => a.value);
  const energy = analytics.filter((a) => a.series === 'energy').map((a) => a.value);
  const sessions = analytics.filter((a) => a.series === 'sessions').map((a) => a.value);

  return (
    <div>
      <div className="flex flex-wrap items-start justify-between gap-4 mb-6">
        <SectionTitle
          eyebrow="01 · Command center"
          title="Executive Dashboard"
          desc="Real-time ecosystem health across customers, chargers, revenue and sustainability."
        />
        <div className="flex items-center gap-2">
          <LiveDot />
          {(['daily', 'monthly', 'yearly'] as const).map((p) => (
            <button
              key={p}
              type="button"
              onClick={() => setPeriod(p)}
              className={cn(
                'px-3 py-1.5 rounded-lg text-xs font-semibold capitalize',
                period === p ? 'bg-kyn-green text-kyn-black' : 'bg-kyn-steel text-kyn-silver'
              )}
            >
              {p}
            </button>
          ))}
          <Btn onClick={load}><RefreshCw size={12} /> Refresh</Btn>
        </div>
      </div>

      {loading ? (
        <Empty label="Loading KPIs…" />
      ) : (
        <>
          <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-3 mb-6">
            {kpis.map((k, i) => (
              <StatCard key={k.id} label={k.label} value={k.value} delta={k.delta} accent={i < 2} />
            ))}
          </div>
          <div className="grid lg:grid-cols-3 gap-4">
            <Panel title="Revenue trend" className="lg:col-span-2">
              <MiniBars values={revenue.length ? revenue : [12, 18, 15, 22, 28, 24, 31, 36, 33, 40, 44, 48]} />
              <div className="mt-3 flex justify-between text-[10px] text-kyn-metal">
                <span>Start</span><span>Now</span>
              </div>
            </Panel>
            <Panel title="Energy delivered (MWh)">
              <MiniBars values={energy.length ? energy : [4, 6, 5, 8, 9, 7, 11, 10, 12, 14, 13, 16]} color="#39ff14" />
            </Panel>
            <Panel title="Charging sessions" className="lg:col-span-2">
              <MiniBars values={sessions.length ? sessions : [80, 95, 88, 110, 120, 105, 140, 150, 132, 160, 175, 190]} color="#22d3ee" />
            </Panel>
            <Panel title="System pulse">
              <div className="space-y-3 text-sm">
                {[
                  ['API Gateway', '99.99%'],
                  ['OCPP Broker', 'Operational'],
                  ['Billing engine', 'Healthy'],
                  ['Support SLA', '94% met'],
                ].map(([l, v]) => (
                  <div key={l} className="flex justify-between">
                    <span className="text-kyn-metal">{l}</span>
                    <span className="text-kyn-green font-medium">{v}</span>
                  </div>
                ))}
              </div>
            </Panel>
          </div>
        </>
      )}
    </div>
  );
}

export function CustomersView() {
  const [rows, setRows] = useState<Customer[]>([]);
  const [q, setQ] = useState('');
  const [status, setStatus] = useState('all');
  const [loading, setLoading] = useState(true);
  const [msg, setMsg] = useState('');

  const load = () => {
    setLoading(true);
    const params = new URLSearchParams();
    if (status !== 'all') params.set('status', status);
    if (q) params.set('q', q);
    apiGet<Customer[]>(`/api/admin-customers?${params}`)
      .then(setRows)
      .catch((e) => setMsg(e.message))
      .finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, [status]);

  const filtered = useMemo(() => {
    if (!q) return rows;
    const s = q.toLowerCase();
    return rows.filter(
      (r) =>
        r.name?.toLowerCase().includes(s) ||
        r.company?.toLowerCase().includes(s) ||
        r.country?.toLowerCase().includes(s)
    );
  }, [rows, q]);

  const setStatusOf = async (id: number, next: string) => {
    try {
      await mutate('/api/admin-customers', 'PUT', { id, status: next });
      setMsg(`Customer #${id} → ${next}`);
      load();
    } catch (e) {
      setMsg(e instanceof Error ? e.message : 'Error');
    }
  };

  const remove = async (id: number) => {
    if (!confirm('Delete this customer?')) return;
    await mutate('/api/admin-customers', 'DELETE', { id });
    load();
  };

  const exportCsv = () => {
    const header = 'Name,Company,Country,Subscription,Chargers,Status,Last Activity';
    const body = filtered
      .map((r) => [r.name, r.company, r.country, r.subscription, r.chargers, r.status, r.last_activity].join(','))
      .join('\n');
    const blob = new Blob([[header, body].join('\n')], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'kynetik-customers.csv';
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div>
      <SectionTitle eyebrow="02 · CRM" title="Customer Management" desc="Global accounts, subscriptions and charger footprints." />
      <Toolbar>
        <SearchInput value={q} onChange={setQ} placeholder="Search name, company, country…" />
        <select
          value={status}
          onChange={(e) => setStatus(e.target.value)}
          className="bg-kyn-steel/50 border border-white/10 rounded-xl px-3 py-2 text-xs text-white outline-none"
        >
          <option value="all">All statuses</option>
          <option value="active">Active</option>
          <option value="trial">Trial</option>
          <option value="suspended">Suspended</option>
        </select>
        <Btn onClick={load}><RefreshCw size={12} /> Refresh</Btn>
        <Btn variant="primary" onClick={exportCsv}><Download size={12} /> Export</Btn>
      </Toolbar>
      {msg && <p className="text-xs text-kyn-green mb-3">{msg}</p>}
      <Panel>
        {loading ? <Empty label="Loading customers…" /> : (
          <DataTable
            columns={['Customer', 'Company', 'Country', 'Plan', 'Chargers', 'Status', 'Last activity', 'Actions']}
            rows={filtered.map((r) => [
              <div key="n"><p className="font-medium text-white">{r.name}</p><p className="text-[10px] text-kyn-metal">{r.email}</p></div>,
              r.company,
              r.country,
              r.subscription,
              String(r.chargers),
              <Badge key="s" tone={statusTone(r.status)}>{r.status}</Badge>,
              r.last_activity,
              <div key="a" className="flex gap-1">
                <Btn onClick={() => setMsg(`Viewing ${r.name}`)}><Eye size={12} /></Btn>
                <Btn onClick={() => setMsg(`Edit ${r.name}`)}><Pencil size={12} /></Btn>
                <Btn onClick={() => setStatusOf(r.id, r.status === 'suspended' ? 'active' : 'suspended')}><Ban size={12} /></Btn>
                <Btn variant="danger" onClick={() => remove(r.id)}><Trash2 size={12} /></Btn>
              </div>,
            ])}
          />
        )}
      </Panel>
    </div>
  );
}

export function InstallersView() {
  const [rows, setRows] = useState<Installer[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    apiGet<Installer[]>('/api/admin-installers')
      .then(setRows)
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  return (
    <div>
      <SectionTitle eyebrow="03 · Network" title="Installer Management" desc="Certified partners, performance scores and field readiness." />
      <Panel>
        {loading ? <Empty label="Loading installers…" /> : (
          <DataTable
            columns={['Installer', 'Company', 'Country', 'Projects', 'Certifications', 'Score', 'Reviews', 'Response', 'Status']}
            rows={rows.map((r) => [
              <span key="n" className="font-medium text-white">{r.name}</span>,
              r.company,
              r.country,
              String(r.projects),
              r.certifications,
              <span key="sc" className="text-kyn-green font-semibold">{r.score}</span>,
              String(r.reviews),
              r.response_time,
              <Badge key="st" tone={statusTone(r.status)}>{r.status}</Badge>,
            ])}
          />
        )}
      </Panel>
    </div>
  );
}

export function ProductsView() {
  const [rows, setRows] = useState<AdminProduct[]>([]);
  const [loading, setLoading] = useState(true);
  const [editId, setEditId] = useState<number | null>(null);
  const [price, setPrice] = useState('');
  const [firmware, setFirmware] = useState('');
  const [msg, setMsg] = useState('');

  const load = () => {
    setLoading(true);
    apiGet<AdminProduct[]>('/api/admin-products')
      .then(setRows)
      .catch(console.error)
      .finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, []);

  const save = async () => {
    if (!editId) return;
    await mutate('/api/admin-products', 'PUT', { id: editId, price, firmware });
    setMsg('Product updated');
    setEditId(null);
    load();
  };

  return (
    <div>
      <SectionTitle eyebrow="04 · Catalog" title="Product Management" desc="GO · FLEX · PRIME · NOVA · EDGE · PRO — specs, pricing, firmware." />
      {msg && <p className="text-xs text-kyn-green mb-3">{msg}</p>}
      {loading ? <Empty label="Loading products…" /> : (
        <div className="grid sm:grid-cols-2 xl:grid-cols-3 gap-4">
          {rows.map((p) => (
            <div key={p.id} className="rounded-2xl border border-white/8 bg-kyn-void overflow-hidden hover:border-kyn-green/25 transition-all">
              <div className="h-40 flex items-center justify-center bg-[radial-gradient(circle,rgba(0,230,118,0.1),transparent_70%)] p-4">
                <img src={p.image_url} alt={p.name} className="max-h-full w-auto object-contain" />
              </div>
              <div className="p-4 border-t border-white/5">
                <div className="flex justify-between items-start gap-2">
                  <div>
                    <p className="text-[10px] text-kyn-green uppercase tracking-wider">{p.line}</p>
                    <h3 className="font-display font-bold">{p.name}</h3>
                  </div>
                  <Badge tone={statusTone(p.availability)}>{p.availability}</Badge>
                </div>
                <p className="text-xs text-kyn-metal mt-2">{p.power}</p>
                <div className="mt-3 flex justify-between text-sm">
                  <span className="text-kyn-silver">{p.price}</span>
                  <span className="text-[11px] text-kyn-metal">FW {p.firmware}</span>
                </div>
                {editId === p.id ? (
                  <div className="mt-3 space-y-2">
                    <input value={price} onChange={(e) => setPrice(e.target.value)} className="w-full bg-kyn-steel border border-white/10 rounded-lg px-2 py-1.5 text-xs" placeholder="Price" />
                    <input value={firmware} onChange={(e) => setFirmware(e.target.value)} className="w-full bg-kyn-steel border border-white/10 rounded-lg px-2 py-1.5 text-xs" placeholder="Firmware" />
                    <div className="flex gap-2">
                      <Btn variant="primary" onClick={save}>Save</Btn>
                      <Btn onClick={() => setEditId(null)}>Cancel</Btn>
                    </div>
                  </div>
                ) : (
                  <div className="mt-3">
                    <Btn onClick={() => { setEditId(p.id); setPrice(p.price); setFirmware(p.firmware); }}>
                      <Pencil size={12} /> Edit
                    </Btn>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export function CloudView() {
  const [rows, setRows] = useState<InfraItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    apiGet<InfraItem[]>('/api/admin-infra')
      .then(setRows)
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  const iconFor = (name: string) => {
    const n = name.toLowerCase();
    if (n.includes('api')) return Server;
    if (n.includes('database') || n.includes('db')) return Database;
    if (n.includes('ocpp')) return Radio;
    if (n.includes('error') || n.includes('log')) return AlertTriangle;
    return Activity;
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-2">
        <SectionTitle eyebrow="05 · Platform" title="Cloud Management" desc="API, servers, database, OCPP gateway and connected chargers." />
        <LiveDot />
      </div>
      {loading ? <Empty label="Loading infrastructure…" /> : (
        <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-3">
          {rows.map((r) => {
            const Icon = iconFor(r.name);
            return (
              <div key={r.id} className="rounded-2xl border border-white/8 bg-kyn-void p-5">
                <div className="flex items-start justify-between gap-3">
                  <div className="w-10 h-10 rounded-xl bg-kyn-green/10 border border-kyn-green/20 flex items-center justify-center text-kyn-green">
                    <Icon size={18} />
                  </div>
                  <Badge tone={statusTone(r.status)}>{r.status}</Badge>
                </div>
                <h3 className="font-display font-semibold mt-4">{r.name}</h3>
                <p className="text-xs text-kyn-metal mt-1">{r.detail}</p>
                <p className="text-[11px] text-kyn-green mt-3 font-mono">{r.latency}</p>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

export function AnalyticsView() {
  const [rows, setRows] = useState<AnalyticsPoint[]>([]);
  useEffect(() => {
    apiGet<AnalyticsPoint[]>('/api/admin-analytics').then(setRows).catch(console.error);
  }, []);

  const series = (name: string) => rows.filter((r) => r.series === name);

  return (
    <div>
      <SectionTitle eyebrow="06 · Insights" title="Analytics Center" desc="Revenue, growth, funnel, traffic and product performance." />
      <div className="grid lg:grid-cols-2 gap-4">
        {[
          ['revenue', 'Revenue', '#00e676'],
          ['orders', 'Orders', '#39ff14'],
          ['traffic', 'Traffic', '#22d3ee'],
          ['conversion', 'Conversion funnel', '#60a5fa'],
          ['countries', 'Top countries', '#a78bfa'],
          ['products', 'Best sellers', '#fbbf24'],
        ].map(([key, title, color]) => {
          const pts = series(key);
          return (
            <Panel key={key} title={title}>
              <MiniBars values={pts.length ? pts.map((p) => p.value) : [10, 14, 12, 18, 22, 20, 26]} color={color} />
              <div className="mt-3 flex flex-wrap gap-2">
                {pts.slice(0, 6).map((p) => (
                  <span key={p.id} className="text-[10px] px-2 py-1 rounded-md bg-white/5 text-kyn-metal">
                    {p.label}: {p.value}
                  </span>
                ))}
              </div>
            </Panel>
          );
        })}
      </div>
    </div>
  );
}

export function SupportView() {
  const [rows, setRows] = useState<Ticket[]>([]);
  const [loading, setLoading] = useState(true);

  const load = () => {
    apiGet<Ticket[]>('/api/admin-tickets')
      .then(setRows)
      .catch(console.error)
      .finally(() => setLoading(false));
  };
  useEffect(() => { load(); }, []);

  const resolve = async (id: number) => {
    await mutate('/api/admin-tickets', 'PUT', { id, status: 'resolved' });
    load();
  };

  return (
    <div>
      <SectionTitle eyebrow="07 · CX" title="Support Center" desc="Tickets, priority, SLA and technician assignment." />
      <Panel>
        {loading ? <Empty label="Loading tickets…" /> : (
          <DataTable
            columns={['Subject', 'Customer', 'Priority', 'Status', 'Assignee', 'SLA', 'Created', '']}
            rows={rows.map((t) => [
              <span key="s" className="font-medium text-white">{t.subject}</span>,
              t.customer,
              <Badge key="p" tone={statusTone(t.priority)}>{t.priority}</Badge>,
              <Badge key="st" tone={statusTone(t.status)}>{t.status}</Badge>,
              t.assignee,
              t.sla,
              t.created_at?.slice?.(0, 10) || t.created_at,
              t.status !== 'resolved' ? (
                <Btn key="r" variant="primary" onClick={() => resolve(t.id)}><CheckCircle2 size={12} /> Resolve</Btn>
              ) : (
                <span key="d" className="text-[10px] text-kyn-metal">Done</span>
              ),
            ])}
          />
        )}
      </Panel>
    </div>
  );
}

export function CmsView() {
  const [rows, setRows] = useState<CmsItem[]>([]);
  const load = () => apiGet<CmsItem[]>('/api/admin-cms').then(setRows).catch(console.error);
  useEffect(() => { load(); }, []);

  const toggle = async (item: CmsItem) => {
    const next = item.status === 'published' ? 'draft' : 'published';
    await mutate('/api/admin-cms', 'PUT', { id: item.id, status: next });
    load();
  };

  return (
    <div>
      <SectionTitle eyebrow="08 · Content" title="CMS" desc="Homepage, products, blog, academy, banners and promotions." />
      <Panel>
        <DataTable
          columns={['Type', 'Title', 'Locale', 'Status', 'Updated', 'Actions']}
          rows={rows.map((r) => [
            <Badge key="t" tone="info">{r.type}</Badge>,
            <span key="ti" className="text-white font-medium">{r.title}</span>,
            r.locale,
            <Badge key="s" tone={statusTone(r.status)}>{r.status}</Badge>,
            r.updated_at?.slice?.(0, 10) || r.updated_at,
            <Btn key="a" onClick={() => toggle(r)}><Pencil size={12} /> Toggle publish</Btn>,
          ])}
        />
      </Panel>
    </div>
  );
}

export function NotificationsView() {
  const [rows, setRows] = useState<NotifItem[]>([]);
  const [title, setTitle] = useState('');
  const [channel, setChannel] = useState('push');
  const load = () => apiGet<NotifItem[]>('/api/admin-notifications').then(setRows).catch(console.error);
  useEffect(() => { load(); }, []);

  const create = async () => {
    if (!title.trim()) return;
    await mutate('/api/admin-notifications', 'POST', {
      title,
      channel,
      audience: 'All customers',
      status: 'scheduled',
      created_at: new Date().toISOString(),
    });
    setTitle('');
    load();
  };

  const icon = (c: string) => {
    if (c === 'email') return Mail;
    if (c === 'push') return Smartphone;
    return Bell;
  };

  return (
    <div>
      <SectionTitle eyebrow="09 · Comms" title="Notification Center" desc="Push, email campaigns, maintenance and firmware announcements." />
      <Panel title="Compose" className="mb-4">
        <div className="flex flex-wrap gap-2">
          <input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Announcement title"
            className="flex-1 min-w-[200px] bg-kyn-steel border border-white/10 rounded-xl px-3 py-2 text-xs outline-none focus:border-kyn-green/40"
          />
          <select value={channel} onChange={(e) => setChannel(e.target.value)} className="bg-kyn-steel border border-white/10 rounded-xl px-3 py-2 text-xs">
            <option value="push">Push</option>
            <option value="email">Email</option>
            <option value="maintenance">Maintenance</option>
            <option value="firmware">Firmware</option>
          </select>
          <Btn variant="primary" onClick={create}><Send size={12} /> Schedule</Btn>
        </div>
      </Panel>
      <div className="space-y-2">
        {rows.map((r) => {
          const Icon = icon(r.channel);
          return (
            <div key={r.id} className="flex items-center gap-3 rounded-xl border border-white/8 bg-kyn-void px-4 py-3">
              <div className="w-9 h-9 rounded-lg bg-kyn-green/10 text-kyn-green flex items-center justify-center"><Icon size={16} /></div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate">{r.title}</p>
                <p className="text-[10px] text-kyn-metal">{r.channel} · {r.audience}</p>
              </div>
              <Badge tone={statusTone(r.status)}>{r.status}</Badge>
            </div>
          );
        })}
      </div>
    </div>
  );
}

export function SecurityView() {
  const [rows, setRows] = useState<SecurityItem[]>([]);
  useEffect(() => {
    apiGet<SecurityItem[]>('/api/admin-security').then(setRows).catch(console.error);
  }, []);

  const groups = ['role', 'permission', 'audit', 'api_key', 'login'];

  return (
    <div>
      <SectionTitle eyebrow="10 · Trust" title="Security" desc="Roles, permissions, audit logs, 2FA, API keys, SSO and login history." />
      <div className="grid md:grid-cols-2 gap-4">
        {groups.map((g) => {
          const items = rows.filter((r) => r.type === g);
          return (
            <Panel key={g} title={g.replace('_', ' ').toUpperCase()}>
              <div className="space-y-2">
                {items.length === 0 && <Empty label="No items" />}
                {items.map((r) => (
                  <div key={r.id} className="flex items-start justify-between gap-3 rounded-lg bg-white/[0.02] border border-white/5 px-3 py-2">
                    <div className="flex gap-2">
                      {g === 'api_key' ? <KeyRound size={14} className="text-kyn-green mt-0.5" /> :
                       g === 'role' ? <Users size={14} className="text-kyn-green mt-0.5" /> :
                       <Shield size={14} className="text-kyn-green mt-0.5" />}
                      <div>
                        <p className="text-sm font-medium">{r.name}</p>
                        <p className="text-[11px] text-kyn-metal">{r.detail}</p>
                      </div>
                    </div>
                    <Badge tone={statusTone(r.status)}>{r.status}</Badge>
                  </div>
                ))}
              </div>
            </Panel>
          );
        })}
      </div>
    </div>
  );
}

export function BillingView() {
  const [rows, setRows] = useState<BillingItem[]>([]);
  useEffect(() => {
    apiGet<BillingItem[]>('/api/admin-billing').then(setRows).catch(console.error);
  }, []);

  const types = ['subscription', 'invoice', 'discount', 'commission', 'refund'];

  return (
    <div>
      <SectionTitle eyebrow="11 · Finance" title="Billing" desc="Subscriptions, invoices, taxes, discounts, partner commissions and refunds." />
      <div className="grid lg:grid-cols-2 gap-4">
        {types.map((t) => (
          <Panel key={t} title={t.charAt(0).toUpperCase() + t.slice(1) + 's'}>
            <DataTable
              columns={['Label', 'Amount', 'Status', 'Meta']}
              rows={rows.filter((r) => r.type === t).map((r) => [
                <span key="l" className="text-white font-medium">{r.label}</span>,
                r.amount,
                <Badge key="s" tone={statusTone(r.status)}>{r.status}</Badge>,
                <span key="m" className="text-[11px] text-kyn-metal">{r.meta}</span>,
              ])}
            />
          </Panel>
        ))}
      </div>
    </div>
  );
}

export function ReportsView() {
  const [busy, setBusy] = useState('');
  const reports = [
    { id: 'financial', title: 'Financial summary', desc: 'MRR, ARR, invoices, refunds' },
    { id: 'operations', title: 'Operations report', desc: 'Chargers, sessions, uptime' },
    { id: 'growth', title: 'Growth analytics', desc: 'Customers, conversion, countries' },
    { id: 'support', title: 'Support SLA pack', desc: 'Tickets, CSAT, response times' },
  ];

  const generate = async (id: string, format: 'pdf' | 'excel') => {
    setBusy(`${id}-${format}`);
    // Pull live KPIs so export is real data-backed
    const kpis = await apiGet<Kpi[]>('/api/admin-kpis?period=monthly').catch(() => []);
    const lines = [
      `KYNETIK Enterprise Report — ${id}`,
      `Format: ${format.toUpperCase()}`,
      `Generated: ${new Date().toISOString()}`,
      '',
      ...kpis.map((k) => `${k.label}: ${k.value} (${k.delta})`),
    ];
    const blob = new Blob([lines.join('\n')], { type: format === 'excel' ? 'text/csv' : 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `kynetik-${id}.${format === 'excel' ? 'csv' : 'txt'}`;
    a.click();
    URL.revokeObjectURL(url);
    setBusy('');
  };

  return (
    <div>
      <SectionTitle eyebrow="12 · Exports" title="Reports" desc="Generate PDF / Excel packs for board, finance and operations." />
      <div className="grid md:grid-cols-2 gap-4">
        {reports.map((r) => (
          <div key={r.id} className="rounded-2xl border border-white/8 bg-kyn-void p-6">
            <FileText className="text-kyn-green mb-3" size={22} />
            <h3 className="font-display font-semibold text-lg">{r.title}</h3>
            <p className="text-sm text-kyn-metal mt-1">{r.desc}</p>
            <div className="mt-5 flex gap-2">
              <Btn variant="primary" disabled={!!busy} onClick={() => generate(r.id, 'pdf')}>
                <Download size={12} /> {busy === `${r.id}-pdf` ? '…' : 'PDF'}
              </Btn>
              <Btn disabled={!!busy} onClick={() => generate(r.id, 'excel')}>
                <Download size={12} /> {busy === `${r.id}-excel` ? '…' : 'Excel'}
              </Btn>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

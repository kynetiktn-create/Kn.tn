import { useEffect, useState, type ComponentType } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  LayoutDashboard, Users, Wrench, Package, Cloud, BarChart3, Headphones,
  FileEdit, Bell, Shield, CreditCard, FileSpreadsheet, Menu, X, Search,
  ChevronRight, Settings, LogOut, Command
} from 'lucide-react';
import BrandLogo from '../../components/BrandLogo';
import { cn } from '../../lib/utils';
import type { AdminSection } from './types';
import {
  DashboardView, CustomersView, InstallersView, ProductsView, CloudView,
  AnalyticsView, SupportView, CmsView, NotificationsView, SecurityView,
  BillingView, ReportsView
} from './views';

const nav: { id: AdminSection; label: string; icon: typeof LayoutDashboard; group: string }[] = [
  { id: 'dashboard', label: 'Executive Dashboard', icon: LayoutDashboard, group: 'Overview' },
  { id: 'customers', label: 'Customers', icon: Users, group: 'Network' },
  { id: 'installers', label: 'Installers', icon: Wrench, group: 'Network' },
  { id: 'products', label: 'Products', icon: Package, group: 'Catalog' },
  { id: 'cloud', label: 'Cloud Ops', icon: Cloud, group: 'Platform' },
  { id: 'analytics', label: 'Analytics', icon: BarChart3, group: 'Platform' },
  { id: 'support', label: 'Support', icon: Headphones, group: 'Operations' },
  { id: 'cms', label: 'CMS', icon: FileEdit, group: 'Operations' },
  { id: 'notifications', label: 'Notifications', icon: Bell, group: 'Operations' },
  { id: 'security', label: 'Security', icon: Shield, group: 'Governance' },
  { id: 'billing', label: 'Billing', icon: CreditCard, group: 'Governance' },
  { id: 'reports', label: 'Reports', icon: FileSpreadsheet, group: 'Governance' },
];

const views: Record<AdminSection, ComponentType> = {
  dashboard: DashboardView,
  customers: CustomersView,
  installers: InstallersView,
  products: ProductsView,
  cloud: CloudView,
  analytics: AnalyticsView,
  support: SupportView,
  cms: CmsView,
  notifications: NotificationsView,
  security: SecurityView,
  billing: BillingView,
  reports: ReportsView,
};

function isSection(s: string | undefined): s is AdminSection {
  return !!s && s in views;
}

export default function AdminPortal() {
  const { section } = useParams();
  const navigate = useNavigate();
  const active: AdminSection = isSection(section) ? section : 'dashboard';
  const [open, setOpen] = useState(false);
  const [clock, setClock] = useState(() => new Date());

  useEffect(() => {
    const t = setInterval(() => setClock(new Date()), 1000);
    return () => clearInterval(t);
  }, []);

  useEffect(() => {
    if (section && !isSection(section)) navigate('/admin/dashboard', { replace: true });
    if (!section) navigate('/admin/dashboard', { replace: true });
  }, [section, navigate]);

  const ActiveView = views[active];
  const groups = Array.from(new Set(nav.map((n) => n.group)));

  return (
    <div className="min-h-screen bg-kyn-black text-white flex">
      {/* Sidebar */}
      <aside className={cn(
        'fixed inset-y-0 left-0 z-40 w-72 border-r border-white/5 bg-kyn-void/95 backdrop-blur-xl flex flex-col transition-transform lg:translate-x-0 lg:static',
        open ? 'translate-x-0' : '-translate-x-full'
      )}>
        <div className="p-5 border-b border-white/5">
          <div className="flex items-center justify-between gap-2">
            <Link to="/admin" className="flex items-center gap-2 min-w-0">
              <BrandLogo height={28} />
            </Link>
            <button type="button" className="lg:hidden p-1 text-kyn-metal" onClick={() => setOpen(false)}>
              <X size={18} />
            </button>
          </div>
          <div className="mt-3 flex items-center gap-2">
            <span className="text-[10px] font-semibold tracking-[0.2em] uppercase text-kyn-green border border-kyn-green/30 rounded-full px-2 py-0.5">
              Enterprise
            </span>
            <span className="text-[10px] text-kyn-metal">Admin Portal</span>
          </div>
        </div>

        <nav className="flex-1 overflow-y-auto p-3 space-y-4">
          {groups.map((g) => (
            <div key={g}>
              <p className="px-3 mb-1.5 text-[9px] uppercase tracking-[0.2em] text-kyn-metal font-semibold">{g}</p>
              <div className="space-y-0.5">
                {nav.filter((n) => n.group === g).map(({ id, label, icon: Icon }) => {
                  const isActive = active === id;
                  return (
                    <button
                      key={id}
                      type="button"
                      onClick={() => {
                        navigate(`/admin/${id}`);
                        setOpen(false);
                      }}
                      className={cn(
                        'w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-left text-sm transition-all',
                        isActive
                          ? 'bg-kyn-green/10 text-kyn-green border border-kyn-green/20'
                          : 'text-kyn-silver hover:bg-white/5 hover:text-white border border-transparent'
                      )}
                    >
                      <Icon size={16} />
                      <span className="flex-1 truncate">{label}</span>
                      {isActive && <ChevronRight size={14} />}
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </nav>

        <div className="p-4 border-t border-white/5 space-y-2">
          <div className="rounded-xl border border-white/8 bg-black/30 p-3">
            <p className="text-[10px] text-kyn-metal uppercase tracking-wider">Signed in</p>
            <p className="text-sm font-medium mt-0.5">Khalifa · Super Admin</p>
            <p className="text-[10px] text-kyn-green mt-1">Global command access</p>
          </div>
          <div className="flex gap-2">
            <Link to="/console" className="flex-1 text-center text-[10px] py-2 rounded-lg border border-white/10 text-kyn-metal hover:text-white">
              Operator
            </Link>
            <Link to="/" className="flex-1 text-center text-[10px] py-2 rounded-lg border border-white/10 text-kyn-metal hover:text-white">
              Website
            </Link>
          </div>
        </div>
      </aside>

      {open && <div className="fixed inset-0 z-30 bg-black/60 lg:hidden" onClick={() => setOpen(false)} />}

      {/* Main */}
      <div className="flex-1 min-w-0 flex flex-col min-h-screen">
        <header className="sticky top-0 z-20 border-b border-white/5 bg-kyn-black/80 backdrop-blur-xl">
          <div className="h-14 md:h-16 px-4 md:px-6 flex items-center gap-3">
            <button type="button" className="lg:hidden p-2 text-kyn-silver" onClick={() => setOpen(true)}>
              <Menu size={18} />
            </button>
            <div className="hidden md:flex items-center gap-2 flex-1 max-w-md rounded-xl border border-white/10 bg-kyn-steel/40 px-3 py-2">
              <Search size={14} className="text-kyn-metal" />
              <input
                placeholder="Search customers, tickets, products…"
                className="bg-transparent border-0 outline-none text-xs flex-1 placeholder:text-kyn-metal"
              />
              <span className="hidden sm:inline-flex items-center gap-1 text-[10px] text-kyn-metal border border-white/10 rounded px-1.5 py-0.5">
                <Command size={10} /> K
              </span>
            </div>
            <div className="ml-auto flex items-center gap-3">
              <div className="hidden sm:block text-right">
                <p className="text-[10px] text-kyn-metal">UTC · Live ops</p>
                <p className="text-xs font-mono text-kyn-silver tabular-nums">
                  {clock.toLocaleTimeString()}
                </p>
              </div>
              <button type="button" className="p-2 rounded-lg border border-white/10 text-kyn-metal hover:text-white">
                <Bell size={16} />
              </button>
              <button type="button" className="p-2 rounded-lg border border-white/10 text-kyn-metal hover:text-white">
                <Settings size={16} />
              </button>
              <Link to="/design-system" className="p-2 rounded-lg border border-white/10 text-kyn-metal hover:text-white" title="Exit">
                <LogOut size={16} />
              </Link>
            </div>
          </div>
        </header>

        <main className="flex-1 p-4 md:p-6 lg:p-8 overflow-x-hidden">
          <AnimatePresence mode="wait">
            <motion.div
              key={active}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -6 }}
              transition={{ duration: 0.25 }}
            >
              <ActiveView />
            </motion.div>
          </AnimatePresence>
        </main>
      </div>
    </div>
  );
}

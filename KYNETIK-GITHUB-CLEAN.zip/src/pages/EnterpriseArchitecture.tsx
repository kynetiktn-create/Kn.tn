import { useEffect, useMemo, useState, type ComponentType, type ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  ArrowRight, Network, Server, Database, KeyRound, PlugZap, CreditCard,
  Bell, BarChart3, Radio, Wifi, Shield, Activity, GitBranch, Brain,
  TrendingUp, BookOpen, Menu, X, CheckCircle2, Layers, Cloud, Smartphone,
  Building2, Wrench, Terminal, Lock, Gauge, Boxes, ChevronRight, Cpu,
  Globe2, HardDrive, Workflow, Rocket, FileCode2, Eye
} from 'lucide-react';
import BrandLogo from '../components/BrandLogo';
import LoadingState from '../components/LoadingState';
import { apiGet, cn } from '../lib/utils';

interface Item {
  id: number;
  type: string;
  category: string;
  title: string;
  subtitle: string;
  body: string;
  meta: string | null;
  sort_order: number;
}

const NAV = [
  { id: 'overview', label: 'Vue globale' },
  { id: 'backend', label: 'Backend' },
  { id: 'data', label: 'Data' },
  { id: 'api', label: 'API' },
  { id: 'ocpp', label: 'OCPP' },
  { id: 'iot', label: 'IoT' },
  { id: 'security', label: 'Sécurité' },
  { id: 'monitor', label: 'Monitoring' },
  { id: 'devops', label: 'DevOps' },
  { id: 'ai', label: 'IA' },
  { id: 'scale', label: 'Scale' },
  { id: 'docs', label: 'Docs' },
];

function Fade({ children, className, delay = 0 }: { children: ReactNode; className?: string; delay?: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 22 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-40px' }}
      transition={{ duration: 0.5, delay }}
      className={className}
    >
      {children}
    </motion.div>
  );
}

function Section({
  id, kicker, title, lead, children,
}: {
  id: string; kicker: string; title: string; lead?: string; children: ReactNode;
}) {
  return (
    <section id={id} className="scroll-mt-28 py-16 md:py-20 border-t border-white/[0.06]">
      <Fade>
        <p className="text-sky-400 text-xs font-semibold tracking-[0.28em] uppercase mb-3">{kicker}</p>
        <h2 className="font-display text-2xl md:text-4xl font-bold tracking-tight max-w-3xl">{title}</h2>
        {lead && <p className="mt-3 text-kyn-silver max-w-2xl leading-relaxed">{lead}</p>}
      </Fade>
      <div className="mt-8">{children}</div>
    </section>
  );
}

function Card({
  title, body, meta, icon: Icon, accent = 'sky',
}: {
  title: string; body: string; meta?: string | null;
  icon?: ComponentType<{ size?: number; className?: string }>; accent?: 'sky' | 'green';
}) {
  const c = accent === 'green' ? 'text-kyn-green border-kyn-green/25 bg-kyn-green/10' : 'text-sky-300 border-sky-400/25 bg-sky-400/10';
  return (
    <div className="rounded-2xl border border-white/10 bg-gradient-to-b from-white/[0.04] to-transparent p-5 h-full hover:border-sky-400/30 transition-colors">
      <div className="flex items-start justify-between gap-3">
        {Icon && (
          <div className={cn('w-9 h-9 rounded-xl border flex items-center justify-center', c)}>
            <Icon size={16} />
          </div>
        )}
        {meta && <span className="text-[10px] font-mono uppercase tracking-wider text-kyn-metal">{meta}</span>}
      </div>
      <h3 className="font-display font-semibold mt-3 text-white">{title}</h3>
      <p className="text-sm text-kyn-metal mt-2 leading-relaxed">{body}</p>
    </div>
  );
}

const ARCH_NODES = [
  { label: 'Mobile App', sub: 'iOS / Android', icon: Smartphone },
  { label: 'Public API', sub: 'Gateway', icon: Globe2 },
  { label: 'Auth · Engine · Pay', sub: 'Core services', icon: Cpu },
  { label: 'Core Backend', sub: 'Domain logic', icon: Server },
  { label: 'Portal · Ntf · BI', sub: 'Surfaces', icon: Cloud },
  { label: 'OCPP Gateway', sub: 'Protocol', icon: Radio },
  { label: 'Chargers', sub: 'GO → PRO', icon: PlugZap },
];

const serviceIcon: Record<string, ComponentType<{ size?: number; className?: string }>> = {
  IAM: KeyRound, CM: PlugZap, CS: Activity, BILL: CreditCard, NTF: Bell, AN: BarChart3,
};

export default function EnterpriseArchitecture() {
  const [items, setItems] = useState<Item[]>([]);
  const [loading, setLoading] = useState(true);
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    apiGet<Item[]>('/api/marketing-content?type=enterprise_arch')
      .then((d) => setItems(d || []))
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const by = (cat: string) =>
    items.filter((i) => i.category === cat).sort((a, b) => a.sort_order - b.sort_order);

  const layers = by('layer');
  const services = by('service');
  const entities = by('entity');
  const apis = by('api');
  const ocpp = by('ocpp');
  const iot = by('iot');
  const security = by('security');
  const monitor = by('monitor');
  const devops = by('devops');
  const ai = by('ai');
  const scale = by('scale');
  const docs = by('docs');

  const auditFields = useMemo(
    () => ['id (UUID/serial)', 'created_at', 'updated_at', 'audit_log / change history'],
    []
  );

  if (loading) {
    return (
      <div className="min-h-screen bg-[#05070c] flex items-center justify-center">
        <LoadingState label="Loading enterprise architecture…" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#05070c] text-white">
      <div className="pointer-events-none fixed inset-0 bg-[radial-gradient(ellipse_at_top,rgba(56,189,248,0.08),transparent_50%),radial-gradient(ellipse_at_bottom_right,rgba(0,230,118,0.05),transparent_40%)]" />

      <header
        className={cn(
          'fixed top-0 inset-x-0 z-50 transition-all',
          scrolled ? 'bg-[#05070c]/90 backdrop-blur-xl border-b border-white/5' : 'bg-transparent'
        )}
      >
        <div className="max-w-7xl mx-auto px-5 md:px-8 h-16 flex items-center justify-between gap-4">
          <Link to="/" className="flex items-center gap-3 shrink-0">
            <BrandLogo height={28} />
            <span className="hidden sm:inline text-[10px] font-semibold tracking-[0.2em] uppercase text-sky-400 border border-sky-400/30 rounded-full px-2 py-0.5">
              Phase 25 · Arch
            </span>
          </Link>
          <nav className="hidden xl:flex items-center gap-4 text-[11px] text-kyn-silver">
            {NAV.slice(0, 8).map((n) => (
              <a key={n.id} href={`#${n.id}`} className="hover:text-white transition-colors">
                {n.label}
              </a>
            ))}
          </nav>
          <div className="flex items-center gap-2">
            <Link
              to="/developers"
              className="hidden sm:inline-flex items-center gap-1.5 px-3.5 py-2 rounded-full bg-sky-400 text-[#05070c] text-xs font-bold"
            >
              Dev Platform <ArrowRight size={13} />
            </Link>
            <button type="button" className="xl:hidden p-2 text-kyn-silver" onClick={() => setMenuOpen(!menuOpen)}>
              {menuOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </div>
        {menuOpen && (
          <div className="xl:hidden border-t border-white/5 bg-[#05070c] px-5 py-4 grid grid-cols-2 gap-2">
            {NAV.map((n) => (
              <a
                key={n.id}
                href={`#${n.id}`}
                onClick={() => setMenuOpen(false)}
                className="rounded-lg border border-white/8 px-3 py-2 text-xs text-kyn-silver hover:text-white"
              >
                {n.label}
              </a>
            ))}
          </div>
        )}
      </header>

      {/* HERO */}
      <section className="relative pt-28 md:pt-36 pb-16 overflow-hidden">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <Fade>
            <p className="text-sky-400 text-xs font-semibold tracking-[0.32em] uppercase mb-4">
              Phase 25 · Enterprise Architecture
            </p>
            <h1 className="font-display text-4xl sm:text-5xl md:text-6xl font-bold tracking-tight leading-[1.05] max-w-4xl">
              Référence technique unifiée
              <br />
              <span className="text-sky-400">pour l&apos;ingénierie KYNETIK.</span>
            </h1>
            <p className="mt-6 text-lg text-kyn-silver max-w-2xl leading-relaxed">
              Architecture globale, services modulaires, modèle de données, OCPP, IoT, sécurité,
              DevOps, IA et scalabilité — le blueprint que Tesla Energy, ABB et ChargePoint formalisent
              avant de scaler le réseau.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <a href="#overview" className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-sky-400 text-[#05070c] text-sm font-bold">
                Explorer l&apos;architecture <ArrowRight size={16} />
              </a>
              <Link to="/engineering-pack" className="inline-flex items-center gap-2 px-6 py-3 rounded-full border border-white/15 text-sm font-semibold">
                Ops Blueprint
              </Link>
              <Link to="/console" className="inline-flex items-center gap-2 px-6 py-3 rounded-full border border-white/15 text-sm font-semibold">
                Cloud Console
              </Link>
            </div>
          </Fade>

          {/* Live stack diagram */}
          <Fade delay={0.1}>
            <div className="mt-14 rounded-3xl border border-white/10 bg-black/40 p-6 md:p-8 overflow-x-auto">
              <p className="text-[11px] uppercase tracking-[0.25em] text-kyn-metal mb-6 flex items-center gap-2">
                <Network size={14} className="text-sky-400" /> KYNETIK Ecosystem · data path
              </p>
              <div className="flex flex-col md:flex-row md:items-stretch gap-3 min-w-[720px] md:min-w-0">
                {ARCH_NODES.map((n, i) => {
                  const Icon = n.icon;
                  return (
                    <div key={n.label} className="flex md:flex-col items-center gap-2 flex-1">
                      <div className="w-full rounded-2xl border border-sky-400/20 bg-sky-400/5 p-4 text-center">
                        <Icon className="mx-auto text-sky-300 mb-2" size={18} />
                        <p className="text-sm font-semibold">{n.label}</p>
                        <p className="text-[10px] text-kyn-metal mt-1">{n.sub}</p>
                      </div>
                      {i < ARCH_NODES.length - 1 && (
                        <ChevronRight className="hidden md:block text-sky-400/40 shrink-0 rotate-0 md:rotate-0 absolute" size={0} />
                      )}
                      {i < ARCH_NODES.length - 1 && (
                        <div className="hidden md:block w-full h-px bg-gradient-to-r from-sky-400/40 to-transparent" />
                      )}
                    </div>
                  );
                })}
              </div>
              <div className="mt-6 grid sm:grid-cols-3 gap-3 text-xs text-kyn-metal">
                <div className="rounded-xl border border-white/8 p-3">TLS everywhere · RBAC · MFA admin</div>
                <div className="rounded-xl border border-white/8 p-3">OCPP 1.6J now · multi-version ready</div>
                <div className="rounded-xl border border-white/8 p-3">Offline buffer · auto-reconnect · sync</div>
              </div>
            </div>
          </Fade>
        </div>
      </section>

      <div className="relative max-w-7xl mx-auto px-5 md:px-8 pb-8">
        {/* 1 Overview layers */}
        <Section
          id="overview"
          kicker="01 · Architecture globale"
          title="Couches de l'écosystème"
          lead="Du mobile jusqu'aux bornes — chaque couche a une responsabilité claire et des contrats stables."
        >
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {layers.map((l, i) => (
              <Fade key={l.id} delay={i * 0.03}>
                <Card title={l.title} body={l.body} meta={l.meta} icon={Layers} />
              </Fade>
            ))}
          </div>
        </Section>

        {/* 2 Backend services */}
        <Section
          id="backend"
          kicker="02 · Backend modulaire"
          title="Services indépendants, cœur unifié"
          lead="Identity, chargers, sessions, billing, notifications, analytics — extensibles sans rewrite monolithe."
        >
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {services.map((s, i) => {
              const Icon = serviceIcon[s.meta || ''] || Server;
              return (
                <Fade key={s.id} delay={i * 0.04}>
                  <Card title={s.title} body={s.body} meta={s.meta} icon={Icon} accent="green" />
                </Fade>
              );
            })}
          </div>
        </Section>

        {/* 3 Data */}
        <Section
          id="data"
          kicker="03 · Base de données"
          title="Entités métier + audit trail"
          lead="Chaque entité porte id, created_at, updated_at et historique de modifications."
        >
          <div className="mb-6 flex flex-wrap gap-2">
            {auditFields.map((f) => (
              <span key={f} className="text-[11px] px-3 py-1.5 rounded-full border border-sky-400/25 bg-sky-400/10 text-sky-200 font-mono">
                {f}
              </span>
            ))}
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
            {entities.map((e, i) => (
              <Fade key={e.id} delay={i * 0.02}>
                <div className="rounded-xl border border-white/10 bg-white/[0.02] p-4 flex items-start gap-3">
                  <HardDrive size={16} className="text-sky-400 shrink-0 mt-0.5" />
                  <div>
                    <p className="font-semibold text-sm">{e.title}</p>
                    <p className="text-xs text-kyn-metal mt-1 leading-relaxed">{e.body}</p>
                  </div>
                </div>
              </Fade>
            ))}
          </div>
          <div className="mt-6 rounded-2xl border border-white/10 p-5 flex flex-wrap gap-3 items-center justify-between">
            <p className="text-sm text-kyn-silver">Voir le schéma live déjà déployé dans le produit.</p>
            <Link to="/docs/database" className="inline-flex items-center gap-2 text-xs font-bold text-sky-400">
              Database Architecture <ArrowRight size={14} />
            </Link>
          </div>
        </Section>

        {/* 4 API */}
        <Section
          id="api"
          kicker="04 · API Strategy"
          title="Une API, quatre consommateurs"
          lead="Contrats versionnés pour mobile, cloud, installateurs et partenaires."
        >
          <div className="grid md:grid-cols-2 gap-4">
            {apis.map((a, i) => (
              <Fade key={a.id} delay={i * 0.05}>
                <div className="rounded-2xl border border-white/10 bg-black/30 p-6 flex gap-4">
                  <div className="w-10 h-10 rounded-xl bg-kyn-green/10 border border-kyn-green/25 flex items-center justify-center text-kyn-green shrink-0">
                    {a.meta === 'MOB' ? <Smartphone size={18} /> :
                     a.meta === 'CLD' ? <Cloud size={18} /> :
                     a.meta === 'INST' ? <Wrench size={18} /> :
                     <Terminal size={18} />}
                  </div>
                  <div>
                    <p className="text-[10px] font-mono text-kyn-green uppercase tracking-wider">{a.meta}</p>
                    <h3 className="font-display font-semibold text-lg mt-1">{a.title}</h3>
                    <p className="text-sm text-kyn-metal mt-2">{a.body}</p>
                  </div>
                </div>
              </Fade>
            ))}
          </div>
          <div className="mt-6 flex flex-wrap gap-3">
            <Link to="/developers" className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full border border-white/15 text-xs font-semibold hover:border-sky-400/40">
              Developer Platform
            </Link>
            <Link to="/developers/docs" className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full border border-white/15 text-xs font-semibold hover:border-sky-400/40">
              API Docs
            </Link>
          </div>
        </Section>

        {/* 5 OCPP */}
        <Section
          id="ocpp"
          kicker="05 · OCPP Layer"
          title="OCPP 1.6J aujourd'hui, multi-version demain"
          lead="Gateway dédié — les services métier ne parlent jamais le protocole brut aux bornes."
        >
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {ocpp.map((o, i) => (
              <Fade key={o.id} delay={i * 0.03}>
                <div className="rounded-2xl border border-white/10 p-4 bg-gradient-to-br from-sky-400/5 to-transparent">
                  <Radio size={16} className="text-sky-400 mb-2" />
                  <p className="font-semibold text-sm">{o.title}</p>
                  <p className="text-xs text-kyn-metal mt-1.5 leading-relaxed">{o.body}</p>
                </div>
              </Fade>
            ))}
          </div>
        </Section>

        {/* 6 IoT */}
        <Section
          id="iot"
          kicker="06 · IoT Communication"
          title="Connectivité résiliente"
          lead="Wi-Fi, Ethernet, 4G/LTE, Bluetooth local — avec reconnect, buffer offline et sync."
        >
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
            {iot.filter((i) => ['WiFi', 'ETH', '4G', 'BT'].includes(i.meta || '')).map((i) => (
              <Card key={i.id} title={i.title} body={i.body} meta={i.meta} icon={Wifi} accent="green" />
            ))}
          </div>
          <div className="grid md:grid-cols-3 gap-3">
            {iot.filter((i) => !['WiFi', 'ETH', '4G', 'BT'].includes(i.meta || '')).map((i) => (
              <div key={i.id} className="rounded-xl border border-kyn-green/20 bg-kyn-green/5 p-4 flex gap-3">
                <CheckCircle2 size={16} className="text-kyn-green shrink-0 mt-0.5" />
                <div>
                  <p className="font-semibold text-sm">{i.title}</p>
                  <p className="text-xs text-kyn-metal mt-1">{i.body}</p>
                </div>
              </div>
            ))}
          </div>
        </Section>

        {/* 7 Security */}
        <Section
          id="security"
          kicker="07 · Sécurité"
          title="Defense in depth"
          lead="Auth standard, chiffrement, RBAC, MFA admin, audit et alertes."
        >
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {security.map((s, i) => (
              <Fade key={s.id} delay={i * 0.04}>
                <Card title={s.title} body={s.body} meta={s.meta} icon={s.meta === 'RBAC' || s.meta === 'MFA' ? Lock : Shield} />
              </Fade>
            ))}
          </div>
        </Section>

        {/* 8 Monitoring */}
        <Section
          id="monitor"
          kicker="08 · Monitoring"
          title="Observabilité temps réel"
          lead="Disponibilité, latence, erreurs, bornes offline, sessions live, santé paiements."
        >
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {monitor.map((m, i) => (
              <Fade key={m.id} delay={i * 0.03}>
                <div className="rounded-2xl border border-white/10 p-5 flex items-start gap-3">
                  <div className="w-9 h-9 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center text-sky-300">
                    <Eye size={16} />
                  </div>
                  <div>
                    <p className="font-semibold text-sm">{m.title}</p>
                    <p className="text-xs text-kyn-metal mt-1">{m.body}</p>
                  </div>
                </div>
              </Fade>
            ))}
          </div>
          <Link to="/console" className="mt-6 inline-flex items-center gap-2 text-sm font-semibold text-kyn-green">
            Ouvrir la Cloud Console <ArrowRight size={14} />
          </Link>
        </Section>

        {/* 9 DevOps */}
        <Section
          id="devops"
          kicker="09 · DevOps Pipeline"
          title="Du code à la surveillance continue"
        >
          <div className="flex flex-col md:flex-row gap-2 md:items-stretch">
            {devops.map((d, i) => (
              <Fade key={d.id} delay={i * 0.05} className="flex-1">
                <div className="h-full rounded-2xl border border-white/10 bg-black/30 p-4 relative">
                  <span className="text-[10px] font-mono text-sky-400">0{d.meta}</span>
                  <p className="font-semibold mt-2 text-sm">{d.title}</p>
                  <p className="text-xs text-kyn-metal mt-1.5">{d.body}</p>
                  {i < devops.length - 1 && (
                    <div className="hidden md:block absolute -right-1 top-1/2 w-2 h-px bg-sky-400/40" />
                  )}
                </div>
              </Fade>
            ))}
          </div>
        </Section>

        {/* 10 AI */}
        <Section
          id="ai"
          kicker="10 · Intelligence artificielle"
          title="Roadmap IA produit"
          lead="Prédictif, énergie, anomalies, BI — branchés sur le même event stream."
        >
          <div className="grid md:grid-cols-2 gap-4">
            {ai.map((a, i) => (
              <Fade key={a.id} delay={i * 0.05}>
                <div className="rounded-2xl border border-white/10 p-6 flex gap-4 bg-gradient-to-br from-violet-500/10 to-transparent">
                  <Brain className="text-violet-300 shrink-0" size={22} />
                  <div>
                    <h3 className="font-display font-semibold text-lg">{a.title}</h3>
                    <p className="text-sm text-kyn-metal mt-2">{a.body}</p>
                    <Link to="/ai-platform" className="mt-3 inline-flex items-center gap-1 text-xs font-semibold text-violet-300">
                      Voir AI Platform <ChevronRight size={12} />
                    </Link>
                  </div>
                </div>
              </Fade>
            ))}
          </div>
        </Section>

        {/* 11 Scale */}
        <Section
          id="scale"
          kicker="11 · Scalabilité"
          title="Croissance par ordres de grandeur"
          lead="Des centaines aux dizaines de milliers de bornes multi-pays — sans reconstruire le cœur."
        >
          <div className="grid md:grid-cols-3 gap-4">
            {scale.map((s, i) => (
              <Fade key={s.id} delay={i * 0.06}>
                <div className="rounded-3xl border border-white/10 p-6 md:p-8 text-center relative overflow-hidden">
                  <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(56,189,248,0.08),transparent_70%)]" />
                  <p className="relative text-sky-400 text-xs font-semibold tracking-[0.2em] uppercase">{s.meta}</p>
                  <h3 className="relative font-display text-xl font-bold mt-3">{s.title}</h3>
                  <p className="relative text-sm text-kyn-metal mt-3">{s.body}</p>
                  <TrendingUp className="relative mx-auto mt-4 text-sky-400/50" size={20} />
                </div>
              </Fade>
            ))}
          </div>
        </Section>

        {/* 12 Docs */}
        <Section
          id="docs"
          kicker="12 · Documentation technique"
          title="Chaque service est documenté"
          lead="Description, API, erreurs, sécurité, exemples, versioning."
        >
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {docs.map((d, i) => (
              <Fade key={d.id} delay={i * 0.03}>
                <Card title={d.title} body={d.body} meta={d.meta} icon={FileCode2} />
              </Fade>
            ))}
          </div>
          <div className="mt-8 grid sm:grid-cols-3 gap-3">
            {[
              { to: '/docs', label: 'Documentation Suite', icon: BookOpen },
              { to: '/master-docs', label: 'Master Documentation', icon: Layers },
              { to: '/developers', label: 'Developer Platform', icon: Terminal },
            ].map(({ to, label, icon: Icon }) => (
              <Link
                key={to}
                to={to}
                className="rounded-2xl border border-white/10 p-5 flex items-center gap-3 hover:border-sky-400/30 transition-colors"
              >
                <Icon className="text-sky-400" size={18} />
                <span className="font-semibold text-sm flex-1">{label}</span>
                <ArrowRight size={14} className="text-kyn-metal" />
              </Link>
            ))}
          </div>
        </Section>

        {/* CTA Phase 26 */}
        <section className="py-20 border-t border-white/[0.06]">
          <Fade>
            <div className="rounded-[2rem] border border-sky-400/25 bg-gradient-to-br from-sky-400/10 via-transparent to-kyn-green/5 p-8 md:p-12 text-center">
              <p className="text-sky-400 text-xs font-semibold tracking-[0.3em] uppercase mb-3">Phase 26 · Next</p>
              <h2 className="font-display text-3xl md:text-4xl font-bold max-w-2xl mx-auto">
                PRD & Engineering Specifications
              </h2>
              <p className="mt-4 text-kyn-silver max-w-xl mx-auto">
                Transformer cette architecture en spécifications exécutables : écrans app, pages web,
                contrats API et business rules.
              </p>
              <div className="mt-8 flex flex-wrap justify-center gap-3">
                <Link to="/product-spec" className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-sky-400 text-[#05070c] text-sm font-bold">
                  Product Spec <ArrowRight size={16} />
                </Link>
                <Link to="/ops" className="inline-flex items-center gap-2 px-6 py-3 rounded-full border border-white/15 text-sm font-semibold">
                  Ops Blueprint
                </Link>
                <Link to="/handoff" className="inline-flex items-center gap-2 px-6 py-3 rounded-full border border-white/15 text-sm font-semibold">
                  Dev Handoff
                </Link>
              </div>
            </div>
          </Fade>
        </section>
      </div>

      <footer className="border-t border-white/5 py-8">
        <div className="max-w-7xl mx-auto px-5 md:px-8 flex flex-wrap justify-between gap-4 items-center">
          <BrandLogo height={26} />
          <p className="text-[11px] text-kyn-metal">Phase 25 · Enterprise Architecture & Technology Stack</p>
          <div className="flex gap-3 text-[11px] text-kyn-metal">
            <Link to="/prd" className="hover:text-white">PRD</Link>
            <Link to="/ops" className="hover:text-white">Ops</Link>
            <Link to="/console" className="hover:text-white">Cloud</Link>
            <Link to="/developers" className="hover:text-white">API</Link>
          </div>
        </div>
      </footer>
    </div>
  );
}

import SectionHeader from '../components/SectionHeader';
import PhoneFrame from '../components/PhoneFrame';
import { DesignTokensMini } from '../components/mobile/screens';

const colors = [
  { name: 'KYNETIK Green', value: '#00E676', use: 'Primary accent, CTAs, status' },
  { name: 'Deep Black', value: '#050505', use: 'App & web backgrounds' },
  { name: 'Graphite', value: '#1E1E1E', use: 'Cards, elevated surfaces' },
  { name: 'White', value: '#FFFFFF', use: 'Primary typography' },
  { name: 'Silver', value: '#C8C8D0', use: 'Secondary text' },
  { name: 'Green Glow', value: '#39FF14', use: 'Charging glow / focus' },
];

export default function UITokens() {
  return (
    <div className="max-w-6xl mx-auto px-6 md:px-10 py-12 md:py-16">
      <SectionHeader
        eyebrow="UI/UX · Design Tokens"
        title="Digital component language"
        description="Shared tokens for Application + Website + Cloud — radius 16px, soft green glow buttons, glassmorphism cards, minimal line icons."
      />

      <div className="grid lg:grid-cols-[280px_1fr] gap-10">
        <PhoneFrame label="Token reference">
          <DesignTokensMini />
        </PhoneFrame>

        <div className="space-y-10">
          <section>
            <h2 className="font-display text-xl font-semibold mb-4">Colors</h2>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {colors.map((c) => (
                <div key={c.value} className="glass-card rounded-2xl overflow-hidden">
                  <div className="h-20" style={{ background: c.value }} />
                  <div className="p-3">
                    <p className="font-semibold text-sm">{c.name}</p>
                    <p className="font-mono text-kyn-green text-xs mt-0.5">{c.value}</p>
                    <p className="text-[11px] text-kyn-metal mt-1">{c.use}</p>
                  </div>
                </div>
              ))}
            </div>
          </section>

          <section>
            <h2 className="font-display text-xl font-semibold mb-4">Typography</h2>
            <div className="grid md:grid-cols-2 gap-4">
              <div className="glass-card rounded-2xl p-6">
                <p className="text-[10px] uppercase tracking-widest text-kyn-metal mb-3">Headlines</p>
                <p className="font-display text-3xl font-bold">Space Grotesk / Montserrat Bold</p>
                <p className="mt-3 text-kyn-silver text-sm">L'énergie en mouvement</p>
              </div>
              <div className="glass-card rounded-2xl p-6">
                <p className="text-[10px] uppercase tracking-widest text-kyn-metal mb-3">Body</p>
                <p className="text-3xl font-semibold">Inter Regular</p>
                <p className="mt-3 text-kyn-silver text-sm leading-relaxed">
                  UI copy, forms, analytics labels — highly legible at 12–16px on dark surfaces.
                </p>
              </div>
            </div>
          </section>

          <section>
            <h2 className="font-display text-xl font-semibold mb-4">Components</h2>
            <div className="grid sm:grid-cols-2 gap-4">
              <div className="glass-card rounded-2xl p-6 space-y-3">
                <p className="text-xs text-kyn-metal mb-2">Buttons · 16px radius · soft glow</p>
                <button type="button" className="w-full rounded-2xl bg-kyn-green text-kyn-black text-sm font-bold py-3 glow-green">Primary</button>
                <button type="button" className="w-full rounded-2xl border border-white/15 text-sm font-semibold py-3">Secondary</button>
                <button type="button" className="w-full rounded-2xl border border-red-500/40 text-red-400 text-sm font-semibold py-3">Destructive</button>
              </div>
              <div className="space-y-3">
                <div className="glass-card rounded-2xl p-5">
                  <p className="text-xs text-kyn-metal">Glass card</p>
                  <p className="font-semibold mt-1">backdrop blur + metal border</p>
                </div>
                <div className="rounded-2xl border border-kyn-green/30 bg-kyn-green/5 p-5">
                  <p className="text-xs text-kyn-green">Status chip</p>
                  <p className="font-semibold mt-1 flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-kyn-green animate-pulse-glow" /> En ligne
                  </p>
                </div>
                <div className="rounded-2xl bg-kyn-steel border border-white/8 px-4 py-3 text-sm text-kyn-metal">
                  Input field · Email
                </div>
              </div>
            </div>
          </section>

          <section className="glass-card rounded-2xl p-6">
            <h2 className="font-display text-lg font-semibold mb-3">Layout rules</h2>
            <ul className="grid md:grid-cols-2 gap-2 text-sm text-kyn-silver">
              <li>• Corner radius default: <span className="text-kyn-green">16px</span> (2xl)</li>
              <li>• Mobile bottom nav: 5 destinations</li>
              <li>• One electric accent per focal region</li>
              <li>• Specs always monospaced or chip form</li>
              <li>• Icons: minimal stroke, 1.5–2px</li>
              <li>• Motion: short energy pulses, no bounce</li>
            </ul>
          </section>
        </div>
      </div>
    </div>
  );
}

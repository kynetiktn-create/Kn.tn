import { useCallback, useEffect, useMemo, useState, type ComponentType, type ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  Activity, AlertTriangle, ArrowLeft, ArrowRight, CheckCircle2, ChevronRight,
  ClipboardList, Clock, Cpu, Download, FileText, HardDrive, History,
  Package, RefreshCw, Search, ShieldAlert, Siren, Wrench, Zap,
} from 'lucide-react';
import BrandLogo from '../components/BrandLogo';
import LoadingState from '../components/LoadingState';
import ErrorState from '../components/ErrorState';
import { apiGet, cn } from '../lib/utils';

interface MaintItem {
  id: number;
  category: string;
  title: string;
  subtitle: string;
  charger_id: string;
  site: string;
  model: string;
  status: string;
  priority: string;
  assignee: string;
  value: string;
  meta: string;
  body: string;
  scheduled_at: string;
  sort_order: number;
}

type SectionKey =
  | 'jobs'
  | 'emergency'
  | 'diagnostics'
  | 'firmware'
  | 'parts'
  | 'history'
  | 'report';

const SECTIONS: { id: SectionKey; label: string; icon: ComponentType<{ size?: number; className?: string }> }[] = [
  { id: 'jobs', label: 'Active Jobs', icon: Wrench },
  { id: 'emergency', label: 'Emergency', icon: Siren },
  { id: 'diagnostics', label: 'Diagnostics', icon: Activity },
  { id: 'firmware', label: 'Firmware', icon: Cpu },
  { id: 'parts', label: 'Spare Parts', icon: Package },
  { id: 'history', label: 'Repair History', icon: History },
  { id: 'report', label: 'Report', icon: FileText },
];

const categoryMap: Record<SectionKey, string> = {
  jobs: 'active_job',
  emergency: 'emergency',
  diagnostics: 'diagnostic',
  firmware: 'firmware',
  parts: 'spare_part',
  history: 'repair_history',
  report: 'report',
};

function priorityTone(p: string) {
  const v = (p || '').toLowerCase();
  if (v === 'critical') return 'text-red-400 bg-red-500/10 border-red-500/30';
  if (v === 'high' || v === 'urgent') return 'text-orange-300 bg-orange-500/10 border-orange-500/30';
  if (v === 'medium') return 'text-amber-200 bg-amber-500/10 border-amber-500/25';
  if (v === 'low') return 'text-kyn-metal bg-white/5 border-white/10';
  return 'text-sky-300 bg-sky-500/10 border-sky-500/25';
}

function statusTone(s: string) {
  const v = (s || '').toLowerCase();
  if (v === 'in_progress' || v === 'running' || v === 'active') return 'text-kyn-green bg-kyn-green/10 border-kyn-green/30';
  if (v === 'scheduled' || v === 'queued' || v === 'pending') return 'text-sky-300 bg-sky-500/10 border-sky-500/25';
  if (v === 'completed' || v === 'healthy' || v === 'passed' || v === 'in_stock') return 'text-emerald-300 bg-emerald-500/10 border-emerald-500/25';
  if (v === 'failed' || v === 'critical' || v === 'out_of_stock') return 'text-red-400 bg-red-500/10 border-red-500/25';
  if (v === 'warning' || v === 'low_stock') return 'text-amber-300 bg-amber-500/10 border-amber-500/25';
  return 'text-kyn-silver bg-white/5 border-white/10';
}

function labelize(s: string) {
  return (s || '').replace(/_/g, ' ');
}

function GlassCard({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <div
      className={cn(
        'rounded-2xl border border-white/8 bg-gradient-to-b from-white/[0.05] to-white/[0.015] backdrop-blur-xl',
        className
      )}
    >
      {children}
    </div>
  );
}

function SectionHead({
  icon: Icon,
  title,
  count,
  action,
}: {
  icon: ComponentType<{ size?: number; className?: string }>;
  title: string;
  count?: number;
  action?: ReactNode;
}) {
  return (
    <div className="flex items-center justify-between gap-3 mb-4">
      <div className="flex items-center gap-2.5">
        <div className="w-9 h-9 rounded-xl bg-kyn-green/10 border border-kyn-green/20 flex items-center justify-center text-kyn-green">
          <Icon size={16} />
        </div>
        <div>
          <h2 className="font-display font-semibold text-base tracking-tight">{title}</h2>
          {typeof count === 'number' && (
            <p className="text-[11px] text-kyn-metal">{count} record{count === 1 ? '' : 's'}</p>
          )}
        </div>
      </div>
      {action}
    </div>
  );
}

function Empty({ label }: { label: string }) {
  return (
    <div className="rounded-xl border border-dashed border-white/10 px-4 py-8 text-center text-sm text-kyn-metal">
      {label}
    </div>
  );
}

export default function Maintenance() {
  const [items, setItems] = useState<MaintItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [section, setSection] = useState<SectionKey>('jobs');
  const [query, setQuery] = useState('');
  const [updatingId, setUpdatingId] = useState<number | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const data = await apiGet<MaintItem[]>('/api/maintenance');
      setItems(Array.isArray(data) ? data : []);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to load maintenance data');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const byCategory = useCallback(
    (cat: string) =>
      items
        .filter((i) => i.category === cat)
        .filter((i) => {
          if (!query.trim()) return true;
          const q = query.toLowerCase();
          return [i.title, i.subtitle, i.charger_id, i.site, i.model, i.assignee, i.status]
            .join(' ')
            .toLowerCase()
            .includes(q);
        }),
    [items, query]
  );

  const jobs = byCategory('active_job');
  const emergencies = byCategory('emergency');
  const diagnostics = byCategory('diagnostic');
  const firmware = byCategory('firmware');
  const parts = byCategory('spare_part');
  const history = byCategory('repair_history');
  const reports = byCategory('report');

  const kpis = useMemo(() => {
    const activeJobs = items.filter((i) => i.category === 'active_job' && i.status !== 'completed').length;
    const emergencyOpen = items.filter((i) => i.category === 'emergency' && i.status !== 'resolved').length;
    const fwPending = items.filter((i) => i.category === 'firmware' && ['queued', 'pending', 'scheduled'].includes(i.status)).length;
    const lowParts = items.filter((i) => i.category === 'spare_part' && ['low_stock', 'out_of_stock'].includes(i.status)).length;
    return { activeJobs, emergencyOpen, fwPending, lowParts };
  }, [items]);

  const updateStatus = async (id: number, status: string) => {
    setUpdatingId(id);
    try {
      const res = await fetch('/api/maintenance', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, status }),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({ error: res.statusText }));
        throw new Error(err.error || 'Update failed');
      }
      await load();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Update failed');
    } finally {
      setUpdatingId(null);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-kyn-black flex items-center justify-center">
        <LoadingState label="Loading maintenance operations…" />
      </div>
    );
  }

  if (error && items.length === 0) {
    return (
      <div className="min-h-screen bg-kyn-black flex items-center justify-center p-8">
        <div className="max-w-md w-full space-y-4">
          <ErrorState message={error} />
          <button
            type="button"
            onClick={load}
            className="w-full rounded-full bg-kyn-green text-kyn-black text-sm font-bold py-3"
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-kyn-black text-white">
      <div className="pointer-events-none fixed inset-0 bg-[radial-gradient(ellipse_at_top,rgba(0,230,118,0.08),transparent_50%)]" />
      <div className="pointer-events-none fixed inset-0 grid-bg opacity-25" />

      <header className="sticky top-0 z-40 border-b border-white/5 bg-kyn-black/80 backdrop-blur-xl">
        <div className="max-w-7xl mx-auto px-4 md:px-8 h-16 md:h-18 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 min-w-0">
            <Link to="/installer" className="p-2 rounded-lg border border-white/10 text-kyn-metal hover:text-white shrink-0">
              <ArrowLeft size={16} />
            </Link>
            <BrandLogo height={28} />
            <div className="hidden sm:block h-6 w-px bg-white/10" />
            <div className="min-w-0">
              <p className="text-[10px] uppercase tracking-[0.22em] text-kyn-green font-semibold">Field Operations</p>
              <h1 className="font-display font-bold text-sm md:text-base truncate">Maintenance</h1>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={load}
              className="inline-flex items-center gap-2 px-3 py-2 rounded-full border border-white/10 text-xs text-kyn-silver hover:text-white"
            >
              <RefreshCw size={13} /> Refresh
            </button>
            <Link
              to="/predictive-maintenance"
              className="hidden md:inline-flex items-center gap-2 px-4 py-2 rounded-full bg-kyn-green text-kyn-black text-xs font-bold"
            >
              AI Predictive <ArrowRight size={13} />
            </Link>
          </div>
        </div>
      </header>

      <main className="relative z-10 max-w-7xl mx-auto px-4 md:px-8 py-8 md:py-10 space-y-8">
        {error && (
          <div className="rounded-xl border border-amber-500/30 bg-amber-500/10 px-4 py-3 text-sm text-amber-100">
            {error}
          </div>
        )}

        {/* KPI strip */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          {[
            { label: 'Active jobs', value: kpis.activeJobs, icon: Wrench, tone: 'text-kyn-green' },
            { label: 'Emergencies', value: kpis.emergencyOpen, icon: Siren, tone: 'text-red-400' },
            { label: 'Firmware queued', value: kpis.fwPending, icon: Cpu, tone: 'text-sky-300' },
            { label: 'Parts alerts', value: kpis.lowParts, icon: Package, tone: 'text-amber-300' },
          ].map((k, i) => {
            const Icon = k.icon;
            return (
              <motion.div
                key={k.label}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
              >
                <GlassCard className="p-4 md:p-5">
                  <div className="flex items-start justify-between">
                    <div>
                      <p className="text-[10px] uppercase tracking-wider text-kyn-metal">{k.label}</p>
                      <p className={cn('font-display text-3xl font-bold mt-1', k.tone)}>{k.value}</p>
                    </div>
                    <div className={cn('w-9 h-9 rounded-xl border border-white/10 bg-white/[0.03] flex items-center justify-center', k.tone)}>
                      <Icon size={16} />
                    </div>
                  </div>
                </GlassCard>
              </motion.div>
            );
          })}
        </div>

        {/* Controls */}
        <div className="flex flex-col lg:flex-row lg:items-center gap-3 justify-between">
          <div className="flex gap-2 overflow-x-auto pb-1">
            {SECTIONS.map(({ id, label, icon: Icon }) => {
              const count = byCategory(categoryMap[id]).length;
              const active = section === id;
              return (
                <button
                  key={id}
                  type="button"
                  onClick={() => setSection(id)}
                  className={cn(
                    'shrink-0 inline-flex items-center gap-2 px-3.5 py-2 rounded-full text-xs font-semibold border transition-all',
                    active
                      ? 'bg-kyn-green text-kyn-black border-kyn-green'
                      : 'border-white/10 text-kyn-silver hover:text-white hover:border-white/20'
                  )}
                >
                  <Icon size={13} />
                  {label}
                  <span className={cn('px-1.5 py-0.5 rounded-full text-[10px]', active ? 'bg-black/15' : 'bg-white/5')}>
                    {count}
                  </span>
                </button>
              );
            })}
          </div>
          <div className="relative w-full lg:w-72">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-kyn-metal" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search charger, site, tech…"
              className="w-full rounded-full bg-white/[0.03] border border-white/10 pl-9 pr-4 py-2.5 text-sm text-white placeholder:text-kyn-metal outline-none focus:border-kyn-green/40"
            />
          </div>
        </div>

        {/* ACTIVE JOBS */}
        {section === 'jobs' && (
          <section>
            <SectionHead icon={Wrench} title="Active Maintenance Jobs" count={jobs.length} />
            {jobs.length === 0 ? (
              <Empty label="No active maintenance jobs" />
            ) : (
              <div className="grid md:grid-cols-2 gap-3">
                {jobs.map((job, i) => (
                  <motion.div
                    key={job.id}
                    initial={{ opacity: 0, y: 12 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.04 }}
                  >
                    <GlassCard className="p-5 h-full">
                      <div className="flex items-start justify-between gap-3">
                        <div>
                          <div className="flex flex-wrap gap-2 mb-2">
                            <span className={cn('text-[10px] font-semibold uppercase tracking-wide px-2 py-0.5 rounded-full border', priorityTone(job.priority))}>
                              {job.priority}
                            </span>
                            <span className={cn('text-[10px] font-semibold uppercase tracking-wide px-2 py-0.5 rounded-full border', statusTone(job.status))}>
                              {labelize(job.status)}
                            </span>
                          </div>
                          <h3 className="font-display font-semibold text-lg">{job.title}</h3>
                          <p className="text-sm text-kyn-metal mt-1">{job.subtitle}</p>
                        </div>
                        <div className="text-right shrink-0">
                          <p className="text-[10px] text-kyn-metal uppercase tracking-wider">Charger</p>
                          <p className="font-mono text-xs text-kyn-green">{job.charger_id}</p>
                        </div>
                      </div>
                      <div className="mt-4 grid grid-cols-2 gap-2 text-xs">
                        <div className="rounded-xl bg-black/30 border border-white/5 px-3 py-2">
                          <p className="text-kyn-metal">Site</p>
                          <p className="font-medium mt-0.5">{job.site}</p>
                        </div>
                        <div className="rounded-xl bg-black/30 border border-white/5 px-3 py-2">
                          <p className="text-kyn-metal">Model</p>
                          <p className="font-medium mt-0.5">{job.model}</p>
                        </div>
                        <div className="rounded-xl bg-black/30 border border-white/5 px-3 py-2">
                          <p className="text-kyn-metal">Assignee</p>
                          <p className="font-medium mt-0.5">{job.assignee}</p>
                        </div>
                        <div className="rounded-xl bg-black/30 border border-white/5 px-3 py-2">
                          <p className="text-kyn-metal">Schedule</p>
                          <p className="font-medium mt-0.5">{job.scheduled_at}</p>
                        </div>
                      </div>
                      {job.body && <p className="mt-3 text-sm text-kyn-silver leading-relaxed">{job.body}</p>}
                      <div className="mt-4 flex flex-wrap gap-2">
                        {job.status !== 'in_progress' && (
                          <button
                            type="button"
                            disabled={updatingId === job.id}
                            onClick={() => updateStatus(job.id, 'in_progress')}
                            className="px-3 py-1.5 rounded-full bg-kyn-green text-kyn-black text-[11px] font-bold disabled:opacity-50"
                          >
                            Start job
                          </button>
                        )}
                        {job.status !== 'completed' && (
                          <button
                            type="button"
                            disabled={updatingId === job.id}
                            onClick={() => updateStatus(job.id, 'completed')}
                            className="px-3 py-1.5 rounded-full border border-white/15 text-[11px] font-semibold text-kyn-silver hover:text-white disabled:opacity-50"
                          >
                            Mark complete
                          </button>
                        )}
                      </div>
                    </GlassCard>
                  </motion.div>
                ))}
              </div>
            )}
          </section>
        )}

        {/* EMERGENCY */}
        {section === 'emergency' && (
          <section>
            <SectionHead
              icon={Siren}
              title="Emergency Requests"
              count={emergencies.length}
              action={
                <span className="text-[10px] font-semibold uppercase tracking-wider text-red-400 bg-red-500/10 border border-red-500/25 px-2.5 py-1 rounded-full">
                  Priority desk
                </span>
              }
            />
            {emergencies.length === 0 ? (
              <Empty label="No emergency requests" />
            ) : (
              <div className="space-y-3">
                {emergencies.map((item) => (
                  <GlassCard key={item.id} className="p-5 border-red-500/15">
                    <div className="flex flex-col md:flex-row md:items-center gap-4 justify-between">
                      <div className="flex gap-3 min-w-0">
                        <div className="w-11 h-11 rounded-xl bg-red-500/10 border border-red-500/25 flex items-center justify-center text-red-400 shrink-0">
                          <AlertTriangle size={18} />
                        </div>
                        <div className="min-w-0">
                          <div className="flex flex-wrap gap-2 mb-1">
                            <span className={cn('text-[10px] font-semibold uppercase px-2 py-0.5 rounded-full border', priorityTone(item.priority))}>
                              {item.priority}
                            </span>
                            <span className={cn('text-[10px] font-semibold uppercase px-2 py-0.5 rounded-full border', statusTone(item.status))}>
                              {labelize(item.status)}
                            </span>
                          </div>
                          <h3 className="font-display font-semibold text-lg">{item.title}</h3>
                          <p className="text-sm text-kyn-metal mt-0.5">{item.subtitle}</p>
                          <p className="text-sm text-kyn-silver mt-2">{item.body}</p>
                          <div className="mt-3 flex flex-wrap gap-x-4 gap-y-1 text-xs text-kyn-metal">
                            <span className="font-mono text-kyn-green">{item.charger_id}</span>
                            <span>{item.site}</span>
                            <span>{item.model}</span>
                            <span className="inline-flex items-center gap-1"><Clock size={11} />{item.scheduled_at}</span>
                          </div>
                        </div>
                      </div>
                      <div className="flex md:flex-col gap-2 shrink-0">
                        <button
                          type="button"
                          disabled={updatingId === item.id}
                          onClick={() => updateStatus(item.id, 'dispatched')}
                          className="px-4 py-2 rounded-full bg-red-500 text-white text-xs font-bold disabled:opacity-50"
                        >
                          Dispatch
                        </button>
                        <button
                          type="button"
                          disabled={updatingId === item.id}
                          onClick={() => updateStatus(item.id, 'resolved')}
                          className="px-4 py-2 rounded-full border border-white/15 text-xs font-semibold text-kyn-silver disabled:opacity-50"
                        >
                          Resolve
                        </button>
                      </div>
                    </div>
                  </GlassCard>
                ))}
              </div>
            )}
          </section>
        )}

        {/* DIAGNOSTICS */}
        {section === 'diagnostics' && (
          <section>
            <SectionHead icon={Activity} title="Diagnostic Results" count={diagnostics.length} />
            {diagnostics.length === 0 ? (
              <Empty label="No diagnostic results" />
            ) : (
              <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-3">
                {diagnostics.map((d) => (
                  <GlassCard key={d.id} className="p-5">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <p className="text-[10px] uppercase tracking-wider text-kyn-metal">{d.charger_id}</p>
                        <h3 className="font-display font-semibold mt-1">{d.title}</h3>
                      </div>
                      <span className={cn('text-[10px] font-semibold uppercase px-2 py-0.5 rounded-full border', statusTone(d.status))}>
                        {labelize(d.status)}
                      </span>
                    </div>
                    <div className="mt-4 flex items-end gap-2">
                      <p className="font-display text-3xl font-bold text-kyn-green">{d.value}</p>
                      <p className="text-xs text-kyn-metal mb-1">{d.meta}</p>
                    </div>
                    <p className="mt-2 text-sm text-kyn-silver">{d.body}</p>
                    <div className="mt-4 pt-3 border-t border-white/5 flex items-center justify-between text-xs text-kyn-metal">
                      <span>{d.model}</span>
                      <span>{d.scheduled_at}</span>
                    </div>
                  </GlassCard>
                ))}
              </div>
            )}
          </section>
        )}

        {/* FIRMWARE */}
        {section === 'firmware' && (
          <section>
            <SectionHead icon={Cpu} title="Firmware Update" count={firmware.length} />
            {firmware.length === 0 ? (
              <Empty label="No firmware campaigns" />
            ) : (
              <div className="space-y-3">
                {firmware.map((fw) => {
                  const pct = Number(fw.value) || 0;
                  return (
                    <GlassCard key={fw.id} className="p-5">
                      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                        <div className="min-w-0 flex-1">
                          <div className="flex flex-wrap items-center gap-2 mb-1">
                            <HardDrive size={14} className="text-kyn-green" />
                            <h3 className="font-display font-semibold">{fw.title}</h3>
                            <span className={cn('text-[10px] font-semibold uppercase px-2 py-0.5 rounded-full border', statusTone(fw.status))}>
                              {labelize(fw.status)}
                            </span>
                          </div>
                          <p className="text-sm text-kyn-metal">{fw.subtitle}</p>
                          <div className="mt-3 flex flex-wrap gap-x-4 gap-y-1 text-xs text-kyn-silver">
                            <span className="font-mono text-kyn-green">{fw.charger_id || fw.meta}</span>
                            <span>{fw.model}</span>
                            <span>{fw.site}</span>
                            <span>{fw.scheduled_at}</span>
                          </div>
                          <div className="mt-4">
                            <div className="flex justify-between text-[11px] text-kyn-metal mb-1.5">
                              <span>Rollout progress</span>
                              <span className="text-kyn-green font-semibold">{pct}%</span>
                            </div>
                            <div className="h-2 rounded-full bg-white/10 overflow-hidden">
                              <div
                                className="h-full rounded-full bg-gradient-to-r from-kyn-green-dim to-kyn-green"
                                style={{ width: `${Math.min(100, Math.max(0, pct))}%` }}
                              />
                            </div>
                          </div>
                          {fw.body && <p className="mt-3 text-sm text-kyn-silver">{fw.body}</p>}
                        </div>
                        <div className="flex md:flex-col gap-2 shrink-0">
                          {fw.status !== 'running' && fw.status !== 'completed' && (
                            <button
                              type="button"
                              disabled={updatingId === fw.id}
                              onClick={() => updateStatus(fw.id, 'running')}
                              className="px-4 py-2 rounded-full bg-kyn-green text-kyn-black text-xs font-bold disabled:opacity-50"
                            >
                              Start OTA
                            </button>
                          )}
                          {fw.status === 'running' && (
                            <button
                              type="button"
                              disabled={updatingId === fw.id}
                              onClick={() => updateStatus(fw.id, 'completed')}
                              className="px-4 py-2 rounded-full border border-kyn-green/40 text-kyn-green text-xs font-semibold disabled:opacity-50"
                            >
                              Complete
                            </button>
                          )}
                        </div>
                      </div>
                    </GlassCard>
                  );
                })}
              </div>
            )}
          </section>
        )}

        {/* SPARE PARTS */}
        {section === 'parts' && (
          <section>
            <SectionHead icon={Package} title="Spare Parts" count={parts.length} />
            {parts.length === 0 ? (
              <Empty label="No spare parts inventory" />
            ) : (
              <div className="overflow-x-auto rounded-2xl border border-white/10">
                <table className="w-full text-left text-sm min-w-[760px]">
                  <thead className="bg-white/[0.03] text-[10px] uppercase tracking-wider text-kyn-metal">
                    <tr>
                      <th className="px-4 py-3 font-medium">Part</th>
                      <th className="px-4 py-3 font-medium">SKU / Meta</th>
                      <th className="px-4 py-3 font-medium">Compatible</th>
                      <th className="px-4 py-3 font-medium">Stock</th>
                      <th className="px-4 py-3 font-medium">Status</th>
                      <th className="px-4 py-3 font-medium">Location</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5">
                    {parts.map((p) => (
                      <tr key={p.id} className="text-kyn-silver hover:bg-white/[0.02]">
                        <td className="px-4 py-3">
                          <p className="font-medium text-white">{p.title}</p>
                          <p className="text-xs text-kyn-metal mt-0.5">{p.subtitle}</p>
                        </td>
                        <td className="px-4 py-3 font-mono text-xs text-kyn-green">{p.meta}</td>
                        <td className="px-4 py-3 text-xs">{p.model}</td>
                        <td className="px-4 py-3 font-display font-semibold text-white">{p.value}</td>
                        <td className="px-4 py-3">
                          <span className={cn('text-[10px] font-semibold uppercase px-2 py-0.5 rounded-full border', statusTone(p.status))}>
                            {labelize(p.status)}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-xs">{p.site}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </section>
        )}

        {/* REPAIR HISTORY */}
        {section === 'history' && (
          <section>
            <SectionHead icon={History} title="Repair History" count={history.length} />
            {history.length === 0 ? (
              <Empty label="No repair history yet" />
            ) : (
              <div className="relative pl-4 md:pl-6 space-y-4">
                <div className="absolute left-[11px] md:left-[15px] top-2 bottom-2 w-px bg-gradient-to-b from-kyn-green/50 via-white/10 to-transparent" />
                {history.map((h) => (
                  <div key={h.id} className="relative">
                    <div className="absolute -left-[3px] md:left-[-1px] top-5 w-2.5 h-2.5 rounded-full bg-kyn-green shadow-[0_0_12px_rgba(0,230,118,0.6)]" />
                    <GlassCard className="ml-4 md:ml-6 p-5">
                      <div className="flex flex-wrap items-start justify-between gap-3">
                        <div>
                          <p className="text-[10px] uppercase tracking-wider text-kyn-metal">{h.scheduled_at}</p>
                          <h3 className="font-display font-semibold text-lg mt-1">{h.title}</h3>
                          <p className="text-sm text-kyn-metal mt-1">{h.subtitle}</p>
                        </div>
                        <span className={cn('text-[10px] font-semibold uppercase px-2 py-0.5 rounded-full border', statusTone(h.status))}>
                          {labelize(h.status)}
                        </span>
                      </div>
                      <p className="mt-3 text-sm text-kyn-silver leading-relaxed">{h.body}</p>
                      <div className="mt-3 flex flex-wrap gap-x-4 gap-y-1 text-xs text-kyn-metal">
                        <span className="font-mono text-kyn-green">{h.charger_id}</span>
                        <span>{h.site}</span>
                        <span>{h.model}</span>
                        <span>Tech · {h.assignee}</span>
                        {h.value && <span>Duration · {h.value}</span>}
                      </div>
                    </GlassCard>
                  </div>
                ))}
              </div>
            )}
          </section>
        )}

        {/* REPORT */}
        {section === 'report' && (
          <section>
            <SectionHead
              icon={FileText}
              title="Maintenance Report"
              count={reports.length}
              action={
                <button
                  type="button"
                  className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-white/15 text-xs text-kyn-silver hover:text-white"
                >
                  <Download size={13} /> Export PDF
                </button>
              }
            />

            <div className="grid lg:grid-cols-3 gap-4 mb-6">
              <GlassCard className="p-5 lg:col-span-2">
                <p className="text-[10px] uppercase tracking-wider text-kyn-metal mb-3">Operations summary</p>
                <div className="grid sm:grid-cols-3 gap-3">
                  {[
                    { l: 'Jobs completed (30d)', v: String(history.filter((h) => h.status === 'completed').length || history.length) },
                    { l: 'Avg resolution', v: '4.2 h' },
                    { l: 'First-time fix rate', v: '91%' },
                  ].map((s) => (
                    <div key={s.l} className="rounded-xl bg-black/30 border border-white/5 p-4">
                      <p className="text-[11px] text-kyn-metal">{s.l}</p>
                      <p className="font-display text-2xl font-bold text-kyn-green mt-1">{s.v}</p>
                    </div>
                  ))}
                </div>
                <p className="mt-4 text-sm text-kyn-silver leading-relaxed">
                  Network health remains within SLA. Emergency volume is concentrated on public DC corridors;
                  firmware 2.4.1 rollout is the primary preventive lever this week.
                </p>
              </GlassCard>

              <GlassCard className="p-5">
                <p className="text-[10px] uppercase tracking-wider text-kyn-metal mb-3">SLA snapshot</p>
                <div className="space-y-3">
                  {[
                    { l: 'Response < 2h', v: 96 },
                    { l: 'Uptime restore', v: 94 },
                    { l: 'Parts availability', v: 88 },
                  ].map((row) => (
                    <div key={row.l}>
                      <div className="flex justify-between text-xs mb-1">
                        <span className="text-kyn-metal">{row.l}</span>
                        <span className="text-kyn-green font-semibold">{row.v}%</span>
                      </div>
                      <div className="h-1.5 rounded-full bg-white/10 overflow-hidden">
                        <div className="h-full bg-kyn-green rounded-full" style={{ width: `${row.v}%` }} />
                      </div>
                    </div>
                  ))}
                </div>
              </GlassCard>
            </div>

            {reports.length === 0 ? (
              <Empty label="No generated reports" />
            ) : (
              <div className="grid md:grid-cols-2 gap-3">
                {reports.map((r) => (
                  <GlassCard key={r.id} className="p-5">
                    <div className="flex items-start gap-3">
                      <div className="w-10 h-10 rounded-xl bg-kyn-green/10 border border-kyn-green/20 flex items-center justify-center text-kyn-green shrink-0">
                        <ClipboardList size={16} />
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-start justify-between gap-2">
                          <h3 className="font-display font-semibold">{r.title}</h3>
                          <ChevronRight size={14} className="text-kyn-metal shrink-0 mt-1" />
                        </div>
                        <p className="text-sm text-kyn-metal mt-1">{r.subtitle}</p>
                        <p className="text-sm text-kyn-silver mt-2">{r.body}</p>
                        <div className="mt-3 flex flex-wrap gap-3 text-xs text-kyn-metal">
                          <span className="text-kyn-green font-semibold">{r.value}</span>
                          <span>{r.scheduled_at}</span>
                          <span>{r.assignee}</span>
                        </div>
                      </div>
                    </div>
                  </GlassCard>
                ))}
              </div>
            )}
          </section>
        )}

        <footer className="pt-4 pb-8 flex flex-wrap items-center justify-between gap-3 border-t border-white/5">
          <p className="text-[11px] text-kyn-metal">KYNETIK Maintenance · Field ops & network reliability</p>
          <div className="flex gap-3 text-[11px]">
            <Link to="/installer" className="text-kyn-metal hover:text-white">Installer Dashboard</Link>
            <Link to="/predictive-maintenance" className="text-kyn-green hover:text-kyn-green-glow">Predictive AI</Link>
            <Link to="/console" className="text-kyn-metal hover:text-white">Cloud Console</Link>
          </div>
        </footer>
      </main>
    </div>
  );
}

import { useCallback, useEffect, useMemo, useState, type ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  CalendarDays, ChevronLeft, ChevronRight, Clock, MapPin, Phone,
  Wrench, PlugZap, Users, Filter, Plus, X, Check, AlertTriangle,
  ArrowLeft, RefreshCw, Search, CircleDot
} from 'lucide-react';
import BrandLogo from '../components/BrandLogo';
import LoadingState from '../components/LoadingState';
import ErrorState from '../components/ErrorState';
import { apiGet, cn } from '../lib/utils';

type ViewMode = 'day' | 'week' | 'month';
type EventType = 'installation' | 'maintenance' | 'appointment' | 'all';

interface CalEvent {
  id: number;
  title: string;
  type: string;
  customer: string;
  city: string;
  address: string;
  product: string;
  installer: string;
  status: string;
  priority: string;
  starts_at: string;
  ends_at: string | null;
  notes: string;
  contact_phone: string;
}

const TYPE_META: Record<string, { label: string; color: string; bg: string; border: string; icon: typeof PlugZap }> = {
  installation: {
    label: 'Installation',
    color: 'text-kyn-green',
    bg: 'bg-kyn-green/15',
    border: 'border-kyn-green/35',
    icon: PlugZap,
  },
  maintenance: {
    label: 'Maintenance',
    color: 'text-amber-300',
    bg: 'bg-amber-400/15',
    border: 'border-amber-400/35',
    icon: Wrench,
  },
  appointment: {
    label: 'Appointment',
    color: 'text-sky-300',
    bg: 'bg-sky-400/15',
    border: 'border-sky-400/35',
    icon: Users,
  },
};

const HOURS = Array.from({ length: 12 }, (_, i) => i + 7); // 07:00 – 18:00
const WEEKDAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

function startOfDay(d: Date) {
  const x = new Date(d);
  x.setHours(0, 0, 0, 0);
  return x;
}

function addDays(d: Date, n: number) {
  const x = new Date(d);
  x.setDate(x.getDate() + n);
  return x;
}

function startOfWeek(d: Date) {
  const x = startOfDay(d);
  const day = x.getDay(); // 0 Sun
  const diff = day === 0 ? -6 : 1 - day;
  return addDays(x, diff);
}

function startOfMonth(d: Date) {
  return new Date(d.getFullYear(), d.getMonth(), 1);
}

function sameDay(a: Date, b: Date) {
  return a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();
}

function formatDayLabel(d: Date) {
  return d.toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
}

function formatShort(d: Date) {
  return d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short' });
}

function formatTime(iso: string) {
  return new Date(iso).toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' });
}


function eventHour(iso: string) {
  return new Date(iso).getHours() + new Date(iso).getMinutes() / 60;
}

function priorityStyles(p: string) {
  if (p === 'urgent') return 'text-red-400 bg-red-500/10 border-red-500/30';
  if (p === 'high') return 'text-amber-300 bg-amber-500/10 border-amber-500/30';
  if (p === 'low') return 'text-kyn-metal bg-white/5 border-white/10';
  return 'text-kyn-silver bg-white/5 border-white/10';
}

function statusStyles(s: string) {
  if (s === 'confirmed') return 'text-kyn-green';
  if (s === 'completed') return 'text-sky-300';
  if (s === 'cancelled') return 'text-red-400';
  return 'text-kyn-metal';
}

export default function InstallerCalendar() {
  const [events, setEvents] = useState<CalEvent[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [view, setView] = useState<ViewMode>('week');
  const [typeFilter, setTypeFilter] = useState<EventType>('all');
  const [cursor, setCursor] = useState(() => startOfDay(new Date('2026-03-23')));
  const [selected, setSelected] = useState<CalEvent | null>(null);
  const [query, setQuery] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    title: '',
    type: 'installation',
    customer: '',
    city: '',
    product: '',
    installer: 'Youssef Trabelsi',
    starts_at: '',
    ends_at: '',
    notes: '',
    priority: 'normal',
  });

  const load = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const data = await apiGet<CalEvent[]>('/api/installer-calendar');
      setEvents(Array.isArray(data) ? data : []);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to load calendar');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const filtered = useMemo(() => {
    return events.filter((e) => {
      if (typeFilter !== 'all' && e.type !== typeFilter) return false;
      if (query) {
        const q = query.toLowerCase();
        const blob = `${e.title} ${e.customer} ${e.city} ${e.product} ${e.installer}`.toLowerCase();
        if (!blob.includes(q)) return false;
      }
      return true;
    });
  }, [events, typeFilter, query]);

  const upcoming = useMemo(() => {
    const now = new Date('2026-03-23T00:00:00');
    return [...filtered]
      .filter((e) => new Date(e.starts_at) >= now)
      .sort((a, b) => +new Date(a.starts_at) - +new Date(b.starts_at))
      .slice(0, 8);
  }, [filtered]);

  const installations = useMemo(
    () => upcoming.filter((e) => e.type === 'installation'),
    [upcoming]
  );
  const maintenance = useMemo(
    () => upcoming.filter((e) => e.type === 'maintenance'),
    [upcoming]
  );
  const appointments = useMemo(
    () => upcoming.filter((e) => e.type === 'appointment'),
    [upcoming]
  );

  const dayEvents = useMemo(() => {
    return filtered
      .filter((e) => sameDay(new Date(e.starts_at), cursor))
      .sort((a, b) => +new Date(a.starts_at) - +new Date(b.starts_at));
  }, [filtered, cursor]);

  const weekDays = useMemo(() => {
    const start = startOfWeek(cursor);
    return Array.from({ length: 7 }, (_, i) => addDays(start, i));
  }, [cursor]);

  const monthCells = useMemo(() => {
    const first = startOfMonth(cursor);
    const gridStart = startOfWeek(first);
    return Array.from({ length: 42 }, (_, i) => addDays(gridStart, i));
  }, [cursor]);

  const kpis = useMemo(() => {
    const weekStart = startOfWeek(cursor);
    const weekEnd = addDays(weekStart, 7);
    const inWeek = filtered.filter((e) => {
      const t = new Date(e.starts_at);
      return t >= weekStart && t < weekEnd;
    });
    return {
      weekTotal: inWeek.length,
      installs: inWeek.filter((e) => e.type === 'installation').length,
      maint: inWeek.filter((e) => e.type === 'maintenance').length,
      appts: inWeek.filter((e) => e.type === 'appointment').length,
    };
  }, [filtered, cursor]);

  const navigate = (dir: -1 | 1) => {
    if (view === 'day') setCursor((c) => addDays(c, dir));
    else if (view === 'week') setCursor((c) => addDays(c, dir * 7));
    else setCursor((c) => new Date(c.getFullYear(), c.getMonth() + dir, 1));
  };

  const headerLabel = useMemo(() => {
    if (view === 'day') return formatDayLabel(cursor);
    if (view === 'week') {
      const s = startOfWeek(cursor);
      const e = addDays(s, 6);
      return `${formatShort(s)} – ${formatShort(e)} ${e.getFullYear()}`;
    }
    return cursor.toLocaleDateString('en-GB', { month: 'long', year: 'numeric' });
  }, [view, cursor]);

  const createEvent = async () => {
    if (!form.title || !form.starts_at) return;
    setSaving(true);
    try {
      const res = await fetch('/api/installer-calendar', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...form,
          starts_at: new Date(form.starts_at).toISOString(),
          ends_at: form.ends_at ? new Date(form.ends_at).toISOString() : null,
          status: 'scheduled',
        }),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || 'Create failed');
      }
      setShowForm(false);
      setForm({
        title: '',
        type: 'installation',
        customer: '',
        city: '',
        product: '',
        installer: 'Youssef Trabelsi',
        starts_at: '',
        ends_at: '',
        notes: '',
        priority: 'normal',
      });
      await load();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not create event');
    } finally {
      setSaving(false);
    }
  };

  const updateStatus = async (id: number, status: string) => {
    try {
      const res = await fetch('/api/installer-calendar', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, status }),
      });
      if (!res.ok) throw new Error('Update failed');
      await load();
      setSelected((s) => (s && s.id === id ? { ...s, status } : s));
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Update failed');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-kyn-black flex items-center justify-center">
        <LoadingState label="Loading installer calendar…" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-kyn-black text-white">
      {/* Top bar */}
      <header className="sticky top-0 z-40 border-b border-white/5 bg-kyn-void/90 backdrop-blur-xl">
        <div className="max-w-[1600px] mx-auto px-4 md:px-6 h-16 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 min-w-0">
            <Link to="/installer" className="p-2 rounded-lg hover:bg-white/5 text-kyn-metal hover:text-white">
              <ArrowLeft size={18} />
            </Link>
            <BrandLogo height={28} />
            <div className="hidden sm:block h-6 w-px bg-white/10" />
            <div className="hidden sm:flex items-center gap-2 min-w-0">
              <CalendarDays size={16} className="text-kyn-green shrink-0" />
              <div className="min-w-0">
                <p className="text-sm font-semibold truncate">Installer Calendar</p>
                <p className="text-[10px] text-kyn-metal uppercase tracking-wider">Field operations</p>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => load()}
              className="p-2 rounded-lg border border-white/10 text-kyn-metal hover:text-white hover:border-white/20"
              title="Refresh"
            >
              <RefreshCw size={15} />
            </button>
            <button
              type="button"
              onClick={() => setShowForm(true)}
              className="inline-flex items-center gap-2 px-3 md:px-4 py-2 rounded-full bg-kyn-green text-kyn-black text-xs font-bold"
            >
              <Plus size={14} /> <span className="hidden sm:inline">New event</span>
            </button>
          </div>
        </div>
      </header>

      <div className="max-w-[1600px] mx-auto px-4 md:px-6 py-6">
        {error && (
          <div className="mb-4">
            <ErrorState message={error} />
          </div>
        )}

        {/* Controls */}
        <div className="flex flex-col xl:flex-row xl:items-center gap-4 mb-6">
          <div className="flex items-center gap-2">
            <button type="button" onClick={() => navigate(-1)} className="p-2 rounded-lg border border-white/10 hover:bg-white/5">
              <ChevronLeft size={16} />
            </button>
            <button
              type="button"
              onClick={() => setCursor(startOfDay(new Date('2026-03-23')))}
              className="px-3 py-2 rounded-lg border border-white/10 text-xs font-semibold hover:bg-white/5"
            >
              Today
            </button>
            <button type="button" onClick={() => navigate(1)} className="p-2 rounded-lg border border-white/10 hover:bg-white/5">
              <ChevronRight size={16} />
            </button>
            <h1 className="ml-2 font-display text-lg md:text-xl font-bold">{headerLabel}</h1>
          </div>

          <div className="flex flex-wrap items-center gap-2 xl:ml-auto">
            <div className="relative">
              <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-kyn-metal" />
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search customer, city, product…"
                className="pl-9 pr-3 py-2 rounded-xl bg-kyn-steel/50 border border-white/10 text-xs w-52 md:w-64 focus:outline-none focus:border-kyn-green/40"
              />
            </div>

            <div className="inline-flex p-1 rounded-full bg-kyn-steel/50 border border-white/10">
              {([
                ['day', 'Day'],
                ['week', 'Week'],
                ['month', 'Month'],
              ] as const).map(([id, label]) => (
                <button
                  key={id}
                  type="button"
                  onClick={() => setView(id)}
                  className={cn(
                    'px-3 py-1.5 rounded-full text-xs font-semibold transition-colors',
                    view === id ? 'bg-kyn-green text-kyn-black' : 'text-kyn-silver hover:text-white'
                  )}
                >
                  {label}
                </button>
              ))}
            </div>

            <div className="inline-flex p-1 rounded-full bg-kyn-steel/50 border border-white/10 items-center">
              <Filter size={12} className="ml-2 text-kyn-metal" />
              {([
                ['all', 'All'],
                ['installation', 'Install'],
                ['maintenance', 'Maint.'],
                ['appointment', 'Appt'],
              ] as const).map(([id, label]) => (
                <button
                  key={id}
                  type="button"
                  onClick={() => setTypeFilter(id)}
                  className={cn(
                    'px-2.5 py-1.5 rounded-full text-[11px] font-semibold transition-colors',
                    typeFilter === id ? 'bg-white/10 text-white' : 'text-kyn-metal hover:text-white'
                  )}
                >
                  {label}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* KPI strip */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
          {[
            { l: 'This week', v: kpis.weekTotal, c: 'text-white' },
            { l: 'Installations', v: kpis.installs, c: 'text-kyn-green' },
            { l: 'Maintenance', v: kpis.maint, c: 'text-amber-300' },
            { l: 'Appointments', v: kpis.appts, c: 'text-sky-300' },
          ].map((k) => (
            <div key={k.l} className="glass-card rounded-2xl px-4 py-3">
              <p className="text-[10px] uppercase tracking-wider text-kyn-metal">{k.l}</p>
              <p className={cn('font-display text-2xl font-bold mt-0.5', k.c)}>{k.v}</p>
            </div>
          ))}
        </div>

        <div className="grid xl:grid-cols-[1fr_340px] gap-5">
          {/* Main calendar */}
          <div className="min-w-0 space-y-5">
            {view === 'day' && (
              <DayView
                date={cursor}
                events={dayEvents}
                onSelect={setSelected}
              />
            )}
            {view === 'week' && (
              <WeekView
                days={weekDays}
                events={filtered}
                cursor={cursor}
                onSelectDay={(d) => {
                  setCursor(d);
                  setView('day');
                }}
                onSelect={setSelected}
              />
            )}
            {view === 'month' && (
              <MonthView
                cells={monthCells}
                cursor={cursor}
                events={filtered}
                onSelectDay={(d) => {
                  setCursor(d);
                  setView('day');
                }}
                onSelect={setSelected}
              />
            )}

            {/* Daily schedule list (always visible under calendar for context) */}
            <section className="glass-card rounded-2xl p-5">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <p className="text-[10px] uppercase tracking-wider text-kyn-green font-semibold">Daily schedule</p>
                  <h2 className="font-display font-bold text-lg mt-0.5">{formatDayLabel(cursor)}</h2>
                </div>
                <span className="text-xs text-kyn-metal">{dayEvents.length} event{dayEvents.length === 1 ? '' : 's'}</span>
              </div>
              {dayEvents.length === 0 ? (
                <p className="text-sm text-kyn-metal py-8 text-center">No events scheduled for this day.</p>
              ) : (
                <div className="space-y-2">
                  {dayEvents.map((e) => (
                    <EventRow key={e.id} event={e} onClick={() => setSelected(e)} />
                  ))}
                </div>
              )}
            </section>
          </div>

          {/* Side panels */}
          <aside className="space-y-4">
            <SideList
              title="Upcoming installations"
              accent="text-kyn-green"
              items={installations}
              empty="No upcoming installations"
              onSelect={setSelected}
            />
            <SideList
              title="Maintenance visits"
              accent="text-amber-300"
              items={maintenance}
              empty="No maintenance visits"
              onSelect={setSelected}
            />
            <SideList
              title="Customer appointments"
              accent="text-sky-300"
              items={appointments}
              empty="No appointments"
              onSelect={setSelected}
            />

            <div className="glass-card rounded-2xl p-4">
              <p className="text-[10px] uppercase tracking-wider text-kyn-metal mb-3">Legend</p>
              <div className="space-y-2">
                {Object.entries(TYPE_META).map(([key, meta]) => {
                  const Icon = meta.icon;
                  return (
                    <div key={key} className="flex items-center gap-2 text-xs">
                      <span className={cn('w-2.5 h-2.5 rounded-full', meta.bg, meta.border, 'border')} />
                      <Icon size={12} className={meta.color} />
                      <span className="text-kyn-silver">{meta.label}</span>
                    </div>
                  );
                })}
              </div>
            </div>
          </aside>
        </div>
      </div>

      {/* Detail drawer */}
      <AnimatePresence>
        {selected && (
          <motion.div
            className="fixed inset-0 z-50 flex justify-end"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <button type="button" className="absolute inset-0 bg-black/60" onClick={() => setSelected(null)} aria-label="Close" />
            <motion.aside
              initial={{ x: 40, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: 40, opacity: 0 }}
              className="relative w-full max-w-md h-full bg-kyn-void border-l border-white/10 p-6 overflow-y-auto"
            >
              <div className="flex items-start justify-between gap-3 mb-6">
                <div>
                  <TypeBadge type={selected.type} />
                  <h3 className="font-display text-xl font-bold mt-2">{selected.title}</h3>
                </div>
                <button type="button" onClick={() => setSelected(null)} className="p-2 rounded-lg hover:bg-white/5">
                  <X size={18} />
                </button>
              </div>

              <div className="space-y-3 text-sm">
                <InfoLine icon={Clock} label="When" value={`${formatTime(selected.starts_at)}${selected.ends_at ? ` – ${formatTime(selected.ends_at)}` : ''} · ${formatShort(new Date(selected.starts_at))}`} />
                <InfoLine icon={Users} label="Customer" value={selected.customer} />
                <InfoLine icon={MapPin} label="Location" value={`${selected.address ? selected.address + ', ' : ''}${selected.city}`} />
                <InfoLine icon={PlugZap} label="Product" value={selected.product || '—'} />
                <InfoLine icon={Wrench} label="Installer" value={selected.installer || '—'} />
                {selected.contact_phone && <InfoLine icon={Phone} label="Contact" value={selected.contact_phone} />}
              </div>

              <div className="mt-5 flex flex-wrap gap-2">
                <span className={cn('text-[10px] px-2 py-1 rounded-full border capitalize', priorityStyles(selected.priority))}>
                  {selected.priority} priority
                </span>
                <span className={cn('text-[10px] px-2 py-1 rounded-full border border-white/10 capitalize', statusStyles(selected.status))}>
                  {selected.status}
                </span>
              </div>

              {selected.notes && (
                <div className="mt-5 rounded-xl border border-white/8 bg-white/[0.03] p-4">
                  <p className="text-[10px] uppercase tracking-wider text-kyn-metal mb-1">Notes</p>
                  <p className="text-sm text-kyn-silver leading-relaxed">{selected.notes}</p>
                </div>
              )}

              <div className="mt-6 grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => updateStatus(selected.id, 'confirmed')}
                  className="rounded-xl bg-kyn-green/15 border border-kyn-green/30 text-kyn-green text-xs font-semibold py-2.5 inline-flex items-center justify-center gap-1.5"
                >
                  <Check size={14} /> Confirm
                </button>
                <button
                  type="button"
                  onClick={() => updateStatus(selected.id, 'completed')}
                  className="rounded-xl bg-white/5 border border-white/10 text-xs font-semibold py-2.5"
                >
                  Mark done
                </button>
              </div>
            </motion.aside>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Create modal */}
      <AnimatePresence>
        {showForm && (
          <motion.div
            className="fixed inset-0 z-50 flex items-center justify-center p-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <button type="button" className="absolute inset-0 bg-black/70" onClick={() => setShowForm(false)} aria-label="Close" />
            <motion.div
              initial={{ scale: 0.96, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.96, opacity: 0 }}
              className="relative w-full max-w-lg rounded-2xl border border-white/10 bg-kyn-void p-6 shadow-2xl"
            >
              <div className="flex items-center justify-between mb-5">
                <h3 className="font-display font-bold text-lg">New calendar event</h3>
                <button type="button" onClick={() => setShowForm(false)} className="p-2 rounded-lg hover:bg-white/5">
                  <X size={16} />
                </button>
              </div>
              <div className="grid sm:grid-cols-2 gap-3">
                <Field label="Title" className="sm:col-span-2">
                  <input
                    className="field"
                    value={form.title}
                    onChange={(e) => setForm({ ...form, title: e.target.value })}
                    placeholder="Installation NOVA…"
                  />
                </Field>
                <Field label="Type">
                  <select className="field" value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })}>
                    <option value="installation">Installation</option>
                    <option value="maintenance">Maintenance</option>
                    <option value="appointment">Appointment</option>
                  </select>
                </Field>
                <Field label="Priority">
                  <select className="field" value={form.priority} onChange={(e) => setForm({ ...form, priority: e.target.value })}>
                    <option value="low">Low</option>
                    <option value="normal">Normal</option>
                    <option value="high">High</option>
                    <option value="urgent">Urgent</option>
                  </select>
                </Field>
                <Field label="Customer">
                  <input className="field" value={form.customer} onChange={(e) => setForm({ ...form, customer: e.target.value })} />
                </Field>
                <Field label="City">
                  <input className="field" value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} />
                </Field>
                <Field label="Product">
                  <input className="field" value={form.product} onChange={(e) => setForm({ ...form, product: e.target.value })} />
                </Field>
                <Field label="Installer">
                  <input className="field" value={form.installer} onChange={(e) => setForm({ ...form, installer: e.target.value })} />
                </Field>
                <Field label="Starts">
                  <input
                    type="datetime-local"
                    className="field"
                    value={form.starts_at}
                    onChange={(e) => setForm({ ...form, starts_at: e.target.value })}
                  />
                </Field>
                <Field label="Ends">
                  <input
                    type="datetime-local"
                    className="field"
                    value={form.ends_at}
                    onChange={(e) => setForm({ ...form, ends_at: e.target.value })}
                  />
                </Field>
                <Field label="Notes" className="sm:col-span-2">
                  <textarea
                    className="field min-h-[72px] resize-none"
                    value={form.notes}
                    onChange={(e) => setForm({ ...form, notes: e.target.value })}
                  />
                </Field>
              </div>
              <div className="mt-5 flex justify-end gap-2">
                <button type="button" onClick={() => setShowForm(false)} className="px-4 py-2 rounded-xl border border-white/10 text-xs font-semibold">
                  Cancel
                </button>
                <button
                  type="button"
                  disabled={saving || !form.title || !form.starts_at}
                  onClick={createEvent}
                  className="px-4 py-2 rounded-xl bg-kyn-green text-kyn-black text-xs font-bold disabled:opacity-40"
                >
                  {saving ? 'Saving…' : 'Create event'}
                </button>
              </div>
              <style>{`
                .field {
                  width: 100%;
                  border-radius: 0.75rem;
                  border: 1px solid rgba(255,255,255,0.1);
                  background: rgba(26,26,30,0.8);
                  padding: 0.55rem 0.75rem;
                  font-size: 0.75rem;
                  color: white;
                  outline: none;
                }
                .field:focus { border-color: rgba(0,230,118,0.4); }
              `}</style>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function Field({ label, children, className }: { label: string; children: ReactNode; className?: string }) {
  return (
    <label className={cn('block', className)}>
      <span className="text-[10px] uppercase tracking-wider text-kyn-metal mb-1 block">{label}</span>
      {children}
    </label>
  );
}

function TypeBadge({ type }: { type: string }) {
  const meta = TYPE_META[type] || TYPE_META.appointment;
  const Icon = meta.icon;
  return (
    <span className={cn('inline-flex items-center gap-1.5 text-[10px] font-semibold px-2 py-1 rounded-full border', meta.bg, meta.border, meta.color)}>
      <Icon size={11} /> {meta.label}
    </span>
  );
}

function InfoLine({ icon: Icon, label, value }: { icon: typeof Clock; label: string; value: string }) {
  return (
    <div className="flex gap-3">
      <div className="w-8 h-8 rounded-lg bg-white/5 border border-white/8 flex items-center justify-center shrink-0">
        <Icon size={14} className="text-kyn-green" />
      </div>
      <div>
        <p className="text-[10px] uppercase tracking-wider text-kyn-metal">{label}</p>
        <p className="text-sm text-kyn-silver mt-0.5">{value}</p>
      </div>
    </div>
  );
}

function EventRow({ event, onClick }: { event: CalEvent; onClick: () => void }) {
  const meta = TYPE_META[event.type] || TYPE_META.appointment;
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        'w-full text-left rounded-xl border p-3.5 flex gap-3 hover:bg-white/[0.03] transition-colors',
        meta.border
      )}
    >
      <div className={cn('w-1 rounded-full shrink-0', meta.bg.replace('/15', ''))} style={{ background: event.type === 'installation' ? '#00e676' : event.type === 'maintenance' ? '#fbbf24' : '#38bdf8' }} />
      <div className="min-w-0 flex-1">
        <div className="flex items-start justify-between gap-2">
          <div className="min-w-0">
            <p className="font-semibold text-sm truncate">{event.title}</p>
            <p className="text-[11px] text-kyn-metal mt-0.5 truncate">
              {event.customer} · {event.city}
            </p>
          </div>
          <div className="text-right shrink-0">
            <p className="text-xs font-semibold text-white">{formatTime(event.starts_at)}</p>
            {event.ends_at && <p className="text-[10px] text-kyn-metal">{formatTime(event.ends_at)}</p>}
          </div>
        </div>
        <div className="mt-2 flex flex-wrap items-center gap-2">
          <TypeBadge type={event.type} />
          <span className={cn('text-[10px] px-2 py-0.5 rounded-full border capitalize', priorityStyles(event.priority))}>
            {event.priority}
          </span>
          <span className="text-[10px] text-kyn-metal truncate">{event.product}</span>
        </div>
      </div>
    </button>
  );
}

function SideList({
  title,
  accent,
  items,
  empty,
  onSelect,
}: {
  title: string;
  accent: string;
  items: CalEvent[];
  empty: string;
  onSelect: (e: CalEvent) => void;
}) {
  return (
    <section className="glass-card rounded-2xl p-4">
      <div className="flex items-center justify-between mb-3">
        <h3 className={cn('text-xs font-semibold uppercase tracking-wider', accent)}>{title}</h3>
        <span className="text-[10px] text-kyn-metal">{items.length}</span>
      </div>
      {items.length === 0 ? (
        <p className="text-xs text-kyn-metal py-4 text-center">{empty}</p>
      ) : (
        <div className="space-y-2">
          {items.map((e) => (
            <button
              key={e.id}
              type="button"
              onClick={() => onSelect(e)}
              className="w-full text-left rounded-xl border border-white/8 bg-black/20 hover:border-white/15 p-3 transition-colors"
            >
              <div className="flex items-start justify-between gap-2">
                <p className="text-xs font-semibold leading-snug">{e.title}</p>
                {e.priority === 'urgent' && <AlertTriangle size={12} className="text-red-400 shrink-0" />}
              </div>
              <p className="text-[10px] text-kyn-metal mt-1">
                {formatShort(new Date(e.starts_at))} · {formatTime(e.starts_at)}
              </p>
              <p className="text-[10px] text-kyn-silver mt-0.5 truncate">
                {e.customer} · {e.city}
              </p>
            </button>
          ))}
        </div>
      )}
    </section>
  );
}

function DayView({ date, events, onSelect }: { date: Date; events: CalEvent[]; onSelect: (e: CalEvent) => void }) {
  return (
    <section className="glass-card rounded-2xl overflow-hidden">
      <div className="px-4 py-3 border-b border-white/5 flex items-center justify-between">
        <p className="text-xs font-semibold text-kyn-silver">Day timeline · 07:00 – 18:00</p>
        <CircleDot size={14} className="text-kyn-green" />
      </div>
      <div className="relative max-h-[560px] overflow-y-auto">
        {HOURS.map((h) => (
          <div key={h} className="relative grid grid-cols-[56px_1fr] border-b border-white/[0.04] min-h-[64px]">
            <div className="text-[10px] text-kyn-metal px-2 py-2 text-right">{String(h).padStart(2, '0')}:00</div>
            <div className="relative border-l border-white/[0.04] p-1">
              {events
                .filter((e) => {
                  const eh = eventHour(e.starts_at);
                  return eh >= h && eh < h + 1;
                })
                .map((e) => {
                  const meta = TYPE_META[e.type] || TYPE_META.appointment;
                  return (
                    <button
                      key={e.id}
                      type="button"
                      onClick={() => onSelect(e)}
                      className={cn('w-full text-left rounded-lg border px-2.5 py-2 mb-1', meta.bg, meta.border)}
                    >
                      <p className={cn('text-[11px] font-semibold', meta.color)}>
                        {formatTime(e.starts_at)} · {e.title}
                      </p>
                      <p className="text-[10px] text-kyn-metal mt-0.5">
                        {e.customer} · {e.city}
                      </p>
                    </button>
                  );
                })}
            </div>
          </div>
        ))}
        {events.length === 0 && (
          <p className="text-sm text-kyn-metal text-center py-16">No events on {formatDayLabel(date)}</p>
        )}
      </div>
    </section>
  );
}

function WeekView({
  days,
  events,
  cursor,
  onSelectDay,
  onSelect,
}: {
  days: Date[];
  events: CalEvent[];
  cursor: Date;
  onSelectDay: (d: Date) => void;
  onSelect: (e: CalEvent) => void;
}) {
  return (
    <section className="glass-card rounded-2xl overflow-hidden">
      <div className="grid grid-cols-7 border-b border-white/5">
        {days.map((d, i) => {
          const isToday = sameDay(d, new Date('2026-03-23'));
          const isActive = sameDay(d, cursor);
          return (
            <button
              key={i}
              type="button"
              onClick={() => onSelectDay(d)}
              className={cn(
                'px-1 py-3 text-center border-r border-white/[0.04] last:border-r-0',
                isActive && 'bg-kyn-green/10'
              )}
            >
              <p className="text-[10px] text-kyn-metal uppercase">{WEEKDAYS[i]}</p>
              <p
                className={cn(
                  'mt-1 mx-auto w-8 h-8 rounded-full flex items-center justify-center text-sm font-semibold',
                  isToday && 'bg-kyn-green text-kyn-black',
                  !isToday && isActive && 'text-kyn-green',
                  !isToday && !isActive && 'text-white'
                )}
              >
                {d.getDate()}
              </p>
            </button>
          );
        })}
      </div>
      <div className="grid grid-cols-7 min-h-[420px]">
        {days.map((d, i) => {
          const dayEvs = events
            .filter((e) => sameDay(new Date(e.starts_at), d))
            .sort((a, b) => +new Date(a.starts_at) - +new Date(b.starts_at));
          return (
            <div key={i} className="border-r border-white/[0.04] last:border-r-0 p-1.5 space-y-1 min-h-[420px]">
              {dayEvs.map((e) => {
                const meta = TYPE_META[e.type] || TYPE_META.appointment;
                return (
                  <button
                    key={e.id}
                    type="button"
                    onClick={() => onSelect(e)}
                    className={cn('w-full text-left rounded-md border px-1.5 py-1.5', meta.bg, meta.border)}
                  >
                    <p className="text-[9px] font-semibold text-white leading-tight line-clamp-2">{e.title}</p>
                    <p className={cn('text-[9px] mt-0.5', meta.color)}>{formatTime(e.starts_at)}</p>
                  </button>
                );
              })}
            </div>
          );
        })}
      </div>
    </section>
  );
}

function MonthView({
  cells,
  cursor,
  events,
  onSelectDay,
  onSelect,
}: {
  cells: Date[];
  cursor: Date;
  events: CalEvent[];
  onSelectDay: (d: Date) => void;
  onSelect: (e: CalEvent) => void;
}) {
  const month = cursor.getMonth();
  return (
    <section className="glass-card rounded-2xl overflow-hidden">
      <div className="grid grid-cols-7 border-b border-white/5">
        {WEEKDAYS.map((d) => (
          <div key={d} className="px-2 py-2 text-center text-[10px] uppercase tracking-wider text-kyn-metal">
            {d}
          </div>
        ))}
      </div>
      <div className="grid grid-cols-7">
        {cells.map((d, i) => {
          const inMonth = d.getMonth() === month;
          const isToday = sameDay(d, new Date('2026-03-23'));
          const dayEvs = events.filter((e) => sameDay(new Date(e.starts_at), d));
          return (
            <div
              key={i}
              className={cn(
                'min-h-[96px] border-r border-b border-white/[0.04] p-1.5',
                !inMonth && 'opacity-35'
              )}
            >
              <button
                type="button"
                onClick={() => onSelectDay(d)}
                className={cn(
                  'w-7 h-7 rounded-full text-xs font-semibold mb-1',
                  isToday ? 'bg-kyn-green text-kyn-black' : 'text-kyn-silver hover:bg-white/5'
                )}
              >
                {d.getDate()}
              </button>
              <div className="space-y-0.5">
                {dayEvs.slice(0, 3).map((e) => {
                  const color =
                    e.type === 'installation' ? 'bg-kyn-green' : e.type === 'maintenance' ? 'bg-amber-400' : 'bg-sky-400';
                  return (
                    <button
                      key={e.id}
                      type="button"
                      onClick={() => onSelect(e)}
                      className="w-full flex items-center gap-1 text-left"
                    >
                      <span className={cn('w-1.5 h-1.5 rounded-full shrink-0', color)} />
                      <span className="text-[9px] text-kyn-silver truncate">{e.title}</span>
                    </button>
                  );
                })}
                {dayEvs.length > 3 && (
                  <p className="text-[9px] text-kyn-metal pl-2.5">+{dayEvs.length - 3} more</p>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}

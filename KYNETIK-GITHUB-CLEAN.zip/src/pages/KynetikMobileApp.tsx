import { useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  ArrowRight, Smartphone, Sparkles, CheckCircle2, Menu, X, Layers,
  Zap, MapPin, BarChart3, User, Bell, Wallet, History, Shield
} from 'lucide-react';
import BrandLogo from '../components/BrandLogo';
import { PhoneShell } from '../components/mobile/PhoneChrome';
import KynetikAppFlow from '../components/mobile/KynetikAppFlow';
import { cn } from '../lib/utils';

const flows = [
  { id: 'splash', title: 'Splash', desc: 'Logo + slogan + energy animation' },
  { id: 'onboarding', title: 'Onboarding', desc: '3 screens · véhicule · contrôle' },
  { id: 'auth', title: 'Login / Register', desc: 'Particulier · Pro · Google · Apple' },
  { id: 'home', title: 'Dashboard', desc: 'Charger live · Start/Pause · stats' },
  { id: 'charge', title: 'Charge', desc: 'Realtime · schedule · power' },
  { id: 'analytics', title: 'Energy', desc: 'kWh · cost · CO₂ · charts' },
  { id: 'history', title: 'History', desc: 'Date · energy · cost · duration' },
  { id: 'devices', title: 'Devices', desc: 'Rename · share · firmware' },
  { id: 'map', title: 'Map Network', desc: 'Stations · filters · navigation' },
  { id: 'wallet', title: 'Payments', desc: 'Wallet · card · mobile · plan' },
  { id: 'notifications', title: 'Notifications', desc: 'Charge · alerts · OTA' },
  { id: 'profile', title: 'Profile', desc: 'Account · vehicle · logout' },
];

const navSpec = [
  { icon: '⌂', label: 'Home' },
  { icon: '⚡', label: 'Charge' },
  { icon: '⌖', label: 'Map' },
  { icon: '◉', label: 'Analytics' },
  { icon: '☺', label: 'Profile' },
];

export default function KynetikMobileApp() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [activeScreen, setActiveScreen] = useState('splash');
  const [key, setKey] = useState(0);

  return (
    <div className="min-h-screen bg-kyn-black text-white">
      <header className="sticky top-0 z-50 border-b border-white/5 bg-kyn-black/90 backdrop-blur-xl">
        <div className="max-w-7xl mx-auto px-5 md:px-8 h-16 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <BrandLogo height={28} />
            <span className="hidden sm:inline text-[10px] font-semibold tracking-[0.2em] uppercase text-kyn-green border border-kyn-green/30 rounded-full px-2 py-0.5">
              Phase 19 · Mobile App
            </span>
          </div>
          <div className="hidden md:flex items-center gap-5 text-xs text-kyn-silver">
            <Link to="/delivery" className="hover:text-white">Architecture</Link>
            <Link to="/console" className="hover:text-white">Cloud</Link>
            <Link to="/portal" className="hover:text-white">Web Portal</Link>
            <Link to="/app-landing" className="hover:text-white">App Landing</Link>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => {
                setKey((k) => k + 1);
                setActiveScreen('splash');
              }}
              className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border border-white/15 text-xs font-semibold hover:border-kyn-green/40"
            >
              Restart flow
            </button>
            <Link
              to="/console"
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-kyn-green text-kyn-black text-xs font-bold"
            >
              Phase 20 Cloud <ArrowRight size={13} />
            </Link>
            <button type="button" className="md:hidden p-2 text-kyn-silver" onClick={() => setMenuOpen(!menuOpen)}>
              {menuOpen ? <X size={18} /> : <Menu size={18} />}
            </button>
          </div>
        </div>
        {menuOpen && (
          <div className="md:hidden border-t border-white/5 px-5 py-3 space-y-2 bg-kyn-void">
            {[
              ['/delivery', 'Architecture'],
              ['/console', 'Cloud Dashboard'],
              ['/portal', 'Customer Portal'],
              ['/app-landing', 'App Landing'],
            ].map(([to, l]) => (
              <Link key={to} to={to} onClick={() => setMenuOpen(false)} className="block text-sm text-kyn-silver py-1">
                {l}
              </Link>
            ))}
          </div>
        )}
      </header>

      {/* Hero */}
      <section className="relative pt-12 md:pt-16 pb-8 overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(0,230,118,0.12),transparent_55%)]" />
        <div className="relative z-10 max-w-7xl mx-auto px-5 md:px-8 grid lg:grid-cols-[1.05fr_0.95fr] gap-10 lg:gap-14 items-center">
          <div>
            <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}>
              <p className="text-kyn-green text-xs font-semibold tracking-[0.3em] uppercase mb-4 flex items-center gap-2">
                <Smartphone size={14} /> Phase 19 · KYNETIK Mobile Application
              </p>
              <h1 className="font-display text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight leading-[1.05]">
                UX/UI complète.
                <br />
                <span className="text-kyn-green text-glow">Prête pour le dev.</span>
              </h1>
              <p className="mt-5 text-kyn-silver text-base md:text-lg max-w-xl leading-relaxed">
                Splash → Onboarding → Auth → Dashboard → Charge → Energy → Map → Wallet → Profile.
                Navigation 5 onglets. Données live via API portal & charge points.
              </p>
              <div className="mt-6 flex flex-wrap gap-2">
                {['L\'énergie en mouvement', 'OCPP-ready control', 'FR · Particulier & Pro'].map((t) => (
                  <span key={t} className="text-[11px] px-3 py-1.5 rounded-full border border-white/10 bg-white/[0.03] text-kyn-metal">
                    {t}
                  </span>
                ))}
              </div>
              <div className="mt-8 flex flex-wrap gap-3">
                <a
                  href="#prototype"
                  className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-kyn-green text-kyn-black text-sm font-bold"
                >
                  Tester le prototype <ArrowRight size={16} />
                </a>
                <Link
                  to="/dev-handoff"
                  className="inline-flex items-center gap-2 px-6 py-3 rounded-full border border-white/15 text-sm font-semibold"
                >
                  <Layers size={15} /> Dev handoff
                </Link>
              </div>
            </motion.div>

            {/* Bottom nav spec */}
            <div className="mt-10 rounded-2xl border border-white/10 bg-kyn-void p-5">
              <p className="text-[10px] uppercase tracking-wider text-kyn-metal font-semibold mb-3">Bottom navigation</p>
              <div className="grid grid-cols-5 gap-2">
                {navSpec.map((t) => (
                  <div key={t.label} className="rounded-xl border border-white/8 bg-black/30 py-3 text-center">
                    <p className="text-base">{t.icon}</p>
                    <p className="text-[10px] font-semibold mt-1 text-kyn-silver">{t.label}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Live phone */}
          <div id="prototype" className="flex flex-col items-center scroll-mt-24">
            <PhoneShell>
              <KynetikAppFlow key={key} onScreenChange={setActiveScreen} />
            </PhoneShell>
            <p className="mt-5 text-[11px] text-kyn-metal">
              Écran actif · <span className="text-kyn-green font-semibold capitalize">{activeScreen}</span>
            </p>
          </div>
        </div>
      </section>

      {/* Screen map */}
      <section className="py-16 md:py-20 border-t border-white/5">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <div className="flex flex-wrap items-end justify-between gap-4 mb-8">
            <div>
              <p className="text-kyn-green text-xs font-semibold tracking-[0.25em] uppercase mb-2">Screen inventory</p>
              <h2 className="font-display text-2xl md:text-3xl font-bold">12 écrans product-ready</h2>
            </div>
            <p className="text-sm text-kyn-metal max-w-md">
              Cliquez dans le téléphone pour parcourir le flow. Les stats tirent les sessions & bornes depuis Supabase.
            </p>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
            {flows.map((f, i) => (
              <motion.div
                key={f.id}
                initial={{ opacity: 0, y: 12 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.03 }}
                className={cn(
                  'rounded-2xl border p-4 transition-colors',
                  activeScreen === f.id
                    ? 'border-kyn-green/40 bg-kyn-green/10'
                    : 'border-white/8 bg-white/[0.02]'
                )}
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="text-[10px] font-mono text-kyn-metal">0{i + 1}</span>
                  {activeScreen === f.id && <CheckCircle2 size={14} className="text-kyn-green" />}
                </div>
                <p className="font-display font-semibold mt-2">{f.title}</p>
                <p className="text-[11px] text-kyn-metal mt-1 leading-relaxed">{f.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Feature grid matching brief */}
      <section className="py-16 border-t border-white/5 bg-kyn-void">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <h2 className="font-display text-2xl md:text-3xl font-bold mb-8">Couverture du brief</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[
              { icon: Sparkles, t: 'Splash + Onboarding', d: 'Slogan « L’énergie en mouvement », 3 slides, CTA Commencer' },
              { icon: Shield, t: 'Auth Particulier / Pro', d: 'Email, téléphone, password · Google · Apple · types entreprise' },
              { icon: Zap, t: 'Dashboard + Control', d: 'PRIME 22 kW · power · battery % · remaining · Start/Pause/Settings' },
              { icon: BarChart3, t: 'Energy Dashboard', d: 'kWh · TND · CO₂ · daily/weekly/monthly charts' },
              { icon: History, t: 'Charging History', d: 'Table Date | Energy | Cost | Duration' },
              { icon: MapPin, t: 'Map Network', d: 'Stations · 7/22/Fast filters · navigation' },
              { icon: Wallet, t: 'Payments', d: 'Wallet balance · carte · mobile · subscription' },
              { icon: Bell, t: 'Notifications', d: 'Charge done · anomaly · firmware OTA' },
              { icon: User, t: 'Profile & Devices', d: 'Vehicle · rename · share · firmware · maintenance' },
            ].map(({ icon: Icon, t, d }) => (
              <div key={t} className="rounded-2xl border border-white/8 bg-black/30 p-5">
                <Icon className="text-kyn-green mb-3" size={18} />
                <p className="font-semibold">{t}</p>
                <p className="text-sm text-kyn-metal mt-1.5 leading-relaxed">{d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Next phase CTA */}
      <section className="py-20 border-t border-white/5 relative">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(0,230,118,0.1),transparent_55%)]" />
        <div className="relative z-10 max-w-3xl mx-auto px-5 text-center">
          <p className="text-kyn-green text-xs font-semibold tracking-[0.28em] uppercase mb-3">Next</p>
          <h2 className="font-display text-3xl md:text-4xl font-bold">
            Phase 20 — Cloud Dashboard
          </h2>
          <p className="mt-4 text-kyn-silver">
            Fleet · multi-stations · revenue · remote control · OCPP monitoring · installer portal
          </p>
          <div className="mt-8 flex flex-wrap justify-center gap-3">
            <Link
              to="/console"
              className="inline-flex items-center gap-2 px-7 py-3.5 rounded-full bg-kyn-green text-kyn-black text-sm font-bold"
            >
              Ouvrir Cloud Console <ArrowRight size={16} />
            </Link>
            <Link
              to="/delivery"
              className="inline-flex items-center gap-2 px-7 py-3.5 rounded-full border border-white/15 text-sm font-semibold"
            >
              Delivery hub
            </Link>
          </div>
        </div>
      </section>

      <footer className="border-t border-white/5 py-8">
        <div className="max-w-7xl mx-auto px-5 md:px-8 flex flex-wrap justify-between gap-3 items-center">
          <BrandLogo height={24} />
          <p className="text-[11px] text-kyn-metal">Phase 19 · Mobile UX/UI · KYNETIK App</p>
        </div>
      </footer>
    </div>
  );
}

import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  Palette, Share2, Smartphone, Globe, Cloud,
  GraduationCap, Presentation, Briefcase, Package, ArrowRight, Zap, Sparkles, Rocket,
  Play, Code2, Star, Layers
} from 'lucide-react';
import BrandLogo from '../components/BrandLogo';
import AppDownloadCTA from '../components/AppDownloadCTA';

const modules = [
  { to: '/production', title: 'Production Assets', desc: 'Phase 15 · library · motion · QA', icon: Layers },
  { to: '/showcase', title: 'Final Showcase', desc: 'Phase 14 · investor portfolio', icon: Star },
  { to: '/prototype', title: 'Interactive Prototype', desc: 'App · Web · Cloud clickable flows', icon: Play },
  { to: '/handoff', title: 'Developer Handoff', desc: 'Tokens, components, routes, assets', icon: Code2 },
  { to: '/', title: 'Premium Homepage', desc: 'Full marketing site · Tesla / ABB grade', icon: Rocket },
  { to: '/console', title: 'Cloud Dashboard', desc: 'Live operator SaaS console', icon: Cloud },
  { to: '/product-system', title: 'Product System', desc: 'GO portable · NOVA · PRIME · EDGE · PRO', icon: Package },
  { to: '/app-landing', title: 'KYNETIK App', desc: 'Mobile product marketing', icon: Smartphone },
  { to: '/brand', title: 'Brand Foundation', desc: 'Colors, typography, logo lockups', icon: Palette },
  { to: '/tokens', title: 'UI Tokens', desc: 'Buttons, cards, radius, digital kit', icon: Sparkles },
  { to: '/app', title: 'Mobile App UX', desc: '35+ screens · full driver journey', icon: Smartphone },
  { to: '/website', title: 'Website UX', desc: '7-section homepage architecture', icon: Globe },
  { to: '/academy', title: 'Academy Platform', desc: 'Courses, paths, certification', icon: GraduationCap },
  { to: '/products', title: 'Product Catalog', desc: 'DB-driven hardware cards', icon: Package },
  { to: '/social', title: 'Social Media Kit', desc: 'Campaign templates multi-format', icon: Share2 },
  { to: '/investor', title: 'Investor Deck', desc: 'Pitch slides system', icon: Presentation },
  { to: '/stationery', title: 'Stationery', desc: 'Cards, letterhead, folder', icon: Briefcase },
];

export default function Overview() {
  return (
    <div className="relative overflow-hidden">
      <section className="relative min-h-[80vh] flex items-center grid-bg">
        <div className="absolute inset-0">
          <img src="/images/hero-city.jpg" alt="" className="w-full h-full object-cover opacity-30" />
          <div className="absolute inset-0 bg-gradient-to-r from-kyn-black via-kyn-black/90 to-kyn-black/60" />
          <div className="absolute inset-0 bg-gradient-to-t from-kyn-black via-transparent to-kyn-black/40" />
        </div>

        <div className="relative z-10 max-w-6xl mx-auto px-6 md:px-10 py-20">
          <motion.div initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7 }}>
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-kyn-green/30 bg-kyn-green/10 text-kyn-green text-xs font-medium mb-8">
              <Zap size={12} /> Phase 15 · Design Assets & Production Ready
            </div>
            <BrandLogo height={56} />
            <h1 className="mt-8 font-display text-4xl md:text-6xl lg:text-7xl font-bold tracking-tight leading-[1.05]">
              KYNETIK
              <br />
              <span className="text-kyn-green text-glow">Design System</span>
            </h1>
            <p className="mt-6 text-lg md:text-xl text-kyn-silver max-w-2xl leading-relaxed">
              Complete system — brand to handoff. Interactive prototypes for investors, clients and engineering.
            </p>
            <div className="mt-10 flex flex-wrap gap-4">
              <Link to="/showcase" className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-kyn-green text-kyn-black font-semibold text-sm hover:bg-kyn-green-glow transition-colors glow-green">
                Final Showcase <ArrowRight size={16} />
              </Link>
              <Link to="/prototype" className="inline-flex items-center gap-2 px-6 py-3 rounded-full border border-white/15 text-white text-sm font-medium hover:border-kyn-green/40 hover:bg-white/5 transition-colors">
                Interactive Prototype
              </Link>
            </div>

            <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-4 max-w-3xl">
              {[
                { label: 'Phases', value: '14/14' },
                { label: 'Surfaces', value: 'Web·App·Cloud' },
                { label: 'Products', value: '5 series' },
                { label: 'Accent', value: '#00E676' },
              ].map((item) => (
                <div key={item.label} className="glass-card rounded-xl p-4">
                  <p className="text-[10px] uppercase tracking-widest text-kyn-metal">{item.label}</p>
                  <p className="mt-1 font-display font-semibold text-white">{item.value}</p>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      <section className="max-w-6xl mx-auto px-6 md:px-10 py-20">
        <p className="text-kyn-green text-xs font-semibold tracking-[0.25em] uppercase mb-3">System map</p>
        <h2 className="font-display text-3xl md:text-4xl font-bold mb-3">Design modules</h2>
        <p className="text-kyn-metal mb-12 max-w-xl">Brand + UI/UX ready for production handoff and AI image generation.</p>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {modules.map((m, i) => {
            const Icon = m.icon;
            return (
              <motion.div key={m.to} initial={{ opacity: 0, y: 16 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.04 }}>
                <Link to={m.to} className="group block glass-card rounded-2xl p-6 h-full hover:border-kyn-green/30 transition-all hover:-translate-y-0.5">
                  <div className="w-10 h-10 rounded-xl bg-kyn-green/10 border border-kyn-green/20 flex items-center justify-center text-kyn-green mb-4 group-hover:glow-green transition-shadow">
                    <Icon size={18} />
                  </div>
                  <h3 className="font-display font-semibold text-lg text-white group-hover:text-kyn-green transition-colors">{m.title}</h3>
                  <p className="mt-2 text-sm text-kyn-metal leading-relaxed">{m.desc}</p>
                  <span className="mt-4 inline-flex items-center gap-1 text-xs text-kyn-green opacity-0 group-hover:opacity-100 transition-opacity">
                    Open <ArrowRight size={12} />
                  </span>
                </Link>
              </motion.div>
            );
          })}
        </div>
      </section>

      <AppDownloadCTA accent="#00e676" />
    </div>
  );
}

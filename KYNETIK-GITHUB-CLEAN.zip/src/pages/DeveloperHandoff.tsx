import { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  ArrowRight, BookOpen, Check, Copy, Database, Download, FileCode2, GitBranch,
  Layers, Palette, Route, Server, Smartphone, Cloud, Package, Workflow,
  Terminal, Boxes, Shield, Radio, Calendar
} from 'lucide-react';
import BrandLogo from '../components/BrandLogo';
import LoadingState from '../components/LoadingState';
import { apiGet, cn } from '../lib/utils';

interface Item {
  id: number;
  category: string;
  title: string;
  body: string;
  meta: string | null;
  sort_order: number;
}

const tokens = [
  { name: 'kyn-black', value: '#050505' },
  { name: 'kyn-void', value: '#0A0A0B' },
  { name: 'kyn-steel', value: '#1A1A1E' },
  { name: 'kyn-green', value: '#00E676' },
  { name: 'kyn-green-glow', value: '#39FF14' },
  { name: 'kyn-white', value: '#F5F5F7' },
  { name: 'kyn-silver', value: '#C8C8D0' },
  { name: 'kyn-metal', value: '#8A8A96' },
];

const surfaces = [
  { path: '/', name: 'Public website home' },
  { path: '/products', name: 'Product catalog' },
  { path: '/products/:slug', name: 'Product detail (GO→PRO)' },
  { path: '/portal/*', name: 'Customer app / account' },
  { path: '/console', name: 'Cloud operator dashboard' },
  { path: '/admin', name: 'Enterprise admin' },
  { path: '/developers', name: 'Developer platform' },
  { path: '/delivery', name: 'Architecture delivery hub' },
  { path: '/components', name: 'UI component library' },
  { path: '/database', name: 'DB architecture' },
];

const apis = [
  { method: 'GET/PUT', path: '/api/portal-chargers', use: 'Customer chargers + remote actions' },
  { method: 'GET', path: '/api/portal-sessions', use: 'Charging history / energy' },
  { method: 'GET/PUT', path: '/api/portal-account', use: 'Profile · warranties' },
  { method: 'GET/PUT', path: '/api/portal-billing', use: 'Subscriptions · invoices' },
  { method: 'GET/PUT', path: '/api/charge-points', use: 'Cloud stations · OCPP actions' },
  { method: 'GET', path: '/api/charging-sessions', use: 'Operator session feed' },
  { method: 'GET', path: '/api/fleets', use: 'Fleet management' },
  { method: 'GET', path: '/api/ocpp-events', use: 'OCPP event stream' },
  { method: 'GET', path: '/api/product-lines', use: 'Product catalog CMS' },
  { method: 'POST', path: '/api/leads · /api/quotes', use: 'Sales intake' },
];

const tables = [
  'product_lines · products',
  'portal_chargers · portal_sessions · portal_vehicles',
  'portal_profiles · portal_subscriptions · portal_invoices',
  'charge_points · charging_sessions · fleets · ocpp_events',
  'cloud_users · cloud_metrics · cloud_notifications',
  'marketing_leads · support_tickets · design_handoff',
];

const roadmap = [
  { phase: 'MVP 0–8 wks', items: ['Auth + customer portal', 'Charger control (start/stop/schedule)', 'Product pages + quote', 'Cloud station list + remote start/stop', 'OCPP 1.6J core messages'] },
  { phase: 'Growth 2–4 mo', items: ['Map + public availability', 'Fleet billing', 'Installer field app', 'Payments / subscriptions', 'Analytics + exports'] },
  { phase: 'Scale 4–9 mo', items: ['Multi-tenant orgs', 'API marketplace', 'AI diagnostics', 'Roaming / OCPI', 'Mobile native shells'] },
];

const packs = [
  { icon: Palette, t: 'Design tokens', d: 'CSS vars + Tailwind theme + src/ui', to: '/design-system/tokens' },
  { icon: Boxes, t: 'Components', d: 'Buttons, forms, cards, status, charts', to: '/components' },
  { icon: Workflow, t: 'User flows', d: 'Journeys + interactive prototype', to: '/ux-journeys' },
  { icon: Smartphone, t: 'Customer app', d: 'Portal screens wired to APIs', to: '/portal' },
  { icon: Cloud, t: 'Cloud console', d: 'Ops dashboard + OCPP actions', to: '/console' },
  { icon: Package, t: 'Product system', d: 'GO→PRO pages + compare', to: '/products' },
  { icon: Database, t: 'Database', d: 'Schema map for eng', to: '/database' },
  { icon: Terminal, t: 'API platform', d: 'Docs · keys · playground', to: '/developers' },
];

export default function DeveloperHandoff() {
  const [items, setItems] = useState<Item[]>([]);
  const [loading, setLoading] = useState(true);
  const [copied, setCopied] = useState('');

  useEffect(() => {
    apiGet<Item[]>('/api/handoff')
      .then(setItems)
      .catch(() => setItems([]))
      .finally(() => setLoading(false));
  }, []);

  const byCat = useMemo(() => {
    const m: Record<string, Item[]> = {};
    for (const i of items) (m[i.category] ||= []).push(i);
    return m;
  }, [items]);

  const copy = async (text: string, id: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(id);
      setTimeout(() => setCopied(''), 1400);
    } catch { /* ignore */ }
  };

  const tokenCss = `:root {\n${tokens.map((t) => `  --color-${t.name}: ${t.value};`).join('\n')}\n  --font-sans: 'Inter', system-ui, sans-serif;\n  --font-display: 'Space Grotesk', 'Inter', system-ui, sans-serif;\n}`;

  return (
    <div className="min-h-screen bg-kyn-black text-white">
      <header className="sticky top-0 z-50 border-b border-white/5 bg-kyn-black/90 backdrop-blur-xl">
        <div className="max-w-7xl mx-auto px-5 md:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <BrandLogo height={28} />
            <span className="text-[10px] font-semibold tracking-[0.2em] uppercase text-kyn-green border border-kyn-green/30 rounded-full px-2 py-0.5">
              Dev Handoff
            </span>
          </div>
          <div className="flex items-center gap-3 text-xs">
            <Link to="/delivery" className="text-kyn-silver hover:text-white hidden sm:inline">Architecture</Link>
            <Link to="/handoff" className="text-kyn-silver hover:text-white hidden sm:inline">Classic</Link>
            <Link to="/components" className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-kyn-green text-kyn-black font-bold">
              UI Kit <ArrowRight size={12} />
            </Link>
          </div>
        </div>
      </header>

      <section className="relative pt-14 pb-10 overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(0,230,118,0.12),transparent_55%)]" />
        <div className="relative z-10 max-w-7xl mx-auto px-5 md:px-8">
          <p className="text-kyn-green text-xs font-semibold tracking-[0.28em] uppercase mb-3">Phase 22</p>
          <h1 className="font-display text-4xl md:text-5xl font-bold tracking-tight max-w-3xl">
            Developer handoff package
          </h1>
          <p className="mt-4 text-kyn-silver max-w-2xl leading-relaxed">
            Tokens, components, routes, APIs, database, OCPP notes and roadmap — so any engineering team can start immediately.
          </p>
          <div className="mt-8 grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {packs.map(({ icon: Icon, t, d, to }) => (
              <Link key={t} to={to} className="rounded-2xl border border-white/8 bg-white/[0.03] p-4 hover:border-kyn-green/35 transition-colors group">
                <Icon size={18} className="text-kyn-green mb-3" />
                <p className="font-semibold text-sm group-hover:text-kyn-green transition-colors">{t}</p>
                <p className="text-[11px] text-kyn-metal mt-1">{d}</p>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <section className="pb-16">
        <div className="max-w-7xl mx-auto px-5 md:px-8 grid lg:grid-cols-2 gap-6">
          {/* Tokens */}
          <div className="rounded-3xl border border-white/8 p-6 md:p-8 bg-kyn-void/40">
            <div className="flex items-center justify-between gap-3 mb-5">
              <h2 className="font-display text-xl font-bold flex items-center gap-2"><Palette size={18} className="text-kyn-green" /> Design tokens</h2>
              <button type="button" onClick={() => copy(tokenCss, 'css')} className="text-xs inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border border-white/10 hover:border-kyn-green/40">
                {copied === 'css' ? <Check size={12} className="text-kyn-green" /> : <Copy size={12} />} Copy CSS
              </button>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-4">
              {tokens.map((t) => (
                <button key={t.name} type="button" onClick={() => copy(t.value, t.name)} className="rounded-xl border border-white/8 overflow-hidden text-left hover:border-white/20">
                  <div className="h-10" style={{ background: t.value }} />
                  <div className="px-2 py-1.5">
                    <p className="text-[10px] font-semibold">{t.name}</p>
                    <p className="text-[10px] text-kyn-metal font-mono">{t.value}</p>
                  </div>
                </button>
              ))}
            </div>
            <pre className="text-[11px] font-mono text-kyn-silver bg-black/40 border border-white/8 rounded-xl p-4 overflow-x-auto">{tokenCss}</pre>
            <p className="mt-3 text-[11px] text-kyn-metal">Type: Inter (UI) · Space Grotesk (display). Logo: green bolt mark + monochrome wordmark (`BrandLogo`).</p>
          </div>

          {/* Routes */}
          <div className="rounded-3xl border border-white/8 p-6 md:p-8 bg-kyn-void/40">
            <h2 className="font-display text-xl font-bold flex items-center gap-2 mb-5"><Route size={18} className="text-kyn-green" /> Key routes</h2>
            <div className="space-y-2">
              {surfaces.map((r) => (
                <div key={r.path} className="flex items-center justify-between gap-3 rounded-xl border border-white/8 px-3 py-2.5 bg-black/20">
                  <div>
                    <p className="text-sm font-medium">{r.name}</p>
                    <p className="text-[11px] font-mono text-kyn-green">{r.path}</p>
                  </div>
                  {!r.path.includes(':') && (
                    <Link to={r.path.replace('/*', '')} className="text-[11px] text-kyn-silver hover:text-white">Open</Link>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* APIs */}
          <div className="rounded-3xl border border-white/8 p-6 md:p-8 bg-kyn-void/40 lg:col-span-2">
            <h2 className="font-display text-xl font-bold flex items-center gap-2 mb-5"><Server size={18} className="text-kyn-green" /> API requirements</h2>
            <div className="overflow-x-auto">
              <table className="w-full text-sm min-w-[640px]">
                <thead>
                  <tr className="text-left text-[11px] uppercase tracking-wider text-kyn-metal border-b border-white/10">
                    <th className="pb-3 pr-4">Method</th>
                    <th className="pb-3 pr-4">Endpoint</th>
                    <th className="pb-3">Purpose</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {apis.map((a) => (
                    <tr key={a.path} className="text-kyn-silver">
                      <td className="py-3 pr-4 font-mono text-[11px] text-kyn-green whitespace-nowrap">{a.method}</td>
                      <td className="py-3 pr-4 font-mono text-[12px] text-white">{a.path}</td>
                      <td className="py-3 text-sm">{a.use}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="mt-5 grid md:grid-cols-3 gap-3">
              <div className="rounded-xl border border-white/8 p-4">
                <Radio size={16} className="text-kyn-green mb-2" />
                <p className="text-sm font-semibold">OCPP 1.6J</p>
                <p className="text-[11px] text-kyn-metal mt-1">BootNotification, Heartbeat, StatusNotification, Start/StopTransaction, RemoteStart/Stop, MeterValues.</p>
              </div>
              <div className="rounded-xl border border-white/8 p-4">
                <Shield size={16} className="text-kyn-green mb-2" />
                <p className="text-sm font-semibold">Auth</p>
                <p className="text-[11px] text-kyn-metal mt-1">Supabase Auth (email + Google). API keys for partners. RBAC on Cloud/Admin.</p>
              </div>
              <div className="rounded-xl border border-white/8 p-4">
                <FileCode2 size={16} className="text-kyn-green mb-2" />
                <p className="text-sm font-semibold">Stack</p>
                <p className="text-[11px] text-kyn-metal mt-1">Vite · React · TS · Tailwind · Framer Motion · Vercel serverless · Supabase.</p>
              </div>
            </div>
          </div>

          {/* DB */}
          <div className="rounded-3xl border border-white/8 p-6 md:p-8 bg-kyn-void/40">
            <h2 className="font-display text-xl font-bold flex items-center gap-2 mb-5"><Database size={18} className="text-kyn-green" /> Database structure</h2>
            <ul className="space-y-2.5">
              {tables.map((t) => (
                <li key={t} className="flex gap-2 text-sm text-kyn-silver">
                  <span className="text-kyn-green mt-1">▸</span>
                  <span className="font-mono text-[12px]">{t}</span>
                </li>
              ))}
            </ul>
            <Link to="/database" className="mt-6 inline-flex items-center gap-2 text-sm font-semibold text-kyn-green">
              Full architecture <ArrowRight size={14} />
            </Link>
          </div>

          {/* Roadmap */}
          <div className="rounded-3xl border border-white/8 p-6 md:p-8 bg-kyn-void/40">
            <h2 className="font-display text-xl font-bold flex items-center gap-2 mb-5"><GitBranch size={18} className="text-kyn-green" /> Development roadmap</h2>
            <div className="space-y-4">
              {roadmap.map((r) => (
                <div key={r.phase} className="rounded-xl border border-white/8 p-4">
                  <p className="text-xs font-bold uppercase tracking-wider text-kyn-green">{r.phase}</p>
                  <ul className="mt-2 space-y-1">
                    {r.items.map((i) => (
                      <li key={i} className="text-sm text-kyn-silver flex gap-2">
                        <Check size={14} className="text-kyn-green shrink-0 mt-0.5" /> {i}
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* DB-driven notes */}
      <section className="pb-24">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <h2 className="font-display text-2xl font-bold mb-6 flex items-center gap-2">
            <BookOpen size={20} className="text-kyn-green" /> Package notes
          </h2>
          {loading ? (
            <LoadingState label="Loading handoff content…" />
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {(items.length ? items : [
                { id: 0, category: 'components', title: 'UI primitives', body: 'Use src/ui exports: Button, Input, Card, Badge, StatusPill. Prefer tokens over hard-coded colors.', meta: 'P0', sort_order: 0 },
                { id: 1, category: 'flows', title: 'Quote → Install → Portal', body: 'Marketing quote creates lead; installer completes job; customer gains portal charger control.', meta: 'P0', sort_order: 1 },
                { id: 2, category: 'api', title: 'Idempotent remote actions', body: 'Start/Stop/Lock must be idempotent and audited. Surface OCPP rejection reasons in UI.', meta: 'P0', sort_order: 2 },
              ]).map((item) => (
                <motion.div
                  key={item.id + item.title}
                  initial={{ opacity: 0, y: 12 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  className="rounded-2xl border border-white/8 bg-white/[0.03] p-5"
                >
                  <p className="text-[10px] uppercase tracking-wider text-kyn-green font-semibold">{item.category}</p>
                  <h3 className="font-semibold mt-1">{item.title}</h3>
                  <p className="text-sm text-kyn-silver mt-2 leading-relaxed">{item.body}</p>
                  {item.meta && <p className="text-[11px] text-kyn-metal mt-3 font-mono">{item.meta}</p>}
                </motion.div>
              ))}
            </div>
          )}

          <div className="mt-12 rounded-3xl border border-kyn-green/25 bg-kyn-green/5 p-8 flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <p className="font-display text-xl font-bold">Ship checklist</p>
              <p className="text-sm text-kyn-silver mt-1">Design system → Customer app → Cloud → Products → this package.</p>
            </div>
            <div className="flex flex-wrap gap-2">
              <Link to="/delivery" className="px-4 py-2 rounded-full bg-kyn-green text-kyn-black text-xs font-bold">Architecture hub</Link>
              <Link to="/prototype" className="px-4 py-2 rounded-full border border-white/15 text-xs font-semibold">Prototype</Link>
              <Link to="/showcase" className="px-4 py-2 rounded-full border border-white/15 text-xs font-semibold">Showcase</Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

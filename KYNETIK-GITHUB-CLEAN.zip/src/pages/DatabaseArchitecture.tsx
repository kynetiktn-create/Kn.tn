import { useEffect, useMemo, useState, type ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  ArrowRight, BookOpen, Building2, CheckCircle2, ChevronRight, Cloud,
  Database, FileText, GitBranch, GraduationCap, HardDrive, KeyRound,
  Layers, Link2, Menu, Network, Receipt, Search, Server, Shield,
  Ticket, Wrench, X, Zap, Clock, Scale, Boxes
} from 'lucide-react';
import BrandLogo from '../components/BrandLogo';
import LoadingState from '../components/LoadingState';
import { apiGet, cn } from '../lib/utils';

interface DocRow {
  id: number;
  chapter: string;
  type: string;
  title: string;
  subtitle: string | null;
  body: string;
  meta: string | null;
  sort_order: number;
}

const CHAPTERS = [
  { id: 'db11', n: '11', label: 'Installations', icon: Wrench },
  { id: 'db12', n: '12', label: 'Maintenance', icon: HardDrive },
  { id: 'db13', n: '13', label: 'Invoices', icon: Receipt },
  { id: 'db14', n: '14', label: 'Payments', icon: KeyRound },
  { id: 'db15', n: '15', label: 'Support Tickets', icon: Ticket },
  { id: 'db16', n: '16', label: 'Academy', icon: GraduationCap },
  { id: 'db17', n: '17', label: 'Audit Logs', icon: Shield },
  { id: 'db18', n: '18', label: 'Relationships', icon: GitBranch },
  { id: 'db19', n: '19', label: 'Index Strategy', icon: Search },
  { id: 'db20', n: '20', label: 'Data Lifecycle', icon: Clock },
  { id: 'db_ddd', n: 'DDD', label: 'Bounded Contexts', icon: Boxes },
  { id: 'db_next', n: 'NEXT', label: 'API Guide', icon: Network },
];

const DOMAINS = [
  {
    name: 'Sales Domain',
    color: '#00e676',
    items: ['Customers / Companies', 'Quotes', 'Orders', 'Invoices', 'Payments'],
  },
  {
    name: 'Charging Domain',
    color: '#38bdf8',
    items: ['Stations', 'Chargers / Connectors', 'Sessions', 'Tariffs', 'Load profiles'],
  },
  {
    name: 'Cloud Domain',
    color: '#a78bfa',
    items: ['Monitoring', 'Alerts', 'Analytics', 'OCPP broker', 'OTA firmware'],
  },
  {
    name: 'Academy Domain',
    color: '#fbbf24',
    items: ['Courses', 'Lessons', 'Quizzes', 'Enrollments', 'Certificates'],
  },
  {
    name: 'Support Domain',
    color: '#fb7185',
    items: ['Tickets', 'Installations', 'Maintenance', 'Warranty', 'SLA'],
  },
  {
    name: 'Administration',
    color: '#94a3b8',
    items: ['Users & RBAC', 'Settings', 'Audit logs', 'Feature flags', 'Tenants'],
  },
];

const RELATIONSHIPS = [
  ['Company', 'Users', '1 : N'],
  ['User', 'Vehicles', '1 : N'],
  ['Station', 'Chargers', '1 : N'],
  ['Charger', 'Sessions', '1 : N'],
  ['Quote', 'Order', '1 : 1 (after accept)'],
  ['Order', 'Invoice', '1 : 1'],
  ['Order', 'Installation', '1 : 1'],
];

const INDEXES = [
  ['users.email', 'Auth & CRM lookup'],
  ['chargers.serial_number', 'Field ops & warranty'],
  ['quotes.reference', 'Sales funnel'],
  ['invoices.invoice_number', 'Finance & legal'],
  ['stations.status', 'NOC filters'],
  ['*.created_at', 'Timeline & retention jobs'],
];

const LIFECYCLE = [
  ['Charging session logs', '10 years'],
  ['Invoices', 'Per local tax law'],
  ['Audit logs', '5 years or more'],
  ['System / app logs', '12 months (archivable)'],
  ['Media (photos, reports)', 'Tied to order / maintenance + archive policy'],
];

function parseMeta(raw: string | null): Record<string, unknown> {
  if (!raw) return {};
  try {
    return JSON.parse(raw);
  } catch {
    return {};
  }
}

function Fade({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 18 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-40px' }}
      transition={{ duration: 0.45 }}
      className={className}
    >
      {children}
    </motion.div>
  );
}

export default function DatabaseArchitecture() {
  const [docs, setDocs] = useState<DocRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [active, setActive] = useState('db11');
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [query, setQuery] = useState('');

  useEffect(() => {
    apiGet<DocRow[]>('/api/master-docs')
      .then((rows) => {
        const db = rows.filter((r) => String(r.chapter || '').startsWith('db'));
        setDocs(db.sort((a, b) => (a.sort_order ?? 0) - (b.sort_order ?? 0)));
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const filteredChapters = useMemo(() => {
    if (!query.trim()) return CHAPTERS;
    const q = query.toLowerCase();
    return CHAPTERS.filter(
      (c) =>
        c.label.toLowerCase().includes(q) ||
        c.n.toLowerCase().includes(q) ||
        docs.some(
          (d) =>
            d.chapter === c.id &&
            (d.title.toLowerCase().includes(q) || d.body.toLowerCase().includes(q))
        )
    );
  }, [query, docs]);

  const activeDoc = docs.find((d) => d.chapter === active) || docs[0];
  const activeMeta = parseMeta(activeDoc?.meta ?? null);
  const activeChapter = CHAPTERS.find((c) => c.id === active) || CHAPTERS[0];
  const ActiveIcon = activeChapter.icon;

  if (loading) {
    return (
      <div className="min-h-screen bg-[#05070c] flex items-center justify-center">
        <LoadingState label="Loading database architecture…" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#05070c] text-white">
      <header
        className={cn(
          'fixed top-0 inset-x-0 z-50 transition-all',
          scrolled ? 'bg-[#05070c]/90 backdrop-blur-xl border-b border-white/5' : 'bg-transparent'
        )}
      >
        <div className="max-w-7xl mx-auto px-5 md:px-8 h-16 flex items-center justify-between">
          <Link to="/docs-suite" className="flex items-center gap-3">
            <BrandLogo height={28} />
            <span className="hidden sm:inline text-[10px] tracking-[0.22em] uppercase text-sky-400 border border-sky-400/30 rounded-full px-2 py-0.5">
              Data Architecture
            </span>
          </Link>
          <nav className="hidden lg:flex items-center gap-6 text-xs text-slate-400">
            <a href="#domains" className="hover:text-white">Domains</a>
            <a href="#entities" className="hover:text-white">Ch. 11–20</a>
            <a href="#er" className="hover:text-white">Relationships</a>
            <a href="#lifecycle" className="hover:text-white">Lifecycle</a>
            <Link to="/developers" className="hover:text-white">API next</Link>
          </nav>
          <button type="button" className="lg:hidden p-2" onClick={() => setMenuOpen(!menuOpen)}>
            {menuOpen ? <X size={18} /> : <Menu size={18} />}
          </button>
        </div>
        {menuOpen && (
          <div className="lg:hidden border-t border-white/5 bg-[#0a0f18] px-5 py-4 space-y-2 text-sm text-slate-300">
            {CHAPTERS.map((c) => (
              <button
                key={c.id}
                type="button"
                className="block w-full text-left py-1.5"
                onClick={() => {
                  setActive(c.id);
                  setMenuOpen(false);
                  document.getElementById('entities')?.scrollIntoView({ behavior: 'smooth' });
                }}
              >
                Ch. {c.n} — {c.label}
              </button>
            ))}
          </div>
        )}
      </header>

      {/* Hero */}
      <section className="relative pt-28 pb-16 md:pt-36 md:pb-24 overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_20%_0%,rgba(56,189,248,0.12),transparent_50%)]" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_80%_40%,rgba(0,230,118,0.08),transparent_45%)]" />
        <div className="relative max-w-7xl mx-auto px-5 md:px-8">
          <Fade>
            <p className="text-sky-400 text-xs font-semibold tracking-[0.3em] uppercase mb-4">
              KYNETIK Platform · Database Blueprint
            </p>
            <h1 className="font-display text-4xl md:text-6xl font-bold tracking-tight max-w-4xl leading-[1.05]">
              Chapters 11–20
              <br />
              <span className="text-sky-400">Operational data model</span>
            </h1>
            <p className="mt-6 text-slate-400 text-lg max-w-2xl leading-relaxed">
              Installations, maintenance, finance, support, Academy and governance — designed for
              multi-year scale with Domain-Driven Design bounded contexts.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <a
                href="#entities"
                className="inline-flex items-center gap-2 px-5 py-3 rounded-full bg-sky-400 text-slate-950 text-sm font-bold"
              >
                Explore entities <ArrowRight size={15} />
              </a>
              <Link
                to="/developers"
                className="inline-flex items-center gap-2 px-5 py-3 rounded-full border border-white/15 text-sm font-medium hover:bg-white/5"
              >
                Next: API Design Guide
              </Link>
              <Link
                to="/docs-suite"
                className="inline-flex items-center gap-2 px-5 py-3 rounded-full border border-white/10 text-sm text-slate-400 hover:text-white"
              >
                Documentation Suite
              </Link>
            </div>
          </Fade>

          <div className="mt-14 grid grid-cols-2 md:grid-cols-4 gap-3">
            {[
              { v: '10', l: 'Core chapters' },
              { v: '6', l: 'Bounded contexts' },
              { v: '7', l: 'Key relationships' },
              { v: '5', l: 'Retention policies' },
            ].map((s) => (
              <div key={s.l} className="rounded-2xl border border-white/10 bg-white/[0.02] p-4">
                <p className="font-display text-2xl font-bold text-sky-300">{s.v}</p>
                <p className="text-[11px] text-slate-500 mt-1 uppercase tracking-wider">{s.l}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* DDD Domains */}
      <section id="domains" className="py-20 border-t border-white/5">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <Fade>
            <p className="text-sky-400 text-xs font-semibold tracking-[0.25em] uppercase mb-3">Architecture recommendation</p>
            <h2 className="font-display text-3xl md:text-4xl font-bold mb-3">Domain-Driven Design</h2>
            <p className="text-slate-400 max-w-2xl mb-10">
              Do not ship KYNETIK as one monolithic schema forever. Split into bounded contexts that
              can evolve, test and scale independently — closer to global energy platforms.
            </p>
          </Fade>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {DOMAINS.map((d, i) => (
              <Fade key={d.name}>
                <div
                  className="h-full rounded-2xl border border-white/10 bg-gradient-to-b from-white/[0.04] to-transparent p-6"
                  style={{ borderTopColor: `${d.color}55` }}
                >
                  <div className="w-2 h-2 rounded-full mb-4" style={{ background: d.color }} />
                  <h3 className="font-display font-semibold text-lg" style={{ color: d.color }}>
                    {d.name}
                  </h3>
                  <ul className="mt-4 space-y-2">
                    {d.items.map((item) => (
                      <li key={item} className="text-sm text-slate-400 flex items-center gap-2">
                        <ChevronRight size={12} style={{ color: d.color }} /> {item}
                      </li>
                    ))}
                  </ul>
                </div>
              </Fade>
            ))}
          </div>
        </div>
      </section>

      {/* Entity explorer */}
      <section id="entities" className="py-20 border-t border-white/5 bg-[#070b12]">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <div className="flex flex-wrap items-end justify-between gap-4 mb-8">
            <div>
              <p className="text-sky-400 text-xs font-semibold tracking-[0.25em] uppercase mb-2">Chapters 11–20</p>
              <h2 className="font-display text-3xl font-bold">Entity catalog</h2>
            </div>
            <div className="relative w-full sm:w-72">
              <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search entities…"
                className="w-full rounded-xl bg-black/40 border border-white/10 pl-9 pr-3 py-2.5 text-sm outline-none focus:border-sky-400/40"
              />
            </div>
          </div>

          <div className="grid lg:grid-cols-[280px_1fr] gap-6">
            <div className="space-y-1 max-h-[70vh] overflow-y-auto pr-1">
              {filteredChapters.map((c) => {
                const Icon = c.icon;
                const isOn = active === c.id;
                return (
                  <button
                    key={c.id}
                    type="button"
                    onClick={() => setActive(c.id)}
                    className={cn(
                      'w-full flex items-center gap-3 px-3 py-3 rounded-xl text-left text-sm transition-all',
                      isOn
                        ? 'bg-sky-400/10 border border-sky-400/30 text-sky-200'
                        : 'border border-transparent text-slate-400 hover:bg-white/[0.03] hover:text-white'
                    )}
                  >
                    <span className="font-mono text-[10px] w-8 text-slate-500">{c.n}</span>
                    <Icon size={15} />
                    <span className="font-medium">{c.label}</span>
                  </button>
                );
              })}
            </div>

            <div className="rounded-3xl border border-white/10 bg-[#0a101a] overflow-hidden min-h-[420px]">
              {activeDoc ? (
                <>
                  <div className="px-6 md:px-8 py-6 border-b border-white/5 flex flex-wrap items-start justify-between gap-4">
                    <div className="flex items-start gap-4">
                      <div className="w-12 h-12 rounded-2xl bg-sky-400/10 border border-sky-400/25 flex items-center justify-center text-sky-300">
                        <ActiveIcon size={22} />
                      </div>
                      <div>
                        <p className="text-[11px] uppercase tracking-wider text-sky-400/80">
                          {activeDoc.subtitle || `Chapter ${activeChapter.n}`}
                        </p>
                        <h3 className="font-display text-2xl md:text-3xl font-bold mt-1">{activeDoc.title}</h3>
                      </div>
                    </div>
                    <span className="text-[10px] font-mono px-2 py-1 rounded-md bg-white/5 text-slate-400 border border-white/10">
                      {activeDoc.type}
                    </span>
                  </div>
                  <div className="px-6 md:px-8 py-6">
                    <p className="text-slate-300 leading-relaxed text-base md:text-lg">{activeDoc.body}</p>

                    {Array.isArray(activeMeta.fields) && (
                      <div className="mt-8">
                        <p className="text-[11px] uppercase tracking-wider text-slate-500 mb-3">Schema fields</p>
                        <div className="flex flex-wrap gap-2">
                          {(activeMeta.fields as string[]).map((f) => (
                            <span
                              key={f}
                              className="px-3 py-1.5 rounded-lg bg-sky-400/5 border border-sky-400/20 text-xs font-mono text-sky-200"
                            >
                              {f}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}

                    {Array.isArray(activeMeta.tables) && (
                      <div className="mt-8">
                        <p className="text-[11px] uppercase tracking-wider text-slate-500 mb-3">Related tables</p>
                        <div className="grid sm:grid-cols-2 gap-2">
                          {(activeMeta.tables as string[]).map((t) => (
                            <div key={t} className="rounded-xl border border-white/10 bg-black/30 px-4 py-3 flex items-center gap-2 text-sm">
                              <Database size={14} className="text-sky-400" /> {t}
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {Array.isArray(activeMeta.methods) && (
                      <div className="mt-8">
                        <p className="text-[11px] uppercase tracking-wider text-slate-500 mb-3">Payment rails</p>
                        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                          {(activeMeta.methods as string[]).map((m) => (
                            <div key={m} className="rounded-xl border border-white/10 px-3 py-3 text-center text-xs font-medium text-slate-300">
                              {m.replace(/_/g, ' ')}
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {Array.isArray(activeMeta.contexts) && (
                      <div className="mt-8 grid sm:grid-cols-2 lg:grid-cols-3 gap-2">
                        {(activeMeta.contexts as string[]).map((c) => (
                          <div key={c} className="rounded-xl border border-emerald-400/20 bg-emerald-400/5 px-4 py-3 text-sm text-emerald-200">
                            {c}
                          </div>
                        ))}
                      </div>
                    )}

                    {Array.isArray(activeMeta.deliverables) && (
                      <div className="mt-8">
                        <p className="text-[11px] uppercase tracking-wider text-slate-500 mb-3">API guide deliverables</p>
                        <ul className="space-y-2">
                          {(activeMeta.deliverables as string[]).map((d) => (
                            <li key={d} className="flex items-center gap-2 text-sm text-slate-300">
                              <CheckCircle2 size={14} className="text-sky-400" /> {d.replace(/_/g, ' ')}
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}

                    {typeof activeMeta.api === 'string' && (
                      <div className="mt-8 rounded-xl border border-white/10 bg-black/40 px-4 py-3 font-mono text-xs text-sky-300">
                        Live surface · {activeMeta.api as string}
                      </div>
                    )}

                    {active === 'db18' && (
                      <div className="mt-8 overflow-x-auto rounded-xl border border-white/10">
                        <table className="w-full text-sm min-w-[480px]">
                          <thead className="text-[11px] uppercase tracking-wider text-slate-500 border-b border-white/10">
                            <tr>
                              <th className="text-left px-4 py-3">From</th>
                              <th className="text-left px-4 py-3">To</th>
                              <th className="text-left px-4 py-3">Cardinality</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-white/5">
                            {RELATIONSHIPS.map((r) => (
                              <tr key={r.join('-')} className="text-slate-300">
                                <td className="px-4 py-3 text-white font-medium">{r[0]}</td>
                                <td className="px-4 py-3">{r[1]}</td>
                                <td className="px-4 py-3 text-sky-300 font-mono text-xs">{r[2]}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )}

                    {active === 'db19' && (
                      <div className="mt-8 grid sm:grid-cols-2 gap-2">
                        {INDEXES.map(([idx, why]) => (
                          <div key={idx} className="rounded-xl border border-white/10 bg-black/30 p-4">
                            <p className="font-mono text-sm text-sky-300">{idx}</p>
                            <p className="text-xs text-slate-500 mt-1">{why}</p>
                          </div>
                        ))}
                      </div>
                    )}

                    {active === 'db20' && (
                      <div className="mt-8 overflow-x-auto rounded-xl border border-white/10">
                        <table className="w-full text-sm min-w-[480px]">
                          <thead className="text-[11px] uppercase tracking-wider text-slate-500 border-b border-white/10">
                            <tr>
                              <th className="text-left px-4 py-3">Data type</th>
                              <th className="text-left px-4 py-3">Retention policy</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-white/5">
                            {LIFECYCLE.map((r) => (
                              <tr key={r[0]} className="text-slate-300">
                                <td className="px-4 py-3 text-white font-medium">{r[0]}</td>
                                <td className="px-4 py-3">{r[1]}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )}
                  </div>
                </>
              ) : (
                <div className="p-10 text-slate-500 text-sm">No chapter content loaded.</div>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* ER strip */}
      <section id="er" className="py-20 border-t border-white/5">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <Fade>
            <div className="flex items-center gap-2 text-sky-400 text-xs font-semibold tracking-[0.25em] uppercase mb-3">
              <Link2 size={14} /> Chapter 18
            </div>
            <h2 className="font-display text-3xl font-bold mb-8">Relationship map</h2>
          </Fade>
          <div className="flex flex-wrap items-center justify-center gap-2 md:gap-3">
            {['Company', 'Users', 'Vehicles', 'Station', 'Chargers', 'Sessions', 'Quote', 'Order', 'Invoice', 'Installation'].map(
              (node, i, arr) => (
                <div key={node} className="flex items-center gap-2 md:gap-3">
                  <div className="rounded-xl border border-sky-400/25 bg-sky-400/5 px-3 py-2 text-xs md:text-sm font-semibold">
                    {node}
                  </div>
                  {i < arr.length - 1 && <span className="text-slate-600 text-xs">→</span>}
                </div>
              )
            )}
          </div>
        </div>
      </section>

      {/* Lifecycle */}
      <section id="lifecycle" className="py-20 border-t border-white/5 bg-[#070b12]">
        <div className="max-w-7xl mx-auto px-5 md:px-8 grid lg:grid-cols-2 gap-10 items-start">
          <Fade>
            <p className="text-sky-400 text-xs font-semibold tracking-[0.25em] uppercase mb-3">Chapter 20</p>
            <h2 className="font-display text-3xl font-bold mb-4">Data lifecycle policy</h2>
            <p className="text-slate-400 leading-relaxed mb-6">
              Every entity class has an explicit retention and archive rule — required for enterprise
              customers, auditors and multi-country expansion.
            </p>
            <div className="space-y-3">
              {LIFECYCLE.map(([t, p]) => (
                <div key={t} className="flex items-start justify-between gap-4 rounded-xl border border-white/10 bg-black/30 px-4 py-3">
                  <span className="text-sm text-white font-medium">{t}</span>
                  <span className="text-xs text-sky-300 font-mono text-right shrink-0">{p}</span>
                </div>
              ))}
            </div>
          </Fade>
          <Fade>
            <div className="rounded-3xl border border-white/10 bg-gradient-to-br from-sky-400/10 to-transparent p-8">
              <Scale className="text-sky-300 mb-4" size={28} />
              <h3 className="font-display text-xl font-bold">Governance defaults</h3>
              <ul className="mt-5 space-y-3 text-sm text-slate-300">
                <li className="flex gap-2"><CheckCircle2 size={16} className="text-sky-400 shrink-0 mt-0.5" /> Immutable audit trail for money, access and OTA</li>
                <li className="flex gap-2"><CheckCircle2 size={16} className="text-sky-400 shrink-0 mt-0.5" /> Soft-delete + archive jobs on hot operational tables</li>
                <li className="flex gap-2"><CheckCircle2 size={16} className="text-sky-400 shrink-0 mt-0.5" /> Media storage keys always foreign-keyed to domain rows</li>
                <li className="flex gap-2"><CheckCircle2 size={16} className="text-sky-400 shrink-0 mt-0.5" /> Tenant isolation ready for multi-company Cloud</li>
              </ul>
            </div>
          </Fade>
        </div>
      </section>

      {/* Next phase CTA */}
      <section className="py-24 border-t border-white/5 relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(56,189,248,0.1),transparent_55%)]" />
        <div className="relative max-w-3xl mx-auto px-5 text-center">
          <Server className="mx-auto text-sky-300 mb-6" size={32} />
          <h2 className="font-display text-3xl md:text-4xl font-bold">
            Next phase: API Design & Integration Guide
          </h2>
          <p className="mt-4 text-slate-400 leading-relaxed">
            Endpoints, request/response schemas, error codes, authentication, authorization,
            versioning, webhooks and real-time OCPP / KYNETIK Cloud events — so the platform is
            documented for product, design, data and engineering before full build-out.
          </p>
          <div className="mt-10 flex flex-wrap justify-center gap-3">
            <Link
              to="/developers"
              className="inline-flex items-center gap-2 px-7 py-3.5 rounded-full bg-sky-400 text-slate-950 text-sm font-bold"
            >
              Open Developer Platform <ArrowRight size={15} />
            </Link>
            <Link
              to="/docs-suite"
              className="inline-flex items-center gap-2 px-7 py-3.5 rounded-full border border-white/15 text-sm font-medium"
            >
              Back to Docs Suite
            </Link>
          </div>
        </div>
      </section>

      <footer className="border-t border-white/5 py-8">
        <div className="max-w-7xl mx-auto px-5 md:px-8 flex flex-wrap justify-between gap-4 items-center">
          <BrandLogo height={24} />
          <p className="text-[11px] text-slate-500">© KYNETIK · Database Architecture Ch. 11–20 · DDD ready</p>
          <div className="flex gap-4 text-[11px] text-slate-500">
            <Link to="/installer" className="hover:text-white">Installations UI</Link>
            <Link to="/maintenance" className="hover:text-white">Maintenance UI</Link>
            <Link to="/academy" className="hover:text-white">Academy</Link>
          </div>
        </div>
      </footer>
    </div>
  );
}

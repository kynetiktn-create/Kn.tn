import { useEffect, useMemo, useState, type ComponentType, type ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  ArrowRight, BookOpen, Menu, X, CheckCircle2, Target, Users, Layers,
  Smartphone, Building2, Wrench, Shield, Gauge, Rocket, FileText,
  ClipboardList, ListChecks, Flag, ChevronRight, Sparkles, Cloud,
  Network, CircleDot, BadgeCheck, Scale, Timer, Globe2
} from 'lucide-react';
import BrandLogo from '../components/BrandLogo';
import LoadingState from '../components/LoadingState';
import { apiGet, cn } from '../lib/utils';

interface Item {
  id: number;
  type: string;
  category: string;
  title: string;
  subtitle: string;
  body: string;
  meta: string | null;
  sort_order: number;
}

const NAV = [
  { id: 'overview', label: 'Overview' },
  { id: 'objectives', label: 'Objectifs' },
  { id: 'personas', label: 'Personas' },
  { id: 'modules', label: 'Modules' },
  { id: 'stories', label: 'User stories' },
  { id: 'rules', label: 'Business rules' },
  { id: 'acceptance', label: 'Acceptance' },
  { id: 'nfr', label: 'NFR' },
  { id: 'mvp', label: 'MVP' },
  { id: 'roadmap', label: 'Roadmap' },
];

const FALLBACK: Item[] = [
  { id: 1, type: 'product_prd', category: 'overview', title: 'KYNETIK Smart EV Charging Ecosystem', subtitle: 'Product name · v1.0', body: 'Plateforme complète pour particuliers, entreprises et opérateurs — gestion des infrastructures de recharge VE.', meta: 'v1.0', sort_order: 1 },
  { id: 10, type: 'product_prd', category: 'objective', title: 'Déployer en Tunisie', subtitle: 'Business objective', body: 'Plateforme de recharge connectée sur le marché tunisien.', meta: 'GEO', sort_order: 10 },
  { id: 11, type: 'product_prd', category: 'objective', title: 'Expérience premium', subtitle: 'Business objective', body: 'UX Tesla/ABB pour app, web et Cloud.', meta: 'UX', sort_order: 11 },
  { id: 12, type: 'product_prd', category: 'objective', title: 'OCPP 1.6J', subtitle: 'Business objective', body: 'Intégration bornes via OCPP 1.6J.', meta: 'OCPP', sort_order: 12 },
  { id: 13, type: 'product_prd', category: 'objective', title: 'KYNETIK Cloud central', subtitle: 'Business objective', body: 'Supervision, tarifs, support et analytics centralisés.', meta: 'CLOUD', sort_order: 13 },
  { id: 14, type: 'product_prd', category: 'objective', title: 'Expansion Afrique du Nord', subtitle: 'Business objective', body: 'Préparer multi-pays et partenaires installateurs.', meta: 'SCALE', sort_order: 14 },
  { id: 20, type: 'product_prd', category: 'persona', title: 'Particulier', subtitle: 'Persona 1', body: 'VE à domicile — start/stop, conso, planification.', meta: 'P1', sort_order: 20 },
  { id: 21, type: 'product_prd', category: 'persona', title: 'Entreprise', subtitle: 'Persona 2', body: 'Multi-bornes — supervision, users, rapports.', meta: 'P2', sort_order: 21 },
  { id: 22, type: 'product_prd', category: 'persona', title: 'Installateur', subtitle: 'Persona 3', body: 'Installer, configurer, tester, maintenir.', meta: 'P3', sort_order: 22 },
  { id: 23, type: 'product_prd', category: 'persona', title: 'Administrateur KYNETIK', subtitle: 'Persona 4', body: 'Plateforme, partenaires, perf, firmware.', meta: 'P4', sort_order: 23 },
  { id: 30, type: 'product_prd', category: 'module', title: 'Authentication', subtitle: 'Functional module', body: 'Login, logout, reset, MFA admin, rôles.', meta: 'AUTH', sort_order: 30 },
  { id: 31, type: 'product_prd', category: 'module', title: 'Utilisateurs', subtitle: 'Functional module', body: 'Profil, véhicules, historique, notifications.', meta: 'USERS', sort_order: 31 },
  { id: 32, type: 'product_prd', category: 'module', title: 'Bornes', subtitle: 'Functional module', body: 'CRUD, état temps réel, historique.', meta: 'CP', sort_order: 32 },
  { id: 33, type: 'product_prd', category: 'module', title: 'Recharge', subtitle: 'Functional module', body: 'Start/Stop, planning, conso, sessions.', meta: 'CHG', sort_order: 33 },
  { id: 34, type: 'product_prd', category: 'module', title: 'Paiement', subtitle: 'Functional module', body: 'Paiement, facture, historique, abonnement.', meta: 'PAY', sort_order: 34 },
  { id: 35, type: 'product_prd', category: 'module', title: 'Support', subtitle: 'Functional module', body: 'Tickets, assistance, chat, FAQ.', meta: 'SUP', sort_order: 35 },
  { id: 40, type: 'product_prd', category: 'story', title: 'Start charge from phone', subtitle: 'Mobile', body: 'Lancer la recharge depuis le téléphone sans action physique sur la borne.', meta: 'MOB-01', sort_order: 40 },
  { id: 41, type: 'product_prd', category: 'story', title: 'Session complete notification', subtitle: 'Mobile', body: 'Notification de fin de session pour débrancher rapidement.', meta: 'MOB-02', sort_order: 41 },
  { id: 42, type: 'product_prd', category: 'story', title: 'Monthly spend view', subtitle: 'Mobile', body: 'Consulter les dépenses mensuelles énergétiques.', meta: 'MOB-03', sort_order: 42 },
  { id: 43, type: 'product_prd', category: 'story', title: 'Multi-charger dashboard', subtitle: 'Entreprise', body: 'Voir toutes les bornes sur une seule interface.', meta: 'BIZ-01', sort_order: 43 },
  { id: 44, type: 'product_prd', category: 'story', title: 'Export reports', subtitle: 'Entreprise', body: 'Exporter des rapports pour analyser les coûts.', meta: 'BIZ-02', sort_order: 44 },
  { id: 45, type: 'product_prd', category: 'story', title: 'Activate charger on site', subtitle: 'Installateur', body: 'Activer une borne depuis l’espace installateur.', meta: 'INS-01', sort_order: 45 },
  { id: 50, type: 'product_prd', category: 'rule', title: 'Single owner per charger', subtitle: 'Business rule', body: 'Une borne appartient à un seul propriétaire à la fois.', meta: 'BR-01', sort_order: 50 },
  { id: 51, type: 'product_prd', category: 'rule', title: 'One active session per connector', subtitle: 'Business rule', body: 'Une seule session active par connecteur.', meta: 'BR-02', sort_order: 51 },
  { id: 52, type: 'product_prd', category: 'rule', title: 'Firmware privilege gate', subtitle: 'Business rule', body: 'Firmware réservé aux utilisateurs habilités.', meta: 'BR-03', sort_order: 52 },
  { id: 53, type: 'product_prd', category: 'rule', title: 'Technical audit log', subtitle: 'Business rule', body: 'Toute intervention technique est journalisée.', meta: 'BR-04', sort_order: 53 },
  { id: 54, type: 'product_prd', category: 'rule', title: 'Configurable tariffs', subtitle: 'Business rule', body: 'Tarifs configurables par type de client.', meta: 'BR-05', sort_order: 54 },
  { id: 60, type: 'product_prd', category: 'acceptance', title: 'Connexion', subtitle: 'Acceptance criteria', body: 'Identifiants valides · erreur claire · session sécurisée.', meta: 'AC-AUTH', sort_order: 60 },
  { id: 61, type: 'product_prd', category: 'acceptance', title: 'Démarrage recharge', subtitle: 'Acceptance criteria', body: 'Borne online · connecteur libre · confirmation · notification.', meta: 'AC-START', sort_order: 61 },
  { id: 62, type: 'product_prd', category: 'acceptance', title: 'Ajout d’une borne', subtitle: 'Acceptance criteria', body: 'Série valide · association compte · sync Cloud.', meta: 'AC-ADD', sort_order: 62 },
  { id: 70, type: 'product_prd', category: 'nfr', title: 'Page load < 2s', subtitle: 'NFR', body: 'Chargement d’une page sous 2 secondes.', meta: 'PERF-1', sort_order: 70 },
  { id: 71, type: 'product_prd', category: 'nfr', title: 'API < 500 ms', subtitle: 'NFR', body: 'Opérations courantes sous 500 ms.', meta: 'PERF-2', sort_order: 71 },
  { id: 72, type: 'product_prd', category: 'nfr', title: 'Disponibilité ≥ 99,5 %', subtitle: 'NFR', body: 'Objectif de disponibilité plateforme.', meta: 'AVAIL', sort_order: 72 },
  { id: 73, type: 'product_prd', category: 'nfr', title: 'Sécurité', subtitle: 'NFR', body: 'TLS, audit des actions critiques, RBAC.', meta: 'SEC', sort_order: 73 },
  { id: 74, type: 'product_prd', category: 'nfr', title: 'Compatibilité', subtitle: 'NFR', body: 'Android, iOS, web moderne.', meta: 'COMPAT', sort_order: 74 },
  { id: 80, type: 'product_prd', category: 'mvp', title: 'Connexion utilisateur', subtitle: 'MVP 1.0', body: 'Auth multi-surface sécurisée.', meta: 'M1', sort_order: 80 },
  { id: 81, type: 'product_prd', category: 'mvp', title: 'Ajout d’une borne', subtitle: 'MVP 1.0', body: 'Onboarding série + compte.', meta: 'M2', sort_order: 81 },
  { id: 82, type: 'product_prd', category: 'mvp', title: 'Start / Stop', subtitle: 'MVP 1.0', body: 'Contrôle session app + Cloud.', meta: 'M3', sort_order: 82 },
  { id: 83, type: 'product_prd', category: 'mvp', title: 'Tableau de bord', subtitle: 'MVP 1.0', body: 'Statut bornes et sessions.', meta: 'M4', sort_order: 83 },
  { id: 84, type: 'product_prd', category: 'mvp', title: 'Historique', subtitle: 'MVP 1.0', body: 'Sessions et consommation.', meta: 'M5', sort_order: 84 },
  { id: 85, type: 'product_prd', category: 'mvp', title: 'Notifications', subtitle: 'MVP 1.0', body: 'Fin de session et alertes.', meta: 'M6', sort_order: 85 },
  { id: 86, type: 'product_prd', category: 'mvp', title: 'Cloud admin', subtitle: 'MVP 1.0', body: 'Console administrateur.', meta: 'M7', sort_order: 86 },
  { id: 87, type: 'product_prd', category: 'mvp', title: 'OCPP 1.6J', subtitle: 'MVP 1.0', body: 'Intégration protocolaire chargeurs.', meta: 'M8', sort_order: 87 },
  { id: 90, type: 'product_prd', category: 'roadmap', title: 'Version 1.0', subtitle: 'Product roadmap', body: 'Mobile · Cloud Dashboard · gestion bornes.', meta: 'v1.0', sort_order: 90 },
  { id: 91, type: 'product_prd', category: 'roadmap', title: 'Version 1.5', subtitle: 'Product roadmap', body: 'Paiement · rapports avancés · multi-users.', meta: 'v1.5', sort_order: 91 },
  { id: 92, type: 'product_prd', category: 'roadmap', title: 'Version 2.0', subtitle: 'Product roadmap', body: 'Flotte · API partenaires · IA prédictive · analytics.', meta: 'v2.0', sort_order: 92 },
];

function Fade({ children, className, delay = 0 }: { children: ReactNode; className?: string; delay?: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-40px' }}
      transition={{ duration: 0.45, delay }}
      className={className}
    >
      {children}
    </motion.div>
  );
}

function Section({
  id, kicker, title, lead, children,
}: {
  id: string; kicker: string; title: string; lead?: string; children: ReactNode;
}) {
  return (
    <section id={id} className="scroll-mt-28 py-16 md:py-20 border-t border-white/[0.06]">
      <Fade>
        <p className="text-violet-300 text-xs font-semibold tracking-[0.28em] uppercase mb-3">{kicker}</p>
        <h2 className="font-display text-2xl md:text-4xl font-bold tracking-tight max-w-3xl">{title}</h2>
        {lead && <p className="mt-3 text-kyn-silver max-w-2xl leading-relaxed">{lead}</p>}
      </Fade>
      <div className="mt-8">{children}</div>
    </section>
  );
}

function Card({
  title, body, meta, icon: Icon, badge,
}: {
  title: string; body: string; meta?: string | null; badge?: string;
  icon?: ComponentType<{ size?: number; className?: string }>;
}) {
  return (
    <div className="rounded-2xl border border-white/10 bg-gradient-to-b from-white/[0.045] to-transparent p-5 h-full hover:border-violet-400/35 transition-colors">
      <div className="flex items-start justify-between gap-3 mb-3">
        <div className="w-10 h-10 rounded-xl border border-violet-400/25 bg-violet-400/10 text-violet-300 flex items-center justify-center shrink-0">
          {Icon ? <Icon size={18} /> : <CircleDot size={18} />}
        </div>
        {(meta || badge) && (
          <span className="text-[10px] font-semibold tracking-wider uppercase px-2 py-1 rounded-full border border-white/10 text-kyn-metal">
            {badge || meta}
          </span>
        )}
      </div>
      <h3 className="font-display font-semibold text-white leading-snug">{title}</h3>
      <p className="mt-2 text-sm text-kyn-silver leading-relaxed">{body}</p>
    </div>
  );
}

export default function ProductRequirements() {
  const [items, setItems] = useState<Item[]>([]);
  const [loading, setLoading] = useState(true);
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    apiGet<Item[]>('/api/marketing-content?type=product_prd')
      .then((data) => setItems(Array.isArray(data) && data.length ? data : FALLBACK))
      .catch(() => setItems(FALLBACK))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const by = useMemo(() => {
    const map: Record<string, Item[]> = {};
    for (const it of items) {
      (map[it.category] ||= []).push(it);
    }
    Object.values(map).forEach((arr) => arr.sort((a, b) => (a.sort_order ?? 0) - (b.sort_order ?? 0)));
    return map;
  }, [items]);

  const overview = by.overview?.[0];
  const personaIcon = [Smartphone, Building2, Wrench, Shield] as const;
  if (loading) {
    return (
      <div className="min-h-screen bg-kyn-black flex items-center justify-center">
        <LoadingState label="Loading Product Requirements…" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#05060a] text-white">
      <div className="pointer-events-none fixed inset-0 bg-[radial-gradient(ellipse_at_top,rgba(167,139,250,0.12),transparent_45%),radial-gradient(ellipse_at_bottom_right,rgba(0,230,118,0.08),transparent_40%)]" />

      <header className={cn(
        'fixed top-0 inset-x-0 z-50 transition-all border-b',
        scrolled ? 'bg-black/80 backdrop-blur-xl border-white/10' : 'bg-transparent border-transparent'
      )}>
        <div className="max-w-7xl mx-auto px-5 md:px-8 h-16 flex items-center justify-between gap-4">
          <Link to="/" className="shrink-0"><BrandLogo height={28} /></Link>
          <nav className="hidden lg:flex items-center gap-1 overflow-x-auto">
            {NAV.map((n) => (
              <a key={n.id} href={`#${n.id}`} className="px-2.5 py-1.5 rounded-lg text-[11px] text-kyn-metal hover:text-white hover:bg-white/5 transition-colors whitespace-nowrap">
                {n.label}
              </a>
            ))}
          </nav>
          <div className="flex items-center gap-2">
            <Link to="/engineering-pack" className="hidden sm:inline-flex items-center gap-1.5 text-xs text-kyn-silver hover:text-white px-3 py-2 rounded-full border border-white/10">
              <Network size={14} /> Architecture
            </Link>
            <Link to="/ops" className="hidden md:inline-flex items-center gap-1.5 text-xs font-semibold text-kyn-black bg-kyn-green px-3.5 py-2 rounded-full hover:bg-kyn-green-glow">
              Ops <ArrowRight size={14} />
            </Link>
            <button type="button" className="lg:hidden p-2 rounded-lg border border-white/10" onClick={() => setMenuOpen((v) => !v)} aria-label="Menu">
              {menuOpen ? <X size={18} /> : <Menu size={18} />}
            </button>
          </div>
        </div>
        {menuOpen && (
          <div className="lg:hidden border-t border-white/10 bg-black/95 px-5 py-4 grid grid-cols-2 gap-2">
            {NAV.map((n) => (
              <a key={n.id} href={`#${n.id}`} onClick={() => setMenuOpen(false)} className="text-sm text-kyn-silver py-2">{n.label}</a>
            ))}
          </div>
        )}
      </header>

      <main className="relative max-w-7xl mx-auto px-5 md:px-8 pt-28 pb-20">
        {/* HERO */}
        <section id="overview" className="scroll-mt-28 pb-10">
          <Fade>
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-violet-400/30 bg-violet-400/10 text-violet-200 text-xs font-semibold tracking-wide mb-6">
              <FileText size={13} /> Phase 26 · Product Requirements Document
            </div>
            <p className="text-kyn-metal text-xs tracking-[0.3em] uppercase font-semibold mb-3">PRD · Engineering-ready</p>
            <h1 className="font-display text-4xl md:text-6xl font-bold tracking-tight leading-[1.05] max-w-4xl">
              {overview?.title || 'KYNETIK Smart EV Charging Ecosystem'}
              <span className="block text-violet-300 mt-2">Product Requirements v1.0</span>
            </h1>
            <p className="mt-6 text-lg text-kyn-silver max-w-2xl leading-relaxed">
              {overview?.body}
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              {[
                { t: 'Personas', d: '4' },
                { t: 'Modules', d: '6' },
                { t: 'MVP items', d: '8' },
                { t: 'Roadmap', d: '3 releases' },
              ].map((s) => (
                <div key={s.t} className="rounded-2xl border border-white/10 bg-white/[0.03] px-4 py-3 min-w-[120px]">
                  <p className="text-xl font-display font-bold text-violet-200">{s.d}</p>
                  <p className="text-[11px] text-kyn-metal uppercase tracking-wider mt-0.5">{s.t}</p>
                </div>
              ))}
            </div>
            <div className="mt-8 flex flex-wrap gap-3">
              <a href="#mvp" className="inline-flex items-center gap-2 px-5 py-3 rounded-full bg-kyn-green text-kyn-black text-sm font-bold">
                Voir le MVP <ChevronRight size={16} />
              </a>
              <Link to="/architecture" className="inline-flex items-center gap-2 px-5 py-3 rounded-full border border-white/15 text-sm font-semibold hover:border-violet-400/40">
                Enterprise Architecture
              </Link>
              <Link to="/product-spec" className="inline-flex items-center gap-2 px-5 py-3 rounded-full border border-white/15 text-sm font-semibold hover:border-white/30">
                Product Spec
              </Link>
            </div>
          </Fade>

          <Fade delay={0.08} className="mt-12 grid md:grid-cols-3 gap-4">
            {[
              { icon: Target, t: 'Purpose', d: 'Unifier hardware, app, Cloud et ops dans un PRD unique pour l’ingénierie.' },
              { icon: BadgeCheck, t: 'Scope v1', d: 'Auth, bornes, sessions, dashboard, historique, notifications, OCPP, Cloud admin.' },
              { icon: Sparkles, t: 'Outcome', d: 'Critères d’acceptation et règles métier exécutables par les équipes produit.' },
            ].map((c) => (
              <div key={c.t} className="rounded-2xl border border-white/10 p-5 bg-black/30">
                <c.icon className="text-violet-300 mb-3" size={20} />
                <p className="font-semibold">{c.t}</p>
                <p className="mt-2 text-sm text-kyn-silver leading-relaxed">{c.d}</p>
              </div>
            ))}
          </Fade>
        </section>

        {/* OBJECTIVES */}
        <Section id="objectives" kicker="02 · Business objectives" title="Objectifs principaux" lead="Ce que le produit doit livrer pour la Tunisie puis l’expansion régionale.">
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {(by.objective || []).map((it, i) => (
              <Fade key={it.id} delay={i * 0.04}>
                <Card title={it.title} body={it.body} meta={it.meta} icon={Target} />
              </Fade>
            ))}
          </div>
        </Section>

        {/* PERSONAS */}
        <Section id="personas" kicker="03 · Personas" title="Qui utilise KYNETIK" lead="Quatre personas structurantes pour prioriser les parcours.">
          <div className="grid sm:grid-cols-2 gap-4">
            {(by.persona || []).map((it, i) => {
              const Icon = personaIcon[i % personaIcon.length];
              return (
                <Fade key={it.id} delay={i * 0.04}>
                  <div className="rounded-2xl border border-white/10 bg-gradient-to-br from-violet-500/10 via-transparent to-transparent p-6 h-full">
                    <div className="flex items-center gap-3 mb-4">
                      <div className="w-11 h-11 rounded-2xl bg-violet-400/15 border border-violet-400/25 text-violet-200 flex items-center justify-center">
                        <Icon size={20} />
                      </div>
                      <div>
                        <p className="text-[10px] uppercase tracking-[0.2em] text-violet-300/80 font-semibold">{it.subtitle}</p>
                        <h3 className="font-display text-xl font-bold">{it.title}</h3>
                      </div>
                    </div>
                    <p className="text-sm text-kyn-silver leading-relaxed">{it.body}</p>
                  </div>
                </Fade>
              );
            })}
          </div>
        </Section>

        {/* MODULES */}
        <Section id="modules" kicker="04 · Modules fonctionnels" title="Capacités produit" lead="Découpage fonctionnel pour l’implémentation et le backlog.">
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {(by.module || []).map((it, i) => {
              const icons = [Shield, Users, Layers, Rocket, Gauge, ClipboardList];
              const Icon = icons[i % icons.length];
              return (
                <Fade key={it.id} delay={i * 0.03}>
                  <Card title={it.title} body={it.body} meta={it.meta} icon={Icon} />
                </Fade>
              );
            })}
          </div>
        </Section>

        {/* STORIES */}
        <Section id="stories" kicker="05 · User stories" title="Récits utilisateurs prioritaires" lead="Formulation prête pour le backlog agile.">
          <div className="space-y-3">
            {(by.story || []).map((it, i) => (
              <Fade key={it.id} delay={Math.min(i * 0.03, 0.2)}>
                <div className="rounded-2xl border border-white/10 bg-white/[0.02] p-5 md:p-6 flex flex-col md:flex-row md:items-start gap-4">
                  <div className="shrink-0">
                    <span className="inline-flex items-center px-2.5 py-1 rounded-full text-[10px] font-bold tracking-wider uppercase border border-violet-400/30 bg-violet-400/10 text-violet-200">
                      {it.meta}
                    </span>
                    <p className="mt-2 text-xs text-kyn-metal uppercase tracking-wider">{it.subtitle}</p>
                  </div>
                  <div className="min-w-0">
                    <h3 className="font-display font-semibold text-lg">{it.title}</h3>
                    <p className="mt-2 text-sm text-kyn-silver leading-relaxed">{it.body}</p>
                  </div>
                </div>
              </Fade>
            ))}
          </div>
        </Section>

        {/* RULES */}
        <Section id="rules" kicker="06 · Business rules" title="Règles métier essentielles" lead="Contraintes non négociables pour la cohérence système.">
          <div className="grid md:grid-cols-2 gap-4">
            {(by.rule || []).map((it, i) => (
              <Fade key={it.id} delay={i * 0.03}>
                <div className="rounded-2xl border border-amber-400/20 bg-amber-400/[0.04] p-5 flex gap-3">
                  <Scale className="text-amber-300 shrink-0 mt-0.5" size={18} />
                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <h3 className="font-semibold">{it.title}</h3>
                      <span className="text-[10px] text-amber-200/80 font-mono">{it.meta}</span>
                    </div>
                    <p className="mt-2 text-sm text-kyn-silver leading-relaxed">{it.body}</p>
                  </div>
                </div>
              </Fade>
            ))}
          </div>
        </Section>

        {/* ACCEPTANCE */}
        <Section id="acceptance" kicker="07 · Acceptance criteria" title="Exemples de critères d’acceptation" lead="Definition of Done pour les flux critiques.">
          <div className="grid md:grid-cols-3 gap-4">
            {(by.acceptance || []).map((it, i) => (
              <Fade key={it.id} delay={i * 0.04}>
                <div className="rounded-2xl border border-white/10 p-5 h-full bg-black/25">
                  <div className="flex items-center gap-2 text-kyn-green mb-3">
                    <ListChecks size={18} />
                    <span className="text-[10px] font-bold tracking-wider uppercase">{it.meta}</span>
                  </div>
                  <h3 className="font-display font-semibold text-lg">{it.title}</h3>
                  <ul className="mt-3 space-y-2">
                    {it.body.split('·').map((part) => (
                      <li key={part} className="flex gap-2 text-sm text-kyn-silver">
                        <CheckCircle2 size={14} className="text-kyn-green shrink-0 mt-0.5" />
                        <span>{part.trim()}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </Fade>
            ))}
          </div>
        </Section>

        {/* NFR */}
        <Section id="nfr" kicker="08 · Non-functional" title="Exigences non fonctionnelles" lead="Performance, disponibilité, sécurité et compatibilité.">
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {(by.nfr || []).map((it, i) => {
              const icons = [Timer, Gauge, Globe2, Shield, Smartphone];
              const Icon = icons[i % icons.length];
              return (
                <Fade key={it.id} delay={i * 0.03}>
                  <Card title={it.title} body={it.body} meta={it.meta} icon={Icon} />
                </Fade>
              );
            })}
          </div>
        </Section>

        {/* MVP */}
        <Section id="mvp" kicker="09 · MVP Version 1" title="Périmètre de lancement" lead="Fonctionnalités prioritaires pour le go-live.">
          <div className="rounded-3xl border border-kyn-green/25 bg-gradient-to-br from-kyn-green/10 via-transparent to-violet-500/10 p-6 md:p-8">
            <div className="flex items-center gap-2 text-kyn-green text-xs font-semibold tracking-[0.2em] uppercase mb-6">
              <Flag size={14} /> Must-have launch set
            </div>
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
              {(by.mvp || []).map((it, i) => (
                <Fade key={it.id} delay={i * 0.03}>
                  <div className="rounded-2xl border border-white/10 bg-black/40 p-4 h-full">
                    <div className="flex items-center justify-between gap-2 mb-2">
                      <span className="text-[10px] font-mono text-kyn-green">{it.meta}</span>
                      <CheckCircle2 size={14} className="text-kyn-green" />
                    </div>
                    <h3 className="font-semibold text-sm leading-snug">{it.title}</h3>
                    <p className="mt-2 text-xs text-kyn-metal leading-relaxed">{it.body}</p>
                  </div>
                </Fade>
              ))}
            </div>
          </div>
        </Section>

        {/* ROADMAP */}
        <Section id="roadmap" kicker="10 · Product roadmap" title="Trajectoire produit" lead="De la fondation opérationnelle à la plateforme intelligente.">
          <div className="relative">
            <div className="hidden md:block absolute top-8 left-8 right-8 h-px bg-gradient-to-r from-violet-400/40 via-kyn-green/40 to-sky-400/40" />
            <div className="grid md:grid-cols-3 gap-4">
              {(by.roadmap || []).map((it, i) => (
                <Fade key={it.id} delay={i * 0.06}>
                  <div className="relative rounded-3xl border border-white/10 bg-white/[0.03] p-6 h-full">
                    <div className="w-10 h-10 rounded-full border border-violet-300/40 bg-violet-400/15 text-violet-100 flex items-center justify-center font-display font-bold text-sm mb-4">
                      {i + 1}
                    </div>
                    <p className="text-[10px] uppercase tracking-[0.25em] text-violet-300 font-semibold">{it.meta}</p>
                    <h3 className="mt-2 font-display text-2xl font-bold">{it.title}</h3>
                    <p className="mt-3 text-sm text-kyn-silver leading-relaxed">{it.body}</p>
                  </div>
                </Fade>
              ))}
            </div>
          </div>
        </Section>

        {/* ENTERPRISE CLOSING */}
        <section className="mt-8 rounded-3xl border border-white/10 overflow-hidden">
          <div className="bg-gradient-to-r from-violet-600/20 via-black to-kyn-green/10 p-8 md:p-10">
            <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6">
              <div className="max-w-2xl">
                <p className="text-xs font-semibold tracking-[0.25em] uppercase text-violet-200 mb-3">Enterprise dossier</p>
                <h2 className="font-display text-2xl md:text-3xl font-bold">Vision · Design · Marketing · Architecture · PRD</h2>
                <p className="mt-3 text-kyn-silver leading-relaxed">
                  Le socle documentaire est en place. Prochaine étape naturelle : spécifications d’ingénierie détaillées
                  (écrans, pages, contrats API, règles exécutables) pour le build sprint par sprint.
                </p>
              </div>
              <div className="flex flex-wrap gap-3">
                <Link to="/architecture" className="inline-flex items-center gap-2 px-5 py-3 rounded-full bg-white text-kyn-black text-sm font-bold">
                  Architecture <ArrowRight size={16} />
                </Link>
                <Link to="/ops" className="inline-flex items-center gap-2 px-5 py-3 rounded-full border border-white/20 text-sm font-semibold">
                  Ops Blueprint
                </Link>
                <Link to="/console" className="inline-flex items-center gap-2 px-5 py-3 rounded-full border border-white/20 text-sm font-semibold">
                  <Cloud size={16} /> Cloud
                </Link>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t border-white/10 py-8">
        <div className="max-w-7xl mx-auto px-5 md:px-8 flex flex-col md:flex-row gap-4 md:items-center justify-between">
          <BrandLogo height={26} />
          <p className="text-[11px] text-kyn-metal">Phase 26 · Product Requirements Document (PRD) · v1.0</p>
          <div className="flex gap-3 text-[11px] text-kyn-metal">
            <Link to="/architecture" className="hover:text-white">Architecture</Link>
            <Link to="/product-spec" className="hover:text-white">Spec</Link>
            <Link to="/engineering-pack" className="hover:text-white">Eng Pack</Link>
            <Link to="/developers" className="hover:text-white">API</Link>
          </div>
        </div>
      </footer>
    </div>
  );
}


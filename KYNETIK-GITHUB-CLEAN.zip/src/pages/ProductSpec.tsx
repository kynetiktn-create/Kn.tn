import { useEffect, useMemo, useState, type ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  ArrowRight, BookOpen, Target, Users, Layout, Shield, KeyRound, FileText,
  Settings2, Gauge, Webhook, BarChart3, Bell, Map as MapIcon, CheckCircle2, Menu, X,
  ChevronRight, Layers, Flag, Compass, Workflow, Database, Rocket, CircleDot
} from 'lucide-react';
import BrandLogo from '../components/BrandLogo';
import LoadingState from '../components/LoadingState';
import ErrorState from '../components/ErrorState';
import { apiGet, cn } from '../lib/utils';

interface SpecSection {
  id: number;
  section_key: string;
  title: string;
  subtitle: string | null;
  body: string | null;
  content_json: unknown;
  sort_order: number;
}

type JsonRec = Record<string, unknown>;

function asArray(v: unknown): unknown[] {
  return Array.isArray(v) ? v : [];
}

function asObj(v: unknown): JsonRec {
  return v && typeof v === 'object' && !Array.isArray(v) ? (v as JsonRec) : {};
}

function asString(v: unknown): string {
  return typeof v === 'string' ? v : v == null ? '' : String(v);
}

const navIcons: Record<string, typeof Target> = {
  cover: BookOpen,
  vision: Compass,
  mission: Flag,
  objectives: Target,
  users: Users,
  modules: Layout,
  functional: Layers,
  auth: KeyRound,
  quote: FileText,
  configurator: Settings2,
  dashboard: Gauge,
  api: Webhook,
  security: Shield,
  analytics: BarChart3,
  cms: Database,
  notifications: Bell,
  roadmap: MapIcon,
  kpis: Target,
  next: Rocket,
};

export default function ProductSpec() {
  const [sections, setSections] = useState<SpecSection[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [active, setActive] = useState('cover');
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    apiGet<SpecSection[]>('/api/product-spec')
      .then((data) => {
        setSections(data || []);
        if (data?.[0]) setActive(data[0].section_key);
      })
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    const onScroll = () => {
      for (const s of [...sections].reverse()) {
        const el = document.getElementById(`spec-${s.section_key}`);
        if (el && el.getBoundingClientRect().top <= 120) {
          setActive(s.section_key);
          break;
        }
      }
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, [sections]);

  const byKey = useMemo(() => {
    const m = new Map<string, SpecSection>();
    sections.forEach((s) => m.set(s.section_key, s));
    return m;
  }, [sections]);

  if (loading) {
    return (
      <div className="min-h-screen bg-[#07080a] flex items-center justify-center">
        <LoadingState label="Loading Product Specification…" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-[#07080a] flex items-center justify-center p-8">
        <ErrorState message={error} />
      </div>
    );
  }

  const scrollTo = (key: string) => {
    setActive(key);
    setMenuOpen(false);
    document.getElementById(`spec-${key}`)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  return (
    <div className="min-h-screen bg-[#07080a] text-white">
      {/* Top bar */}
      <header className="sticky top-0 z-50 border-b border-white/5 bg-[#07080a]/90 backdrop-blur-xl">
        <div className="max-w-[1400px] mx-auto px-4 md:px-8 h-16 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 min-w-0">
            <BrandLogo height={28} />
            <div className="hidden sm:block h-5 w-px bg-white/10" />
            <div className="hidden sm:block min-w-0">
              <p className="text-[10px] uppercase tracking-[0.22em] text-kyn-green font-semibold">Product Specification</p>
              <p className="text-xs text-kyn-metal truncate">Smart EV Mobility Platform · Tunisia & North Africa</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <span className="hidden md:inline-flex text-[10px] px-2.5 py-1 rounded-full border border-kyn-green/30 text-kyn-green bg-kyn-green/10 font-semibold">
              v1.0 · Strategic
            </span>
            <span className="hidden lg:inline text-[10px] text-kyn-metal">Confidential · Product Design</span>
            <Link to="/product-system" className="hidden sm:inline-flex text-xs text-kyn-silver hover:text-white px-3 py-1.5">
              Product System
            </Link>
            <button type="button" className="lg:hidden p-2 text-kyn-silver" onClick={() => setMenuOpen(!menuOpen)}>
              {menuOpen ? <X size={18} /> : <Menu size={18} />}
            </button>
          </div>
        </div>
        {menuOpen && (
          <div className="lg:hidden border-t border-white/5 px-4 py-3 max-h-[60vh] overflow-y-auto space-y-1 bg-[#0a0b0e]">
            {sections.map((s) => (
              <button
                key={s.section_key}
                type="button"
                onClick={() => scrollTo(s.section_key)}
                className={cn(
                  'w-full text-left px-3 py-2 rounded-lg text-sm',
                  active === s.section_key ? 'bg-kyn-green/10 text-kyn-green' : 'text-kyn-silver'
                )}
              >
                {s.title}
              </button>
            ))}
          </div>
        )}
      </header>

      <div className="max-w-[1400px] mx-auto px-4 md:px-8 py-8 md:py-12 grid lg:grid-cols-[260px_1fr] gap-8 lg:gap-12">
        {/* Side nav */}
        <aside className="hidden lg:block">
          <div className="sticky top-24 space-y-1 max-h-[calc(100vh-8rem)] overflow-y-auto pr-2">
            <p className="text-[10px] uppercase tracking-[0.2em] text-kyn-metal mb-3 px-3">Document map</p>
            {sections.map((s, i) => {
              const Icon = navIcons[s.section_key] || CircleDot;
              return (
                <button
                  key={s.section_key}
                  type="button"
                  onClick={() => scrollTo(s.section_key)}
                  className={cn(
                    'w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-left text-[12px] transition-all',
                    active === s.section_key
                      ? 'bg-kyn-green/10 text-kyn-green border border-kyn-green/20'
                      : 'text-kyn-metal hover:text-white hover:bg-white/5 border border-transparent'
                  )}
                >
                  <span className="text-[10px] w-4 opacity-50 font-mono">{String(i + 1).padStart(2, '0')}</span>
                  <Icon size={13} className="shrink-0" />
                  <span className="truncate">{s.title}</span>
                </button>
              );
            })}
            <div className="mt-6 p-4 rounded-xl border border-kyn-green/20 bg-kyn-green/5">
              <p className="text-[10px] uppercase tracking-wider text-kyn-green font-semibold mb-1">Next gate</p>
              <p className="text-xs text-kyn-silver leading-relaxed">UX Flows & User Journeys before prototype & build.</p>
            </div>
          </div>
        </aside>

        {/* Content */}
        <main className="min-w-0 space-y-10 md:space-y-14 pb-24">
          {/* Cover */}
          <CoverBlock section={byKey.get('cover')} />

          {sections
            .filter((s) => s.section_key !== 'cover')
            .map((section, idx) => (
              <SectionShell key={section.id} section={section} index={idx + 1}>
                <SectionBody section={section} />
              </SectionShell>
            ))}

          {/* Footer CTA */}
          <section className="rounded-3xl border border-kyn-green/25 bg-gradient-to-br from-kyn-green/10 via-[#0c0e12] to-[#07080a] p-8 md:p-12 text-center">
            <p className="text-kyn-green text-xs font-semibold tracking-[0.25em] uppercase mb-3">Phase gate</p>
            <h2 className="font-display text-2xl md:text-4xl font-bold max-w-2xl mx-auto leading-tight">
              Next critical step: UX Flows & User Journeys
            </h2>
            <p className="mt-4 text-kyn-silver max-w-xl mx-auto text-sm md:text-base leading-relaxed">
              This Product Specification locks the strategic and functional scope. The immediate next deliverable is a
              complete journey map for each user type — before high-fidelity prototype and engineering sprint planning.
            </p>
            <div className="mt-8 flex flex-wrap justify-center gap-3">
              <Link
                to="/prototype"
                className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-kyn-green text-kyn-black text-sm font-bold"
              >
                Open prototype workspace <ArrowRight size={15} />
              </Link>
              <Link
                to="/product-system"
                className="inline-flex items-center gap-2 px-6 py-3 rounded-full border border-white/15 text-sm font-medium text-white"
              >
                Product System
              </Link>
              <Link
                to="/handoff"
                className="inline-flex items-center gap-2 px-6 py-3 rounded-full border border-white/15 text-sm font-medium text-white"
              >
                Dev handoff
              </Link>
            </div>
          </section>

          <footer className="border-t border-white/5 pt-8 flex flex-wrap justify-between gap-3 text-[11px] text-kyn-metal">
            <p>KYNETIK · Product Design Lead · Tunisia & North Africa</p>
            <p>Document status: Approved for UX journey phase</p>
          </footer>
        </main>
      </div>
    </div>
  );
}

function CoverBlock({ section }: { section?: SpecSection }) {
  const meta = asObj(section?.content_json);
  const chips = asArray(meta.meta).map(asString);

  return (
    <section id="spec-cover" className="relative overflow-hidden rounded-3xl border border-white/10 bg-[#0c0e12]">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,rgba(0,230,118,0.14),transparent_50%)]" />
      <div className="absolute inset-0 grid-bg opacity-30" />
      <div className="relative z-10 p-8 md:p-14">
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}>
          <div className="flex flex-wrap items-center gap-2 mb-8">
            <span className="text-[10px] uppercase tracking-[0.25em] text-kyn-green font-semibold px-2.5 py-1 rounded-full border border-kyn-green/30 bg-kyn-green/10">
              Enterprise Product Spec
            </span>
            {chips.map((c) => (
              <span key={c} className="text-[10px] px-2.5 py-1 rounded-full bg-white/5 border border-white/10 text-kyn-metal">
                {c}
              </span>
            ))}
          </div>
          <p className="text-kyn-metal text-sm mb-3">Product Design Lead · Strategic Document</p>
          <h1 className="font-display text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold leading-[1.08] max-w-3xl">
            {section?.title || 'KYNETIK Product Specification'}
          </h1>
          <p className="mt-4 text-lg md:text-xl text-kyn-green font-medium">
            {section?.subtitle || 'Smart EV Charging Platform'}
          </p>
          <p className="mt-6 text-kyn-silver max-w-2xl leading-relaxed text-sm md:text-base">
            {section?.body}
          </p>
          <div className="mt-10 grid grid-cols-2 md:grid-cols-4 gap-3">
            {[
              { l: 'Region', v: 'Tunisia · MENA' },
              { l: 'Category', v: 'EV Hardware + SaaS' },
              { l: 'Stage', v: 'Spec → UX Journeys' },
              { l: 'Owner', v: 'Product Design' },
            ].map((x) => (
              <div key={x.l} className="rounded-xl border border-white/8 bg-black/30 p-4">
                <p className="text-[10px] uppercase tracking-wider text-kyn-metal">{x.l}</p>
                <p className="font-display font-semibold mt-1 text-sm md:text-base">{x.v}</p>
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}

function SectionShell({
  section,
  index,
  children,
}: {
  section: SpecSection;
  index: number;
  children: ReactNode;
}) {
  return (
    <section id={`spec-${section.section_key}`} className="scroll-mt-24">
      <div className="flex items-start gap-4 mb-6">
        <div className="w-10 h-10 rounded-xl bg-kyn-green/10 border border-kyn-green/20 flex items-center justify-center text-kyn-green font-display font-bold text-sm shrink-0">
          {String(index).padStart(2, '0')}
        </div>
        <div>
          <h2 className="font-display text-2xl md:text-3xl font-bold tracking-tight">{section.title}</h2>
          {section.subtitle && <p className="text-kyn-green text-sm mt-1 font-medium">{section.subtitle}</p>}
          {section.body && <p className="text-kyn-silver mt-3 max-w-3xl leading-relaxed text-sm md:text-base">{section.body}</p>}
        </div>
      </div>
      {children}
    </section>
  );
}

function SectionBody({ section }: { section: SpecSection }) {
  const data = section.content_json;
  const key = section.section_key;

  if (key === 'vision' || key === 'mission') {
    const o = asObj(data);
    const pillars = asArray(o.pillars).map(asString);
    return (
      <div className="grid md:grid-cols-3 gap-3">
        {pillars.map((p, i) => (
          <div key={i} className="rounded-2xl border border-white/8 bg-white/[0.02] p-5">
            <div className="w-8 h-8 rounded-lg bg-kyn-green/10 text-kyn-green flex items-center justify-center text-xs font-bold mb-3">
              {i + 1}
            </div>
            <p className="text-sm text-kyn-silver leading-relaxed">{p}</p>
          </div>
        ))}
      </div>
    );
  }

  if (key === 'objectives') {
    const rows = asArray(data);
    return (
      <div className="overflow-x-auto rounded-2xl border border-white/10">
        <table className="w-full text-left text-sm min-w-[640px]">
          <thead className="bg-white/[0.03] text-[11px] uppercase tracking-wider text-kyn-metal">
            <tr>
              <th className="px-4 py-3 font-medium">Objective</th>
              <th className="px-4 py-3 font-medium">Horizon</th>
              <th className="px-4 py-3 font-medium">Success metric</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/5">
            {rows.map((r, i) => {
              const o = asObj(r);
              return (
                <tr key={i} className="text-kyn-silver">
                  <td className="px-4 py-3.5 text-white font-medium">{asString(o.objective)}</td>
                  <td className="px-4 py-3.5">
                    <span className="text-[11px] px-2 py-1 rounded-md bg-kyn-green/10 text-kyn-green border border-kyn-green/20">
                      {asString(o.horizon)}
                    </span>
                  </td>
                  <td className="px-4 py-3.5">{asString(o.metric)}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    );
  }

  if (key === 'users') {
    const rows = asArray(data);
    return (
      <div className="grid md:grid-cols-2 gap-4">
        {rows.map((r, i) => {
          const o = asObj(r);
          const needs = asArray(o.needs).map(asString);
          return (
            <div key={i} className="rounded-2xl border border-white/8 bg-[#0c0e12] p-6">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="font-display text-lg font-bold">{asString(o.role)}</p>
                  <p className="text-xs text-kyn-green mt-1">{asString(o.segment)}</p>
                </div>
                <Users size={18} className="text-kyn-green shrink-0" />
              </div>
              <p className="text-sm text-kyn-metal mt-3 leading-relaxed">{asString(o.goal)}</p>
              <ul className="mt-4 space-y-2">
                {needs.map((n) => (
                  <li key={n} className="flex gap-2 text-xs text-kyn-silver">
                    <CheckCircle2 size={13} className="text-kyn-green shrink-0 mt-0.5" />
                    {n}
                  </li>
                ))}
              </ul>
            </div>
          );
        })}
      </div>
    );
  }

  if (key === 'modules') {
    const rows = asArray(data);
    return (
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {rows.map((r, i) => {
          const o = asObj(r);
          return (
            <div key={i} className="rounded-2xl border border-white/8 bg-white/[0.02] p-5 hover:border-kyn-green/25 transition-colors">
              <div className="flex items-center gap-2 mb-2">
                <Layout size={14} className="text-kyn-green" />
                <p className="font-semibold text-sm">{asString(o.module)}</p>
              </div>
              <p className="text-xs text-kyn-metal leading-relaxed">{asString(o.purpose)}</p>
              <p className="mt-3 text-[10px] uppercase tracking-wider text-kyn-green">{asString(o.surface)}</p>
            </div>
          );
        })}
      </div>
    );
  }

  if (key === 'functional' || key === 'security' || key === 'analytics' || key === 'cms' || key === 'notifications') {
    const rows = asArray(data);
    return (
      <div className="space-y-2">
        {rows.map((r, i) => {
          const o = asObj(r);
          return (
            <div key={i} className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-4 rounded-xl border border-white/8 bg-black/20 px-4 py-3">
              <span className="text-[11px] font-mono text-kyn-green shrink-0 w-20">{asString(o.id) || `REQ-${i + 1}`}</span>
              <p className="text-sm text-white flex-1">{asString(o.requirement) || asString(o.item) || asString(o.title)}</p>
              <span className="text-[10px] px-2 py-1 rounded-md bg-white/5 text-kyn-metal border border-white/10 shrink-0">
                {asString(o.priority) || asString(o.level) || 'Must'}
              </span>
            </div>
          );
        })}
      </div>
    );
  }

  if (key === 'auth' || key === 'quote' || key === 'configurator' || key === 'dashboard') {
    const o = asObj(data);
    const steps = asArray(o.flow).map(asString);
    const features = asArray(o.features).map(asString);
    const roles = asArray(o.roles).map(asString);
    return (
      <div className="grid lg:grid-cols-2 gap-4">
        <div className="rounded-2xl border border-white/10 bg-[#0c0e12] p-6">
          <p className="text-[10px] uppercase tracking-wider text-kyn-green font-semibold mb-4 flex items-center gap-2">
            <Workflow size={13} /> Primary flow
          </p>
          <ol className="space-y-3">
            {steps.map((s, i) => (
              <li key={i} className="flex gap-3 items-start">
                <span className="w-6 h-6 rounded-full bg-kyn-green/15 text-kyn-green text-[11px] font-bold flex items-center justify-center shrink-0">
                  {i + 1}
                </span>
                <span className="text-sm text-kyn-silver pt-0.5">{s}</span>
              </li>
            ))}
          </ol>
        </div>
        <div className="rounded-2xl border border-white/10 bg-[#0c0e12] p-6">
          <p className="text-[10px] uppercase tracking-wider text-kyn-green font-semibold mb-4 flex items-center gap-2">
            <Layers size={13} /> Capabilities
          </p>
          <ul className="space-y-2.5">
            {features.map((f) => (
              <li key={f} className="flex gap-2 text-sm text-kyn-silver">
                <ChevronRight size={14} className="text-kyn-green shrink-0 mt-0.5" />
                {f}
              </li>
            ))}
          </ul>
          {roles.length > 0 && (
            <div className="mt-5 pt-4 border-t border-white/5 flex flex-wrap gap-2">
              {roles.map((r) => (
                <span key={r} className="text-[10px] px-2.5 py-1 rounded-full border border-white/10 text-kyn-metal">
                  {r}
                </span>
              ))}
            </div>
          )}
        </div>
      </div>
    );
  }

  if (key === 'api') {
    const o = asObj(data);
    const endpoints = asArray(o.endpoints);
    const principles = asArray(o.principles).map(asString);
    return (
      <div className="space-y-4">
        {principles.length > 0 && (
          <div className="flex flex-wrap gap-2">
            {principles.map((p) => (
              <span key={p} className="text-[11px] px-3 py-1.5 rounded-full border border-kyn-green/25 text-kyn-green bg-kyn-green/5">
                {p}
              </span>
            ))}
          </div>
        )}
        <div className="overflow-x-auto rounded-2xl border border-white/10">
          <table className="w-full text-left text-sm min-w-[640px]">
            <thead className="bg-white/[0.03] text-[11px] uppercase tracking-wider text-kyn-metal">
              <tr>
                <th className="px-4 py-3 font-medium">Method</th>
                <th className="px-4 py-3 font-medium">Endpoint</th>
                <th className="px-4 py-3 font-medium">Purpose</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {endpoints.map((e, i) => {
                const row = asObj(e);
                return (
                  <tr key={i} className="text-kyn-silver">
                    <td className="px-4 py-3">
                      <span className="font-mono text-[11px] text-kyn-green">{asString(row.method)}</span>
                    </td>
                    <td className="px-4 py-3 font-mono text-xs text-white">{asString(row.path)}</td>
                    <td className="px-4 py-3">{asString(row.purpose)}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    );
  }

  if (key === 'roadmap') {
    const rows = asArray(data);
    return (
      <div className="relative pl-4 md:pl-0">
        <div className="hidden md:block absolute left-1/2 top-0 bottom-0 w-px bg-gradient-to-b from-kyn-green/50 via-white/10 to-transparent" />
        <div className="space-y-4">
          {rows.map((r, i) => {
            const o = asObj(r);
            const left = i % 2 === 0;
            return (
              <div key={i} className={cn('md:grid md:grid-cols-2 md:gap-8', left ? '' : '')}>
                <div className={cn('rounded-2xl border border-white/10 bg-[#0c0e12] p-5', left ? 'md:mr-6' : 'md:col-start-2 md:ml-6')}>
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-[10px] font-semibold tracking-wider uppercase text-kyn-green">{asString(o.phase)}</span>
                    <span className="text-[10px] text-kyn-metal">{asString(o.timing)}</span>
                  </div>
                  <p className="font-display font-semibold">{asString(o.title)}</p>
                  <p className="text-sm text-kyn-metal mt-2 leading-relaxed">{asString(o.focus)}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  }

  if (key === 'kpis') {
    const rows = asArray(data);
    return (
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {rows.map((r, i) => {
          const o = asObj(r);
          return (
            <div key={i} className="rounded-2xl border border-white/8 bg-gradient-to-b from-white/[0.03] to-transparent p-5">
              <p className="text-[10px] uppercase tracking-wider text-kyn-metal">{asString(o.category)}</p>
              <p className="font-display text-2xl font-bold text-kyn-green mt-2">{asString(o.target)}</p>
              <p className="text-sm text-white mt-1 font-medium">{asString(o.kpi)}</p>
              <p className="text-xs text-kyn-metal mt-2">{asString(o.rationale)}</p>
            </div>
          );
        })}
      </div>
    );
  }

  if (key === 'next') {
    const o = asObj(data);
    const deliverables = asArray(o.deliverables).map(asString);
    const exits = asArray(o.exit_criteria).map(asString);
    return (
      <div className="grid md:grid-cols-2 gap-4">
        <div className="rounded-2xl border border-kyn-green/25 bg-kyn-green/5 p-6">
          <p className="text-xs font-semibold text-kyn-green uppercase tracking-wider mb-3">Deliverables</p>
          <ul className="space-y-2">
            {deliverables.map((d) => (
              <li key={d} className="flex gap-2 text-sm text-kyn-silver">
                <Rocket size={14} className="text-kyn-green shrink-0 mt-0.5" /> {d}
              </li>
            ))}
          </ul>
        </div>
        <div className="rounded-2xl border border-white/10 bg-[#0c0e12] p-6">
          <p className="text-xs font-semibold text-kyn-metal uppercase tracking-wider mb-3">Exit criteria to prototype</p>
          <ul className="space-y-2">
            {exits.map((d) => (
              <li key={d} className="flex gap-2 text-sm text-kyn-silver">
                <CheckCircle2 size={14} className="text-kyn-green shrink-0 mt-0.5" /> {d}
              </li>
            ))}
          </ul>
        </div>
      </div>
    );
  }

  return <GenericJson data={data} />;
}

function GenericJson({ data }: { data: unknown }) {
  if (Array.isArray(data)) {
    const first = data[0];
    if (first && typeof first === 'object') {
      const keys = Object.keys(first as object);
      if (keys.length >= 2) {
        return (
          <div className="overflow-x-auto rounded-2xl border border-white/10">
            <table className="w-full text-left text-sm min-w-[560px]">
              <thead className="bg-white/[0.03] text-[11px] uppercase tracking-wider text-kyn-metal">
                <tr>
                  {keys.map((k) => (
                    <th key={k} className="px-4 py-3 font-medium capitalize">{k.replace(/_/g, ' ')}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {data.map((row, i) => {
                  const o = asObj(row);
                  return (
                    <tr key={i} className="text-kyn-silver">
                      {keys.map((k) => (
                        <td key={k} className="px-4 py-3 align-top">
                          {Array.isArray(o[k])
                            ? (o[k] as unknown[]).map(asString).join(' · ')
                            : asString(o[k])}
                        </td>
                      ))}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        );
      }
    }
    return (
      <ul className="space-y-2">
        {data.map((item, i) => (
          <li key={i} className="flex gap-2 text-sm text-kyn-silver rounded-xl border border-white/8 px-4 py-3">
            <CheckCircle2 size={14} className="text-kyn-green shrink-0 mt-0.5" />
            {asString(item)}
          </li>
        ))}
      </ul>
    );
  }

  const o = asObj(data);
  const entries = Object.entries(o);
  if (!entries.length) return null;

  return (
    <div className="grid md:grid-cols-2 gap-3">
      {entries.map(([k, v]) => (
        <div key={k} className="rounded-2xl border border-white/8 bg-white/[0.02] p-5">
          <p className="text-[10px] uppercase tracking-wider text-kyn-green font-semibold mb-2">{k.replace(/_/g, ' ')}</p>
          {Array.isArray(v) ? (
            <ul className="space-y-1.5">
              {v.map((item, i) => (
                <li key={i} className="text-sm text-kyn-silver flex gap-2">
                  <span className="text-kyn-green">·</span> {asString(item)}
                </li>
              ))}
            </ul>
          ) : typeof v === 'object' && v ? (
            <pre className="text-xs text-kyn-metal whitespace-pre-wrap">{JSON.stringify(v, null, 2)}</pre>
          ) : (
            <p className="text-sm text-kyn-silver leading-relaxed">{asString(v)}</p>
          )}
        </div>
      ))}
    </div>
  );
}

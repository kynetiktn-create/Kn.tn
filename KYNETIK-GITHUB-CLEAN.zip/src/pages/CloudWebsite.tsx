import { useEffect, useState, type ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { motion, useScroll, useTransform } from 'framer-motion';
import {
  ArrowRight, Cloud, Shield, Lock, Server, Smartphone, Zap, Activity,
  BarChart3, CheckCircle2, Menu, X, Gauge, Wallet, Leaf, Network,
  Hotel, Building2, Car, Landmark, Play, Pause, RotateCcw, Download,
  Bell, Users, MapPin, Eye, Settings2, TrendingUp, Globe2, KeyRound,
  Radio, Cpu, LineChart, BatteryCharging
} from 'lucide-react';
import BrandLogo from '../components/BrandLogo';
import EnterpriseDashboard from '../components/cloud/EnterpriseDashboard';
import LoadingState from '../components/LoadingState';
import { apiGet, cn } from '../lib/utils';

interface Metric {
  id: number;
  label: string;
  value: string;
  delta: string;
}

function FadeIn({
  children, className, delay = 0,
}: { children: ReactNode; className?: string; delay?: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 28 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-50px' }}
      transition={{ duration: 0.6, delay, ease: [0.22, 1, 0.36, 1] }}
      className={className}
    >
      {children}
    </motion.div>
  );
}

function Label({ children }: { children: ReactNode }) {
  return (
    <p className="inline-flex items-center gap-2 text-[#00e676] text-[11px] font-semibold tracking-[0.28em] uppercase mb-4">
      <span className="w-6 h-px bg-[#00e676]/70" />
      {children}
    </p>
  );
}

const featurePillars = [
  {
    icon: Eye,
    title: 'Smart Monitoring',
    items: ['Real-time station status', 'Online / Offline detection', 'Live charging sessions', 'Energy consumption'],
  },
  {
    icon: Settings2,
    title: 'Remote Management',
    items: ['Start charging', 'Stop charging', 'Restart station', 'Update firmware OTA'],
  },
  {
    icon: Gauge,
    title: 'Energy Intelligence',
    items: ['Power usage curves', 'Peak hours analysis', 'Load optimization', 'Cost analysis'],
  },
  {
    icon: Users,
    title: 'Fleet Management',
    items: ['Multiple vehicles', 'Multiple drivers', 'Automated reports', 'Performance tracking'],
  },
];

const businessSolutions = [
  {
    icon: Hotel,
    title: 'Hotels',
    items: ['Guest charging', 'Automated billing', 'Occupancy monitoring'],
    tone: 'Hospitality-ready guest experience with branded sessions.',
  },
  {
    icon: Building2,
    title: 'Companies',
    items: ['Employee charging', 'Access control', 'HR & ESG reports'],
    tone: 'Workplace energy policy with role-based access.',
  },
  {
    icon: Car,
    title: 'Fleets',
    items: ['Vehicle management', 'Cost optimization', 'Depot load balance'],
    tone: 'Keep depots charged, costs controlled, uptime high.',
  },
  {
    icon: Landmark,
    title: 'Public Charging',
    items: ['Public access', 'Payment system', 'Network management'],
    tone: 'Scale city and corridor networks with roaming-ready ops.',
  },
];

const securityCards = [
  { icon: Lock, title: 'Data Protection', body: 'Encrypted storage, secrets management, audit-ready logs.' },
  { icon: Globe2, title: 'Secure Communication', body: 'TLS 1.3, signed OTA packages, hardened OCPP channels.' },
  { icon: KeyRound, title: 'User Management', body: 'RBAC for NOC, site managers, installers and finance.' },
  { icon: Server, title: 'System Reliability', body: '99.95% SLA target, multi-AZ resilience, 24/7 health checks.' },
];

export default function CloudWebsite() {
  const [metrics, setMetrics] = useState<Metric[]>([]);
  const [loading, setLoading] = useState(true);
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const { scrollY } = useScroll();
  const heroOpacity = useTransform(scrollY, [0, 400], [1, 0.3]);
  const heroY = useTransform(scrollY, [0, 400], [0, 60]);

  useEffect(() => {
    apiGet<Metric[]>('/api/cloud-metrics')
      .then(setMetrics)
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 28);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const navLinks = [
    { href: '#architecture', label: 'Architecture' },
    { href: '#features', label: 'Features' },
    { href: '#dashboard', label: 'Dashboard' },
    { href: '#ocpp', label: 'OCPP' },
    { href: '#solutions', label: 'Solutions' },
    { href: '#security', label: 'Security' },
  ];

  const kpiFallback = [
    { label: 'Stations Online', value: '156', delta: '+8 today' },
    { label: 'Energy Today', value: '4.8 MWh', delta: '+12%' },
    { label: 'Active Users', value: '328', delta: 'live' },
    { label: 'Revenue', value: '18,500 DT', delta: '+9%' },
  ];

  const dashboardMetrics =
    metrics.length >= 4
      ? metrics.slice(0, 4).map((m) => ({ label: m.label, value: m.value, delta: m.delta }))
      : kpiFallback;

  if (loading) {
    return (
      <div className="min-h-screen bg-[#050505] flex items-center justify-center">
        <LoadingState label="Loading KYNETIK Cloud…" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#050505] text-white overflow-x-hidden">
      {/* NAV */}
      <header
        className={cn(
          'fixed top-0 inset-x-0 z-50 transition-all duration-300',
          scrolled ? 'bg-[#050505]/85 backdrop-blur-xl border-b border-white/5' : 'bg-transparent'
        )}
      >
        <div className="max-w-7xl mx-auto px-5 md:px-8 h-16 md:h-[4.5rem] flex items-center justify-between">
          <Link to="/" className="flex items-center gap-3">
            <BrandLogo height={30} />
            <span className="hidden sm:inline text-[10px] font-semibold tracking-[0.22em] uppercase text-[#00e676] border border-[#00e676]/35 rounded-full px-2.5 py-0.5">
              Cloud
            </span>
          </Link>

          <nav className="hidden lg:flex items-center gap-7">
            {navLinks.map((l) => (
              <a key={l.href} href={l.href} className="text-xs font-medium text-[#c8c8d0] hover:text-white transition-colors">
                {l.label}
              </a>
            ))}
          </nav>

          <div className="flex items-center gap-3">
            <Link to="/product-system" className="hidden md:inline text-xs text-[#8a8a96] hover:text-white">
              Hardware
            </Link>
            <a
              href="#cta"
              className="hidden sm:inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#00e676] text-[#050505] text-xs font-bold hover:bg-[#39ff14] transition-colors"
            >
              Request Demo <ArrowRight size={13} />
            </a>
            <button type="button" className="lg:hidden p-2 text-[#c8c8d0]" onClick={() => setMenuOpen(!menuOpen)} aria-label="Menu">
              {menuOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </div>

        {menuOpen && (
          <div className="lg:hidden border-t border-white/5 bg-[#0a0a0b]/98 backdrop-blur-xl px-5 py-4 space-y-1">
            {navLinks.map((l) => (
              <a key={l.href} href={l.href} onClick={() => setMenuOpen(false)} className="block py-2.5 text-sm text-[#c8c8d0]">
                {l.label}
              </a>
            ))}
            <a href="#cta" onClick={() => setMenuOpen(false)} className="mt-2 block text-center rounded-full bg-[#00e676] text-[#050505] text-xs font-bold py-3">
              Request Demo
            </a>
          </div>
        )}
      </header>

      {/* 01 HERO */}
      <section className="relative min-h-screen flex items-center pt-20 pb-16">
        <div className="absolute inset-0">
          <img src="/images/cloud-datacenter.jpg" alt="" className="w-full h-full object-cover opacity-30" />
          <div className="absolute inset-0 bg-gradient-to-b from-[#050505] via-[#050505]/88 to-[#050505]" />
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(0,230,118,0.14),transparent_55%)]" />
          <div className="absolute inset-0 grid-bg opacity-40" />
          {/* floating data lines */}
          <div className="absolute inset-x-0 top-1/3 h-px bg-gradient-to-r from-transparent via-[#00e676]/30 to-transparent animate-pulse" />
          <div className="absolute inset-x-0 top-1/2 h-px bg-gradient-to-r from-transparent via-[#00e676]/15 to-transparent" />
        </div>

        <motion.div style={{ opacity: heroOpacity, y: heroY }} className="relative z-10 max-w-7xl mx-auto px-5 md:px-8 w-full">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-14 items-center">
            <motion.div initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7 }}>
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-[#00e676]/30 bg-[#00e676]/10 text-[#00e676] text-[11px] font-semibold mb-7">
                <Cloud size={13} /> Smart Charging Management Platform · v1.0
              </div>
              <p className="text-[#00e676] text-xs font-semibold tracking-[0.35em] uppercase mb-4">KYNETIK CLOUD</p>
              <h1 className="font-display text-4xl sm:text-5xl md:text-[3.4rem] font-bold leading-[1.05] tracking-tight">
                Control your charging ecosystem from{' '}
                <span className="text-[#00e676] text-glow">one intelligent platform</span>
              </h1>
              <p className="mt-6 text-base md:text-lg text-[#c8c8d0] max-w-xl leading-relaxed">
                Manage, monitor and optimize your EV charging infrastructure in real time —
                hardware, sessions, energy and billing unified as a Digital Energy Platform.
              </p>
              <div className="mt-9 flex flex-wrap gap-3">
                <a
                  href="#cta"
                  className="inline-flex items-center gap-2 px-6 py-3.5 rounded-full bg-[#00e676] text-[#050505] text-sm font-bold glow-green hover:bg-[#39ff14] transition-colors"
                >
                  Request Demo <ArrowRight size={16} />
                </a>
                <a
                  href="#dashboard"
                  className="inline-flex items-center gap-2 px-6 py-3.5 rounded-full border border-white/15 text-sm font-medium hover:border-[#00e676]/40 hover:bg-white/5 transition-colors"
                >
                  Explore dashboard
                </a>
              </div>
              <div className="mt-12 grid grid-cols-3 gap-4 max-w-md">
                {[
                  { v: 'OCPP', l: '1.6J / 2.0.1' },
                  { v: '99.95%', l: 'Platform SLA' },
                  { v: 'Realtime', l: 'WebSocket ops' },
                ].map((s) => (
                  <div key={s.l}>
                    <p className="font-display text-lg md:text-xl font-bold">{s.v}</p>
                    <p className="text-[10px] text-[#8a8a96] uppercase tracking-wider mt-0.5">{s.l}</p>
                  </div>
                ))}
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, scale: 0.96, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.12 }}
              className="relative"
            >
              <div className="absolute -inset-6 bg-[#00e676]/10 blur-3xl rounded-full" />
              <EnterpriseDashboard metrics={dashboardMetrics} />
              <div className="absolute -bottom-4 -left-2 md:left-4 glass-card rounded-xl px-3 py-2 flex items-center gap-2 text-[10px]">
                <MapPin size={12} className="text-[#00e676]" />
                <span className="text-[#c8c8d0]">Live charging map · Tunisia network</span>
              </div>
            </motion.div>
          </div>
        </motion.div>
      </section>

      {/* 02 ARCHITECTURE */}
      <section id="architecture" className="py-24 md:py-32 relative border-t border-white/5 overflow-hidden">
        <div className="absolute inset-0 opacity-25">
          <img src="/images/tech-abstract.jpg" alt="" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-[#050505]/85" />
        </div>
        <div className="relative z-10 max-w-7xl mx-auto px-5 md:px-8">
          <FadeIn className="text-center max-w-2xl mx-auto mb-14">
            <Label>Cloud architecture</Label>
            <h2 className="font-display text-3xl md:text-5xl font-bold">One platform. Complete control.</h2>
            <p className="mt-5 text-[#c8c8d0] leading-relaxed">
              Vehicles send telemetry. Chargers stream sessions. KYNETIK Cloud analyzes.
              Operators and drivers stay in control — from one nervous system.
            </p>
          </FadeIn>

          <FadeIn>
            <div className="rounded-3xl border border-[#00e676]/25 bg-black/50 backdrop-blur-xl p-8 md:p-12">
              {/* Center cloud */}
              <div className="flex justify-center mb-10">
                <div className="relative">
                  <div className="absolute inset-0 bg-[#00e676]/20 blur-2xl rounded-full" />
                  <div className="relative w-28 h-28 md:w-32 md:h-32 rounded-3xl border border-[#00e676]/50 bg-[#00e676]/10 flex flex-col items-center justify-center glow-green">
                    <Cloud className="text-[#00e676]" size={36} />
                    <span className="mt-2 text-[10px] font-bold tracking-wider text-[#00e676]">CLOUD</span>
                  </div>
                </div>
              </div>

              <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 relative">
                {[
                  { icon: Smartphone, t: 'Mobile App', s: 'Drivers & notifications' },
                  { icon: Activity, t: 'Dashboard', s: 'NOC & operators' },
                  { icon: Zap, t: 'Charging Stations', s: 'NOVA · PRIME · GO · PRO' },
                  { icon: Car, t: 'Vehicles', s: 'Sessions · SoC · Fleets' },
                ].map((n, i) => (
                  <motion.div
                    key={n.t}
                    initial={{ opacity: 0, y: 12 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: i * 0.06 }}
                    className="rounded-2xl border border-white/10 bg-white/[0.03] p-5 text-center hover:border-[#00e676]/35 transition-colors"
                  >
                    <div className="w-12 h-12 mx-auto rounded-xl bg-[#00e676]/10 border border-[#00e676]/25 flex items-center justify-center text-[#00e676] mb-3">
                      <n.icon size={20} />
                    </div>
                    <p className="font-display font-semibold">{n.t}</p>
                    <p className="text-[11px] text-[#8a8a96] mt-1">{n.s}</p>
                  </motion.div>
                ))}
              </div>

              <div className="mt-10 flex flex-wrap items-center justify-center gap-2 text-[11px] md:text-xs font-medium">
                {['Vehicle data', 'Charger telemetry', 'Cloud intelligence', 'User control'].map((step, i, arr) => (
                  <div key={step} className="flex items-center gap-2">
                    <span className="px-3 py-1.5 rounded-full border border-[#00e676]/30 bg-[#00e676]/5 text-[#00e676]">
                      {step}
                    </span>
                    {i < arr.length - 1 && <span className="text-[#00e676]/50">→</span>}
                  </div>
                ))}
              </div>
            </div>
          </FadeIn>
        </div>
      </section>

      {/* 03 FEATURES */}
      <section id="features" className="py-24 md:py-28 bg-[#0a0a0b] border-y border-white/5">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <FadeIn className="mb-14 max-w-2xl">
            <Label>Platform capabilities</Label>
            <h2 className="font-display text-3xl md:text-4xl font-bold">
              Everything operators need to run a network
            </h2>
            <p className="mt-4 text-[#8a8a96] leading-relaxed">
              KYNETIK is not only hardware — it is the intelligent layer that turns chargers into a scalable energy business.
            </p>
          </FadeIn>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {featurePillars.map((f, i) => (
              <FadeIn key={f.title} delay={i * 0.05}>
                <div className="h-full rounded-2xl border border-white/8 bg-black/30 p-6 hover:border-[#00e676]/30 transition-all group">
                  <div className="w-11 h-11 rounded-xl bg-[#00e676]/10 border border-[#00e676]/20 flex items-center justify-center text-[#00e676] mb-5 group-hover:glow-green transition-shadow">
                    <f.icon size={20} />
                  </div>
                  <h3 className="font-display text-lg font-semibold">{f.title}</h3>
                  <ul className="mt-4 space-y-2.5">
                    {f.items.map((item) => (
                      <li key={item} className="flex items-start gap-2 text-sm text-[#c8c8d0]">
                        <CheckCircle2 size={14} className="text-[#00e676] mt-0.5 shrink-0" />
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>
              </FadeIn>
            ))}
          </div>

          {/* Remote actions strip */}
          <FadeIn className="mt-6">
            <div className="rounded-2xl border border-white/8 bg-gradient-to-r from-white/[0.03] to-transparent p-5 md:p-6 flex flex-wrap items-center gap-3 justify-between">
              <p className="text-sm text-[#c8c8d0]">
                <span className="text-white font-semibold">Remote command bar</span> — intervene without truck rolls
              </p>
              <div className="flex flex-wrap gap-2">
                {[
                  { icon: Play, l: 'Start' },
                  { icon: Pause, l: 'Stop' },
                  { icon: RotateCcw, l: 'Restart' },
                  { icon: Download, l: 'Firmware' },
                ].map(({ icon: Icon, l }) => (
                  <span
                    key={l}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border border-[#00e676]/25 bg-[#00e676]/10 text-[11px] font-semibold text-[#00e676]"
                  >
                    <Icon size={12} /> {l}
                  </span>
                ))}
              </div>
            </div>
          </FadeIn>
        </div>
      </section>

      {/* 04 DASHBOARD EXPERIENCE */}
      <section id="dashboard" className="py-24 md:py-32">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center mb-12">
            <FadeIn>
              <Label>Dashboard experience</Label>
              <h2 className="font-display text-3xl md:text-4xl font-bold leading-tight">
                See your entire network in one cinematic console
              </h2>
              <p className="mt-5 text-[#c8c8d0] leading-relaxed">
                Stations online, energy throughput, active users and revenue — with map intelligence and analytics built for enterprise operators and investors.
              </p>
            </FadeIn>
            <FadeIn delay={0.08}>
              <div className="grid grid-cols-2 gap-3">
                {dashboardMetrics.map((m) => (
                  <div key={m.label} className="rounded-2xl border border-white/8 bg-[#121214] p-5">
                    <p className="text-[10px] uppercase tracking-wider text-[#8a8a96]">{m.label}</p>
                    <p className="font-display text-2xl md:text-3xl font-bold mt-1 text-[#00e676] text-glow">{m.value}</p>
                    <p className="text-[11px] text-[#8a8a96] mt-1">{m.delta}</p>
                  </div>
                ))}
              </div>
            </FadeIn>
          </div>
          <FadeIn>
            <EnterpriseDashboard metrics={dashboardMetrics} />
          </FadeIn>
        </div>
      </section>

      {/* 05 OCPP */}
      <section id="ocpp" className="py-24 md:py-28 bg-[#0a0a0b] border-y border-white/5">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <FadeIn>
              <Label>Open standards</Label>
              <h2 className="font-display text-3xl md:text-4xl font-bold">Built on open charging standards</h2>
              <p className="mt-5 text-[#c8c8d0] leading-relaxed">
                OCPP keeps KYNETIK future-ready and vendor-agnostic — onboard mixed hardware fleets without lock-in.
              </p>
              <div className="mt-8 grid grid-cols-2 gap-3">
                {['Compatibility', 'Scalability', 'Remote control', 'Future ready'].map((b) => (
                  <div key={b} className="flex items-center gap-2 text-sm text-[#c8c8d0]">
                    <CheckCircle2 size={16} className="text-[#00e676] shrink-0" />
                    {b}
                  </div>
                ))}
              </div>
            </FadeIn>

            <FadeIn delay={0.1}>
              <div className="rounded-3xl border border-white/10 bg-black/40 p-8 md:p-10">
                <div className="flex flex-col items-center gap-0">
                  {[
                    { icon: Zap, t: 'Charging Station', s: 'OCPP client' },
                    { icon: Cloud, t: 'KYNETIK Cloud', s: 'OCPP 1.6J / 2.0.1 broker' },
                    { icon: Activity, t: 'Management System', s: 'Dashboard · API · Billing' },
                  ].map((n, i, arr) => (
                    <div key={n.t} className="w-full max-w-sm flex flex-col items-center">
                      <div className="w-full rounded-2xl border border-[#00e676]/30 bg-[#00e676]/5 px-5 py-4 flex items-center gap-4">
                        <div className="w-11 h-11 rounded-xl bg-[#00e676]/15 border border-[#00e676]/30 flex items-center justify-center text-[#00e676]">
                          <n.icon size={20} />
                        </div>
                        <div>
                          <p className="font-display font-semibold">{n.t}</p>
                          <p className="text-[11px] text-[#8a8a96]">{n.s}</p>
                        </div>
                      </div>
                      {i < arr.length - 1 && (
                        <div className="h-8 w-px bg-gradient-to-b from-[#00e676] to-[#00e676]/20 my-1" />
                      )}
                    </div>
                  ))}
                </div>
                <p className="mt-8 text-center text-xs text-[#8a8a96] tracking-wide uppercase">
                  Protocol backbone · OCPP 1.6J
                </p>
              </div>
            </FadeIn>
          </div>
        </div>
      </section>

      {/* 06 BUSINESS SOLUTIONS */}
      <section id="solutions" className="py-24 md:py-32">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <FadeIn className="mb-14 max-w-2xl">
            <Label>Business solutions</Label>
            <h2 className="font-display text-3xl md:text-4xl font-bold">Designed for every operator model</h2>
            <p className="mt-4 text-[#8a8a96]">
              From hotel guest charging to public networks — one Cloud, tailored workflows.
            </p>
          </FadeIn>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {businessSolutions.map((s, i) => (
              <FadeIn key={s.title} delay={i * 0.05}>
                <div className="h-full rounded-2xl border border-white/8 bg-gradient-to-b from-white/[0.04] to-transparent p-6 hover:border-[#00e676]/30 transition-colors">
                  <div className="w-11 h-11 rounded-xl bg-[#00e676]/10 border border-[#00e676]/20 flex items-center justify-center text-[#00e676] mb-4">
                    <s.icon size={20} />
                  </div>
                  <h3 className="font-display text-xl font-semibold">{s.title}</h3>
                  <p className="mt-2 text-xs text-[#8a8a96] leading-relaxed">{s.tone}</p>
                  <ul className="mt-5 space-y-2">
                    {s.items.map((item) => (
                      <li key={item} className="text-sm text-[#c8c8d0] flex items-center gap-2">
                        <span className="w-1 h-1 rounded-full bg-[#00e676]" />
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>
              </FadeIn>
            ))}
          </div>
        </div>
      </section>

      {/* 07 MOBILE INTEGRATION */}
      <section className="py-24 md:py-28 bg-[#0a0a0b] border-y border-white/5 relative overflow-hidden">
        <div className="absolute right-0 top-0 w-1/2 h-full opacity-20 pointer-events-none hidden lg:block">
          <img src="/images/ev-network.jpg" alt="" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-l from-transparent to-[#0a0a0b]" />
        </div>
        <div className="relative z-10 max-w-7xl mx-auto px-5 md:px-8">
          <div className="grid lg:grid-cols-2 gap-14 items-center">
            <FadeIn>
              <Label>Mobile integration</Label>
              <h2 className="font-display text-3xl md:text-4xl font-bold">Cloud ↔ App ↔ User</h2>
              <p className="mt-5 text-[#c8c8d0] leading-relaxed max-w-lg">
                The driver app is not a separate product — it is the human interface of KYNETIK Cloud.
                Sessions, payments and alerts stay synchronized in real time.
              </p>
              <div className="mt-8 grid grid-cols-2 gap-3">
                {[
                  { icon: Bell, t: 'Notifications' },
                  { icon: Settings2, t: 'Remote control' },
                  { icon: BatteryCharging, t: 'Charging history' },
                  { icon: Wallet, t: 'Account & billing' },
                ].map(({ icon: Icon, t }) => (
                  <div key={t} className="rounded-xl border border-white/8 bg-black/30 px-4 py-3 flex items-center gap-2 text-sm text-[#c8c8d0]">
                    <Icon size={15} className="text-[#00e676]" /> {t}
                  </div>
                ))}
              </div>
              <Link to="/app" className="mt-8 inline-flex items-center gap-2 text-sm font-semibold text-[#00e676] hover:gap-3 transition-all">
                Explore mobile UX <ArrowRight size={15} />
              </Link>
            </FadeIn>

            <FadeIn delay={0.1}>
              <div className="rounded-3xl border border-[#00e676]/20 bg-black/40 p-8 md:p-10">
                <div className="flex flex-col md:flex-row items-center justify-center gap-4 md:gap-6">
                  {[
                    { icon: Cloud, t: 'CLOUD' },
                    { icon: Smartphone, t: 'MOBILE APP' },
                    { icon: Users, t: 'USER' },
                  ].map((n, i, arr) => (
                    <div key={n.t} className="flex flex-col md:flex-row items-center gap-4 md:gap-6">
                      <div className="w-28 h-28 rounded-2xl border border-[#00e676]/35 bg-[#00e676]/10 flex flex-col items-center justify-center">
                        <n.icon className="text-[#00e676]" size={28} />
                        <span className="mt-2 text-[10px] font-bold tracking-wider text-[#00e676]">{n.t}</span>
                      </div>
                      {i < arr.length - 1 && (
                        <span className="text-[#00e676] font-bold rotate-90 md:rotate-0">↕</span>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </FadeIn>
          </div>
        </div>
      </section>

      {/* 08 SECURITY */}
      <section id="security" className="py-24 md:py-32">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <FadeIn className="mb-14 max-w-2xl">
            <Label>Enterprise security</Label>
            <h2 className="font-display text-3xl md:text-4xl font-bold">Enterprise-grade trust, by design</h2>
          </FadeIn>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {securityCards.map((c, i) => (
              <FadeIn key={c.title} delay={i * 0.05}>
                <div className="h-full rounded-2xl border border-white/8 bg-white/[0.02] p-6">
                  <div className="w-10 h-10 rounded-xl bg-[#00e676]/10 border border-[#00e676]/20 flex items-center justify-center text-[#00e676] mb-4">
                    <c.icon size={18} />
                  </div>
                  <h3 className="font-display font-semibold">{c.title}</h3>
                  <p className="mt-2 text-sm text-[#8a8a96] leading-relaxed">{c.body}</p>
                </div>
              </FadeIn>
            ))}
          </div>
        </div>
      </section>

      {/* 09 ANALYTICS */}
      <section id="analytics" className="py-24 md:py-28 bg-[#0a0a0b] border-y border-white/5">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <FadeIn>
              <Label>Analytics & impact</Label>
              <h2 className="font-display text-3xl md:text-4xl font-bold">
                Numbers investors and operators care about
              </h2>
              <p className="mt-5 text-[#c8c8d0] leading-relaxed">
                Energy saved, CO₂ reduced, usage trends and growth — board-ready reporting from live infrastructure data.
              </p>
              <div className="mt-8 space-y-3">
                {[
                  { icon: Leaf, t: 'CO₂ reduction tracking', d: 'Sustainability KPIs for ESG reports' },
                  { icon: TrendingUp, t: 'Usage & growth trends', d: 'Sessions, ARPU, utilization curves' },
                  { icon: LineChart, t: 'Energy intelligence', d: 'Peak shaving and cost per kWh' },
                ].map(({ icon: Icon, t, d }) => (
                  <div key={t} className="flex gap-3 items-start">
                    <div className="w-9 h-9 rounded-lg bg-[#00e676]/10 border border-[#00e676]/20 flex items-center justify-center text-[#00e676] shrink-0">
                      <Icon size={16} />
                    </div>
                    <div>
                      <p className="font-semibold text-sm">{t}</p>
                      <p className="text-xs text-[#8a8a96] mt-0.5">{d}</p>
                    </div>
                  </div>
                ))}
              </div>
            </FadeIn>

            <FadeIn delay={0.1}>
              <div className="rounded-3xl border border-white/10 bg-black/40 p-6 md:p-8">
                <div className="grid grid-cols-2 gap-3 mb-6">
                  {[
                    { v: '1.1 t', l: 'CO₂ avoided / week' },
                    { v: '8.2k', l: 'kWh today' },
                    { v: '+18%', l: 'Uptime lift' },
                    { v: '-22%', l: 'Peak demand' },
                  ].map((s) => (
                    <div key={s.l} className="rounded-2xl border border-white/8 bg-white/[0.03] p-4">
                      <p className="font-display text-2xl font-bold text-[#00e676]">{s.v}</p>
                      <p className="text-[11px] text-[#8a8a96] mt-1">{s.l}</p>
                    </div>
                  ))}
                </div>
                <div className="h-32 flex items-end gap-1.5">
                  {[40, 55, 48, 62, 58, 72, 68, 80, 75, 88, 82, 95, 78, 90, 85, 92].map((h, i) => (
                    <div
                      key={i}
                      className="flex-1 rounded-t-sm bg-gradient-to-t from-[#00e676]/25 to-[#00e676]"
                      style={{ height: `${h}%` }}
                    />
                  ))}
                </div>
                <p className="mt-3 text-[10px] text-[#8a8a96] uppercase tracking-wider">Network growth · 16 weeks</p>
              </div>
            </FadeIn>
          </div>
        </div>
      </section>

      {/* Technical foundation teaser */}
      <section className="py-16 border-b border-white/5">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <FadeIn>
            <div className="rounded-2xl border border-white/8 bg-gradient-to-r from-[#121214] to-transparent p-6 md:p-8 flex flex-wrap gap-6 items-center justify-between">
              <div>
                <p className="text-[11px] text-[#00e676] font-semibold tracking-[0.25em] uppercase mb-2">Technical foundation</p>
                <p className="font-display text-xl font-semibold">API · Database · OCPP Server · WebSocket · MQTT · REST</p>
                <p className="text-sm text-[#8a8a96] mt-2 max-w-xl">
                  Built for AWS-class cloud infrastructure — ready for enterprise integration and national-scale networks.
                </p>
              </div>
              <div className="flex flex-wrap gap-2">
                {['REST API', 'Webhooks', 'OCPP', 'WebSocket', 'RBAC'].map((t) => (
                  <span key={t} className="px-3 py-1.5 rounded-full border border-white/10 text-[11px] text-[#c8c8d0]">
                    {t}
                  </span>
                ))}
              </div>
            </div>
          </FadeIn>
        </div>
      </section>

      {/* 10 CTA */}
      <section id="cta" className="py-24 md:py-32 relative">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(0,230,118,0.12),transparent_60%)]" />
        <div className="relative z-10 max-w-3xl mx-auto px-5 text-center">
          <FadeIn>
            <BrandLogo height={40} className="mx-auto justify-center" />
            <h2 className="mt-8 font-display text-3xl md:text-5xl font-bold leading-tight">
              Ready to build your
              <br />
              <span className="text-[#00e676] text-glow">smart charging network?</span>
            </h2>
            <p className="mt-5 text-[#c8c8d0] max-w-xl mx-auto leading-relaxed">
              Schedule a demo — for enterprises, station operators and investors who want hardware + Cloud as one platform.
            </p>
            <div className="mt-10 flex flex-wrap justify-center gap-3">
              <a
                href="mailto:cloud@kynetik.tn?subject=KYNETIK%20Cloud%20Demo"
                className="inline-flex items-center gap-2 px-8 py-4 rounded-full bg-[#00e676] text-[#050505] text-sm font-bold glow-green hover:bg-[#39ff14] transition-colors"
              >
                Schedule a Demo <ArrowRight size={16} />
              </a>
              <Link
                to="/product-system"
                className="inline-flex items-center gap-2 px-8 py-4 rounded-full border border-white/15 text-sm font-medium hover:bg-white/5 transition-colors"
              >
                View hardware
              </Link>
            </div>
            <div className="mt-12 flex flex-wrap justify-center gap-6 text-[11px] text-[#8a8a96]">
              {[
                { t: 'Enterprise', d: 'Demo → technical meeting' },
                { t: 'Station owner', d: 'Features → subscription' },
                { t: 'Investor', d: 'Technology → vision' },
              ].map((x) => (
                <div key={x.t} className="text-center">
                  <p className="text-[#00e676] font-semibold uppercase tracking-wider">{x.t}</p>
                  <p className="mt-1">{x.d}</p>
                </div>
              ))}
            </div>
          </FadeIn>
        </div>
      </section>

      <footer className="border-t border-white/5 py-10">
        <div className="max-w-7xl mx-auto px-5 md:px-8 flex flex-wrap items-center justify-between gap-4">
          <BrandLogo height={28} />
          <p className="text-[11px] text-[#8a8a96]">© KYNETIK Cloud — Digital Energy Platform · Tunisie</p>
          <div className="flex gap-4 text-[11px] text-[#8a8a96]">
            <Link to="/" className="hover:text-white">Home</Link>
            <Link to="/product-system" className="hover:text-white">Products</Link>
            <Link to="/app" className="hover:text-white">App</Link>
            <Link to="/design-system" className="hover:text-white">Design System</Link>
          </div>
        </div>
      </footer>
    </div>
  );
}

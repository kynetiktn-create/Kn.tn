import { Link } from 'react-router-dom';
import {
  ArrowRight, MessageSquare, FileSpreadsheet, Wrench, Globe2, Star,
  FolderOpen, HelpCircle, LifeBuoy, GraduationCap, Briefcase, CheckCircle2, Zap, Target,
  ClipboardList, Network, FileText, Server } from 'lucide-react';
import MarketingShell, { Fade } from '../../components/marketing/Shell';

const funnels = [
  {
    title: 'Buyers',
    color: '#00e676',
    items: [
      { to: '/quote', label: 'Request a Quote' },
      { to: '/products', label: 'Browse products' },
      { to: '/success-stories', label: 'Success stories' },
      { to: '/contact', label: 'Talk to sales' },
    ],
  },
  {
    title: 'Partners',
    color: '#2dd4bf',
    items: [
      { to: '/installers', label: 'Become an installer' },
      { to: '/distributors', label: 'Become a distributor' },
      { to: '/academy-landing', label: 'Academy certification' },
      { to: '/resources', label: 'Partner resources' },
    ],
  },
  {
    title: 'Trust & support',
    color: '#60a5fa',
    items: [
      { to: '/faq', label: 'FAQ center' },
      { to: '/support', label: 'Support tickets' },
      { to: '/resources', label: 'Downloads' },
      { to: '/careers', label: 'Careers' },
    ],
  },
];

const modules = [
  { to: '/csms', title: 'CSMS Dashboard', desc: 'OCPP operator control plane', icon: Server },
  { to: '/ocpp', title: 'OCPP CSMS', desc: 'Charge point backend 1.6J' },
  { to: '/engineering-pack', title: 'Engineering Pack', desc: 'SAD · OpenAPI · DB · DevOps · QA · Ops · Sec' },
              { to: '/prd', title: '00 · Product PRD', desc: 'Personas, modules, stories, MVP, roadmap, NFR.', icon: FileText },
  { to: '/architecture', title: '00 · Enterprise Architecture', desc: 'Stack, OCPP, IoT, sécurité, DevOps, IA et scalabilité.', icon: Network },
  { to: '/ops', title: '00 · Ops Blueprint', desc: 'SOPs, QC, HSE, warranty, spare parts, KPIs opérationnels, support L1–L3.', icon: ClipboardList },
  { to: '/brand-launch', title: '00 · Brand & Launch', desc: 'Positionnement, GTM 24 mois, product launch order, canaux, calendrier, content & sales kit.', icon: Zap },

  { to: '/contact', title: '01 · Contact', desc: 'Business inquiry, partnership, installer & distributor intents + map + live chat.', icon: MessageSquare },
  { to: '/quote', title: '02 · Request a Quote', desc: 'Multi-step form: product, power, home/business, vehicle, electrical, schedule, PDF-style summary.', icon: FileSpreadsheet },
  { to: '/installers', title: '03 · Become an Installer', desc: 'Benefits, certification roadmap, Academy link, application + portal preview.', icon: Wrench },
  { to: '/distributors', title: '04 · Become a Distributor', desc: 'Territories, commercial & marketing support, exclusive SKUs, application.', icon: Globe2 },
  { to: '/success-stories', title: '05 · Success Stories', desc: 'Villa, office, hotel, retail, fleet — before/after, KPIs, testimonials.', icon: Star },
  { to: '/resources', title: '06 · Resources', desc: 'Datasheets, guides, warranty, certificates, videos, white papers.', icon: FolderOpen },
  { to: '/faq', title: '07 · FAQ Center', desc: 'Search + categories: installation, charging, Cloud, warranty, payments.', icon: HelpCircle },
  { to: '/support', title: '08 · Support Center', desc: 'Ticket creation, knowledge base, live chat, remote diagnostics, emergency.', icon: LifeBuoy },
  { to: '/academy-landing', title: '09 · Academy', desc: 'Installer, business & Cloud tracks with live course catalog.', icon: GraduationCap },
  { to: '/sales', title: '11 · Sales System', desc: 'Équipe, segments, packs Home/Business/Enterprise, journey, KPIs, partenaires, revenus.', icon: Target },
  { to: '/careers', title: '12 · Careers', desc: 'Culture, open roles from database, application form.', icon: Briefcase },
];

export default function MarketingHub() {
  return (
    <MarketingShell>
      <section className="relative pt-16 pb-12 overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(0,230,118,0.16),transparent_55%)]" />
        <div className="absolute inset-0 grid-bg opacity-25" />
        <div className="relative z-10 max-w-7xl mx-auto px-5 md:px-8">
          <Fade>
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-kyn-green/30 bg-kyn-green/10 text-kyn-green text-[11px] font-semibold mb-6">
              <Zap size={12} /> Conversion system · Apple / Stripe / Tesla craft
            </div>
            <h1 className="font-display text-4xl md:text-6xl lg:text-7xl font-bold max-w-4xl leading-[1.05]">
              Marketing & Sales
              <br />
              <span className="text-kyn-green text-glow">Ecosystem</span>
            </h1>
            <p className="mt-5 text-lg md:text-xl text-kyn-silver max-w-2xl leading-relaxed">
              Turn visitors into customers, certified installers and distributors — with premium UX,
              live chat, multi-step quotes and CRM-ready lead capture on Supabase.
            </p>
            <div className="mt-9 flex flex-wrap gap-3">
              <Link to="/brand-launch" className="inline-flex items-center gap-2 px-6 py-3.5 rounded-full border border-violet-400/30 text-violet-200 text-sm font-semibold hover:border-violet-400/50">
                Phase 22 · Brand Launch
              </Link>
              <Link to="/quote" className="inline-flex items-center gap-2 px-6 py-3.5 rounded-full bg-kyn-green text-kyn-black text-sm font-bold glow-green">
                Request a Quote <ArrowRight size={16} />
              </Link>
              <Link to="/contact" className="inline-flex items-center gap-2 px-6 py-3.5 rounded-full border border-white/15 text-sm font-semibold hover:border-kyn-green/40">
                Contact sales
              </Link>
              <Link to="/installers" className="inline-flex items-center gap-2 px-6 py-3.5 rounded-full border border-white/15 text-sm font-semibold hover:border-kyn-green/40">
                Partner programs
              </Link>
            </div>
          </Fade>

          <div className="mt-14 grid grid-cols-2 md:grid-cols-4 gap-3">
            {[
              { v: '10', l: 'Conversion surfaces' },
              { v: '<24h', l: 'Sales response SLA' },
              { v: '3', l: 'Lead funnels' },
              { v: '100%', l: 'Design-system aligned' },
            ].map((s) => (
              <div key={s.l} className="rounded-2xl border border-white/10 bg-kyn-void/80 p-4 md:p-5">
                <p className="font-display text-2xl md:text-3xl font-bold text-kyn-green">{s.v}</p>
                <p className="text-[11px] text-kyn-metal mt-1 uppercase tracking-wider">{s.l}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Funnels */}
      <section className="py-16 bg-kyn-void border-y border-white/5">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <Fade>
            <p className="text-kyn-green text-xs font-semibold tracking-[0.25em] uppercase mb-3">Journeys</p>
            <h2 className="font-display text-3xl font-bold mb-8">Three paths to revenue</h2>
          </Fade>
          <div className="grid md:grid-cols-3 gap-4">
            {funnels.map((f, i) => (
              <Fade key={f.title} delay={i * 0.06}>
                <div className="rounded-3xl border border-white/10 bg-black/30 p-6 h-full">
                  <div className="w-10 h-1 rounded-full mb-4" style={{ background: f.color }} />
                  <h3 className="font-display text-xl font-bold" style={{ color: f.color }}>{f.title}</h3>
                  <ul className="mt-5 space-y-3">
                    {f.items.map((item) => (
                      <li key={item.to}>
                        <Link to={item.to} className="flex items-center justify-between text-sm text-kyn-silver hover:text-white group">
                          <span className="inline-flex items-center gap-2">
                            <CheckCircle2 size={14} style={{ color: f.color }} />
                            {item.label}
                          </span>
                          <ArrowRight size={14} className="opacity-0 group-hover:opacity-100 transition-opacity" />
                        </Link>
                      </li>
                    ))}
                  </ul>
                </div>
              </Fade>
            ))}
          </div>
        </div>
      </section>

      {/* Modules grid */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <Fade>
            <p className="text-kyn-green text-xs font-semibold tracking-[0.25em] uppercase mb-3">Surfaces</p>
            <h2 className="font-display text-3xl md:text-4xl font-bold mb-3">Complete ecosystem map</h2>
            <p className="text-kyn-metal mb-10 max-w-xl">Every page submits to Supabase via `/api/leads` or `/api/support-tickets` and loads content from `/api/marketing-content`.</p>
          </Fade>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {modules.map((m, i) => {
              const Icon = m.icon;
              return (
                <Fade key={m.to} delay={i * 0.03}>
                  <Link
                    to={m.to}
                    className="group block rounded-2xl border border-white/10 bg-kyn-void p-6 h-full hover:border-kyn-green/35 hover:-translate-y-0.5 transition-all"
                  >
                    <div className="w-10 h-10 rounded-xl bg-kyn-green/10 border border-kyn-green/20 flex items-center justify-center text-kyn-green mb-4 group-hover:shadow-[0_0_20px_rgba(0,230,118,0.25)]">
                      <Icon size={18} />
                    </div>
                    <p className="font-display font-semibold text-lg group-hover:text-kyn-green transition-colors">{m.title}</p>
                    <p className="text-sm text-kyn-metal mt-2 leading-relaxed">{m.desc}</p>
                    <span className="mt-4 inline-flex items-center gap-1 text-xs text-kyn-green opacity-0 group-hover:opacity-100 transition-opacity">
                      Open surface <ArrowRight size={12} />
                    </span>
                  </Link>
                </Fade>
              );
            })}
          </div>
        </div>
      </section>

      <section className="py-20 border-t border-white/5 bg-kyn-void">
        <div className="max-w-3xl mx-auto px-5 text-center">
          <Fade>
            <h2 className="font-display text-3xl md:text-4xl font-bold">Ready to convert the next visitor?</h2>
            <p className="mt-4 text-kyn-silver">Start with a quote, a partner application, or a direct conversation with sales.</p>
            <div className="mt-8 flex flex-wrap justify-center gap-3">
              <Link to="/quote" className="inline-flex items-center gap-2 px-7 py-3.5 rounded-full bg-kyn-green text-kyn-black text-sm font-bold glow-green">
                Get a quotation <ArrowRight size={16} />
              </Link>
              <Link to="/" className="inline-flex items-center gap-2 px-7 py-3.5 rounded-full border border-white/15 text-sm font-medium">
                Back to homepage
              </Link>
            </div>
          </Fade>
        </div>
      </section>
    </MarketingShell>
  );
}

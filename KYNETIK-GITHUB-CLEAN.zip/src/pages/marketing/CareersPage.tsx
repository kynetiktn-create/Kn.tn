import { useEffect, useState, FormEvent } from 'react';
import { ArrowRight, Heart, Rocket, Users, Sparkles } from 'lucide-react';
import MarketingShell, { Fade, Field, inputClass, SuccessBanner } from '../../components/marketing/Shell';
import { apiGet, apiPost, cn } from '../../lib/utils';

interface Job {
  id: number;
  title: string;
  subtitle: string;
  body: string;
  category: string;
  meta: string | null;
}

const culture = [
  { icon: Rocket, t: 'Build real infrastructure', d: 'Ship hardware + Cloud that cities and homes rely on.' },
  { icon: Heart, t: 'Premium craft', d: 'Apple-level product taste with industrial reliability.' },
  { icon: Users, t: 'One team', d: 'Engineering, field and design sit at the same table.' },
  { icon: Sparkles, t: 'Growth', d: 'Academy access, mentorship, ownership.' },
];

export default function CareersPage() {
  const [jobs, setJobs] = useState<Job[]>([]);
  const [selected, setSelected] = useState<Job | null>(null);
  const [form, setForm] = useState({ name: '', email: '', phone: '', linkedin: '', message: '' });
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    apiGet<Job[]>('/api/marketing-content?type=job')
      .then((data) => {
        setJobs(data || []);
        setSelected(data?.[0] || null);
      })
      .catch(() => setJobs([]));
  }, []);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!form.email.includes('@') || !form.name) {
      setError('Name and email required');
      return;
    }
    setLoading(true);
    setError('');
    try {
      await apiPost('/api/leads', {
        type: 'career',
        name: form.name,
        email: form.email,
        phone: form.phone,
        subject: selected ? `Application · ${selected.title}` : 'General application',
        message: form.message,
        payload: { ...form, role: selected?.title },
      });
      setDone(true);
    } catch (err: any) {
      setError(err.message || 'Failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <MarketingShell ctaLabel="Apply" ctaTo="#apply">
      <section className="pt-16 pb-12 relative">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(0,230,118,0.12),transparent_55%)]" />
        <div className="relative z-10 max-w-7xl mx-auto px-5 md:px-8">
          <Fade>
            <p className="text-kyn-green text-xs font-semibold tracking-[0.3em] uppercase mb-4">Careers</p>
            <h1 className="font-display text-4xl md:text-6xl font-bold max-w-3xl">Build the operating system of mobility</h1>
            <p className="mt-5 text-lg text-kyn-silver max-w-2xl">Join KYNETIK — product, engineering, field ops and growth roles for a premium EV company.</p>
          </Fade>
        </div>
      </section>

      <section className="py-16 bg-kyn-void border-y border-white/5">
        <div className="max-w-7xl mx-auto px-5 md:px-8 grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {culture.map((c, i) => {
            const Icon = c.icon;
            return (
              <Fade key={c.t} delay={i * 0.05}>
                <div className="rounded-2xl border border-white/8 bg-black/30 p-5 h-full">
                  <Icon className="text-kyn-green mb-3" size={18} />
                  <p className="font-semibold">{c.t}</p>
                  <p className="text-sm text-kyn-metal mt-2">{c.d}</p>
                </div>
              </Fade>
            );
          })}
        </div>
      </section>

      <section className="py-20">
        <div className="max-w-7xl mx-auto px-5 md:px-8 grid lg:grid-cols-5 gap-6">
          <div className="lg:col-span-2 space-y-3">
            <h2 className="font-display text-2xl font-bold mb-4">Open positions</h2>
            {jobs.map((j) => (
              <button key={j.id} type="button" onClick={() => { setSelected(j); setDone(false); }} className={cn('w-full text-left rounded-2xl border p-4', selected?.id === j.id ? 'border-kyn-green/40 bg-kyn-green/10' : 'border-white/8 bg-kyn-void')}>
                <p className="text-[10px] uppercase tracking-wider text-kyn-green">{j.category}</p>
                <p className="font-semibold mt-1">{j.title}</p>
                <p className="text-xs text-kyn-metal mt-1">{j.meta || j.subtitle}</p>
              </button>
            ))}
            {!jobs.length && <p className="text-sm text-kyn-metal">Roles loading from database…</p>}
          </div>
          <div className="lg:col-span-3" id="apply">
            <div className="rounded-3xl border border-white/10 bg-kyn-void p-6 md:p-8">
              {selected && (
                <>
                  <p className="text-kyn-green text-xs font-semibold uppercase tracking-wider">{selected.category}</p>
                  <h3 className="font-display text-2xl font-bold mt-1">{selected.title}</h3>
                  <p className="text-sm text-kyn-silver mt-3 leading-relaxed">{selected.body}</p>
                </>
              )}
              <div className="mt-8">
                <h4 className="font-semibold mb-4">Application</h4>
                {done ? (
                  <SuccessBanner title="Application received" body="People team will review and get back to you." />
                ) : (
                  <form onSubmit={submit} className="space-y-4">
                    <div className="grid sm:grid-cols-2 gap-4">
                      <Field label="Full name"><input className={inputClass} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></Field>
                      <Field label="Email"><input type="email" className={inputClass} value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></Field>
                      <Field label="Phone"><input className={inputClass} value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></Field>
                      <Field label="LinkedIn / portfolio"><input className={inputClass} value={form.linkedin} onChange={(e) => setForm({ ...form, linkedin: e.target.value })} /></Field>
                    </div>
                    <Field label="Note"><textarea className={cn(inputClass, 'min-h-[90px]')} value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} /></Field>
                    {error && <p className="text-sm text-red-400">{error}</p>}
                    <button disabled={loading} className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-kyn-green text-kyn-black text-sm font-bold">{loading ? 'Sending…' : 'Submit application'} <ArrowRight size={16} /></button>
                  </form>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>
    </MarketingShell>
  );
}

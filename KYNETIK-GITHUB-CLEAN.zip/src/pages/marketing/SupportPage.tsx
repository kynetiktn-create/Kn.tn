import { useEffect, useState, FormEvent } from 'react';
import { Link } from 'react-router-dom';
import { LifeBuoy, BookOpen, MessageCircle, Cpu, Siren, ArrowRight, CheckCircle2 } from 'lucide-react';
import MarketingShell, { Fade, Field, inputClass, SuccessBanner } from '../../components/marketing/Shell';
import { apiGet, apiPost, cn } from '../../lib/utils';

interface Ticket {
  id: number;
  ticket_no: string;
  subject: string;
  status: string;
  priority: string;
}

interface Kb {
  id: number;
  title: string;
  body: string;
  category: string;
}

export default function SupportPage() {
  const [kb, setKb] = useState<Kb[]>([]);
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [form, setForm] = useState({ name: '', email: '', priority: 'normal', category: 'general', subject: '', description: '' });
  const [loading, setLoading] = useState(false);
  const [created, setCreated] = useState<Ticket | null>(null);
  const [error, setError] = useState('');

  const load = () => {
    apiGet<Kb[]>('/api/marketing-content?type=kb').then(setKb).catch(() => {});
    apiGet<Ticket[]>('/api/support-tickets').then(setTickets).catch(() => {});
  };

  useEffect(() => { load(); }, []);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!form.email.includes('@') || !form.subject.trim()) {
      setError('Email and subject required');
      return;
    }
    setLoading(true);
    setError('');
    try {
      const t = await apiPost<Ticket>('/api/support-tickets', form);
      setCreated(t);
      load();
    } catch (err: any) {
      setError(err.message || 'Failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <MarketingShell ctaLabel="Emergency" ctaTo="#ticket">
      <section className="pt-16 pb-10 relative">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(0,230,118,0.1),transparent_50%)]" />
        <div className="relative z-10 max-w-7xl mx-auto px-5 md:px-8">
          <Fade>
            <p className="text-kyn-green text-xs font-semibold tracking-[0.3em] uppercase mb-4">Support</p>
            <h1 className="font-display text-4xl md:text-6xl font-bold">We're here when energy must keep moving</h1>
            <p className="mt-4 text-kyn-silver text-lg max-w-2xl">Tickets, knowledge base, live chat, remote diagnostics and emergency assistance.</p>
          </Fade>
          <div className="mt-10 grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {[
              { icon: LifeBuoy, t: 'Ticket desk', d: 'Tracked SLA responses' },
              { icon: BookOpen, t: 'Knowledge base', d: 'Self-serve guides' },
              { icon: MessageCircle, t: 'Live chat', d: 'Bottom-right bubble' },
              { icon: Cpu, t: 'Remote diagnostics', d: 'Cloud-assisted checks' },
            ].map(({ icon: Icon, t, d }) => (
              <div key={t} className="rounded-2xl border border-white/10 bg-kyn-void p-5">
                <Icon className="text-kyn-green mb-2" size={18} />
                <p className="font-semibold text-sm">{t}</p>
                <p className="text-xs text-kyn-metal mt-1">{d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="pb-20">
        <div className="max-w-7xl mx-auto px-5 md:px-8 grid lg:grid-cols-2 gap-8">
          <Fade>
            <div id="ticket" className="rounded-3xl border border-white/10 bg-kyn-void p-6 md:p-8">
              <h2 className="font-display text-2xl font-bold">Create a ticket</h2>
              {created ? (
                <div className="mt-6">
                  <SuccessBanner title="Ticket opened" body={`Reference ${created.ticket_no}. We'll email updates to ${form.email}.`} />
                </div>
              ) : (
                <form onSubmit={submit} className="mt-6 space-y-4">
                  <div className="grid sm:grid-cols-2 gap-4">
                    <Field label="Name"><input className={inputClass} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></Field>
                    <Field label="Email"><input type="email" className={inputClass} value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></Field>
                    <Field label="Priority">
                      <select className={inputClass} value={form.priority} onChange={(e) => setForm({ ...form, priority: e.target.value })}>
                        <option value="low">Low</option>
                        <option value="normal">Normal</option>
                        <option value="high">High</option>
                        <option value="emergency">Emergency</option>
                      </select>
                    </Field>
                    <Field label="Category">
                      <select className={inputClass} value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}>
                        <option value="general">General</option>
                        <option value="hardware">Hardware</option>
                        <option value="cloud">Cloud / App</option>
                        <option value="billing">Billing</option>
                        <option value="install">Installation</option>
                      </select>
                    </Field>
                  </div>
                  <Field label="Subject"><input className={inputClass} value={form.subject} onChange={(e) => setForm({ ...form, subject: e.target.value })} /></Field>
                  <Field label="Description"><textarea className={cn(inputClass, 'min-h-[110px]')} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="Charger ID, site, error codes…" /></Field>
                  {error && <p className="text-sm text-red-400">{error}</p>}
                  <button disabled={loading} className="px-6 py-3 rounded-full bg-kyn-green text-kyn-black text-sm font-bold">{loading ? 'Creating…' : 'Submit ticket'}</button>
                </form>
              )}
            </div>
          </Fade>

          <div className="space-y-4">
            <Fade delay={0.05}>
              <div className="rounded-3xl border border-red-500/30 bg-red-500/5 p-6">
                <div className="flex items-center gap-2 text-red-300 font-semibold"><Siren size={18} /> Emergency assistance</div>
                <p className="text-sm text-kyn-silver mt-2">Safety incidents or site-wide outages — call +216 71 000 000 (24/7 hotline) and open a High/Emergency ticket.</p>
              </div>
            </Fade>
            <Fade delay={0.08}>
              <div className="rounded-3xl border border-white/10 bg-kyn-void p-6">
                <h3 className="font-display font-bold text-lg mb-4">Knowledge base</h3>
                <div className="space-y-2">
                  {kb.map((k) => (
                    <details key={k.id} className="rounded-xl border border-white/8 bg-black/20 px-4 py-3">
                      <summary className="cursor-pointer text-sm font-medium">{k.title}</summary>
                      <p className="mt-2 text-xs text-kyn-metal leading-relaxed">{k.body}</p>
                    </details>
                  ))}
                  {!kb.length && <p className="text-sm text-kyn-metal">Loading articles…</p>}
                </div>
                <Link to="/faq" className="mt-4 inline-flex items-center gap-1 text-xs text-kyn-green font-semibold">Full FAQ <ArrowRight size={12} /></Link>
              </div>
            </Fade>
            <Fade delay={0.1}>
              <div className="rounded-3xl border border-white/10 bg-kyn-void p-6">
                <h3 className="font-display font-bold text-lg mb-3">Recent tickets</h3>
                <div className="space-y-2">
                  {tickets.slice(0, 5).map((t) => (
                    <div key={t.id} className="flex items-center justify-between text-sm rounded-xl border border-white/8 px-3 py-2">
                      <div>
                        <p className="font-medium">{t.ticket_no}</p>
                        <p className="text-xs text-kyn-metal">{t.subject}</p>
                      </div>
                      <span className="text-[10px] text-kyn-green capitalize">{t.status}</span>
                    </div>
                  ))}
                  {!tickets.length && <p className="text-xs text-kyn-metal">No tickets yet — yours will appear here after submit.</p>}
                </div>
              </div>
            </Fade>
          </div>
        </div>
      </section>
    </MarketingShell>
  );
}

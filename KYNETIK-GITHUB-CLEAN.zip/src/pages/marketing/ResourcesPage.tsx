import { useEffect, useMemo, useState } from 'react';
import { Download, FileText, Film, Shield, BookOpen, Search } from 'lucide-react';
import MarketingShell, { Fade } from '../../components/marketing/Shell';
import LoadingState from '../../components/LoadingState';
import { apiGet, cn } from '../../lib/utils';

interface Item {
  id: number;
  type: string;
  category: string;
  title: string;
  subtitle: string;
  body: string;
  meta: string | null;
  sort_order: number;
}

const catIcon: Record<string, any> = {
  datasheet: FileText,
  guide: BookOpen,
  warranty: Shield,
  certificate: Shield,
  video: Film,
  whitepaper: FileText,
};

export default function ResourcesPage() {
  const [items, setItems] = useState<Item[]>([]);
  const [loading, setLoading] = useState(true);
  const [q, setQ] = useState('');
  const [cat, setCat] = useState('all');

  useEffect(() => {
    apiGet<Item[]>('/api/marketing-content?type=resource')
      .then(setItems)
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  const cats = useMemo(() => ['all', ...Array.from(new Set(items.map((i) => i.category)))], [items]);
  const filtered = items.filter((i) => {
    const okCat = cat === 'all' || i.category === cat;
    const okQ = !q || `${i.title} ${i.body} ${i.subtitle}`.toLowerCase().includes(q.toLowerCase());
    return okCat && okQ;
  });

  return (
    <MarketingShell>
      <section className="pt-16 pb-10 relative">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(0,230,118,0.1),transparent_50%)]" />
        <div className="relative z-10 max-w-7xl mx-auto px-5 md:px-8">
          <Fade>
            <p className="text-kyn-green text-xs font-semibold tracking-[0.3em] uppercase mb-4">Resources</p>
            <h1 className="font-display text-4xl md:text-5xl font-bold">Resource center</h1>
            <p className="mt-3 text-kyn-silver max-w-xl">Datasheets, installation guides, warranty docs, certificates, videos and white papers.</p>
          </Fade>
          <div className="mt-8 flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-kyn-metal" />
              <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search resources…" className="w-full rounded-xl bg-kyn-steel/50 border border-white/10 pl-10 pr-3 py-3 text-sm focus:outline-none focus:border-kyn-green/40" />
            </div>
            <div className="flex flex-wrap gap-2">
              {cats.map((c) => (
                <button key={c} type="button" onClick={() => setCat(c)} className={cn('px-3 py-2 rounded-full text-xs font-semibold capitalize', cat === c ? 'bg-kyn-green text-kyn-black' : 'bg-kyn-steel text-kyn-silver')}>{c}</button>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="pb-24">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          {loading ? (
            <LoadingState />
          ) : (
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {filtered.map((r, i) => {
                const Icon = catIcon[r.category] || FileText;
                return (
                  <Fade key={r.id} delay={i * 0.03}>
                    <div className="rounded-2xl border border-white/10 bg-kyn-void p-5 h-full flex flex-col hover:border-kyn-green/30 transition-colors">
                      <div className="flex items-center justify-between">
                        <div className="w-10 h-10 rounded-xl bg-kyn-green/10 border border-kyn-green/20 flex items-center justify-center text-kyn-green">
                          <Icon size={18} />
                        </div>
                        <span className="text-[10px] uppercase tracking-wider text-kyn-metal">{r.category}</span>
                      </div>
                      <h3 className="font-display font-semibold mt-4">{r.title}</h3>
                      <p className="text-sm text-kyn-metal mt-2 flex-1">{r.body || r.subtitle}</p>
                      <div className="mt-4 flex items-center justify-between">
                        <span className="text-[11px] text-kyn-metal">{r.meta || 'PDF'}</span>
                        <button type="button" className="inline-flex items-center gap-1.5 text-xs font-semibold text-kyn-green">
                          <Download size={14} /> Download
                        </button>
                      </div>
                    </div>
                  </Fade>
                );
              })}
            </div>
          )}
        </div>
      </section>
    </MarketingShell>
  );
}

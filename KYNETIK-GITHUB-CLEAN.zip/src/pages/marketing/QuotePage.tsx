import { useEffect, useMemo, useState, type ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  ArrowRight, ArrowLeft, Check, Home, Building2, Car, Landmark,
  AlertCircle, Download, RefreshCw, LifeBuoy, Loader2
} from 'lucide-react';
import MarketingShell, { Fade } from '../../components/marketing/Shell';
import { apiGet, cn } from '../../lib/utils';
import { track } from '../../lib/analytics';
import { submitQuote } from '../../lib/quoteService';

interface Product {
  id: number;
  name: string;
  power: string;
  image_url: string;
  category: string;
  tagline?: string;
  specs?: string;
  features?: string;
}

const PROJECT_TYPES = [
  { id: 'Home', icon: Home, desc: 'Residential garage or driveway' },
  { id: 'Business', icon: Building2, desc: 'Workplace & office parking' },
  { id: 'Fleet', icon: Car, desc: 'Depots and commercial fleets' },
  { id: 'Public', icon: Landmark, desc: 'Public & destination charging' },
] as const;

const STEPS = ['Project', 'Product', 'Installation', 'Customer', 'Review'];

const COUNTRIES = ['Tunisia', 'France', 'Morocco', 'Algeria', 'Libya', 'Other'];
const PHASES = ['Single-phase 230V', 'Three-phase 400V', 'Unknown — need survey'];
const PARKING = ['Private garage', 'Outdoor driveway', 'Shared parking', 'Street / public', 'Depot'];
const LANGS = [
  { id: 'fr', label: 'Français' },
  { id: 'en', label: 'English' },
  { id: 'ar', label: 'العربية' },
];

function todayISO() {
  const d = new Date();
  return d.toISOString().slice(0, 10);
}

function matchesProject(p: Product, type: string) {
  const blob = `${p.name} ${p.category} ${p.tagline || ''}`.toLowerCase();
  if (type === 'Home') return /nova|go|prime|residential|home/.test(blob);
  if (type === 'Business') return /prime|edge|pro|business|workplace|hospitality|commercial/.test(blob);
  if (type === 'Fleet') return /pro|edge|fleet|depot|go/.test(blob);
  if (type === 'Public') return /pro|edge|public|urban|commercial/.test(blob);
  return true;
}

export default function QuotePage() {
  const [products, setProducts] = useState<Product[]>([]);
  const [step, setStep] = useState(0);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});
  const [success, setSuccess] = useState<{ reference: string } | null>(null);

  const [projectType, setProjectType] = useState('');
  const [selectedIds, setSelectedIds] = useState<number[]>([]);
  const [installation, setInstallation] = useState({
    country: 'Tunisia',
    city: '',
    location: 'Outdoor',
    parking_type: 'Private garage',
    chargers: 1,
    phase: PHASES[0],
    desired_date: '',
  });
  const [customer, setCustomer] = useState({
    first_name: '',
    last_name: '',
    company: '',
    email: '',
    phone: '',
    address: '',
    language: 'fr',
  });

  useEffect(() => {
    track('Quote Started');
    apiGet<Product[]>('/api/products')
      .then((data) => {
        setProducts((data || []).filter((p) => p.name && !String(p.name).startsWith('_')));
      })
      .catch(() => setProducts([]));
  }, []);

  const filteredProducts = useMemo(() => {
    if (!projectType) return products;
    const matched = products.filter((p) => matchesProject(p, projectType));
    return matched.length ? matched : products;
  }, [products, projectType]);

  const selectedProducts = useMemo(
    () => products.filter((p) => selectedIds.includes(p.id)),
    [products, selectedIds]
  );

  const toggleProduct = (id: number) => {
    setSelectedIds((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));
  };

  const validateStep = () => {
    const errs: Record<string, string> = {};
    if (step === 0 && !projectType) errs.projectType = 'Please select a project type.';
    if (step === 1 && selectedIds.length < 1) errs.products = 'Select at least one product.';
    if (step === 2) {
      if (!installation.country) errs.country = 'Country is required.';
      if (!installation.city.trim()) errs.city = 'City is required.';
      if (!installation.chargers || installation.chargers < 1) errs.chargers = 'Number of chargers must be ≥ 1.';
      if (installation.desired_date && installation.desired_date < todayISO()) {
        errs.desired_date = 'Date cannot be in the past.';
      }
    }
    if (step === 3) {
      if (!customer.first_name.trim()) errs.first_name = 'First name is required.';
      if (!customer.last_name.trim()) errs.last_name = 'Last name is required.';
      if (!customer.email.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(customer.email)) {
        errs.email = 'Valid email is required.';
      }
      if (!customer.phone.trim()) errs.phone = 'Phone is required.';
      if (projectType !== 'Home' && !customer.company.trim()) {
        errs.company = 'Company is recommended for business projects.';
      }
    }
    setFieldErrors(errs);
    // company is soft for home
    const hard = { ...errs };
    if (projectType === 'Home') delete hard.company;
    return Object.keys(hard).filter((k) => k !== 'company' || projectType !== 'Home').every((k) => {
      if (projectType === 'Home' && k === 'company') return true;
      return !hard[k];
    }) && Object.keys(errs).filter((k) => !(projectType === 'Home' && k === 'company')).length === 0;
  };

  const next = () => {
    if (!validateStep()) return;
    setStep((s) => Math.min(s + 1, STEPS.length - 1));
  };
  const prev = () => {
    setError('');
    setStep((s) => Math.max(s - 1, 0));
  };

  const submit = async () => {
    if (!validateStep()) return;
    setLoading(true);
    setError('');
    const payload = {
      customer,
      project: { type: projectType },
      products: selectedProducts.map((p) => ({
        id: p.id,
        name: p.name,
        power: p.power,
        category: p.category,
      })),
      installation,
    };
    try {
      const data = await submitQuote(payload);
      setSuccess({ reference: data.reference });
    } catch (e: any) {
      setError(e.message || 'Request Failed.');
      track('Quote Failed', { error: e.message });
    } finally {
      setLoading(false);
    }
  };

  const downloadSummary = () => {
    if (!success) return;
    const lines = [
      'KYNETIK Quotation Request Summary',
      `Reference: ${success.reference}`,
      `Project: ${projectType}`,
      `Products: ${selectedProducts.map((p) => p.name).join(', ')}`,
      `Chargers: ${installation.chargers}`,
      `Location: ${installation.city}, ${installation.country}`,
      `Customer: ${customer.first_name} ${customer.last_name}`,
      `Email: ${customer.email}`,
      `Phone: ${customer.phone}`,
    ];
    const blob = new Blob([lines.join('\n')], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${success.reference}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <MarketingShell ctaLabel="Contact" ctaTo="/contact">
      <section className="relative pt-14 pb-8">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(0,230,118,0.1),transparent_50%)]" />
        <div className="relative z-10 max-w-4xl mx-auto px-5 md:px-8">
          <Fade>
            <p className="text-kyn-green text-xs font-semibold tracking-[0.3em] uppercase mb-3">WEB-QUOTE-001</p>
            <h1 className="font-display text-4xl md:text-5xl font-bold">Request a Quote</h1>
            <p className="mt-3 text-kyn-silver">5-step wizard — project, product, installation, contact and review.</p>
          </Fade>
          <div className="mt-8 flex gap-2 overflow-x-auto pb-2">
            {STEPS.map((s, i) => (
              <div
                key={s}
                className={cn(
                  'flex items-center gap-2 shrink-0 text-xs font-semibold px-3 py-1.5 rounded-full border',
                  i === step
                    ? 'bg-kyn-green text-kyn-black border-kyn-green'
                    : i < step
                      ? 'border-kyn-green/40 text-kyn-green'
                      : 'border-white/10 text-kyn-metal'
                )}
              >
                {i < step ? <Check size={12} /> : <span>{i + 1}</span>} {s}
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="pb-24">
        <div className="max-w-4xl mx-auto px-5 md:px-8">
          {success ? (
            <Fade>
              <div className="rounded-3xl border border-kyn-green/30 bg-gradient-to-b from-kyn-green/10 to-kyn-void p-8 md:p-12 text-center">
                <div className="w-16 h-16 mx-auto rounded-full bg-kyn-green/20 border border-kyn-green/40 flex items-center justify-center mb-6">
                  <Check className="text-kyn-green" size={28} />
                </div>
                <h2 className="font-display text-3xl md:text-4xl font-bold">Thank You.</h2>
                <p className="mt-4 text-kyn-silver">Your quotation request has been received.</p>
                <p className="mt-6 text-sm text-kyn-metal uppercase tracking-wider">Reference Number</p>
                <p className="mt-2 font-display text-2xl md:text-3xl font-bold text-kyn-green text-glow">
                  {success.reference}
                </p>
                <div className="mt-10 flex flex-wrap justify-center gap-3">
                  <button
                    type="button"
                    onClick={downloadSummary}
                    className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-kyn-green text-kyn-black text-sm font-bold"
                  >
                    <Download size={16} /> Download Summary
                  </button>
                  <Link
                    to="/site"
                    className="inline-flex items-center gap-2 px-6 py-3 rounded-full border border-white/15 text-sm font-medium"
                  >
                    Back to Homepage
                  </Link>
                </div>
              </div>
            </Fade>
          ) : (
            <div className="rounded-3xl border border-white/10 bg-kyn-void/80 p-6 md:p-8">
              <AnimatePresence mode="wait">
                <motion.div
                  key={step}
                  initial={{ opacity: 0, x: 16 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -16 }}
                  transition={{ duration: 0.25 }}
                >
                  {step === 0 && (
                    <div>
                      <h2 className="font-display text-2xl font-bold">Project Type</h2>
                      <p className="text-sm text-kyn-metal mt-1">Select the context for your charging project.</p>
                      <div className="mt-6 grid sm:grid-cols-2 gap-3">
                        {PROJECT_TYPES.map(({ id, icon: Icon, desc }) => (
                          <button
                            key={id}
                            type="button"
                            onClick={() => setProjectType(id)}
                            className={cn(
                              'text-left rounded-2xl border p-5 transition-all',
                              projectType === id
                                ? 'border-kyn-green/50 bg-kyn-green/10'
                                : 'border-white/10 hover:border-white/25 bg-black/20'
                            )}
                          >
                            <Icon size={20} className={projectType === id ? 'text-kyn-green' : 'text-kyn-metal'} />
                            <p className="font-display font-bold mt-3">{id}</p>
                            <p className="text-xs text-kyn-metal mt-1">{desc}</p>
                          </button>
                        ))}
                      </div>
                      {fieldErrors.projectType && (
                        <p className="mt-3 text-sm text-red-400 flex items-center gap-1">
                          <AlertCircle size={14} /> {fieldErrors.projectType}
                        </p>
                      )}
                    </div>
                  )}

                  {step === 1 && (
                    <div>
                      <h2 className="font-display text-2xl font-bold">Product</h2>
                      <p className="text-sm text-kyn-metal mt-1">Choose one or more products suited to {projectType || 'your project'}.</p>
                      <div className="mt-6 grid sm:grid-cols-2 gap-3 max-h-[420px] overflow-y-auto pr-1">
                        {filteredProducts.map((p) => {
                          const on = selectedIds.includes(p.id);
                          return (
                            <button
                              key={p.id}
                              type="button"
                              onClick={() => toggleProduct(p.id)}
                              className={cn(
                                'text-left rounded-2xl border p-4 flex gap-3 transition-all',
                                on ? 'border-kyn-green/50 bg-kyn-green/10' : 'border-white/10 bg-black/20 hover:border-white/25'
                              )}
                            >
                              <img src={p.image_url} alt={p.name} className="w-16 h-20 object-contain" loading="lazy" />
                              <div className="min-w-0">
                                <p className="font-semibold text-sm">{p.name}</p>
                                <p className="text-kyn-green text-xs mt-0.5">{p.power}</p>
                                <p className="text-[11px] text-kyn-metal mt-1 line-clamp-2">{p.tagline}</p>
                              </div>
                              <div className={cn('ml-auto w-5 h-5 rounded-full border flex items-center justify-center shrink-0', on ? 'bg-kyn-green border-kyn-green text-kyn-black' : 'border-white/20')}>
                                {on && <Check size={12} />}
                              </div>
                            </button>
                          );
                        })}
                      </div>
                      {fieldErrors.products && (
                        <p className="mt-3 text-sm text-red-400 flex items-center gap-1">
                          <AlertCircle size={14} /> {fieldErrors.products}
                        </p>
                      )}
                    </div>
                  )}

                  {step === 2 && (
                    <div>
                      <h2 className="font-display text-2xl font-bold">Installation</h2>
                      <p className="text-sm text-kyn-metal mt-1">Site details for survey and deployment planning.</p>
                      <div className="mt-6 grid sm:grid-cols-2 gap-4">
                        <Field label="Country *" error={fieldErrors.country}>
                          <select
                            className={inputClass}
                            value={installation.country}
                            onChange={(e) => setInstallation({ ...installation, country: e.target.value })}
                          >
                            {COUNTRIES.map((c) => (
                              <option key={c} value={c}>{c}</option>
                            ))}
                          </select>
                        </Field>
                        <Field label="City *" error={fieldErrors.city}>
                          <input
                            className={inputClass}
                            value={installation.city}
                            onChange={(e) => setInstallation({ ...installation, city: e.target.value })}
                            placeholder="Tunis"
                          />
                        </Field>
                        <Field label="Indoor / Outdoor">
                          <select
                            className={inputClass}
                            value={installation.location}
                            onChange={(e) => setInstallation({ ...installation, location: e.target.value })}
                          >
                            <option>Indoor</option>
                            <option>Outdoor</option>
                            <option>Mixed</option>
                          </select>
                        </Field>
                        <Field label="Parking Type">
                          <select
                            className={inputClass}
                            value={installation.parking_type}
                            onChange={(e) => setInstallation({ ...installation, parking_type: e.target.value })}
                          >
                            {PARKING.map((p) => (
                              <option key={p}>{p}</option>
                            ))}
                          </select>
                        </Field>
                        <Field label="Number of Chargers *" error={fieldErrors.chargers}>
                          <input
                            type="number"
                            min={1}
                            className={inputClass}
                            value={installation.chargers}
                            onChange={(e) => setInstallation({ ...installation, chargers: Number(e.target.value) })}
                          />
                        </Field>
                        <Field label="Electrical Phase">
                          <select
                            className={inputClass}
                            value={installation.phase}
                            onChange={(e) => setInstallation({ ...installation, phase: e.target.value })}
                          >
                            {PHASES.map((p) => (
                              <option key={p}>{p}</option>
                            ))}
                          </select>
                        </Field>
                        <Field label="Desired Installation Date" error={fieldErrors.desired_date} className="sm:col-span-2">
                          <input
                            type="date"
                            min={todayISO()}
                            className={inputClass}
                            value={installation.desired_date}
                            onChange={(e) => setInstallation({ ...installation, desired_date: e.target.value })}
                          />
                        </Field>
                      </div>
                    </div>
                  )}

                  {step === 3 && (
                    <div>
                      <h2 className="font-display text-2xl font-bold">Customer Information</h2>
                      <p className="text-sm text-kyn-metal mt-1">We use this to send your formal quotation.</p>
                      <div className="mt-6 grid sm:grid-cols-2 gap-4">
                        <Field label="First Name *" error={fieldErrors.first_name}>
                          <input className={inputClass} value={customer.first_name} onChange={(e) => setCustomer({ ...customer, first_name: e.target.value })} />
                        </Field>
                        <Field label="Last Name *" error={fieldErrors.last_name}>
                          <input className={inputClass} value={customer.last_name} onChange={(e) => setCustomer({ ...customer, last_name: e.target.value })} />
                        </Field>
                        <Field label={projectType === 'Home' ? 'Company (optional)' : 'Company *'} error={fieldErrors.company} className="sm:col-span-2">
                          <input className={inputClass} value={customer.company} onChange={(e) => setCustomer({ ...customer, company: e.target.value })} />
                        </Field>
                        <Field label="Email *" error={fieldErrors.email}>
                          <input type="email" className={inputClass} value={customer.email} onChange={(e) => setCustomer({ ...customer, email: e.target.value })} />
                        </Field>
                        <Field label="Phone *" error={fieldErrors.phone}>
                          <input className={inputClass} value={customer.phone} onChange={(e) => setCustomer({ ...customer, phone: e.target.value })} placeholder="+216 ..." />
                        </Field>
                        <Field label="Address" className="sm:col-span-2">
                          <input className={inputClass} value={customer.address} onChange={(e) => setCustomer({ ...customer, address: e.target.value })} />
                        </Field>
                        <Field label="Preferred Language" className="sm:col-span-2">
                          <div className="flex flex-wrap gap-2">
                            {LANGS.map((l) => (
                              <button
                                key={l.id}
                                type="button"
                                onClick={() => setCustomer({ ...customer, language: l.id })}
                                className={cn(
                                  'px-4 py-2 rounded-full text-xs font-semibold border',
                                  customer.language === l.id
                                    ? 'bg-kyn-green text-kyn-black border-kyn-green'
                                    : 'border-white/15 text-kyn-silver'
                                )}
                              >
                                {l.label}
                              </button>
                            ))}
                          </div>
                        </Field>
                      </div>
                    </div>
                  )}

                  {step === 4 && (
                    <div>
                      <h2 className="font-display text-2xl font-bold">Review</h2>
                      <p className="text-sm text-kyn-metal mt-1">Confirm details before submit.</p>
                      <div className="mt-6 space-y-3">
                        <ReviewCard title="Project" body={projectType} />
                        <ReviewCard
                          title="Product"
                          body={selectedProducts.map((p) => `${p.name} (${p.power})`).join('\n') || '—'}
                        />
                        <ReviewCard
                          title="Installation"
                          body={`${installation.chargers} charger(s) · ${installation.location}\n${installation.parking_type}\n${installation.city}, ${installation.country}\n${installation.phase}\nDate: ${installation.desired_date || 'TBD'}`}
                        />
                        <ReviewCard
                          title="Contact"
                          body={`${customer.first_name} ${customer.last_name}\n${customer.company}\n${customer.email}\n${customer.phone}\n${customer.address}\nLang: ${customer.language}`}
                        />
                      </div>
                      {error && (
                        <div className="mt-6 rounded-2xl border border-red-500/30 bg-red-500/10 p-5">
                          <p className="font-semibold text-red-300">Request Failed.</p>
                          <p className="text-sm text-red-200/80 mt-1">{error}</p>
                          <div className="mt-4 flex flex-wrap gap-2">
                            <button
                              type="button"
                              onClick={submit}
                              className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-kyn-green text-kyn-black text-xs font-bold"
                            >
                              <RefreshCw size={14} /> Retry
                            </button>
                            <Link
                              to="/support"
                              className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-white/15 text-xs font-medium"
                            >
                              <LifeBuoy size={14} /> Contact Support
                            </Link>
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </motion.div>
              </AnimatePresence>

              <div className="mt-8 flex items-center justify-between gap-3 border-t border-white/5 pt-6">
                <button
                  type="button"
                  onClick={prev}
                  disabled={step === 0 || loading}
                  className="inline-flex items-center gap-2 px-4 py-2.5 rounded-full border border-white/15 text-sm font-medium disabled:opacity-40"
                >
                  <ArrowLeft size={16} /> Previous
                </button>
                {step < STEPS.length - 1 ? (
                  <button
                    type="button"
                    onClick={next}
                    className="inline-flex items-center gap-2 px-6 py-2.5 rounded-full bg-kyn-green text-kyn-black text-sm font-bold"
                  >
                    Continue <ArrowRight size={16} />
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={submit}
                    disabled={loading}
                    className="inline-flex items-center gap-2 px-6 py-2.5 rounded-full bg-kyn-green text-kyn-black text-sm font-bold disabled:opacity-60"
                  >
                    {loading ? <Loader2 size={16} className="animate-spin" /> : <Check size={16} />}
                    Submit
                  </button>
                )}
              </div>
            </div>
          )}
        </div>
      </section>
    </MarketingShell>
  );
}

function Field({
  label,
  error,
  children,
  className,
}: {
  label: string;
  error?: string;
  children: ReactNode;
  className?: string;
}) {
  return (
    <label className={cn('block', className)}>
      <span className="text-[11px] uppercase tracking-wider text-kyn-metal font-semibold">{label}</span>
      <div className="mt-1.5">{children}</div>
      {error && <span className="mt-1 block text-xs text-red-400">{error}</span>}
    </label>
  );
}

function ReviewCard({ title, body }: { title: string; body: string }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-black/30 p-4">
      <p className="text-[10px] uppercase tracking-wider text-kyn-green font-semibold">{title}</p>
      <p className="mt-2 text-sm text-kyn-silver whitespace-pre-line">{body}</p>
    </div>
  );
}

const inputClass =
  'w-full rounded-xl bg-black/40 border border-white/10 px-3 py-2.5 text-sm text-white outline-none focus:border-kyn-green/50';

import { useState, FormEvent } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, CheckCircle2, Globe2, Megaphone, Package, Map } from 'lucide-react';
import MarketingShell, { Fade, Field, inputClass, SuccessBanner } from '../../components/marketing/Shell';
import { apiPost, cn } from '../../lib/utils';

const benefits = [
  { icon: Package, t: 'Exclusive SKUs', d: 'Priority allocation on NOVA, PRIME, GO and EDGE lines.' },
  { icon: Megaphone, t: 'Marketing support', d: 'Campaign kits, showroom assets, demo units.' },
  { icon: Globe2, t: 'Commercial support', d: 'Deal desk, bid support, margin frameworks.' },
  { icon: Map, t: 'Territory rights', d: 'Protected coverage with clear performance SLAs.' },
];

const territories = ['Grand Tunis', 'Nabeul–Hammamet', 'Sfax–South', 'Sousse–Sahel', 'Bizerte–North', 'International MENA'];

export default function DistributorPage() {
  const [form, setForm] = useState({ name: '', email: '', phone: '', company: '', territory: territories[0], revenue: '', message: '' });
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(false);
  const [error, setError] = useState('');

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!form.email.includes('@') || !form.company) {
      setError('Company and email required');
      return;
    }
    setLoading(true);
    setError('');
    try {
      await apiPost('/api/leads', {
        type: 'distributor',
        name: form.name,
        email: form.email,
        phone: form.phone,
        company: form.company,
        subject: `Distributor · ${form.territory}`,
        message: form.message,
        payload: form,
      });
      setDone(true);
    } catch (err: any) {
      setError(err.message || 'Failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <MarketingShell ctaLabel="Apply" ctaTo="#apply">
      <section className="relative pt-16 pb-14">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(0,230,118,0.12),transparent_55%)]" />
        <div className="relative z-10 max-w-7xl mx-auto px-5 md:px-8">
          <Fade>
            <p className="text-kyn-green text-xs font-semibold tracking-[0.3em] uppercase mb-4">Distribution</p>
            <h1 className="font-display text-4xl md:text-6xl font-bold max-w-3xl">Become a KYNETIK Distributor</h1>
            <p className="mt-5 text-lg text-kyn-silver max-w-2xl">Scale premium EV charging across your market with hardware exclusivity, Cloud enablement and enterprise sales support.</p>
            <a href="#apply" className="mt-8 inline-flex items-center gap-2 px-6 py-3 rounded-full bg-kyn-green text-kyn-black text-sm font-bold">Request partnership <ArrowRight size={16} /></a>
          </Fade>
        </div>
      </section>

      <section className="py-16 bg-kyn-void border-y border-white/5">
        <div className="max-w-7xl mx-auto px-5 md:px-8 grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {benefits.map((b, i) => {
            const Icon = b.icon;
            return (
              <Fade key={b.t} delay={i * 0.05}>
                <div className="rounded-2xl border border-white/8 bg-black/30 p-6 h-full">
                  <Icon className="text-kyn-green mb-3" size={20} />
                  <p className="font-display font-semibold">{b.t}</p>
                  <p className="text-sm text-kyn-metal mt-2">{b.d}</p>
                </div>
              </Fade>
            );
          })}
        </div>
      </section>

      <section className="py-20">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <Fade><h2 className="font-display text-3xl font-bold mb-8">Territories</h2></Fade>
          <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-3">
            {territories.map((t) => (
              <div key={t} className="rounded-xl border border-white/10 px-4 py-3 text-sm flex items-center gap-2">
                <CheckCircle2 size={14} className="text-kyn-green" /> {t}
              </div>
            ))}
          </div>
          <Fade>
            <div className="mt-10 rounded-3xl border border-white/10 p-6 md:p-8 bg-gradient-to-br from-kyn-steel/40 to-transparent">
              <h3 className="font-display text-xl font-bold">Exclusive product access</h3>
              <p className="mt-2 text-sm text-kyn-silver max-w-2xl">Distributors unlock demo fleets, early PRIME/GO allocations, and co-selling on Cloud SaaS subscriptions for CPO and fleet accounts.</p>
              <Link to="/products" className="mt-4 inline-flex text-sm text-kyn-green font-semibold items-center gap-1">View product system <ArrowRight size={14} /></Link>
            </div>
          </Fade>
        </div>
      </section>

      <section id="apply" className="py-20 border-t border-white/5 bg-kyn-void">
        <div className="max-w-2xl mx-auto px-5 md:px-8">
          <Fade>
            <h2 className="font-display text-3xl font-bold mb-6">Distributor application</h2>
            {done ? (
              <SuccessBanner title="Application sent" body="Channel team will review territory fit and respond with next steps." />
            ) : (
              <form onSubmit={submit} className="rounded-3xl border border-white/10 bg-kyn-black/50 p-6 md:p-8 space-y-4">
                <div className="grid sm:grid-cols-2 gap-4">
                  <Field label="Contact name"><input className={inputClass} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></Field>
                  <Field label="Email"><input type="email" className={inputClass} value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></Field>
                  <Field label="Phone"><input className={inputClass} value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></Field>
                  <Field label="Company"><input className={inputClass} value={form.company} onChange={(e) => setForm({ ...form, company: e.target.value })} /></Field>
                  <Field label="Territory interest">
                    <select className={inputClass} value={form.territory} onChange={(e) => setForm({ ...form, territory: e.target.value })}>
                      {territories.map((t) => <option key={t}>{t}</option>)}
                    </select>
                  </Field>
                  <Field label="Annual revenue band"><input className={inputClass} value={form.revenue} onChange={(e) => setForm({ ...form, revenue: e.target.value })} placeholder="e.g. 1–5 M DT" /></Field>
                </div>
                <Field label="Why KYNETIK?"><textarea className={cn(inputClass, 'min-h-[100px]')} value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} /></Field>
                {error && <p className="text-sm text-red-400">{error}</p>}
                <button disabled={loading} className="px-6 py-3 rounded-full bg-kyn-green text-kyn-black text-sm font-bold">{loading ? 'Submitting…' : 'Submit application'}</button>
              </form>
            )}
          </Fade>
        </div>
      </section>
    </MarketingShell>
  );
}

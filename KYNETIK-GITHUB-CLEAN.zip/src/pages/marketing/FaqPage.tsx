import { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown, Search } from 'lucide-react';
import MarketingShell, { Fade } from '../../components/marketing/Shell';
import LoadingState from '../../components/LoadingState';
import { apiGet, cn } from '../../lib/utils';

interface Item {
  id: number;
  type: string;
  category: string;
  title: string;
  body: string;
  sort_order: number;
}

export default function FaqPage() {
  const [items, setItems] = useState<Item[]>([]);
  const [loading, setLoading] = useState(true);
  const [q, setQ] = useState('');
  const [cat, setCat] = useState('all');
  const [openId, setOpenId] = useState<number | null>(null);

  useEffect(() => {
    apiGet<Item[]>('/api/marketing-content?type=faq')
      .then((data) => {
        setItems(data || []);
        if (data?.[0]) setOpenId(data[0].id);
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  const cats = useMemo(() => ['all', ...Array.from(new Set(items.map((i) => i.category)))], [items]);
  const filtered = items.filter((i) => {
    const okCat = cat === 'all' || i.category === cat;
    const okQ = !q || `${i.title} ${i.body}`.toLowerCase().includes(q.toLowerCase());
    return okCat && okQ;
  });

  return (
    <MarketingShell>
      <section className="pt-16 pb-10 relative">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(0,230,118,0.1),transparent_50%)]" />
        <div className="relative z-10 max-w-3xl mx-auto px-5 md:px-8 text-center">
          <Fade>
            <p className="text-kyn-green text-xs font-semibold tracking-[0.3em] uppercase mb-4">FAQ</p>
            <h1 className="font-display text-4xl md:text-5xl font-bold">Answers, instantly</h1>
            <p className="mt-3 text-kyn-silver">Installation, charging, Cloud, warranty and payments.</p>
          </Fade>
          <div className="mt-8 relative">
            <Search size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-kyn-metal" />
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search FAQ…" className="w-full rounded-2xl bg-kyn-steel/50 border border-white/10 pl-11 pr-4 py-3.5 text-sm focus:outline-none focus:border-kyn-green/40" />
          </div>
          <div className="mt-4 flex flex-wrap justify-center gap-2">
            {cats.map((c) => (
              <button key={c} type="button" onClick={() => setCat(c)} className={cn('px-3 py-1.5 rounded-full text-xs font-semibold capitalize', cat === c ? 'bg-kyn-green text-kyn-black' : 'bg-kyn-steel text-kyn-silver')}>{c}</button>
            ))}
          </div>
        </div>
      </section>

      <section className="pb-24">
        <div className="max-w-3xl mx-auto px-5 md:px-8 space-y-3">
          {loading && <LoadingState />}
          {!loading && filtered.map((f) => {
            const open = openId === f.id;
            return (
              <div key={f.id} className="rounded-2xl border border-white/10 bg-kyn-void overflow-hidden">
                <button type="button" onClick={() => setOpenId(open ? null : f.id)} className="w-full flex items-center justify-between gap-4 px-5 py-4 text-left">
                  <div>
                    <p className="text-[10px] uppercase tracking-wider text-kyn-green">{f.category}</p>
                    <p className="font-semibold text-sm md:text-base mt-0.5">{f.title}</p>
                  </div>
                  <ChevronDown size={18} className={cn('text-kyn-metal shrink-0 transition-transform', open && 'rotate-180 text-kyn-green')} />
                </button>
                <AnimatePresence initial={false}>
                  {open && (
                    <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.25 }} className="overflow-hidden">
                      <div className="px-5 pb-5 text-sm text-kyn-silver leading-relaxed border-t border-white/5 pt-3">{f.body}</div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            );
          })}
          <Fade>
            <div className="mt-10 rounded-2xl border border-white/10 p-6 text-center">
              <p className="font-semibold">Still need help?</p>
              <div className="mt-4 flex flex-wrap justify-center gap-3">
                <Link to="/support" className="px-4 py-2 rounded-full bg-kyn-green text-kyn-black text-xs font-bold">Open support</Link>
                <Link to="/contact" className="px-4 py-2 rounded-full border border-white/15 text-xs font-semibold">Contact sales</Link>
              </div>
            </div>
          </Fade>
        </div>
      </section>
    </MarketingShell>
  );
}

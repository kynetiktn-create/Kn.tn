import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Award, BookOpen, Cloud, Briefcase, Wrench, CheckCircle2 } from 'lucide-react';
import MarketingShell, { Fade } from '../../components/marketing/Shell';
import LoadingState from '../../components/LoadingState';
import { apiGet } from '../../lib/utils';

interface Course {
  id: number;
  title: string;
  level: string;
  duration: string;
  modules: number;
  description: string;
}

const tracks = [
  { icon: Wrench, t: 'Installer Training', d: 'AC/DC safety, commissioning, site handover.' },
  { icon: Briefcase, t: 'Business Training', d: 'Selling KYNETIK, quoting, territory playbooks.' },
  { icon: Cloud, t: 'Cloud Training', d: 'OCPP ops, dashboards, alerts, billing basics.' },
];

export default function AcademyLandingPage() {
  const [courses, setCourses] = useState<Course[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    apiGet<Course[]>('/api/academy-courses')
      .then(setCourses)
      .catch(() => setCourses([]))
      .finally(() => setLoading(false));
  }, []);

  return (
    <MarketingShell ctaLabel="Apply as installer" ctaTo="/installers">
      <section className="relative pt-16 pb-14 overflow-hidden">
        <div className="absolute inset-0">
          <img src="/images/academy.jpg" alt="" className="w-full h-full object-cover opacity-25" />
          <div className="absolute inset-0 bg-gradient-to-r from-kyn-black via-kyn-black/90 to-kyn-black/70" />
        </div>
        <div className="relative z-10 max-w-7xl mx-auto px-5 md:px-8">
          <Fade>
            <p className="text-kyn-green text-xs font-semibold tracking-[0.3em] uppercase mb-4">KYNETIK Academy</p>
            <h1 className="font-display text-4xl md:text-6xl font-bold max-w-3xl">Train the experts of electric mobility</h1>
            <p className="mt-5 text-lg text-kyn-silver max-w-2xl">Courses, certifications and role-based paths for installers, partners and Cloud operators.</p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link to="/installers" className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-kyn-green text-kyn-black text-sm font-bold">Become certified <ArrowRight size={16} /></Link>
              <Link to="/design-system/academy" className="hidden" />
              <a href="#courses" className="inline-flex items-center gap-2 px-6 py-3 rounded-full border border-white/15 text-sm font-medium">Browse courses</a>
            </div>
          </Fade>
        </div>
      </section>

      <section className="py-16 bg-kyn-void border-y border-white/5">
        <div className="max-w-7xl mx-auto px-5 md:px-8 grid md:grid-cols-3 gap-4">
          {tracks.map((t, i) => {
            const Icon = t.icon;
            return (
              <Fade key={t.t} delay={i * 0.06}>
                <div className="rounded-2xl border border-white/10 bg-black/30 p-6 h-full">
                  <Icon className="text-kyn-green mb-3" size={22} />
                  <p className="font-display font-semibold text-lg">{t.t}</p>
                  <p className="text-sm text-kyn-metal mt-2">{t.d}</p>
                </div>
              </Fade>
            );
          })}
        </div>
      </section>

      <section id="courses" className="py-20">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <Fade>
            <div className="flex flex-wrap items-end justify-between gap-4 mb-8">
              <h2 className="font-display text-3xl font-bold">Courses</h2>
              <div className="flex items-center gap-2 text-sm text-kyn-metal"><Award size={16} className="text-kyn-green" /> Certificate on completion</div>
            </div>
          </Fade>
          {loading ? <LoadingState /> : (
            <div className="grid md:grid-cols-2 gap-4">
              {courses.map((c, i) => (
                <Fade key={c.id} delay={i * 0.04}>
                  <div className="rounded-2xl border border-white/10 bg-kyn-void p-6 hover:border-kyn-green/30 transition-colors">
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <p className="text-[10px] uppercase tracking-wider text-kyn-green">{c.level}</p>
                        <h3 className="font-display font-semibold text-lg mt-1">{c.title}</h3>
                      </div>
                      <BookOpen className="text-kyn-metal shrink-0" size={18} />
                    </div>
                    <p className="text-sm text-kyn-metal mt-3">{c.description}</p>
                    <div className="mt-4 flex gap-4 text-xs text-kyn-silver">
                      <span>{c.duration}</span>
                      <span>{c.modules} modules</span>
                    </div>
                  </div>
                </Fade>
              ))}
              {!courses.length && (
                <div className="col-span-2 rounded-2xl border border-white/10 p-8 text-kyn-metal text-sm">
                  Courses will appear here from the Academy database.
                </div>
              )}
            </div>
          )}
        </div>
      </section>

      <section className="py-16 border-t border-white/5 bg-kyn-void">
        <div className="max-w-7xl mx-auto px-5 md:px-8 grid md:grid-cols-2 gap-8 items-center">
          <Fade>
            <h2 className="font-display text-3xl font-bold">Certification outcomes</h2>
            <ul className="mt-6 space-y-3 text-sm text-kyn-silver">
              {['Digital + printable badge', 'Listed in partner directory', 'Portal commissioning rights', 'Continuing education credits'].map((x) => (
                <li key={x} className="flex gap-2"><CheckCircle2 size={16} className="text-kyn-green" />{x}</li>
              ))}
            </ul>
          </Fade>
          <Fade delay={0.08}>
            <div className="rounded-3xl border border-kyn-green/30 bg-kyn-green/5 p-8 text-center">
              <Award className="mx-auto text-kyn-green" size={40} />
              <p className="font-display text-2xl font-bold mt-4">KYNETIK Certified</p>
              <p className="text-sm text-kyn-metal mt-2">Installer · Partner · Cloud Operator</p>
              <Link to="/installers" className="mt-6 inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-kyn-green text-kyn-black text-xs font-bold">Start path <ArrowRight size={14} /></Link>
            </div>
          </Fade>
        </div>
      </section>
    </MarketingShell>
  );
}

import { useState, FormEvent } from 'react';
import { Link } from 'react-router-dom';
import { Award, CheckCircle2, ArrowRight, GraduationCap, Wrench, BadgeCheck, Laptop } from 'lucide-react';
import MarketingShell, { Fade, Field, inputClass, SuccessBanner } from '../../components/marketing/Shell';
import { apiPost, cn } from '../../lib/utils';

const benefits = [
  'Access to certified product training (Academy)',
  'Priority lead routing in your territory',
  'Installation playbooks & remote diagnostics',
  'Co-branded marketing kits',
  'Preferred hardware pricing',
  'Direct Cloud portal for commissioning',
];

const roadmap = [
  { t: 'Apply', d: 'Submit company profile and coverage area' },
  { t: 'Review', d: 'KYNETIK validates electrical credentials' },
  { t: 'Train', d: 'Academy modules + hands-on assessment' },
  { t: 'Certify', d: 'Receive installer badge & portal access' },
  { t: 'Deploy', d: 'Receive jobs, commission on Cloud' },
];

export default function InstallerPage() {
  const [form, setForm] = useState({ name: '', email: '', phone: '', company: '', city: '', experience: '', message: '' });
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(false);
  const [error, setError] = useState('');

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!form.email.includes('@') || !form.name) {
      setError('Name and valid email required');
      return;
    }
    setLoading(true);
    setError('');
    try {
      await apiPost('/api/leads', {
        type: 'installer',
        name: form.name,
        email: form.email,
        phone: form.phone,
        company: form.company,
        subject: 'Installer application',
        message: form.message,
        payload: form,
      });
      setDone(true);
    } catch (err: any) {
      setError(err.message || 'Failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <MarketingShell ctaLabel="Apply now" ctaTo="#apply">
      <section className="relative pt-16 pb-12 overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,rgba(0,230,118,0.12),transparent_50%)]" />
        <div className="relative z-10 max-w-7xl mx-auto px-5 md:px-8 grid lg:grid-cols-2 gap-10 items-center">
          <Fade>
            <p className="text-kyn-green text-xs font-semibold tracking-[0.3em] uppercase mb-4">Partner program</p>
            <h1 className="font-display text-4xl md:text-6xl font-bold leading-tight">Become a KYNETIK Certified Installer</h1>
            <p className="mt-5 text-kyn-silver text-lg">Join the network powering Tunisia's EV infrastructure — training, tools, and qualified demand.</p>
            <div className="mt-8 flex flex-wrap gap-3">
              <a href="#apply" className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-kyn-green text-kyn-black text-sm font-bold">Start application <ArrowRight size={16} /></a>
              <Link to="/academy-landing" className="inline-flex items-center gap-2 px-6 py-3 rounded-full border border-white/15 text-sm font-medium">View training</Link>
            </div>
          </Fade>
          <Fade delay={0.1}>
            <div className="rounded-3xl border border-white/10 bg-kyn-void p-6 grid grid-cols-2 gap-3">
              {[
                { icon: GraduationCap, t: 'Academy path' },
                { icon: BadgeCheck, t: 'Official badge' },
                { icon: Laptop, t: 'Installer portal' },
                { icon: Wrench, t: 'Field playbooks' },
              ].map(({ icon: Icon, t }) => (
                <div key={t} className="rounded-2xl border border-white/8 bg-black/30 p-4">
                  <Icon className="text-kyn-green mb-2" size={18} />
                  <p className="text-sm font-semibold">{t}</p>
                </div>
              ))}
            </div>
          </Fade>
        </div>
      </section>

      <section className="py-16 border-y border-white/5 bg-kyn-void">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <Fade><h2 className="font-display text-3xl font-bold mb-8">Benefits</h2></Fade>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {benefits.map((b, i) => (
              <Fade key={b} delay={i * 0.04}>
                <div className="rounded-2xl border border-white/8 bg-black/20 p-5 flex gap-3">
                  <CheckCircle2 className="text-kyn-green shrink-0" size={18} />
                  <p className="text-sm text-kyn-silver">{b}</p>
                </div>
              </Fade>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <Fade><h2 className="font-display text-3xl font-bold mb-10">Certification roadmap</h2></Fade>
          <div className="grid md:grid-cols-5 gap-4">
            {roadmap.map((r, i) => (
              <Fade key={r.t} delay={i * 0.05}>
                <div className="rounded-2xl border border-white/10 p-5 h-full bg-gradient-to-b from-white/[0.04] to-transparent">
                  <p className="text-kyn-green font-display text-2xl font-bold">0{i + 1}</p>
                  <p className="font-semibold mt-2">{r.t}</p>
                  <p className="text-xs text-kyn-metal mt-2">{r.d}</p>
                </div>
              </Fade>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 bg-kyn-void border-y border-white/5">
        <div className="max-w-7xl mx-auto px-5 md:px-8 grid lg:grid-cols-2 gap-8 items-center">
          <Fade>
            <h2 className="font-display text-3xl font-bold">Installer portal preview</h2>
            <p className="mt-3 text-kyn-silver">Commission chargers, upload photos, complete checklists and sync OCPP status — built for field speed.</p>
            <ul className="mt-6 space-y-2 text-sm text-kyn-silver">
              {['Job queue by territory', 'Digital handover forms', 'Spare parts requests', 'SLA timers'].map((x) => (
                <li key={x} className="flex gap-2"><CheckCircle2 size={16} className="text-kyn-green" />{x}</li>
              ))}
            </ul>
          </Fade>
          <Fade delay={0.08}>
            <div className="rounded-2xl border border-white/10 bg-kyn-black p-4 shadow-2xl">
              <div className="flex items-center justify-between mb-4 text-xs text-kyn-metal">
                <span>Portal · Jobs</span><span className="text-kyn-green">● Online</span>
              </div>
              {['NOVA install · La Marsa', 'PRIME dual · Hotel Palm', 'GO fleet · Sfax depot'].map((j, i) => (
                <div key={j} className="flex items-center justify-between rounded-xl border border-white/8 bg-white/[0.03] px-3 py-3 mb-2 text-sm">
                  <span>{j}</span>
                  <span className={cn('text-[10px] px-2 py-0.5 rounded-full', i === 0 ? 'bg-kyn-green/15 text-kyn-green' : 'bg-white/5 text-kyn-metal')}>{i === 0 ? 'Active' : 'Queued'}</span>
                </div>
              ))}
            </div>
          </Fade>
        </div>
      </section>

      <section className="py-16">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <Fade>
            <div className="rounded-3xl border border-white/10 p-6 md:p-8 bg-gradient-to-r from-kyn-green/10 to-transparent flex flex-wrap gap-6 items-center">
              <Award className="text-kyn-green" size={36} />
              <div className="flex-1 min-w-[200px]">
                <p className="font-display text-xl font-bold">Success story</p>
                <p className="text-sm text-kyn-silver mt-1">“Certification took two weeks. We now commission 12+ NOVA units monthly with Cloud-first workflows.” — Atlas Elec, Tunis</p>
              </div>
              <Link to="/success-stories" className="text-xs font-semibold text-kyn-green inline-flex items-center gap-1">All stories <ArrowRight size={12} /></Link>
            </div>
          </Fade>
        </div>
      </section>

      <section id="apply" className="py-20 border-t border-white/5">
        <div className="max-w-2xl mx-auto px-5 md:px-8">
          <Fade>
            <h2 className="font-display text-3xl font-bold mb-6">Application form</h2>
            {done ? (
              <SuccessBanner title="Application received" body="Academy team will schedule your onboarding call within 48h." />
            ) : (
              <form onSubmit={submit} className="rounded-3xl border border-white/10 bg-kyn-void p-6 md:p-8 space-y-4">
                <div className="grid sm:grid-cols-2 gap-4">
                  <Field label="Contact name"><input className={inputClass} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></Field>
                  <Field label="Email"><input type="email" className={inputClass} value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></Field>
                  <Field label="Phone"><input className={inputClass} value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></Field>
                  <Field label="Company"><input className={inputClass} value={form.company} onChange={(e) => setForm({ ...form, company: e.target.value })} /></Field>
                  <Field label="City / coverage"><input className={inputClass} value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} /></Field>
                  <Field label="Years experience"><input className={inputClass} value={form.experience} onChange={(e) => setForm({ ...form, experience: e.target.value })} /></Field>
                </div>
                <Field label="Message"><textarea className={cn(inputClass, 'min-h-[100px]')} value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} /></Field>
                {error && <p className="text-sm text-red-400">{error}</p>}
                <button disabled={loading} className="px-6 py-3 rounded-full bg-kyn-green text-kyn-black text-sm font-bold disabled:opacity-50">{loading ? 'Submitting…' : 'Submit application'}</button>
              </form>
            )}
          </Fade>
        </div>
      </section>
    </MarketingShell>
  );
}

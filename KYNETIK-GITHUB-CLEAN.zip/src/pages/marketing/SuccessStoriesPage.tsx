import { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Quote, Leaf, Zap, Building2, Home, Hotel, Store, Car } from 'lucide-react';
import MarketingShell, { Fade } from '../../components/marketing/Shell';
import LoadingState from '../../components/LoadingState';
import { apiGet, cn } from '../../lib/utils';

interface Item {
  id: number;
  type: string;
  category: string;
  title: string;
  subtitle: string;
  body: string;
  meta: string | null;
  image_url: string | null;
  sort_order: number;
}

const icons: Record<string, any> = {
  villa: Home,
  office: Building2,
  hotel: Hotel,
  retail: Store,
  fleet: Car,
};

export default function SuccessStoriesPage() {
  const [items, setItems] = useState<Item[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');
  const [active, setActive] = useState<Item | null>(null);

  useEffect(() => {
    apiGet<Item[]>('/api/marketing-content?type=story')
      .then((data) => {
        setItems(data || []);
        setActive((data && data[0]) || null);
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  const cats = useMemo(() => ['all', ...Array.from(new Set(items.map((i) => i.category).filter(Boolean)))], [items]);
  const filtered = filter === 'all' ? items : items.filter((i) => i.category === filter);

  if (loading) {
    return (
      <MarketingShell>
        <div className="min-h-[50vh] flex items-center justify-center"><LoadingState label="Loading stories…" /></div>
      </MarketingShell>
    );
  }

  return (
    <MarketingShell>
      <section className="relative pt-16 pb-10">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(0,230,118,0.1),transparent_50%)]" />
        <div className="relative z-10 max-w-7xl mx-auto px-5 md:px-8">
          <Fade>
            <p className="text-kyn-green text-xs font-semibold tracking-[0.3em] uppercase mb-4">Success stories</p>
            <h1 className="font-display text-4xl md:text-6xl font-bold max-w-3xl">Proof from the field</h1>
            <p className="mt-4 text-kyn-silver text-lg max-w-2xl">Luxury homes, workplaces, hotels, retail and fleets — measurable energy outcomes with KYNETIK hardware + Cloud.</p>
          </Fade>
          <div className="mt-8 flex flex-wrap gap-2">
            {cats.map((c) => (
              <button key={c} type="button" onClick={() => setFilter(c)} className={cn('px-3 py-1.5 rounded-full text-xs font-semibold capitalize', filter === c ? 'bg-kyn-green text-kyn-black' : 'bg-kyn-steel text-kyn-silver')}>{c}</button>
            ))}
          </div>
        </div>
      </section>

      <section className="pb-24">
        <div className="max-w-7xl mx-auto px-5 md:px-8 grid lg:grid-cols-5 gap-6">
          <div className="lg:col-span-2 space-y-3">
            {filtered.map((s) => {
              const Icon = icons[s.category] || Building2;
              return (
                <button key={s.id} type="button" onClick={() => setActive(s)} className={cn('w-full text-left rounded-2xl border p-4 transition-all', active?.id === s.id ? 'border-kyn-green/40 bg-kyn-green/10' : 'border-white/8 bg-kyn-void hover:border-white/20')}>
                  <div className="flex items-center gap-2 text-kyn-green text-[10px] uppercase tracking-wider font-semibold">
                    <Icon size={12} /> {s.category}
                  </div>
                  <p className="font-display font-semibold mt-1">{s.title}</p>
                  <p className="text-xs text-kyn-metal mt-1 line-clamp-2">{s.subtitle}</p>
                </button>
              );
            })}
            {!filtered.length && <p className="text-sm text-kyn-metal">No stories in this category yet.</p>}
          </div>

          <div className="lg:col-span-3">
            {active && (
              <Fade>
                <div className="rounded-3xl border border-white/10 overflow-hidden bg-kyn-void">
                  <div className="relative h-56 md:h-72">
                    <img src={active.image_url || '/images/hero-city.jpg'} alt="" className="w-full h-full object-cover opacity-70" />
                    <div className="absolute inset-0 bg-gradient-to-t from-kyn-void via-transparent to-transparent" />
                    <div className="absolute bottom-4 left-5 right-5">
                      <p className="text-kyn-green text-xs font-semibold uppercase tracking-wider">{active.category}</p>
                      <h2 className="font-display text-2xl md:text-3xl font-bold mt-1">{active.title}</h2>
                    </div>
                  </div>
                  <div className="p-6 md:p-8">
                    <p className="text-kyn-silver leading-relaxed">{active.body}</p>
                    {active.meta && (
                      <div className="mt-6 grid sm:grid-cols-3 gap-3">
                        {String(active.meta).split('|').map((m) => {
                          const [k, v] = m.split(':');
                          return (
                            <div key={m} className="rounded-xl border border-white/8 bg-black/30 p-4">
                              <p className="text-[10px] uppercase tracking-wider text-kyn-metal">{(k || '').trim()}</p>
                              <p className="font-display font-bold text-kyn-green mt-1">{(v || k || '').trim()}</p>
                            </div>
                          );
                        })}
                      </div>
                    )}
                    <div className="mt-8 grid sm:grid-cols-2 gap-4">
                      <div className="rounded-2xl border border-white/8 p-4">
                        <p className="text-xs text-kyn-metal uppercase tracking-wider mb-2">Before</p>
                        <p className="text-sm text-kyn-silver">Unmanaged charging, no visibility, peak overloads risk.</p>
                      </div>
                      <div className="rounded-2xl border border-kyn-green/30 bg-kyn-green/5 p-4">
                        <p className="text-xs text-kyn-green uppercase tracking-wider mb-2">After</p>
                        <p className="text-sm text-kyn-silver">Smart schedules, Cloud telemetry, guest-ready experience.</p>
                      </div>
                    </div>
                    <div className="mt-8 flex items-start gap-3 rounded-2xl bg-white/[0.03] border border-white/8 p-5">
                      <Quote className="text-kyn-green shrink-0" size={20} />
                      <div>
                        <p className="text-sm text-kyn-silver italic">{active.subtitle}</p>
                        <p className="text-xs text-kyn-metal mt-2">Verified customer feedback</p>
                      </div>
                    </div>
                    <div className="mt-6 flex flex-wrap gap-3">
                      <Link to="/quote" className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-kyn-green text-kyn-black text-xs font-bold">Start similar project <ArrowRight size={14} /></Link>
                      <span className="inline-flex items-center gap-2 text-xs text-kyn-metal"><Leaf size={14} className="text-kyn-green" /> CO₂ & energy KPIs tracked in Cloud</span>
                    </div>
                  </div>
                </div>
              </Fade>
            )}
          </div>
        </div>
      </section>
    </MarketingShell>
  );
}

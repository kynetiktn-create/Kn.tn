import { useState, FormEvent } from 'react';
import { Link } from 'react-router-dom';
import {
  Mail, Phone, MapPin, Building2, Wrench, Handshake, Send,
  Linkedin, Instagram, Facebook, Clock, ArrowRight
} from 'lucide-react';
import MarketingShell, { Fade, Field, inputClass, SuccessBanner } from '../../components/marketing/Shell';
import { apiPost, cn } from '../../lib/utils';

const intents = [
  { id: 'business', label: 'Business inquiry', icon: Building2, desc: 'Projects, fleet, enterprise' },
  { id: 'partnership', label: 'Partnership', icon: Handshake, desc: 'Strategic & OEM' },
  { id: 'installer', label: 'Become installer', icon: Wrench, desc: 'Certification path' },
  { id: 'distributor', label: 'Become distributor', icon: Send, desc: 'Territory rights' },
];

export default function ContactPage() {
  const [intent, setIntent] = useState('business');
  const [form, setForm] = useState({ name: '', email: '', phone: '', company: '', message: '' });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(false);
  const [err, setErr] = useState('');

  const set = (k: string, v: string) => setForm((f) => ({ ...f, [k]: v }));

  const validate = () => {
    const e: Record<string, string> = {};
    if (!form.name.trim()) e.name = 'Required';
    if (!form.email.includes('@')) e.email = 'Valid email required';
    if (!form.message.trim()) e.message = 'Tell us briefly how we can help';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const onSubmit = async (ev: FormEvent) => {
    ev.preventDefault();
    if (!validate()) return;
    setLoading(true);
    setErr('');
    try {
      await apiPost('/api/leads', {
        type: 'contact',
        ...form,
        subject: intents.find((i) => i.id === intent)?.label || intent,
        payload: { intent },
      });
      setDone(true);
    } catch (e: any) {
      setErr(e.message || 'Submission failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <MarketingShell>
      <section className="relative pt-16 pb-10 overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(0,230,118,0.12),transparent_55%)]" />
        <div className="absolute inset-0 grid-bg opacity-30" />
        <div className="relative z-10 max-w-7xl mx-auto px-5 md:px-8">
          <Fade>
            <p className="text-kyn-green text-xs font-semibold tracking-[0.3em] uppercase mb-4">Contact</p>
            <h1 className="font-display text-4xl md:text-6xl font-bold tracking-tight max-w-3xl">
              Let's build the next charging project together
            </h1>
            <p className="mt-5 text-kyn-silver text-lg max-w-2xl">
              Sales, partnerships, installer network or distribution — one premium team, clear response under 24h.
            </p>
          </Fade>
        </div>
      </section>

      <section className="pb-24">
        <div className="max-w-7xl mx-auto px-5 md:px-8 grid lg:grid-cols-5 gap-8">
          <div className="lg:col-span-3">
            <Fade>
              <div className="rounded-3xl border border-white/10 bg-kyn-void/80 p-6 md:p-8">
                <p className="text-xs uppercase tracking-widest text-kyn-metal mb-4">How can we help?</p>
                <div className="grid sm:grid-cols-2 gap-3 mb-8">
                  {intents.map((i) => {
                    const Icon = i.icon;
                    return (
                      <button
                        key={i.id}
                        type="button"
                        onClick={() => setIntent(i.id)}
                        className={cn(
                          'text-left rounded-2xl border p-4 transition-all',
                          intent === i.id
                            ? 'border-kyn-green/40 bg-kyn-green/10'
                            : 'border-white/8 bg-black/20 hover:border-white/20'
                        )}
                      >
                        <Icon size={18} className={intent === i.id ? 'text-kyn-green' : 'text-kyn-metal'} />
                        <p className="mt-2 font-semibold text-sm">{i.label}</p>
                        <p className="text-[11px] text-kyn-metal mt-0.5">{i.desc}</p>
                      </button>
                    );
                  })}
                </div>

                {done ? (
                  <SuccessBanner
                    title="Message received"
                    body="A KYNETIK specialist will contact you shortly. For urgent installs, call +216 71 000 000."
                  />
                ) : (
                  <form onSubmit={onSubmit} className="space-y-4">
                    <div className="grid sm:grid-cols-2 gap-4">
                      <Field label="Full name" error={errors.name}>
                        <input className={inputClass} value={form.name} onChange={(e) => set('name', e.target.value)} placeholder="Khalifa Ben Ali" />
                      </Field>
                      <Field label="Email" error={errors.email}>
                        <input className={inputClass} type="email" value={form.email} onChange={(e) => set('email', e.target.value)} placeholder="you@company.com" />
                      </Field>
                      <Field label="Phone">
                        <input className={inputClass} value={form.phone} onChange={(e) => set('phone', e.target.value)} placeholder="+216 …" />
                      </Field>
                      <Field label="Company">
                        <input className={inputClass} value={form.company} onChange={(e) => set('company', e.target.value)} placeholder="Company name" />
                      </Field>
                    </div>
                    <Field label="Message" error={errors.message}>
                      <textarea className={cn(inputClass, 'min-h-[120px] resize-y')} value={form.message} onChange={(e) => set('message', e.target.value)} placeholder="Project size, location, timeline…" />
                    </Field>
                    {err && <p className="text-sm text-red-400">{err}</p>}
                    <button
                      type="submit"
                      disabled={loading}
                      className="inline-flex items-center gap-2 px-6 py-3.5 rounded-full bg-kyn-green text-kyn-black text-sm font-bold hover:bg-kyn-green-glow disabled:opacity-60"
                    >
                      {loading ? 'Sending…' : 'Send message'} <ArrowRight size={16} />
                    </button>
                  </form>
                )}
              </div>
            </Fade>
          </div>

          <div className="lg:col-span-2 space-y-4">
            <Fade delay={0.05}>
              <div className="rounded-3xl border border-white/10 bg-gradient-to-b from-kyn-steel/40 to-kyn-void p-6 space-y-4">
                {[
                  { icon: MapPin, t: 'HQ Tunis', d: 'Les Berges du Lac 2, Tunis, Tunisia' },
                  { icon: Mail, t: 'Email', d: 'hello@kynetik.tn · sales@kynetik.tn' },
                  { icon: Phone, t: 'Phone', d: '+216 71 000 000' },
                  { icon: Clock, t: 'Hours', d: 'Mon–Fri · 09:00–18:00 CET' },
                ].map(({ icon: Icon, t, d }) => (
                  <div key={t} className="flex gap-3">
                    <div className="w-10 h-10 rounded-xl bg-kyn-green/10 border border-kyn-green/20 flex items-center justify-center text-kyn-green shrink-0">
                      <Icon size={16} />
                    </div>
                    <div>
                      <p className="text-sm font-semibold">{t}</p>
                      <p className="text-xs text-kyn-metal mt-0.5">{d}</p>
                    </div>
                  </div>
                ))}
                <div className="flex gap-2 pt-2">
                  {[Linkedin, Instagram, Facebook].map((Icon, i) => (
                    <a key={i} href="#" className="w-9 h-9 rounded-full border border-white/10 flex items-center justify-center text-kyn-metal hover:text-kyn-green">
                      <Icon size={14} />
                    </a>
                  ))}
                </div>
              </div>
            </Fade>

            <Fade delay={0.1}>
              <div className="rounded-3xl border border-white/10 overflow-hidden h-56 bg-[#0d1110] relative">
                <div
                  className="absolute inset-0 opacity-50"
                  style={{
                    backgroundImage:
                      'linear-gradient(rgba(0,230,118,0.08) 1px, transparent 1px), linear-gradient(90deg, rgba(0,230,118,0.08) 1px, transparent 1px)',
                    backgroundSize: '28px 28px',
                  }}
                />
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
                  <div className="w-10 h-10 rounded-full bg-kyn-green/20 border-2 border-kyn-green flex items-center justify-center animate-pulse">
                    <MapPin size={16} className="text-kyn-green" />
                  </div>
                </div>
                <div className="absolute bottom-3 left-3 right-3 rounded-xl bg-kyn-void/90 border border-white/10 px-3 py-2 text-xs">
                  <p className="font-semibold">KYNETIK HQ · Lac 2</p>
                  <p className="text-kyn-metal">Interactive map placeholder · Tunis</p>
                </div>
              </div>
            </Fade>

            <Fade delay={0.15}>
              <div className="grid grid-cols-2 gap-3">
                {[
                  { to: '/quote', l: 'Request quote' },
                  { to: '/installers', l: 'Installers' },
                  { to: '/distributors', l: 'Distributors' },
                  { to: '/support', l: 'Support' },
                ].map((x) => (
                  <Link key={x.to} to={x.to} className="rounded-xl border border-white/10 bg-black/30 px-3 py-3 text-xs font-semibold text-center hover:border-kyn-green/40 hover:text-kyn-green transition-colors">
                    {x.l}
                  </Link>
                ))}
              </div>
            </Fade>
          </div>
        </div>
      </section>
    </MarketingShell>
  );
}

import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import {
  Cloud as CloudIcon, Activity, Server, Shield, Zap, AlertTriangle,
  CheckCircle2, Radio, Settings2, Users
} from 'lucide-react';
import SectionHeader from '../components/SectionHeader';
import LoadingState from '../components/LoadingState';
import ErrorState from '../components/ErrorState';
import Logo from '../components/Logo';
import { apiGet, cn } from '../lib/utils';

interface Metric {
  id: number;
  label: string;
  value: string;
  delta: string;
  category: string;
  sort_order: number;
}

interface Asset {
  id: number;
  title: string;
  category: string;
  description: string;
  meta: string | null;
}

export default function Cloud() {
  const [metrics, setMetrics] = useState<Metric[]>([]);
  const [assets, setAssets] = useState<Asset[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [tab, setTab] = useState<'overview' | 'stations' | 'sessions' | 'alerts'>('overview');

  useEffect(() => {
    Promise.all([
      apiGet<Metric[]>('/api/cloud-metrics'),
      apiGet<Asset[]>('/api/design-assets?category=cloud'),
    ])
      .then(([m, a]) => {
        setMetrics(m);
        setAssets(a);
      })
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <div className="p-10"><LoadingState label="Loading Cloud dashboard…" /></div>;
  if (error) return <div className="p-10"><ErrorState message={error} /></div>;

  const stations = [
    { name: 'Hub Lac 2', type: 'PRIME 120kW', status: 'online', load: 72 },
    { name: 'NOVA Marsa', type: 'NOVA 22kW', status: 'charging', load: 48 },
    { name: 'Depot Sfax', type: 'PRO 180kW', status: 'online', load: 31 },
    { name: 'Hotel Palm', type: 'NOVA 22kW', status: 'offline', load: 0 },
    { name: 'Fleet GO-03', type: 'GO 11kW', status: 'charging', load: 64 },
  ];

  return (
    <div className="max-w-6xl mx-auto px-6 md:px-10 py-12 md:py-16">
      <SectionHeader
        eyebrow="UI/UX · KYNETIK Cloud"
        title="Operator dashboard"
        description="Premium OCPP control center — live metrics, station fleet, sessions and alerts with the same black / electric green system language."
      />

      {/* Dashboard chrome */}
      <div className="rounded-2xl border border-white/10 overflow-hidden poster-shadow bg-kyn-void">
        <div className="flex flex-wrap items-center justify-between gap-3 px-5 py-4 border-b border-white/5 bg-kyn-charcoal">
          <div className="flex items-center gap-3">
            <Logo size="sm" glowing />
            <div className="h-6 w-px bg-white/10" />
            <span className="text-xs text-kyn-silver font-medium flex items-center gap-1.5">
              <CloudIcon size={13} className="text-kyn-green" /> Cloud Console
            </span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-[10px] text-kyn-green bg-kyn-green/10 px-2 py-1 rounded-full flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-kyn-green animate-pulse-glow" /> Live
            </span>
            <button type="button" className="p-2 rounded-lg bg-white/5 text-kyn-metal"><Users size={14} /></button>
            <button type="button" className="p-2 rounded-lg bg-white/5 text-kyn-metal"><Settings2 size={14} /></button>
          </div>
        </div>

        <div className="flex border-b border-white/5 overflow-x-auto">
          {([
            ['overview', 'Overview'],
            ['stations', 'Stations'],
            ['sessions', 'Sessions'],
            ['alerts', 'Alerts'],
          ] as const).map(([id, label]) => (
            <button
              key={id}
              type="button"
              onClick={() => setTab(id)}
              className={cn(
                'px-5 py-3 text-xs font-semibold border-b-2 -mb-px transition-colors',
                tab === id ? 'border-kyn-green text-kyn-green' : 'border-transparent text-kyn-metal hover:text-white'
              )}
            >
              {label}
            </button>
          ))}
        </div>

        <div className="p-5 md:p-8">
          {tab === 'overview' && (
            <>
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-6">
                {metrics.map((m, i) => (
                  <motion.div
                    key={m.id}
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.05 }}
                    className="rounded-2xl border border-white/8 bg-kyn-steel/40 p-4"
                  >
                    <p className="text-[10px] text-kyn-metal uppercase tracking-wider">{m.label}</p>
                    <p className="font-display text-2xl font-bold mt-1 text-white">{m.value}</p>
                    <p className={cn('text-[11px] mt-1', m.delta.startsWith('-') && !m.label.includes('CO') ? 'text-red-400' : 'text-kyn-green')}>
                      {m.delta}
                    </p>
                  </motion.div>
                ))}
              </div>

              <div className="grid lg:grid-cols-3 gap-4">
                <div className="lg:col-span-2 rounded-2xl border border-white/8 bg-kyn-charcoal/80 p-5">
                  <div className="flex justify-between mb-4">
                    <p className="text-sm font-semibold">Energy throughput (24h)</p>
                    <Activity size={14} className="text-kyn-green" />
                  </div>
                  <div className="h-40 flex items-end gap-1.5">
                    {[35, 42, 38, 55, 48, 62, 70, 58, 75, 68, 82, 90, 78, 85, 72, 88, 95, 80, 70, 65, 58, 52, 45, 40].map((h, i) => (
                      <div key={i} className="flex-1 rounded-t bg-gradient-to-t from-kyn-green/30 to-kyn-green" style={{ height: `${h}%` }} />
                    ))}
                  </div>
                </div>
                <div className="rounded-2xl border border-white/8 bg-kyn-charcoal/80 p-5">
                  <p className="text-sm font-semibold mb-4">System health</p>
                  <div className="space-y-3">
                    {[
                      { icon: Server, l: 'API gateway', s: 'Operational' },
                      { icon: Radio, l: 'OCPP broker', s: 'Operational' },
                      { icon: Shield, l: 'Security', s: 'Protected' },
                      { icon: Zap, l: 'Smart load', s: 'Balancing' },
                    ].map(({ icon: Icon, l, s }) => (
                      <div key={l} className="flex items-center justify-between">
                        <div className="flex items-center gap-2 text-xs text-kyn-silver">
                          <Icon size={13} className="text-kyn-green" /> {l}
                        </div>
                        <span className="text-[10px] text-kyn-green">{s}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </>
          )}

          {tab === 'stations' && (
            <div className="space-y-2">
              {stations.map((s) => (
                <div key={s.name} className="flex flex-wrap items-center gap-4 rounded-xl border border-white/8 bg-kyn-steel/30 px-4 py-3">
                  <div className="flex-1 min-w-[140px]">
                    <p className="font-semibold text-sm">{s.name}</p>
                    <p className="text-[10px] text-kyn-metal">{s.type}</p>
                  </div>
                  <span className={cn(
                    'text-[10px] px-2 py-1 rounded-full capitalize',
                    s.status === 'offline' ? 'bg-white/5 text-kyn-metal' :
                    s.status === 'charging' ? 'bg-kyn-green/15 text-kyn-green' : 'bg-emerald-500/10 text-emerald-400'
                  )}>
                    {s.status}
                  </span>
                  <div className="w-28">
                    <div className="h-1.5 rounded-full bg-white/10 overflow-hidden">
                      <div className="h-full bg-kyn-green rounded-full" style={{ width: `${s.load}%` }} />
                    </div>
                    <p className="text-[9px] text-kyn-metal mt-1">{s.load}% load</p>
                  </div>
                </div>
              ))}
            </div>
          )}

          {tab === 'sessions' && (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="text-kyn-metal border-b border-white/5">
                  <tr>
                    <th className="pb-3 font-medium">Session</th>
                    <th className="pb-3 font-medium">Station</th>
                    <th className="pb-3 font-medium">Energy</th>
                    <th className="pb-3 font-medium">Duration</th>
                    <th className="pb-3 font-medium">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {[
                    ['#K-88421', 'Hub Lac 2', '34.2 kWh', '48 min', 'Active'],
                    ['#K-88418', 'NOVA Marsa', '12.8 kWh', '1h 12m', 'Active'],
                    ['#K-88402', 'Depot Sfax', '86.0 kWh', '2h 05m', 'Completed'],
                    ['#K-88391', 'Hotel Palm', '8.4 kWh', '38 min', 'Completed'],
                  ].map((row) => (
                    <tr key={row[0]} className="text-kyn-silver">
                      {row.map((cell, i) => (
                        <td key={i} className={cn('py-3', i === 4 && cell === 'Active' && 'text-kyn-green')}>
                          {cell}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {tab === 'alerts' && (
            <div className="space-y-3">
              {[
                { level: 'warn', t: 'Hotel Palm offline > 2h', d: 'Check connectivity / breaker' },
                { level: 'info', t: 'Firmware 2.4.1 available', d: '12 stations eligible for OTA' },
                { level: 'ok', t: 'Load balance OK — Lac corridor', d: 'Peak shaved 14% this hour' },
              ].map((a) => (
                <div key={a.t} className="flex gap-3 rounded-xl border border-white/8 bg-kyn-steel/30 p-4">
                  {a.level === 'warn' ? <AlertTriangle className="text-amber-400 shrink-0" size={16} /> :
                   a.level === 'ok' ? <CheckCircle2 className="text-kyn-green shrink-0" size={16} /> :
                   <Activity className="text-sky-400 shrink-0" size={16} />}
                  <div>
                    <p className="text-sm font-medium">{a.t}</p>
                    <p className="text-xs text-kyn-metal mt-0.5">{a.d}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="mt-10 grid md:grid-cols-3 gap-4">
        {assets.map((a) => (
          <div key={a.id} className="glass-card rounded-2xl p-6">
            <h3 className="font-display font-semibold">{a.title}</h3>
            <p className="text-sm text-kyn-metal mt-2">{a.description}</p>
            {a.meta && <p className="mt-3 text-xs font-mono text-kyn-green">{a.meta}</p>}
          </div>
        ))}
      </div>
    </div>
  );
}

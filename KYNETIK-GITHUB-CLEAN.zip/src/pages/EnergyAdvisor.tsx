import { useEffect, useMemo, useState, type ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  ArrowLeft, ArrowRight, Brain, Sun, Moon, Clock, Leaf, Zap, Wallet,
  TrendingDown, Sparkles, CheckCircle2, AlertTriangle, Activity,
  BatteryCharging, CloudSun, Gauge, ShieldAlert, RefreshCw, Target,
} from 'lucide-react';
import BrandLogo from '../components/BrandLogo';
import LoadingState from '../components/LoadingState';
import ErrorState from '../components/ErrorState';
import { apiGet, cn } from '../lib/utils';

interface AdvisorItem {
  id: number;
  type: string;
  title: string;
  subtitle: string;
  body: string;
  value: string;
  meta: string | null;
  priority: string | null;
  sort_order: number;
}

function priorityTone(p?: string | null) {
  const s = (p || '').toLowerCase();
  if (s === 'critical' || s === 'high') return 'text-amber-300 border-amber-400/30 bg-amber-400/10';
  if (s === 'success' || s === 'best' || s === 'solar') return 'text-kyn-green border-kyn-green/30 bg-kyn-green/10';
  if (s === 'warning' || s === 'avoid' || s === 'medium') return 'text-orange-300 border-orange-400/30 bg-orange-400/10';
  return 'text-sky-300 border-sky-400/25 bg-sky-400/10';
}

function Glass({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <div className={cn('rounded-2xl border border-white/10 bg-white/[0.03] backdrop-blur-sm', className)}>
      {children}
    </div>
  );
}

function SectionTitle({ eyebrow, title, description }: { eyebrow: string; title: string; description?: string }) {
  return (
    <div className="mb-6">
      <p className="text-kyn-green text-[11px] font-semibold tracking-[0.28em] uppercase mb-2">{eyebrow}</p>
      <h2 className="font-display text-2xl md:text-3xl font-bold">{title}</h2>
      {description && <p className="mt-2 text-sm text-kyn-metal max-w-2xl leading-relaxed">{description}</p>}
    </div>
  );
}

export default function EnergyAdvisor() {
  const [items, setItems] = useState<AdvisorItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [applied, setApplied] = useState<Record<number, boolean>>({});
  const [refreshing, setRefreshing] = useState(false);

  const load = async () => {
    try {
      const data = await apiGet<AdvisorItem[]>('/api/ai-insights?source=energy');
      setItems(Array.isArray(data) ? data : []);
      setError('');
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to load energy advisor');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  const byType = (t: string) => items.filter((i) => i.type === t).sort((a, b) => a.sort_order - b.sort_order);

  const kpis = byType('kpi');
  const analysis = byType('analysis');
  const schedule = byType('schedule');
  const costs = byType('cost');
  const solar = byType('solar');
  const savings = byType('savings');
  const recommendations = byType('recommendation');

  const maxSave = useMemo(() => Math.max(1, ...savings.map((s) => Number(s.value) || 0)), [savings]);
  const totalProjected = useMemo(
    () => savings.reduce((acc, s) => acc + (Number(s.value) || 0), 0),
    [savings]
  );

  const hourBars = [
    { h: '18', v: 88, band: 'peak' },
    { h: '19', v: 95, band: 'peak' },
    { h: '20', v: 90, band: 'peak' },
    { h: '21', v: 70, band: 'shoulder' },
    { h: '22', v: 48, band: 'shoulder' },
    { h: '23', v: 36, band: 'ok' },
    { h: '00', v: 28, band: 'best' },
    { h: '01', v: 22, band: 'best' },
    { h: '02', v: 20, band: 'best' },
    { h: '03', v: 18, band: 'best' },
    { h: '04', v: 21, band: 'best' },
    { h: '05', v: 26, band: 'best' },
    { h: '12', v: 34, band: 'solar' },
    { h: '13', v: 30, band: 'solar' },
    { h: '14', v: 32, band: 'solar' },
    { h: '15', v: 38, band: 'solar' },
  ];

  if (loading) {
    return (
      <div className="min-h-screen bg-kyn-black flex items-center justify-center">
        <LoadingState label="Loading AI Energy Advisor…" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-kyn-black flex items-center justify-center p-8">
        <ErrorState message={error} />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-kyn-black text-white">
      <div className="pointer-events-none fixed inset-0">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(0,230,118,0.12),transparent_45%)]" />
        <div className="absolute inset-0 grid-bg opacity-30" />
      </div>

      <header className="sticky top-0 z-40 border-b border-white/5 bg-kyn-black/80 backdrop-blur-xl">
        <div className="max-w-7xl mx-auto px-5 md:px-8 h-16 flex items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <Link to="/ai" className="text-kyn-metal hover:text-white transition-colors">
              <ArrowLeft size={18} />
            </Link>
            <BrandLogo height={28} />
            <span className="hidden sm:inline text-[10px] tracking-[0.22em] uppercase text-kyn-green border border-kyn-green/30 rounded-full px-2.5 py-1">
              AI Energy Advisor
            </span>
          </div>
          <button
            type="button"
            onClick={() => {
              setRefreshing(true);
              load();
            }}
            className="inline-flex items-center gap-2 px-3 py-2 rounded-full border border-white/10 text-xs text-kyn-silver hover:border-kyn-green/40 hover:text-white"
          >
            <RefreshCw size={13} className={refreshing ? 'animate-spin' : ''} /> Refresh
          </button>
        </div>
      </header>

      <main className="relative z-10 max-w-7xl mx-auto px-5 md:px-8 py-10 md:py-14">
        {/* Hero */}
        <section className="mb-12 md:mb-16">
          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}>
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-kyn-green/30 bg-kyn-green/10 text-kyn-green text-[11px] font-semibold mb-5">
              <Brain size={13} /> Personal energy intelligence
            </div>
            <h1 className="font-display text-4xl md:text-5xl font-bold tracking-tight leading-[1.08] max-w-3xl">
              AI Energy Advisor
              <span className="block text-kyn-green text-glow mt-1">Charge smarter. Spend less.</span>
            </h1>
            <p className="mt-5 text-kyn-silver max-w-2xl leading-relaxed">
              Real-time analysis of your sessions, tariffs, and solar forecast — with actionable schedules that plug into KYNETIK Cloud and your NOVA / PRIME chargers.
            </p>
          </motion.div>

          <div className="mt-8 grid grid-cols-2 lg:grid-cols-4 gap-3">
            {kpis.map((k, i) => (
              <motion.div
                key={k.id}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
              >
                <Glass className="p-4 md:p-5 h-full">
                  <p className="text-[10px] uppercase tracking-wider text-kyn-metal">{k.title}</p>
                  <p className="font-display text-2xl md:text-3xl font-bold mt-2 text-white">{k.value}</p>
                  <p className="text-xs text-kyn-green mt-1">{k.meta}</p>
                  <p className="text-[11px] text-kyn-metal mt-2 line-clamp-2">{k.subtitle}</p>
                </Glass>
              </motion.div>
            ))}
          </div>
        </section>

        {/* Energy Analysis */}
        <section className="mb-14">
          <SectionTitle
            eyebrow="01 · Energy Analysis"
            title="What is driving your bill"
            description="AI breaks down load pressure, session habits, tariff alignment and weather-aware opportunities."
          />
          <div className="grid md:grid-cols-2 gap-3">
            {analysis.map((a, i) => (
              <motion.div
                key={a.id}
                initial={{ opacity: 0, y: 10 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.04 }}
              >
                <Glass className="p-5 h-full">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <p className="font-display font-semibold text-lg">{a.title}</p>
                      <p className="text-xs text-kyn-metal mt-1">{a.subtitle}</p>
                    </div>
                    <span className={cn('text-[10px] font-semibold px-2.5 py-1 rounded-full border', priorityTone(a.priority))}>
                      {a.value}
                    </span>
                  </div>
                  <p className="mt-3 text-sm text-kyn-silver leading-relaxed">{a.body}</p>
                </Glass>
              </motion.div>
            ))}
          </div>
        </section>

        {/* Best Charging Time */}
        <section className="mb-14">
          <SectionTitle
            eyebrow="02 · Best Charging Time"
            title="When to plug in"
            description="Price bands and renewable intensity across the next cycle — deep night wins, solar midday is the runner-up."
          />
          <div className="grid lg:grid-cols-[1.2fr_0.8fr] gap-4">
            <Glass className="p-5 md:p-6">
              <div className="flex items-center justify-between mb-5">
                <p className="text-sm font-semibold text-kyn-silver">Grid price intensity</p>
                <div className="flex gap-3 text-[10px] text-kyn-metal">
                  <span className="inline-flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-red-400" /> Peak</span>
                  <span className="inline-flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-kyn-green" /> Best</span>
                  <span className="inline-flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-amber-300" /> Solar</span>
                </div>
              </div>
              <div className="h-44 flex items-end gap-1.5 md:gap-2">
                {hourBars.map((b) => (
                  <div key={b.h} className="flex-1 flex flex-col items-center gap-2">
                    <div
                      className={cn(
                        'w-full rounded-t-md min-h-[8px]',
                        b.band === 'peak' && 'bg-gradient-to-t from-red-500/30 to-red-400',
                        b.band === 'best' && 'bg-gradient-to-t from-kyn-green/30 to-kyn-green',
                        b.band === 'solar' && 'bg-gradient-to-t from-amber-500/30 to-amber-300',
                        b.band === 'shoulder' && 'bg-gradient-to-t from-white/10 to-white/40',
                        b.band === 'ok' && 'bg-gradient-to-t from-sky-500/20 to-sky-300/80'
                      )}
                      style={{ height: `${b.v}%` }}
                    />
                    <span className="text-[9px] text-kyn-metal">{b.h}</span>
                  </div>
                ))}
              </div>
            </Glass>

            <div className="space-y-3">
              {schedule.map((s) => (
                <Glass key={s.id} className="p-4">
                  <div className="flex items-start gap-3">
                    <div className={cn('mt-0.5 w-9 h-9 rounded-xl border flex items-center justify-center shrink-0', priorityTone(s.meta || s.priority))}>
                      {s.meta === 'solar' ? <Sun size={15} /> : s.meta === 'avoid' ? <ShieldAlert size={15} /> : s.meta === 'best' ? <Moon size={15} /> : <Clock size={15} />}
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <p className="font-semibold text-sm">{s.title}</p>
                          <p className="text-[11px] text-kyn-metal">{s.subtitle}</p>
                        </div>
                        <span className="text-xs font-bold text-kyn-green whitespace-nowrap">{s.value}</span>
                      </div>
                      <p className="text-xs text-kyn-silver mt-2 leading-relaxed">{s.body}</p>
                    </div>
                  </div>
                </Glass>
              ))}
            </div>
          </div>
        </section>

        {/* Cost Optimization */}
        <section className="mb-14">
          <SectionTitle
            eyebrow="03 · Cost Optimization"
            title="Levers that move the invoice"
            description="Stackable tactics — schedule automation, SoC targets, panel load balance, workplace mix."
          />
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {costs.map((c, i) => (
              <motion.div
                key={c.id}
                initial={{ opacity: 0, y: 10 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.05 }}
              >
                <Glass className="p-5 h-full relative overflow-hidden">
                  <div className="absolute -right-4 -top-4 w-20 h-20 rounded-full bg-kyn-green/10 blur-2xl" />
                  <Wallet size={16} className="text-kyn-green mb-3" />
                  <p className="font-display text-2xl font-bold text-kyn-green text-glow">{c.value}</p>
                  <p className="font-semibold mt-2 text-sm">{c.title}</p>
                  <p className="text-[11px] text-kyn-metal mt-1">{c.meta}</p>
                  <p className="text-xs text-kyn-silver mt-3 leading-relaxed">{c.body}</p>
                </Glass>
              </motion.div>
            ))}
          </div>
        </section>

        {/* Solar Integration */}
        <section className="mb-14">
          <SectionTitle
            eyebrow="04 · Solar Integration"
            title="PV-aware charging"
            description="When the roof produces, the car should absorb — not the grid export meter."
          />
          <div className="grid lg:grid-cols-2 gap-4">
            <Glass className="p-6 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-amber-400/10 via-transparent to-kyn-green/10" />
              <div className="relative z-10">
                <div className="flex items-center gap-2 text-amber-300 text-xs font-semibold uppercase tracking-wider mb-4">
                  <CloudSun size={16} /> Live solar posture
                </div>
                <div className="grid grid-cols-2 gap-3 mb-6">
                  {[
                    { l: 'PV today', v: '18.6 kWh', i: Sun },
                    { l: 'EV absorbable', v: '14.0 kWh', i: BatteryCharging },
                    { l: 'Self-use target', v: '34%', i: Target },
                    { l: 'Grid import risk', v: 'Low', i: Gauge },
                  ].map(({ l, v, i: Icon }) => (
                    <div key={l} className="rounded-xl border border-white/10 bg-black/30 p-3">
                      <Icon size={14} className="text-amber-300 mb-2" />
                      <p className="text-[10px] text-kyn-metal uppercase tracking-wider">{l}</p>
                      <p className="font-display font-bold text-lg mt-1">{v}</p>
                    </div>
                  ))}
                </div>
                <div className="h-24 flex items-end gap-1">
                  {[20, 35, 55, 78, 92, 100, 96, 88, 70, 48, 30, 18].map((h, idx) => (
                    <div
                      key={idx}
                      className="flex-1 rounded-t bg-gradient-to-t from-amber-500/20 to-amber-300"
                      style={{ height: `${h}%`, opacity: 0.45 + h / 200 }}
                    />
                  ))}
                </div>
                <p className="text-[10px] text-kyn-metal mt-2">Hourly PV curve · today</p>
              </div>
            </Glass>

            <div className="space-y-3">
              {solar.map((s) => (
                <Glass key={s.id} className="p-4 flex gap-3">
                  <div className="w-10 h-10 rounded-xl bg-amber-400/10 border border-amber-300/25 flex items-center justify-center text-amber-300 shrink-0">
                    <Sun size={16} />
                  </div>
                  <div>
                    <div className="flex flex-wrap items-center gap-2">
                      <p className="font-semibold text-sm">{s.title}</p>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-kyn-green/10 text-kyn-green border border-kyn-green/20">
                        {s.value}
                      </span>
                    </div>
                    <p className="text-[11px] text-kyn-metal mt-0.5">{s.subtitle}</p>
                    <p className="text-xs text-kyn-silver mt-2 leading-relaxed">{s.body}</p>
                  </div>
                </Glass>
              ))}
            </div>
          </div>
        </section>

        {/* Savings Chart */}
        <section className="mb-14">
          <SectionTitle
            eyebrow="05 · Savings Chart"
            title="AI impact over 6 weeks"
            description="Weekly savings in DT after enabling advisor schedules versus unoptimized charging."
          />
          <Glass className="p-5 md:p-8">
            <div className="flex flex-wrap items-end justify-between gap-4 mb-8">
              <div>
                <p className="text-[10px] uppercase tracking-wider text-kyn-metal">Projected cumulative</p>
                <p className="font-display text-3xl md:text-4xl font-bold text-kyn-green text-glow mt-1">
                  {totalProjected.toFixed(0)} DT
                </p>
              </div>
              <div className="inline-flex items-center gap-2 text-xs text-kyn-silver">
                <TrendingDown size={14} className="text-kyn-green" /> Bill trajectory improving
              </div>
            </div>
            <div className="h-56 flex items-end gap-3 md:gap-4">
              {savings.map((s, i) => {
                const val = Number(s.value) || 0;
                const h = (val / maxSave) * 100;
                return (
                  <motion.div
                    key={s.id}
                    className="flex-1 flex flex-col items-center gap-2"
                    initial={{ opacity: 0, scaleY: 0.6 }}
                    whileInView={{ opacity: 1, scaleY: 1 }}
                    viewport={{ once: true }}
                    transition={{ delay: i * 0.06 }}
                    style={{ originY: 1 }}
                  >
                    <span className="text-[11px] font-semibold text-kyn-green">{val} DT</span>
                    <div className="w-full max-w-[64px] rounded-t-xl bg-gradient-to-t from-kyn-green/20 via-kyn-green/70 to-kyn-green relative" style={{ height: `${Math.max(h, 8)}%` }}>
                      <div className="absolute inset-x-0 top-0 h-1 rounded-full bg-white/30" />
                    </div>
                    <span className="text-[10px] text-kyn-metal text-center">{s.title}</span>
                  </motion.div>
                );
              })}
            </div>
          </Glass>
        </section>

        {/* AI Recommendations */}
        <section className="mb-10">
          <SectionTitle
            eyebrow="06 · AI Recommendations"
            title="Actions ready to apply"
            description="One-tap intents for Cloud schedules, SoC targets and peak shields."
          />
          <div className="space-y-3">
            {recommendations.map((r, i) => {
              const done = !!applied[r.id];
              return (
                <motion.div
                  key={r.id}
                  initial={{ opacity: 0, x: -8 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.04 }}
                >
                  <Glass className="p-4 md:p-5">
                    <div className="flex flex-col md:flex-row md:items-center gap-4">
                      <div className="flex items-start gap-3 flex-1 min-w-0">
                        <div className={cn('w-10 h-10 rounded-xl border flex items-center justify-center shrink-0', priorityTone(r.priority))}>
                          {done ? <CheckCircle2 size={16} /> : r.priority === 'high' ? <Sparkles size={16} /> : <Activity size={16} />}
                        </div>
                        <div className="min-w-0">
                          <div className="flex flex-wrap items-center gap-2">
                            <p className="font-display font-semibold">{r.title}</p>
                            <span className={cn('text-[10px] px-2 py-0.5 rounded-full border capitalize', priorityTone(r.priority))}>
                              {r.priority || 'info'}
                            </span>
                          </div>
                          <p className="text-[11px] text-kyn-metal mt-0.5">{r.subtitle}</p>
                          <p className="text-sm text-kyn-silver mt-2 leading-relaxed">{r.body}</p>
                          <p className="text-xs text-kyn-green font-semibold mt-2">{r.value}</p>
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => setApplied((prev) => ({ ...prev, [r.id]: !prev[r.id] }))}
                        className={cn(
                          'shrink-0 inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-full text-xs font-bold transition-colors',
                          done
                            ? 'bg-kyn-green/15 text-kyn-green border border-kyn-green/30'
                            : 'bg-kyn-green text-kyn-black hover:bg-kyn-green-glow'
                        )}
                      >
                        {done ? (
                          <>
                            <CheckCircle2 size={14} /> Applied
                          </>
                        ) : (
                          <>
                            {r.meta || 'Apply'} <ArrowRight size={13} />
                          </>
                        )}
                      </button>
                    </div>
                  </Glass>
                </motion.div>
              );
            })}
          </div>
        </section>

        <Glass className="p-6 md:p-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <p className="font-display text-xl font-bold">Push advisor rules to KYNETIK Cloud</p>
            <p className="text-sm text-kyn-metal mt-1">Schedules sync to NOVA / PRIME and appear in the mobile charging timeline.</p>
          </div>
          <div className="flex flex-wrap gap-2">
            <Link
              to="/console"
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-kyn-green text-kyn-black text-xs font-bold"
            >
              Open Cloud Console <ArrowRight size={13} />
            </Link>
            <Link
              to="/ai"
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full border border-white/15 text-xs font-medium text-kyn-silver hover:text-white"
            >
              AI Dashboard
            </Link>
          </div>
        </Glass>
      </main>

      <footer className="relative z-10 border-t border-white/5 py-8">
        <div className="max-w-7xl mx-auto px-5 md:px-8 flex flex-wrap items-center justify-between gap-3">
          <BrandLogo height={24} />
          <p className="text-[11px] text-kyn-metal">KYNETIK AI Energy Advisor · Tariff · Solar · Savings</p>
        </div>
      </footer>
    </div>
  );
}

import { motion } from 'framer-motion';
import { Check, Copy, Download } from 'lucide-react';
import { useState } from 'react';
import SectionHeader from '../components/SectionHeader';
import Logo from '../components/Logo';
import BrandLogo from '../components/BrandLogo';

const palette = [
  { name: 'Electric Green', hex: '#00E676', role: 'Primary accent · CTAs · charging status · LED' },
  { name: 'Green Glow', hex: '#39FF14', role: 'Energy pulse · focus · active charge' },
  { name: 'Deep Black', hex: '#050505', role: 'Primary background · premium void' },
  { name: 'Void', hex: '#0A0A0B', role: 'Elevated panels · sidebars' },
  { name: 'Graphite', hex: '#2A2A30', role: 'Borders · chips · secondary surfaces' },
  { name: 'Silver', hex: '#C8C8D0', role: 'Secondary text · metal details' },
  { name: 'White', hex: '#F5F5F7', role: 'Primary typography · logo on dark' },
  { name: 'Steel', hex: '#1A1A1E', role: 'Cards · inputs · glass base' },
];

const logoRules = [
  'Green bolt mark is the primary brand symbol — keep electric green #00E676',
  'Clear space = height of the bolt icon on all sides',
  'Minimum digital height: 24px (mark) / 28px (full lockup)',
  'White wordmark + green bolt on black / charcoal surfaces',
  'Dark wordmark + green bolt on light / print surfaces',
  'Never recolor the bolt (no blue, gold, or gradient fills)',
  'Do not stretch, rotate, or separate bolt from wordmark in marketing lockups',
  'On tight UI (app icon, favicon, splash): use bolt mark only',
];

const downloads = [
  { href: '/images/brand/dna-master-white.png', label: 'DNA master · white' },
  { href: '/images/brand/dna-master-dark.png', label: 'DNA master · dark' },
  { href: '/images/brand/dna-master-white-glow.png', label: 'DNA master · white glow' },
  { href: '/images/brand/dna-master-dark-glow.png', label: 'DNA master · dark glow' },
  { href: '/images/kynetik-logo-white.png', label: 'UI lockup white (transparent)' },
  { href: '/images/kynetik-logo-dark.png', label: 'UI lockup dark (transparent)' },
  { href: '/images/kynetik-mark-white.png', label: 'Monogram white' },
  { href: '/images/kynetik-mark-dark.png', label: 'Monogram dark' },
];

function Swatch({ name, hex, role }: { name: string; hex: string; role: string }) {
  const [ok, setOk] = useState(false);
  return (
    <button
      type="button"
      onClick={() => {
        navigator.clipboard?.writeText(hex).catch(() => undefined);
        setOk(true);
        setTimeout(() => setOk(false), 1200);
      }}
      className="glass-card rounded-2xl overflow-hidden text-left group hover:border-kyn-green/30 transition-colors"
    >
      <div className="h-16 relative" style={{ background: hex }}>
        <span className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity text-black/50">
          {ok ? <Check size={14} /> : <Copy size={14} />}
        </span>
      </div>
      <div className="p-3">
        <p className="font-semibold text-sm">{name}</p>
        <p className="font-mono text-kyn-green text-xs mt-0.5">{hex}</p>
        <p className="text-[11px] text-kyn-metal mt-1 leading-snug">{role}</p>
      </div>
    </button>
  );
}

export default function Brand() {
  return (
    <div className="max-w-6xl mx-auto px-6 md:px-10 py-12 md:py-16">
      <SectionHeader
        eyebrow="Brand DNA · Identity system"
        title="Original KYNETIK logo"
        description="Official bolt mark, wordmark and tagline — L'énergie en mouvement. Applied on every page through BrandLogo and Logo."
      />

      {/* Hero DNA */}
      <motion.section
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-12 rounded-3xl border border-white/10 overflow-hidden"
      >
        <div className="relative min-h-[220px] md:min-h-[280px] bg-kyn-black flex items-center justify-center p-10 md:p-16">
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(255,255,255,0.06),transparent_60%)]" />
          <img
            src="/images/kynetik-logo-white-glow.png?v=bolt1"
            alt="KYNETIK DNA"
            className="relative z-10 w-full max-w-xl h-auto object-contain"
          />
        </div>
        <div className="grid md:grid-cols-2">
          <div className="bg-white flex items-center justify-center p-10 md:p-14 border-t md:border-t-0 md:border-r border-white/10">
            <img
              src="/images/kynetik-logo-dark.png?v=bolt1"
              alt="KYNETIK dark lockup"
              className="w-full max-w-sm h-auto object-contain"
            />
          </div>
          <div className="bg-kyn-void flex items-center justify-center p-10 md:p-14 border-t border-white/10">
            <img
              src="/images/kynetik-logo-white.png?v=bolt1"
              alt="KYNETIK white lockup"
              className="w-full max-w-sm h-auto object-contain"
            />
          </div>
        </div>
      </motion.section>

      {/* Live components */}
      <section className="mb-14">
        <h2 className="font-display text-xl font-semibold mb-6">Live components (all pages)</h2>
        <div className="grid sm:grid-cols-3 gap-4">
          <div className="rounded-2xl bg-kyn-black border border-white/10 p-8 flex flex-col items-center justify-center gap-4 min-h-[160px]">
            <BrandLogo height={40} />
            <p className="text-[10px] uppercase tracking-wider text-kyn-metal">BrandLogo white</p>
          </div>
          <div className="rounded-2xl bg-white border border-black/5 p-8 flex flex-col items-center justify-center gap-4 min-h-[160px]">
            <BrandLogo variant="dark" height={40} />
            <p className="text-[10px] uppercase tracking-wider text-neutral-500">BrandLogo dark</p>
          </div>
          <div className="rounded-2xl bg-kyn-void border border-white/10 p-8 flex flex-col items-center justify-center gap-4 min-h-[160px]">
            <Logo size="xl" showWordmark={false} glowing />
            <p className="text-[10px] uppercase tracking-wider text-kyn-metal">Logo bolt mark</p>
          </div>
        </div>
        <div className="mt-4 grid sm:grid-cols-2 gap-4">
          <div className="rounded-2xl bg-kyn-steel/50 border border-white/8 p-6 flex items-center justify-center gap-6">
            <Logo size="sm" glowing />
            <Logo size="md" />
            <Logo size="lg" glowing />
          </div>
          <div className="rounded-2xl bg-kyn-black border border-white/8 p-6 flex items-center justify-center gap-8">
            <BrandLogo markOnly height={36} />
            <BrandLogo height={32} />
            <BrandLogo height={28} showTagline />
          </div>
        </div>
      </section>

      {/* Rules */}
      <section className="mb-14">
        <h2 className="font-display text-xl font-semibold mb-4">Usage rules</h2>
        <ul className="grid md:grid-cols-2 gap-2">
          {logoRules.map((r) => (
            <li key={r} className="flex gap-2 text-sm text-kyn-silver glass-card rounded-xl px-4 py-3">
              <Check size={14} className="text-kyn-green shrink-0 mt-0.5" />
              {r}
            </li>
          ))}
        </ul>
      </section>

      {/* Color DNA */}
      <section className="mb-14">
        <h2 className="font-display text-xl font-semibold mb-2">Color DNA</h2>
        <p className="text-sm text-kyn-metal mb-6">
          Bolt stays electric green · wordmark stays white or black. Green is brand-critical in the mark and UI accents.
        </p>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {palette.map((c) => (
            <Swatch key={c.hex} {...c} />
          ))}
        </div>
      </section>

      {/* Type */}
      <section className="mb-14">
        <h2 className="font-display text-xl font-semibold mb-4">Typography DNA</h2>
        <div className="grid md:grid-cols-2 gap-4">
          <div className="glass-card rounded-2xl p-6">
            <p className="text-[10px] uppercase tracking-widest text-kyn-metal mb-3">Display</p>
            <p className="font-display text-3xl md:text-4xl font-bold">Space Grotesk</p>
            <p className="mt-3 text-kyn-silver text-sm">Headlines · product names · investor decks</p>
          </div>
          <div className="glass-card rounded-2xl p-6">
            <p className="text-[10px] uppercase tracking-widest text-kyn-metal mb-3">Body</p>
            <p className="text-3xl md:text-4xl font-semibold">Inter</p>
            <p className="mt-3 text-kyn-silver text-sm">UI · forms · Cloud · long-form</p>
          </div>
        </div>
      </section>

      {/* Downloads */}
      <section>
        <h2 className="font-display text-xl font-semibold mb-4">DNA asset pack</h2>
        <div className="grid sm:grid-cols-2 gap-2">
          {downloads.map(({ href, label }) => (
            <a
              key={href}
              href={href}
              download
              className="flex items-center justify-between gap-3 glass-card rounded-xl px-4 py-3 text-sm text-kyn-silver hover:border-kyn-green/40 hover:text-kyn-green transition-colors"
            >
              <span className="inline-flex items-center gap-2">
                <Download size={14} /> {label}
              </span>
              <span className="text-[10px] text-kyn-metal uppercase tracking-wider">PNG</span>
            </a>
          ))}
        </div>
      </section>
    </div>
  );
}

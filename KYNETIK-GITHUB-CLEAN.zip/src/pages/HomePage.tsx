import { useEffect, useState, type ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { motion, useScroll, useTransform } from 'framer-motion';
import {
  ArrowRight, Menu, X, Zap, Shield, Cloud, Smartphone, CheckCircle2,
  Building2, Home, Hotel, Landmark, Car, Store, Quote, Activity,
  Gauge, Leaf, Cpu, Radio, Globe2, Play, Layers, Sparkles, Clock,
  Bell, Wallet, QrCode, BarChart3, Users, Wifi, Monitor, Wrench,
  Award, Linkedin, Facebook, Instagram, ChevronRight
} from 'lucide-react';
import BrandLogo from '../components/BrandLogo';
import LoadingState from '../components/LoadingState';
import { apiGet, cn } from '../lib/utils';

interface Metric {
  label: string;
  value: string;
  delta: string;
}

function Fade({
  children,
  className,
  delay = 0,
}: {
  children: ReactNode;
  className?: string;
  delay?: number;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 32 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-80px' }}
      transition={{ duration: 0.7, delay, ease: [0.22, 1, 0.36, 1] }}
      className={className}
    >
      {children}
    </motion.div>
  );
}

const navLinks = [
  { href: '/products', label: 'Products', route: true },
  { href: '/cloud', label: 'Cloud', route: true },
  { href: '/app-landing', label: 'App', route: true },
  { href: '/success-stories', label: 'Stories', route: true },
  { href: '/grow', label: 'Partners', route: true },
  { href: '/contact', label: 'Contact', route: true },
];

const trustItems = [
  { icon: Award, label: 'European Quality' },
  { icon: Radio, label: 'OCPP Compatible' },
  { icon: Cloud, label: 'Smart Cloud' },
  { icon: Monitor, label: '24/7 Monitoring' },
  { icon: Wrench, label: 'Professional Installation' },
  { icon: Shield, label: 'Premium Support' },
];

const productFamily = [
  {
    key: 'GO',
    name: 'GO',
    power: '3.7 · 7.4 kW',
    useCase: 'Travel · Apartments',
    description: 'Portable EV charger — apartments and travel, plug in anywhere.',
    image: '/images/products/go-cee.png',
    accent: '#60a5fa',
    href: '/products/go',
  },
  {
    key: 'FLEX',
    name: 'FLEX',
    power: '7.4 kW',
    useCase: 'Smart residential',
    description: 'Smart home wall charger — simple, connected, everyday ready.',
    image: '/images/products/flex-socket.png',
    accent: '#a78bfa',
    href: '/products/flex',
  },
  {
    key: 'PRIME',
    name: 'PRIME',
    power: '7.4 · 11 · 22 kW',
    useCase: 'Premium home',
    description: 'Pearl white premium charger for design-led homes and hospitality.',
    image: '/images/products/prime-hero.png',
    accent: '#2dd4bf',
    href: '/products/prime',
  },
  {
    key: 'NOVA',
    name: 'NOVA',
    power: '7.4 · 11 · 22 kW',
    useCase: 'Professional',
    description: 'Matte black professional charger — electric green, Cloud-native.',
    image: '/images/products/nova-tethered.png',
    accent: '#00e676',
    href: '/products/nova',
  },
  {
    key: 'EDGE',
    name: 'EDGE',
    power: '7.4 · 11 · 22 kW',
    useCase: 'Commercial',
    description: 'Commercial wall & pedestal for urban and shared parking.',
    image: '/images/products/edge-pedestal.png',
    accent: '#a3e635',
    href: '/products/edge',
  },
  {
    key: 'PRO',
    name: 'PRO',
    power: '22 · 44 kW Dual',
    useCase: 'Enterprise',
    description: 'Enterprise pedestal with dual-output for depots and campuses.',
    image: '/images/products/pro-tethered.png',
    accent: '#4ade80',
    href: '/products/pro',
  },
];

const cloudModules = [
  { icon: Zap, label: 'Energy' },
  { icon: Activity, label: 'Charging Sessions' },
  { icon: Gauge, label: 'Remote Control' },
  { icon: BarChart3, label: 'Analytics' },
  { icon: Car, label: 'Fleet' },
  { icon: Users, label: 'Users' },
  { icon: Wifi, label: 'Real-time Status' },
];

const appFeatures = [
  { icon: Zap, label: 'Remote Charging' },
  { icon: Clock, label: 'Scheduling' },
  { icon: Activity, label: 'Live Status' },
  { icon: Bell, label: 'Notifications' },
  { icon: BarChart3, label: 'Statistics' },
  { icon: Wallet, label: 'Wallet' },
  { icon: QrCode, label: 'QR Scan' },
];

const whyItems = [
  { icon: Sparkles, title: 'Premium Design', body: 'Industrial design language worthy of luxury homes and flagship workplaces.' },
  { icon: Cpu, title: 'Reliable Hardware', body: 'Engineered for continuous duty with safety-first electrical architecture.' },
  { icon: Wrench, title: 'Fast Installation', body: 'Certified partners and clear commissioning via KYNETIK Academy.' },
  { icon: Cloud, title: 'Cloud Connected', body: 'OCPP-native supervision, smart charging and remote diagnostics.' },
  { icon: Layers, title: 'Future Ready', body: 'Software-defined features that evolve with energy markets and EVs.' },
  { icon: Award, title: 'Made for Professionals', body: 'Built for operators, installers, fleets and enterprise buyers.' },
];

const segments = [
  { icon: Home, title: 'Luxury Homes', body: 'Quiet power for premium residences and villas.' },
  { icon: Building2, title: 'Companies', body: 'Workplace charging with policies and analytics.' },
  { icon: Hotel, title: 'Hotels', body: 'Guest-ready hospitality finishes and experiences.' },
  { icon: Store, title: 'Retail', body: 'Destination charging that elevates dwell time.' },
  { icon: Landmark, title: 'Public Charging', body: 'Reliable urban infrastructure for cities.' },
  { icon: Car, title: 'Fleet Management', body: 'Depot and multi-bay control at scale.' },
];

const testimonials = [
  {
    quote:
      'KYNETIK delivered a Tesla-level driver experience with industrial reliability. Our workplace chargers finally feel like critical infrastructure.',
    name: 'Leila Mansour',
    role: 'Head of Mobility · Corporate Campus Tunis',
  },
  {
    quote:
      'From NOVA at home to PRO on our parking decks, one brand system and one Cloud. Installation was fast, the finish is impeccable.',
    name: 'Karim Ben Salah',
    role: 'Facilities Director · Hospitality Group',
  },
  {
    quote:
      'Investors understood the story immediately — premium hardware, software margins, and a clear North African expansion path.',
    name: 'Sofia Hartmann',
    role: 'Partner · Climate Tech Fund',
  },
];

function CloudPreview({ metrics }: { metrics: Metric[] }) {
  const cards = metrics.length
    ? metrics.slice(0, 4)
    : [
        { label: 'Energy today', value: '8.2k kWh', delta: '+4.1%' },
        { label: 'Sessions', value: '1 284', delta: '+12%' },
        { label: 'Uptime', value: '99.4%', delta: 'SLA OK' },
        { label: 'Online', value: '118', delta: '+6' },
      ];
  const bars = [40, 55, 48, 70, 62, 78, 72, 88, 80, 92, 85, 95, 78, 88, 70, 82, 90, 76, 68, 74, 86, 92, 80, 72];

  return (
    <div className="rounded-3xl border border-white/10 bg-gradient-to-b from-[#14161c] to-[#08090c] overflow-hidden shadow-[0_40px_120px_rgba(0,0,0,0.55)]">
      <div className="flex items-center justify-between px-5 py-3.5 border-b border-white/5 bg-white/[0.02]">
        <div className="flex items-center gap-3">
          <div className="flex gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-red-500/80" />
            <span className="w-2.5 h-2.5 rounded-full bg-yellow-500/80" />
            <span className="w-2.5 h-2.5 rounded-full bg-green-500/80" />
          </div>
          <span className="text-[11px] text-kyn-silver font-medium tracking-wide">KYNETIK Cloud · Live</span>
        </div>
        <span className="flex items-center gap-1.5 text-[10px] text-kyn-green font-semibold">
          <span className="w-1.5 h-1.5 rounded-full bg-kyn-green animate-pulse" /> REAL-TIME
        </span>
      </div>
      <div className="p-5">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-2.5 mb-4">
          {cards.map((m) => (
            <div key={m.label} className="rounded-2xl border border-white/8 bg-white/[0.03] p-3.5 backdrop-blur">
              <p className="text-[9px] uppercase tracking-wider text-kyn-metal">{m.label}</p>
              <p className="font-display text-xl md:text-2xl font-bold mt-1 text-white">{m.value}</p>
              <p className="text-[10px] text-kyn-green mt-0.5">{m.delta}</p>
            </div>
          ))}
        </div>
        <div className="rounded-2xl border border-white/8 bg-black/40 p-4 mb-4">
          <div className="flex items-center justify-between mb-3">
            <p className="text-xs font-semibold text-kyn-silver">Energy · 24h</p>
            <Activity size={13} className="text-kyn-green" />
          </div>
          <div className="h-28 md:h-36 flex items-end gap-1">
            {bars.map((h, i) => (
              <div
                key={i}
                className="flex-1 rounded-t-sm bg-gradient-to-t from-kyn-green/20 via-kyn-green/70 to-kyn-green"
                style={{ height: `${h}%`, opacity: 0.5 + (i / bars.length) * 0.5 }}
              />
            ))}
          </div>
        </div>
        <div className="flex flex-wrap gap-2">
          {cloudModules.map(({ icon: Icon, label }) => (
            <span
              key={label}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border border-white/8 bg-white/[0.03] text-[10px] text-kyn-silver"
            >
              <Icon size={11} className="text-kyn-green" /> {label}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}

function PhoneMock({
  title,
  children,
  offset = false,
}: {
  title: string;
  children: ReactNode;
  offset?: boolean;
}) {
  return (
    <div className={cn('phone-frame w-[170px] sm:w-[200px] h-[350px] sm:h-[410px] rounded-[2.2rem] p-2 shrink-0', offset && 'mt-10')}>
      <div className="w-full h-full rounded-[1.75rem] bg-kyn-void border border-white/5 overflow-hidden relative flex flex-col">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-20 h-5 bg-black rounded-b-xl z-20" />
        <div className="flex-1 pt-8 px-3 pb-3 relative">{children}</div>
        <p className="text-center text-[9px] text-kyn-metal pb-2 tracking-wide">{title}</p>
      </div>
    </div>
  );
}

export default function HomePage() {
  const [metrics, setMetrics] = useState<Metric[]>([]);
  const [loading, setLoading] = useState(true);
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [testimonialIdx, setTestimonialIdx] = useState(0);
  const { scrollY } = useScroll();
  const heroY = useTransform(scrollY, [0, 500], [0, 120]);
  const heroOpacity = useTransform(scrollY, [0, 450], [1, 0.35]);

  useEffect(() => {
    apiGet<Metric[]>('/api/cloud-metrics')
      .then((m) => setMetrics(m.map((x: Metric & { label: string }) => ({ label: x.label, value: x.value, delta: x.delta }))))
      .catch(() => setMetrics([]))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 32);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    const t = setInterval(() => setTestimonialIdx((i) => (i + 1) % testimonials.length), 6000);
    return () => clearInterval(t);
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-kyn-black flex items-center justify-center">
        <LoadingState label="Loading KYNETIK…" />
      </div>
    );
  }

  const t = testimonials[testimonialIdx];

  return (
    <div className="min-h-screen bg-kyn-black text-white overflow-x-hidden selection:bg-kyn-green/30">
      {/* NAV */}
      <header
        className={cn(
          'fixed top-0 inset-x-0 z-50 transition-all duration-500',
          scrolled ? 'bg-kyn-black/80 backdrop-blur-2xl border-b border-white/5 shadow-[0_10px_40px_rgba(0,0,0,0.45)]' : 'bg-transparent'
        )}
      >
        <div className="max-w-7xl mx-auto px-5 md:px-8 h-16 md:h-[4.5rem] flex items-center justify-between">
          <a href="#top" className="flex items-center gap-3">
            <BrandLogo height={30} />
          </a>
          <nav className="hidden lg:flex items-center gap-8">
            {navLinks.map((l) =>
              l.route ? (
                <Link key={l.href} to={l.href} className="text-[12px] font-medium text-kyn-silver hover:text-white transition-colors tracking-wide">
                  {l.label}
                </Link>
              ) : (
                <a key={l.href} href={l.href} className="text-[12px] font-medium text-kyn-silver hover:text-white transition-colors tracking-wide">
                  {l.label}
                </a>
              )
            )}
          </nav>
          <div className="flex items-center gap-3">
            <Link to="/grow" className="hidden md:inline text-xs text-kyn-metal hover:text-kyn-green transition-colors tracking-wide">
              Partners
            </Link>
            <Link to="/support" className="hidden lg:inline text-xs text-kyn-metal hover:text-white transition-colors">
              Support
            </Link>
            <Link
              to="/quote"
              className="hidden sm:inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-kyn-green text-kyn-black text-xs font-bold hover:bg-kyn-green-glow transition-all glow-green"
            >
              Request a Quote
            </Link>
            <button type="button" className="lg:hidden p-2 text-kyn-silver" onClick={() => setMenuOpen(!menuOpen)} aria-label="Menu">
              {menuOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </div>
        {menuOpen && (
          <div className="lg:hidden border-t border-white/5 bg-kyn-void/98 backdrop-blur-xl px-5 py-5 space-y-1">
            {navLinks.map((l) =>
              l.route ? (
                <Link key={l.href} to={l.href} onClick={() => setMenuOpen(false)} className="block py-3 text-sm text-kyn-silver border-b border-white/5">
                  {l.label}
                </Link>
              ) : (
                <a key={l.href} href={l.href} onClick={() => setMenuOpen(false)} className="block py-3 text-sm text-kyn-silver border-b border-white/5">
                  {l.label}
                </a>
              )
            )}
            <Link to="/quote" onClick={() => setMenuOpen(false)} className="mt-4 block text-center rounded-full bg-kyn-green text-kyn-black text-xs font-bold py-3.5">
              Request a Quote
            </Link>
          </div>
        )}
      </header>

      {/* 01 HERO */}
      <section id="top" className="relative min-h-[100svh] flex items-end md:items-center pt-20 pb-16 overflow-hidden">
        <motion.div style={{ y: heroY }} className="absolute inset-0">
          <img
            src="/images/hero-luxury-home.jpg"
            alt="Luxury home EV charging"
            className="w-full h-full object-cover scale-105"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black via-black/85 to-black/40" />
          <div className="absolute inset-0 bg-gradient-to-t from-kyn-black via-transparent to-black/50" />
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_70%_60%,rgba(0,230,118,0.14),transparent_45%)]" />
          <div className="absolute inset-0 grid-bg opacity-20" />
        </motion.div>

        {/* Animated light orbs */}
        <div className="pointer-events-none absolute inset-0 overflow-hidden">
          <motion.div
            animate={{ opacity: [0.25, 0.55, 0.25], scale: [1, 1.15, 1] }}
            transition={{ duration: 6, repeat: Infinity, ease: 'easeInOut' }}
            className="absolute right-[18%] top-[42%] w-40 h-40 md:w-64 md:h-64 rounded-full bg-kyn-green/25 blur-[60px]"
          />
          <motion.div
            animate={{ opacity: [0.15, 0.4, 0.15] }}
            transition={{ duration: 4.5, repeat: Infinity, ease: 'easeInOut', delay: 1 }}
            className="absolute left-[30%] bottom-[25%] w-24 h-24 rounded-full bg-kyn-green/20 blur-[40px]"
          />
        </div>

        <motion.div style={{ opacity: heroOpacity }} className="relative z-10 max-w-7xl mx-auto px-5 md:px-8 w-full py-16 md:py-24">
          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.85, ease: [0.22, 1, 0.36, 1] }}>
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full border border-kyn-green/30 bg-kyn-green/10 text-kyn-green text-[11px] font-semibold mb-8 backdrop-blur-md">
              <Zap size={12} /> Premium EV Charging Technology
            </div>
            <h1 className="font-display text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold tracking-tight leading-[1.05] max-w-4xl">
              Powering the Future of{' '}
              <span className="text-kyn-green text-glow">Electric Mobility.</span>
            </h1>
            <p className="mt-6 text-base md:text-xl text-kyn-silver max-w-2xl leading-relaxed">
              Premium EV Charging Solutions for Homes, Businesses and Smart Cities.
            </p>
            <div className="mt-10 flex flex-wrap gap-3">
              <Link
                to="/products"
                className="inline-flex items-center gap-2 px-7 py-3.5 rounded-full bg-kyn-green text-kyn-black text-sm font-bold glow-green hover:bg-kyn-green-glow transition-all"
              >
                Explore Products <ArrowRight size={16} />
              </Link>
              <Link
                to="/configurator"
                className="inline-flex items-center gap-2 px-7 py-3.5 rounded-full border border-white/20 bg-white/5 backdrop-blur-md text-sm font-semibold hover:border-kyn-green/40 hover:bg-white/10 transition-all"
              >
                Configure your charger
              </Link>
            </div>
            <div className="mt-14 flex flex-wrap gap-8 md:gap-12">
              {[
                { v: '6', l: 'Product series' },
                { v: 'OCPP', l: 'Cloud native' },
                { v: '24/7', l: 'Monitoring' },
              ].map((s) => (
                <div key={s.l}>
                  <p className="font-display text-2xl md:text-3xl font-bold">{s.v}</p>
                  <p className="text-[11px] text-kyn-metal uppercase tracking-wider mt-1">{s.l}</p>
                </div>
              ))}
            </div>
          </motion.div>
        </motion.div>

        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 hidden md:flex flex-col items-center gap-2 text-kyn-metal">
          <span className="text-[10px] tracking-[0.35em] uppercase">Scroll</span>
          <motion.div
            animate={{ height: [12, 28, 12], opacity: [0.4, 1, 0.4] }}
            transition={{ duration: 1.8, repeat: Infinity }}
            className="w-px bg-gradient-to-b from-kyn-green to-transparent"
          />
        </div>
      </section>

      {/* 02 TRUST */}
      <section className="relative border-y border-white/5 bg-kyn-void/90">
        <div className="max-w-7xl mx-auto px-5 md:px-8 py-8 md:py-10">
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4 md:gap-6">
            {trustItems.map(({ icon: Icon, label }, i) => (
              <Fade key={label} delay={i * 0.04}>
                <div className="flex flex-col items-center text-center gap-2.5 py-2 group">
                  <div className="w-11 h-11 rounded-2xl border border-white/10 bg-white/[0.03] flex items-center justify-center text-kyn-green group-hover:border-kyn-green/35 group-hover:glow-green transition-all">
                    <Icon size={18} />
                  </div>
                  <p className="text-[11px] md:text-xs font-medium text-kyn-silver leading-snug">{label}</p>
                </div>
              </Fade>
            ))}
          </div>
        </div>
      </section>

      {/* 03 PRODUCT FAMILY */}
      <section id="products" className="py-24 md:py-32 relative">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(0,230,118,0.06),transparent_50%)]" />
        <div className="relative z-10 max-w-7xl mx-auto px-5 md:px-8">
          <Fade>
            <p className="text-kyn-green text-xs font-semibold tracking-[0.3em] uppercase mb-4">Product family</p>
            <div className="flex flex-wrap items-end justify-between gap-6 mb-14">
              <h2 className="font-display text-3xl md:text-5xl font-bold max-w-xl leading-tight">
                A complete charging ecosystem
              </h2>
              <p className="text-kyn-metal max-w-sm text-sm md:text-base leading-relaxed">
                From portable GO to commercial PRO — one design language, one Cloud, infinite sites.
              </p>
            </div>
          </Fade>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-5">
            {productFamily.map((p, i) => (
              <Fade key={p.key} delay={i * 0.06}>
                <Link
                  to={p.href}
                  className="group relative block h-full rounded-[1.75rem] border border-white/8 bg-gradient-to-b from-white/[0.04] to-transparent overflow-hidden hover:border-white/20 transition-all duration-500 hover:-translate-y-1 hover:shadow-[0_30px_80px_rgba(0,0,0,0.45)]"
                >
                  <div
                    className="relative h-52 md:h-56 flex items-center justify-center"
                    style={{ background: `radial-gradient(circle at 50% 60%, ${p.accent}22, transparent 65%)` }}
                  >
                    <img
                      src={p.image}
                      alt={p.name}
                      className="relative z-10 h-[78%] w-auto object-contain transition-transform duration-700 group-hover:scale-110 drop-shadow-[0_20px_40px_rgba(0,0,0,0.5)]"
                    />
                    <div className="absolute top-4 left-4 px-2.5 py-1 rounded-full border border-white/10 bg-black/40 backdrop-blur text-[10px] font-semibold tracking-wider uppercase text-kyn-silver">
                      {p.useCase}
                    </div>
                  </div>
                  <div className="p-6 pt-2">
                    <div className="flex items-center justify-between gap-3">
                      <h3 className="font-display text-2xl font-bold" style={{ color: p.accent }}>
                        {p.name}
                      </h3>
                      <span className="text-xs font-semibold text-white/90">{p.power}</span>
                    </div>
                    <p className="mt-3 text-sm text-kyn-metal leading-relaxed min-h-[3rem]">{p.description}</p>
                    <span className="mt-5 inline-flex items-center gap-1.5 text-xs font-semibold text-kyn-green group-hover:gap-2.5 transition-all">
                      Learn More <ArrowRight size={13} />
                    </span>
                  </div>
                </Link>
              </Fade>
            ))}
          </div>
        </div>
      </section>

      {/* 04 CLOUD */}
      <section id="cloud" className="py-24 md:py-32 bg-kyn-void border-y border-white/5 relative overflow-hidden">
        <div className="absolute right-0 top-0 w-1/2 h-full opacity-20 pointer-events-none hidden lg:block">
          <img src="/images/cloud-datacenter.jpg" alt="" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-l from-transparent to-kyn-void" />
        </div>
        <div className="relative z-10 max-w-7xl mx-auto px-5 md:px-8">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
            <Fade>
              <p className="text-kyn-green text-xs font-semibold tracking-[0.3em] uppercase mb-4">KYNETIK Cloud</p>
              <h2 className="font-display text-3xl md:text-5xl font-bold leading-tight">
                Command every kilowatt in real time
              </h2>
              <p className="mt-5 text-kyn-silver leading-relaxed text-base md:text-lg max-w-lg">
                Enterprise-grade supervision for energy, sessions, fleets and users — with remote control and investor-ready analytics.
              </p>
              <div className="mt-8 grid grid-cols-2 gap-3">
                {cloudModules.map(({ icon: Icon, label }) => (
                  <div key={label} className="flex items-center gap-2.5 rounded-2xl border border-white/8 bg-black/30 px-3.5 py-3">
                    <Icon size={15} className="text-kyn-green shrink-0" />
                    <span className="text-xs font-medium text-kyn-silver">{label}</span>
                  </div>
                ))}
              </div>
              <Link
                to="/cloud"
                className="mt-10 inline-flex items-center gap-2 px-6 py-3.5 rounded-full bg-kyn-green text-kyn-black text-sm font-bold hover:bg-kyn-green-glow transition-colors glow-green"
              >
                Discover KYNETIK Cloud <ArrowRight size={16} />
              </Link>
            </Fade>
            <Fade delay={0.12}>
              <CloudPreview metrics={metrics} />
            </Fade>
          </div>
        </div>
      </section>

      {/* 05 MOBILE APP */}
      <section id="app" className="py-24 md:py-32 relative">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <div className="grid lg:grid-cols-2 gap-14 items-center">
            <Fade className="order-2 lg:order-1 flex justify-center gap-4 md:gap-6">
              <PhoneMock title="Charging">
                <div className="h-full flex flex-col items-center justify-center">
                  <div
                    className="w-28 h-28 rounded-full flex items-center justify-center"
                    style={{ background: 'conic-gradient(from 210deg, #00e676 0%, #00e676 72%, #2a2a30 72%)' }}
                  >
                    <div className="w-[78%] h-[78%] rounded-full bg-kyn-void flex flex-col items-center justify-center">
                      <span className="font-display text-2xl font-bold text-kyn-green">72%</span>
                      <span className="text-[8px] text-kyn-metal">Live</span>
                    </div>
                  </div>
                  <p className="mt-4 text-[10px] text-kyn-silver">NOVA Home · 11.2 kW</p>
                  <div className="mt-4 w-full grid grid-cols-2 gap-1.5">
                    {['28 min', '18 kWh'].map((v) => (
                      <div key={v} className="rounded-lg bg-white/5 border border-white/5 py-1.5 text-center text-[9px] text-kyn-metal">
                        {v}
                      </div>
                    ))}
                  </div>
                </div>
              </PhoneMock>
              <PhoneMock title="Map & Wallet" offset>
                <div className="h-full flex flex-col">
                  <div className="flex-1 relative rounded-xl bg-[#0d1210] border border-white/5 overflow-hidden mb-2">
                    <div
                      className="absolute inset-0 opacity-40"
                      style={{
                        backgroundImage:
                          'linear-gradient(rgba(0,230,118,0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(0,230,118,0.1) 1px, transparent 1px)',
                        backgroundSize: '18px 18px',
                      }}
                    />
                    {[30, 55, 42].map((top, i) => (
                      <div
                        key={i}
                        className="absolute w-5 h-5 rounded-full border border-kyn-green bg-kyn-green/20 flex items-center justify-center"
                        style={{ top: `${top}%`, left: `${28 + i * 18}%` }}
                      >
                        <Zap size={9} className="text-kyn-green" />
                      </div>
                    ))}
                  </div>
                  <div className="rounded-xl border border-kyn-green/25 bg-kyn-green/10 p-2.5">
                    <p className="text-[9px] text-kyn-metal">Wallet</p>
                    <p className="font-display font-bold text-sm text-kyn-green">84.50 DT</p>
                  </div>
                </div>
              </PhoneMock>
            </Fade>

            <Fade className="order-1 lg:order-2" delay={0.08}>
              <p className="text-kyn-green text-xs font-semibold tracking-[0.3em] uppercase mb-4">Mobile app</p>
              <h2 className="font-display text-3xl md:text-5xl font-bold leading-tight">
                Your energy, in your pocket
              </h2>
              <p className="mt-5 text-kyn-silver leading-relaxed max-w-lg">
                A premium driver experience — remote control, scheduling, live status and payments — perfectly aligned with KYNETIK Cloud.
              </p>
              <div className="mt-8 grid grid-cols-2 gap-2.5">
                {appFeatures.map(({ icon: Icon, label }) => (
                  <div key={label} className="flex items-center gap-2.5 rounded-2xl border border-white/8 bg-white/[0.02] px-3.5 py-3 hover:border-kyn-green/25 transition-colors">
                    <Icon size={15} className="text-kyn-green shrink-0" />
                    <span className="text-xs font-medium text-kyn-silver">{label}</span>
                  </div>
                ))}
              </div>
              <Link
                to="/app-landing"
                className="mt-10 inline-flex items-center gap-2 text-sm font-semibold text-kyn-green hover:gap-3 transition-all"
              >
                Explore the app experience <ArrowRight size={15} />
              </Link>
            </Fade>
          </div>
        </div>
      </section>

      {/* 06 WHY KYNETIK */}
      <section id="why" className="py-24 md:py-28 bg-kyn-void border-y border-white/5">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <Fade className="mb-14 max-w-2xl">
            <p className="text-kyn-green text-xs font-semibold tracking-[0.3em] uppercase mb-4">Why KYNETIK</p>
            <h2 className="font-display text-3xl md:text-5xl font-bold leading-tight">
              Built like a global technology brand
            </h2>
          </Fade>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {whyItems.map(({ icon: Icon, title, body }, i) => (
              <Fade key={title} delay={i * 0.05}>
                <div className="h-full rounded-3xl border border-white/8 bg-black/25 p-7 hover:border-kyn-green/30 hover:bg-kyn-green/[0.03] transition-all duration-300 group">
                  <div className="w-12 h-12 rounded-2xl border border-kyn-green/25 bg-kyn-green/10 flex items-center justify-center text-kyn-green mb-5 group-hover:glow-green transition-shadow">
                    <Icon size={20} />
                  </div>
                  <h3 className="font-display text-xl font-semibold">{title}</h3>
                  <p className="mt-3 text-sm text-kyn-metal leading-relaxed">{body}</p>
                </div>
              </Fade>
            ))}
          </div>
        </div>
      </section>

      {/* 07 SEGMENTS */}
      <section id="segments" className="py-24 md:py-32">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <Fade className="text-center max-w-2xl mx-auto mb-14">
            <p className="text-kyn-green text-xs font-semibold tracking-[0.3em] uppercase mb-4">Customer segments</p>
            <h2 className="font-display text-3xl md:text-5xl font-bold">Solutions for every ambition</h2>
          </Fade>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3 md:gap-4">
            {segments.map(({ icon: Icon, title, body }, i) => (
              <Fade key={title} delay={i * 0.05}>
                <div className="group h-full rounded-3xl border border-white/8 bg-gradient-to-b from-white/[0.03] to-transparent p-6 md:p-8 hover:border-kyn-green/30 transition-all hover:-translate-y-0.5">
                  <div className="w-11 h-11 rounded-2xl bg-kyn-green/10 border border-kyn-green/20 flex items-center justify-center text-kyn-green mb-5">
                    <Icon size={18} />
                  </div>
                  <h3 className="font-display font-semibold text-lg">{title}</h3>
                  <p className="mt-2 text-sm text-kyn-metal leading-relaxed">{body}</p>
                  <span className="mt-4 inline-flex items-center gap-1 text-[11px] text-kyn-green opacity-0 group-hover:opacity-100 transition-opacity">
                    Explore <ChevronRight size={12} />
                  </span>
                </div>
              </Fade>
            ))}
          </div>
        </div>
      </section>

      {/* 08 TESTIMONIALS */}
      <section className="py-24 md:py-28 relative overflow-hidden border-y border-white/5">
        <div className="absolute inset-0">
          <img src="/images/presentation.jpg" alt="" className="w-full h-full object-cover opacity-15" />
          <div className="absolute inset-0 bg-gradient-to-r from-kyn-black via-kyn-black/95 to-kyn-black/85" />
        </div>
        <div className="relative z-10 max-w-4xl mx-auto px-5 md:px-8 text-center">
          <Fade>
            <Quote className="mx-auto text-kyn-green mb-8" size={36} />
            <div className="min-h-[160px] md:min-h-[140px] flex items-center justify-center">
              <motion.blockquote
                key={testimonialIdx}
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="font-display text-2xl md:text-4xl font-medium leading-snug text-white"
              >
                “{t.quote}”
              </motion.blockquote>
            </div>
            <div className="mt-8">
              <p className="font-semibold">{t.name}</p>
              <p className="text-sm text-kyn-metal mt-1">{t.role}</p>
            </div>
            <div className="mt-8 flex justify-center gap-2">
              {testimonials.map((_, i) => (
                <button
                  key={i}
                  type="button"
                  onClick={() => setTestimonialIdx(i)}
                  className={cn('h-1.5 rounded-full transition-all', i === testimonialIdx ? 'w-8 bg-kyn-green' : 'w-1.5 bg-white/25')}
                  aria-label={`Testimonial ${i + 1}`}
                />
              ))}
            </div>
          </Fade>
        </div>
      </section>

      {/* 09 CTA */}
      <section id="contact" className="py-24 md:py-32 relative">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(0,230,118,0.14),transparent_55%)]" />
        <div className="relative z-10 max-w-5xl mx-auto px-5 md:px-8">
          <Fade>
            <div className="rounded-[2rem] border border-kyn-green/25 bg-gradient-to-br from-kyn-green/10 via-kyn-void to-kyn-black p-10 md:p-16 text-center shadow-[0_40px_100px_rgba(0,230,118,0.08)]">
              <p className="text-kyn-green text-xs font-semibold tracking-[0.3em] uppercase mb-4">Next step</p>
              <h2 className="font-display text-3xl md:text-5xl lg:text-6xl font-bold leading-tight">
                Ready to Electrify Your Future?
              </h2>
              <p className="mt-5 text-kyn-silver max-w-xl mx-auto leading-relaxed">
                Talk to our team about homes, workplaces, hospitality, public networks or fleet depots — or join the partner program.
              </p>
              <div className="mt-10 flex flex-wrap justify-center gap-3">
                <a
                  href="mailto:contact@kynetik.tn"
                  className="inline-flex items-center gap-2 px-8 py-4 rounded-full bg-kyn-green text-kyn-black text-sm font-bold glow-green hover:bg-kyn-green-glow transition-colors"
                >
                  Contact Us <ArrowRight size={16} />
                </a>
                <a
                  href="mailto:partners@kynetik.tn"
                  className="inline-flex items-center gap-2 px-8 py-4 rounded-full border border-white/20 bg-white/5 text-sm font-semibold hover:border-kyn-green/40 transition-colors"
                >
                  Become a Partner
                </a>
              </div>
              <div className="mt-10 flex flex-wrap justify-center gap-5 text-[11px] text-kyn-metal">
                {['Investor-ready', 'Certified installers', 'Global-standard UX'].map((x) => (
                  <span key={x} className="inline-flex items-center gap-1.5">
                    <CheckCircle2 size={12} className="text-kyn-green" /> {x}
                  </span>
                ))}
              </div>
            </div>
          </Fade>
        </div>
      </section>

      {/* 10 FOOTER */}
      <footer className="border-t border-white/5 bg-kyn-void">
        <div className="max-w-7xl mx-auto px-5 md:px-8 py-16">
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-10">
            <div className="col-span-2 md:col-span-3 lg:col-span-2">
              <BrandLogo height={32} />
              <p className="mt-4 text-sm text-kyn-metal max-w-xs leading-relaxed">
                L'énergie en mouvement — premium EV charging hardware, Cloud and experiences for the next decade of mobility.
              </p>
              <div className="mt-6 flex gap-3">
                {[
                  { icon: Linkedin, label: 'LinkedIn' },
                  { icon: Facebook, label: 'Facebook' },
                  { icon: Instagram, label: 'Instagram' },
                ].map(({ icon: Icon, label }) => (
                  <a
                    key={label}
                    href="#"
                    aria-label={label}
                    className="w-10 h-10 rounded-full border border-white/10 flex items-center justify-center text-kyn-metal hover:text-kyn-green hover:border-kyn-green/40 transition-colors"
                  >
                    <Icon size={16} />
                  </a>
                ))}
              </div>
            </div>

            {[
              {
                title: 'Products',
                links: [
                  { l: 'GO', to: '/products/go' },
                  { l: 'FLEX', to: '/products/flex' },
                  { l: 'PRIME', to: '/products/prime' },
                  { l: 'NOVA', to: '/products/nova' },
                  { l: 'EDGE', to: '/products/edge' },
                  { l: 'PRO', to: '/products/pro' },
                ],
              },
              {
                title: 'Cloud',
                links: [
                  { l: 'Platform', to: '/cloud' },
                  { l: 'Console', to: '/console' },
                  { l: 'API', to: '/cloud' },
                ],
              },
              {
                title: 'Company',
                links: [
                  { l: 'Contact', to: '/contact' },
                  { l: 'Quote', to: '/quote' },
                  { l: 'Installers', to: '/installers' },
                  { l: 'Distributors', to: '/distributors' },
                  { l: 'Success Stories', to: '/success-stories' },
                  { l: 'Resources', to: '/resources' },
                  { l: 'FAQ', to: '/faq' },
                  { l: 'Support', to: '/support' },
                  { l: 'Academy', to: '/academy-landing' },
                  { l: 'Careers', to: '/careers' },
                  { l: 'Partners Hub', to: '/grow' },
                ],
              },
            ].map((col) => (
              <div key={col.title}>
                <p className="text-[11px] font-semibold tracking-[0.2em] uppercase text-kyn-metal mb-4">{col.title}</p>
                <ul className="space-y-2.5">
                  {col.links.map((link) =>
                    link.to.startsWith('#') ? (
                      <li key={link.l}>
                        <a href={link.to} className="text-sm text-kyn-silver hover:text-white transition-colors">
                          {link.l}
                        </a>
                      </li>
                    ) : (
                      <li key={link.l}>
                        <Link to={link.to} className="text-sm text-kyn-silver hover:text-white transition-colors">
                          {link.l}
                        </Link>
                      </li>
                    )
                  )}
                </ul>
              </div>
            ))}
          </div>

          <div className="mt-14 pt-8 border-t border-white/5 flex flex-wrap items-center justify-between gap-4">
            <p className="text-[11px] text-kyn-metal">© {new Date().getFullYear()} KYNETIK. All rights reserved.</p>
            <p className="text-[11px] text-kyn-metal tracking-wide">Tunisia · Premium EV Technology</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

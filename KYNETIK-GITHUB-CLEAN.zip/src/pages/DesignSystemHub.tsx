import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  ArrowRight, BookOpen, Component, Palette, Sparkles, Layers, Package,
  Smartphone, Globe, Cloud, Code2, LayoutGrid, Zap, Network, Server } from 'lucide-react';
import BrandLogo from '../components/BrandLogo';
import { Button, GlassPanel, SectionLabel, SpecChip, StatusPill, colors } from '../ui';
import { cn } from '../lib/utils';

const modules = [
  { to: '/design-system/tokens', title: 'Design Tokens', desc: 'Color, type, space, radius, motion — live kit', icon: Sparkles, tag: 'Foundation' },
  { to: '/ui-library', title: 'UI Component Library', desc: 'Buttons, forms, tables, feedback, domain widgets', icon: Component, tag: 'Components' },
  { to: '/design-bible', title: 'Design Bible', desc: 'Vision, voice, visual rules, accessibility', icon: BookOpen, tag: 'Principles' },
  { to: '/brand', title: 'Brand Foundation', desc: 'Logo, lockups, color stories', icon: Palette, tag: 'Brand' },
  { to: '/tokens', title: 'Legacy token sheet', desc: 'Original compact token reference', icon: LayoutGrid, tag: 'Archive' },
  { to: '/products', title: 'Product System', desc: 'Hardware family in brand language', icon: Package, tag: 'Product' },
  { to: '/app', title: 'Mobile App UX', desc: 'Driver journey screens', icon: Smartphone, tag: 'App' },
  { to: '/cloud-console', title: 'Cloud Console UX', desc: 'Operator interface patterns', icon: Cloud, tag: 'Cloud' },
  { to: '/website', title: 'Website UX', desc: 'Marketing architecture', icon: Globe, tag: 'Web' },
  { to: '/handoff', title: 'Developer Handoff', desc: 'Tokens → code mapping', icon: Code2, tag: 'Handoff' },
  { to: '/production', title: 'Production Assets', desc: 'Renders, motion, QA', icon: Layers, tag: 'Assets' },
  { to: '/csms', title: 'CSMS Dashboard', desc: 'OCPP operator control plane', icon: Server },
  { to: '/ocpp', title: 'OCPP CSMS', desc: '1.6J WebSocket + REST + console', icon: Server, tag: 'Cloud' },
  { to: '/engineering-pack', title: 'Engineering Pack', desc: 'SAD · API · DB · DevOps · QA · Ops · Sec', icon: Network, tag: 'Eng' },
  { to: '/docs-suite', title: 'Documentation Suite', desc: 'Canonical product docs', icon: BookOpen, tag: 'Docs' },
];

export default function DesignSystemHub() {
  return (
    <div className="min-h-screen bg-kyn-black text-white">
      <div className="relative overflow-hidden border-b border-white/5">
        <div className="absolute inset-0 grid-bg opacity-40" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(0,230,118,0.14),transparent_55%)]" />
        <div className="relative z-10 mx-auto max-w-6xl px-6 py-16 md:px-10 md:py-24">
          <div className="mb-8 flex flex-wrap items-center gap-3">
            <BrandLogo height={32} />
            <StatusPill status="online" pulse>Design System</StatusPill>
          </div>
          <SectionLabel>KYNETIK · Extend, don't reinvent</SectionLabel>
          <h1 className="mt-4 max-w-3xl font-display text-4xl font-bold tracking-tight md:text-6xl">
            Design System Hub
          </h1>
          <p className="mt-5 max-w-2xl text-base leading-relaxed text-kyn-silver md:text-lg">
            One brand language for hardware, app, website and Cloud. This hub extends the existing
            identity — colors, type, spacing and components stay canonical.
          </p>
          <div className="mt-6 flex flex-wrap gap-2">
            <SpecChip accent>#00E676</SpecChip>
            <SpecChip>Space Grotesk · Inter</SpecChip>
            <SpecChip>Radius 16</SpecChip>
            <SpecChip>Glass + glow</SpecChip>
          </div>
          <div className="mt-10 flex flex-wrap gap-3">
            <Link to="/design-system/tokens">
              <Button size="lg">Open tokens <ArrowRight size={16} /></Button>
            </Link>
            <Link to="/ui-library">
              <Button variant="secondary" size="lg">Component library</Button>
            </Link>
            <Link to="/design-system">
              <Button variant="ghost" size="lg">System overview</Button>
            </Link>
          </div>
        </div>
      </div>

      <section className="mx-auto max-w-6xl px-6 py-16 md:px-10">
        <div className="mb-10 grid gap-4 sm:grid-cols-3">
          {[
            { l: 'Primary accent', v: colors.green },
            { l: 'Surfaces', v: 'Black · Void · Steel' },
            { l: 'Principle', v: 'Extend existing DS' },
          ].map((x) => (
            <GlassPanel key={x.l} className="p-5">
              <p className="text-[10px] uppercase tracking-widest text-kyn-metal">{x.l}</p>
              <p className="mt-2 font-display text-lg font-semibold" style={{ color: x.v.startsWith('#') ? x.v : undefined }}>
                {x.v}
              </p>
            </GlassPanel>
          ))}
        </div>

        <p className="mb-3 text-xs font-semibold uppercase tracking-[0.25em] text-kyn-green">Modules</p>
        <h2 className="mb-8 font-display text-3xl font-bold">Everything under one language</h2>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {modules.map((m, i) => {
            const Icon = m.icon;
            return (
              <motion.div
                key={m.to}
                initial={{ opacity: 0, y: 12 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.03 }}
              >
                <Link
                  to={m.to}
                  className={cn(
                    'group block h-full rounded-2xl border border-white/8 bg-kyn-void/80 p-6 transition-all',
                    'hover:-translate-y-0.5 hover:border-kyn-green/30'
                  )}
                >
                  <div className="mb-4 flex items-start justify-between gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-xl border border-kyn-green/20 bg-kyn-green/10 text-kyn-green">
                      <Icon size={18} />
                    </div>
                    <span className="rounded-full border border-white/10 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider text-kyn-metal">
                      {m.tag}
                    </span>
                  </div>
                  <h3 className="font-display text-lg font-semibold group-hover:text-kyn-green">{m.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-kyn-metal">{m.desc}</p>
                  <span className="mt-4 inline-flex items-center gap-1 text-xs font-semibold text-kyn-green opacity-0 transition-opacity group-hover:opacity-100">
                    Open <ArrowRight size={12} />
                  </span>
                </Link>
              </motion.div>
            );
          })}
        </div>

        <GlassPanel className="mt-14 p-8 md:p-10">
          <div className="flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
            <div>
              <div className="mb-2 flex items-center gap-2 text-kyn-green">
                <Zap size={16} />
                <span className="text-xs font-semibold uppercase tracking-[0.2em]">Consistency rule</span>
              </div>
              <p className="max-w-xl font-display text-xl font-semibold md:text-2xl">
                Never fork the brand. New screens inherit tokens, glass cards, green accent and Space Grotesk / Inter.
              </p>
            </div>
            <Link to="/design-system/tokens">
              <Button size="lg">Token reference <ArrowRight size={16} /></Button>
            </Link>
          </div>
        </GlassPanel>
      </section>
    </div>
  );
}

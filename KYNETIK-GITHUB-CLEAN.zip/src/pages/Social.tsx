import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { QrCode } from 'lucide-react';
import SectionHeader from '../components/SectionHeader';
import LoadingState from '../components/LoadingState';
import ErrorState from '../components/ErrorState';
import Logo from '../components/Logo';
import { apiGet, cn } from '../lib/utils';

interface Template {
  id: number;
  title: string;
  platform: string;
  type: string;
  format: string;
  headline: string;
  subheadline: string;
  cta: string;
  theme: string;
  specs: string | null;
  sort_order: number;
}

function SocialPoster({ t }: { t: Template }) {
  const isLight = t.theme === 'light';
  const isStory = t.format.includes('1920');
  const isBanner = t.format.includes('1584') || t.format.includes('1200');
  const specs = t.specs ? (() => { try { return JSON.parse(t.specs) as string[]; } catch { return []; } })() : [];

  return (
    <div
      className={cn(
        'relative overflow-hidden poster-shadow rounded-xl',
        isLight ? 'bg-white text-kyn-black' : 'bg-kyn-void text-white',
        isStory ? 'aspect-[9/16]' : isBanner ? 'aspect-[2.5/1]' : 'aspect-square'
      )}
    >
      {/* Background effects */}
      {!isLight && (
        <>
          <div className="absolute inset-0 grid-bg opacity-60" />
          <div className="absolute -right-10 -top-10 w-48 h-48 rounded-full bg-kyn-green/20 blur-3xl" />
          <div className="absolute -left-10 bottom-0 w-40 h-40 rounded-full bg-kyn-green/10 blur-3xl" />
          {(t.type === 'product' || t.type === 'corporate') && (
            <img
              src={t.type === 'product' ? '/images/charger-wall.jpg' : '/images/hero-city.jpg'}
              alt=""
              className="absolute inset-0 w-full h-full object-cover opacity-25"
            />
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-kyn-black via-kyn-black/70 to-kyn-black/40" />
        </>
      )}
      {isLight && (
        <div className="absolute top-0 right-0 w-32 h-32 bg-kyn-green/10 rounded-full blur-2xl" />
      )}

      <div className={cn('relative z-10 h-full flex flex-col p-5 md:p-6', isBanner && 'p-4 md:p-5 flex-row items-center gap-6')}>
        <div className={cn(isBanner && 'shrink-0')}>
          <div className={isLight ? '[&_span]:text-kyn-black' : ''}>
            <Logo size="sm" glowing={!isLight} />
          </div>
        </div>

        {t.type === 'product' && !isBanner && (
          <div className="flex-1 flex items-center justify-center py-4">
            <div className="w-24 h-36 rounded-2xl bg-gradient-to-b from-kyn-graphite to-black border border-kyn-green/30 flex flex-col items-center justify-between py-4 glow-green">
              <div className="w-8 h-0.5 bg-kyn-green rounded-full" />
              <span className="text-kyn-green text-xs font-bold tracking-widest">NOVA</span>
              <div className="w-8 h-8 rounded-full border border-kyn-green flex items-center justify-center">
                <div className="w-3 h-3 rounded-full bg-kyn-green animate-pulse-glow" />
              </div>
            </div>
          </div>
        )}

        {t.type === 'educational' && (
          <div className="flex-1 flex flex-col justify-center py-4">
            <div className="w-10 h-10 rounded-full bg-kyn-green/15 border border-kyn-green/40 flex items-center justify-center text-kyn-green font-bold text-sm mb-3">
              0{t.sort_order}
            </div>
            <div className="space-y-2">
              {[1, 2, 3].map((n) => (
                <div key={n} className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-kyn-green" />
                  <div className={cn('h-1.5 rounded-full flex-1', isLight ? 'bg-black/10' : 'bg-white/10')} style={{ maxWidth: `${90 - n * 15}%` }} />
                </div>
              ))}
            </div>
          </div>
        )}

        {(t.type === 'corporate' || t.type === 'ad' || isBanner) && !isBanner && (
          <div className="flex-1" />
        )}

        <div className={cn(isBanner && 'flex-1')}>
          <h3 className={cn(
            'font-display font-bold leading-tight',
            isBanner ? 'text-lg md:text-xl' : isStory ? 'text-2xl' : 'text-xl md:text-2xl',
            isLight ? 'text-kyn-black' : 'text-white'
          )}>
            {t.headline}
          </h3>
          {t.subheadline && (
            <p className={cn('mt-2 text-sm', isLight ? 'text-kyn-graphite' : 'text-kyn-silver')}>
              {t.subheadline}
            </p>
          )}

          {specs.length > 0 && (
            <div className="mt-4 grid grid-cols-2 gap-2">
              {specs.map((s) => (
                <div key={s} className="rounded-lg bg-black/40 border border-kyn-green/20 px-2 py-1.5 text-[10px] font-medium text-kyn-green">
                  {s}
                </div>
              ))}
            </div>
          )}

          {t.cta && (
            <div className="mt-4 flex items-center gap-3">
              <span className={cn(
                'inline-flex px-4 py-2 rounded-full text-xs font-semibold',
                isLight ? 'bg-kyn-green text-kyn-black' : 'bg-kyn-green text-kyn-black'
              )}>
                {t.cta}
              </span>
              {t.type === 'ad' && (
                <div className={cn('w-8 h-8 rounded border flex items-center justify-center', isLight ? 'border-black/20' : 'border-white/20')}>
                  <QrCode size={14} />
                </div>
              )}
            </div>
          )}
        </div>

        <div className={cn('mt-auto pt-3 flex justify-between items-center', isBanner && 'mt-0 pt-0 flex-col items-end')}>
          <div className={cn('h-px flex-1 mr-3', isLight ? 'bg-kyn-green/40' : 'bg-kyn-green/50', isBanner && 'hidden')} />
          <span className={cn('text-[9px] tracking-[0.2em] uppercase', isLight ? 'text-kyn-graphite' : 'text-kyn-metal')}>
            {t.platform} · {t.format}
          </span>
        </div>
      </div>
    </div>
  );
}

export default function Social() {
  const [templates, setTemplates] = useState<Template[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [filter, setFilter] = useState('all');

  useEffect(() => {
    apiGet<Template[]>('/api/social-templates')
      .then(setTemplates)
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <div className="p-10"><LoadingState /></div>;
  if (error) return <div className="p-10"><ErrorState message={error} /></div>;

  const types = ['all', ...Array.from(new Set(templates.map((t) => t.type)))];
  const filtered = filter === 'all' ? templates : templates.filter((t) => t.type === filter);

  return (
    <div className="max-w-6xl mx-auto px-6 md:px-10 py-12 md:py-16">
      <SectionHeader
        eyebrow="03 · Social Media Kit"
        title="Campaign templates"
        description="Ready-to-adapt layouts for Instagram, Facebook and LinkedIn — corporate, product launch, Academy education and paid ads."
      />

      <div className="flex flex-wrap gap-2 mb-8">
        {types.map((type) => (
          <button
            key={type}
            type="button"
            onClick={() => setFilter(type)}
            className={cn(
              'px-4 py-2 rounded-full text-xs font-semibold capitalize transition-colors',
              filter === type
                ? 'bg-kyn-green text-kyn-black'
                : 'bg-kyn-steel text-kyn-silver hover:text-white'
            )}
          >
            {type}
          </button>
        ))}
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {filtered.map((t, i) => (
          <motion.div
            key={t.id}
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.04 }}
          >
            <p className="text-xs text-kyn-metal mb-2 font-medium">{t.title}</p>
            <SocialPoster t={t} />
          </motion.div>
        ))}
      </div>
    </div>
  );
}

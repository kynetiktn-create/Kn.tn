import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  ArrowRight, CheckCircle2, Smartphone, Globe, Cloud, Package, GraduationCap, Palette, Presentation, Share2, Briefcase, Play, Layers, Code2, Sparkles, Monitor
} from 'lucide-react';
import BrandLogo from '../components/BrandLogo';
import PhoneFrame from '../components/PhoneFrame';
import { SplashScreen, DashboardScreen, ChargingScreen, MapScreen } from '../components/mobile/screens';
import LiveDashboard from '../components/cloud/LiveDashboard';
import { apiGet } from '../lib/utils';

interface Product {
  id: number;
  name: string;
  image_url: string;
  power: string;
  accent: string;
  sort_order: number;
}

const milestones = [
  { n: '01', t: 'Brand Foundation', d: 'Logo, color, type, principles', ok: true },
  { n: '02', t: 'UI Tokens', d: 'Buttons, cards, spacing, radius', ok: true },
  { n: '03', t: 'Product System', d: 'GO · FLEX · NOVA · PRIME · EDGE · PRO', ok: true },
  { n: '04', t: 'Mobile App UX', d: 'Full customer journey screens', ok: true },
  { n: '05', t: 'Cloud Dashboard', d: 'Operator console SaaS', ok: true },
  { n: '06', t: 'Website UX', d: 'Marketing + product storytelling', ok: true },
  { n: '07', t: 'Academy Platform', d: 'Training & certification UI', ok: true },
  { n: '08', t: 'Social Media Kit', d: 'Campaign templates', ok: true },
  { n: '09', t: 'Investor Deck', d: 'Pitch narrative slides', ok: true },
  { n: '10', t: 'Stationery', d: 'Cards, letterhead, folder', ok: true },
  { n: '11', t: 'Interactive Prototype', d: 'Clickable multi-surface flows', ok: true },
  { n: '12', t: 'Design QA', d: 'Spacing, a11y, consistency', ok: true },
  { n: '13', t: 'Developer Handoff', d: 'Tokens, assets, routes', ok: true },
  { n: '14', t: 'Final Showcase', d: 'Investor-ready portfolio', ok: true },
  { n: '15', t: 'Production Assets', d: 'Library · motion · templates · QA', ok: true },
  { n: '18', t: 'Design System locked', d: 'Logo · palette · type · components · responsive', ok: true },
  { n: '19', t: 'Customer App', d: 'Portal · control · map · energy · account', ok: true },
  { n: '20', t: 'Cloud Platform B2B', d: 'Stations · fleet · OCPP · analytics', ok: true },
  { n: '21', t: 'Product Pages', d: 'GO→PRO hero · specs · install · CTA', ok: true },
  { n: '22', t: 'Dev Handoff Pack', d: 'API · DB · roadmap · tokens export', ok: true },
];

const surfaces = [
  { to: '/delivery', title: 'Digital Architecture', icon: Layers, desc: 'Phases 18–22 delivery hub' },
  { to: '/experience', title: 'Brand Experience', icon: Sparkles, desc: 'Cinematic final showcase' },
  { to: '/', title: 'Website', icon: Globe, desc: 'Public marketing homepage' },
  { to: '/products', title: 'Products', icon: Package, desc: 'GO · FLEX · NOVA · PRIME · EDGE · PRO' },
  { to: '/portal', title: 'Customer App', icon: Smartphone, desc: 'Account · chargers · map · energy' },
  { to: '/kynetik-app', title: 'Mobile App', icon: Smartphone, desc: 'Phase 19 full UX' },
  { to: '/cloud-platform', title: 'Cloud Platform', icon: Cloud, desc: 'Phase 20 B2B SaaS' },
  { to: '/console', title: 'Cloud Console', icon: Cloud, desc: 'B2B ops · OCPP · fleet' },
  { to: '/app-landing', title: 'App Landing', icon: Smartphone, desc: 'Driver marketing' },
  { to: '/academy', title: 'Academy', icon: GraduationCap, desc: 'Training platform' },
  { to: '/prototype', title: 'Prototype', icon: Play, desc: 'Interactive flows' },
  { to: '/dev-handoff', title: 'Dev Handoff', icon: Code2, desc: 'Tokens · API · DB · roadmap' },
  { to: '/components', title: 'UI Library', icon: Layers, desc: 'Component documentation' },
  { to: '/design-system', title: 'Design System', icon: Palette, desc: 'Full module map' },
];

export default function Showcase() {
  const [products, setProducts] = useState<Product[]>([]);
  const [phone, setPhone] = useState(0);

  useEffect(() => {
    apiGet<Product[]>('/api/products')
      .then((d) => setProducts(d.filter((p) => p.name && !p.name.includes('Archive')).slice(0, 6)))
      .catch(() => {});
  }, []);

  useEffect(() => {
    const t = setInterval(() => setPhone((p) => (p + 1) % 4), 2800);
    return () => clearInterval(t);
  }, []);

  const phones = [
    { label: 'Splash', ui: <SplashScreen /> },
    { label: 'Home', ui: <DashboardScreen /> },
    { label: 'Charging', ui: <ChargingScreen /> },
    { label: 'Map', ui: <MapScreen /> },
  ];

  return (
    <div className="min-h-screen bg-kyn-black text-white overflow-x-hidden">
      <header className="fixed top-0 inset-x-0 z-50 border-b border-white/5 bg-kyn-black/80 backdrop-blur-xl">
        <div className="max-w-7xl mx-auto px-5 md:px-8 h-16 flex items-center justify-between">
          <BrandLogo height={28} />
          <div className="flex items-center gap-3">
            <Link to="/experience" className="hidden sm:inline text-xs text-kyn-silver hover:text-white">Experience</Link>
            <Link to="/prototype" className="hidden sm:inline text-xs text-kyn-silver hover:text-white">Prototype</Link>
            <Link to="/handoff" className="hidden sm:inline text-xs text-kyn-silver hover:text-white">Handoff</Link>
            <a
              href="mailto:hello@kynetik.tn"
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-full bg-kyn-green text-kyn-black text-xs font-bold"
            >
              Contact <ArrowRight size={12} />
            </a>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="relative pt-28 pb-20 md:pt-36 md:pb-28">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(0,230,118,0.14),transparent_55%)]" />
        <div className="absolute inset-0 grid-bg opacity-30" />
        <div className="relative z-10 max-w-7xl mx-auto px-5 md:px-8">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="max-w-3xl">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-kyn-green/30 bg-kyn-green/10 text-kyn-green text-[11px] font-semibold mb-6">
              <Sparkles size={12} /> Final · Premium Brand Experience
            </div>
            <h1 className="font-display text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold leading-[1.05] tracking-tight">
              KYNETIK
              <br />
              <span className="text-kyn-green text-glow">Complete Design System</span>
            </h1>
            <p className="mt-6 text-lg text-kyn-silver leading-relaxed max-w-2xl">
              Identité visuelle, produit hardware, application mobile, Cloud SaaS, Academy et handoff développement —
              un système prêt investisseurs et prêt build.
            </p>
            <div className="mt-10 flex flex-wrap gap-3">
              <Link to="/experience" className="inline-flex items-center gap-2 px-6 py-3.5 rounded-full bg-kyn-green text-kyn-black text-sm font-bold glow-green">
                Launch brand experience <Play size={16} />
              </Link>
              <Link to="/" className="inline-flex items-center gap-2 px-6 py-3.5 rounded-full border border-white/15 text-sm font-medium">
                Open website
              </Link>
            </div>
          </motion.div>

          <div className="mt-14 grid grid-cols-2 md:grid-cols-4 gap-3 max-w-3xl">
            {[
              { v: '14', l: 'Phases complete' },
              { v: '5', l: 'Product series' },
              { v: '3', l: 'Digital surfaces' },
              { v: '1', l: 'Brand system' },
            ].map((s) => (
              <div key={s.l} className="rounded-2xl border border-white/8 bg-white/[0.03] p-4">
                <p className="font-display text-2xl font-bold text-kyn-green">{s.v}</p>
                <p className="text-[11px] text-kyn-metal mt-1">{s.l}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Multi-device demo */}
      <section className="py-20 md:py-28 border-t border-white/5 bg-kyn-void">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <p className="text-kyn-green text-xs font-semibold tracking-[0.3em] uppercase mb-3">Demo stage</p>
          <h2 className="font-display text-3xl md:text-4xl font-bold mb-12">App · Web · Console</h2>

          <div className="grid lg:grid-cols-[280px_1fr] gap-10 items-center">
            <div className="flex justify-center">
              <PhoneFrame label={phones[phone].label} width={240}>
                {phones[phone].ui}
              </PhoneFrame>
            </div>
            <div>
              <div className="mb-6 flex items-center gap-2 text-xs text-kyn-metal">
                <Monitor size={14} className="text-kyn-green" /> Desktop console preview
              </div>
              <LiveDashboard />
              <div className="mt-6 flex flex-wrap gap-2">
                {phones.map((p, i) => (
                  <button
                    key={p.label}
                    type="button"
                    onClick={() => setPhone(i)}
                    className={`px-3 py-1.5 rounded-full text-[11px] font-semibold ${
                      phone === i ? 'bg-kyn-green text-kyn-black' : 'bg-kyn-steel text-kyn-silver'
                    }`}
                  >
                    {p.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Products strip */}
      <section className="py-20 md:py-24 border-t border-white/5">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <div className="flex flex-wrap items-end justify-between gap-4 mb-10">
            <div>
              <p className="text-kyn-green text-xs font-semibold tracking-[0.3em] uppercase mb-3">Hardware</p>
              <h2 className="font-display text-3xl font-bold">Product family</h2>
            </div>
            <Link to="/product-system" className="text-sm text-kyn-green inline-flex items-center gap-1">
              Product System <ArrowRight size={14} />
            </Link>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
            {products.map((p) => (
              <div key={p.id} className="rounded-2xl border border-white/8 bg-kyn-void p-3 text-center">
                <div className="h-28 flex items-center justify-center mb-2">
                  <img src={p.image_url} alt={p.name} className="max-h-full w-auto object-contain" />
                </div>
                <p className="text-xs font-semibold truncate">{p.name}</p>
                <p className="text-[10px] mt-0.5" style={{ color: p.accent || '#00e676' }}>{p.power}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Surfaces */}
      <section className="py-20 md:py-24 border-t border-white/5 bg-kyn-void">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <h2 className="font-display text-3xl font-bold mb-10">Explore every surface</h2>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {surfaces.map((s) => {
              const Icon = s.icon;
              return (
                <Link
                  key={s.to}
                  to={s.to}
                  className="group rounded-2xl border border-white/8 bg-black/30 p-6 hover:border-kyn-green/35 transition-all hover:-translate-y-0.5"
                >
                  <Icon className="text-kyn-green mb-4 group-hover:scale-110 transition-transform" size={22} />
                  <p className="font-display font-semibold text-lg group-hover:text-kyn-green transition-colors">{s.title}</p>
                  <p className="text-sm text-kyn-metal mt-2">{s.desc}</p>
                </Link>
              );
            })}
          </div>
        </div>
      </section>

      {/* Roadmap complete */}
      <section className="py-20 md:py-28 border-t border-white/5">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <p className="text-kyn-green text-xs font-semibold tracking-[0.3em] uppercase mb-3">Project map</p>
          <h2 className="font-display text-3xl md:text-4xl font-bold mb-10">14 / 14 phases delivered</h2>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
            {milestones.map((m) => (
              <div key={m.n} className="rounded-2xl border border-kyn-green/20 bg-kyn-green/[0.04] p-4 flex gap-3">
                <CheckCircle2 className="text-kyn-green shrink-0" size={18} />
                <div>
                  <p className="text-[10px] font-mono text-kyn-green">{m.n}</p>
                  <p className="font-semibold text-sm mt-0.5">{m.t}</p>
                  <p className="text-[11px] text-kyn-metal mt-1">{m.d}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Brand strip */}
      <section className="py-16 border-t border-white/5 bg-kyn-void">
        <div className="max-w-7xl mx-auto px-5 md:px-8 flex flex-wrap gap-6 justify-center md:justify-between items-center">
          {[
            { icon: Palette, l: 'Brand' },
            { icon: Share2, l: 'Social' },
            { icon: Presentation, l: 'Investors' },
            { icon: Briefcase, l: 'Stationery' },
            { icon: Layers, l: 'Tokens' },
          ].map(({ icon: Icon, l }) => (
            <div key={l} className="flex items-center gap-2 text-kyn-silver text-sm">
              <Icon size={16} className="text-kyn-green" /> {l}
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="py-24 md:py-32 relative">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(0,230,118,0.12),transparent_55%)]" />
        <div className="relative z-10 max-w-3xl mx-auto px-5 text-center">
          <BrandLogo height={40} className="mx-auto justify-center" />
          <h2 className="mt-8 font-display text-3xl md:text-5xl font-bold">
            L'énergie en mouvement
          </h2>
          <p className="mt-4 text-kyn-silver">
            Design system complet — prêt pour pitch, partenariats et développement produit.
          </p>
          <div className="mt-10 flex flex-wrap justify-center gap-3">
            <Link to="/prototype" className="inline-flex items-center gap-2 px-8 py-4 rounded-full bg-kyn-green text-kyn-black text-sm font-bold glow-green">
              Interactive Prototype
            </Link>
            <Link to="/handoff" className="inline-flex items-center gap-2 px-8 py-4 rounded-full border border-white/15 text-sm font-medium">
              Developer Handoff
            </Link>
          </div>
        </div>
      </section>

      <footer className="border-t border-white/5 py-8">
        <div className="max-w-7xl mx-auto px-5 md:px-8 flex flex-wrap justify-between gap-4 text-[11px] text-kyn-metal">
          <BrandLogo height={24} />
          <p>© KYNETIK — Design System Showcase · Tunisia</p>
        </div>
      </footer>
    </div>
  );
}

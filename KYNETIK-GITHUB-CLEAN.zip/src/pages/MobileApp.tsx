import { useEffect, useState, type ReactNode } from 'react';
import { motion } from 'framer-motion';
import SectionHeader from '../components/SectionHeader';
import LoadingState from '../components/LoadingState';
import ErrorState from '../components/ErrorState';
import PhoneFrame from '../components/PhoneFrame';
import type { AppTab } from '../components/AppBottomNav';
import {
  SplashScreen, OnboardingScreen, AuthScreen, DashboardScreen, ChargingScreen,
  StationScreen, MapScreen, AnalyticsScreen, PaymentsScreen, ProfileScreen, DesignTokensMini,
} from '../components/mobile/screens';
import {
  SignupScreen, FindChargerScreen, ChargerDetailsScreen, QrScanScreen, StartChargingScreen,
  ChargingLiveScreen, PauseResumeScreen, StopChargingScreen, ChargingSummaryScreen,
  PaymentMethodsScreen, WalletScreen, SubscriptionScreen, HistoryScreen, NotificationsScreen,
  FavoritesScreen, VehiclesScreen, RfidScreen, SupportScreen, ChatSupportScreen, TicketsScreen,
  SettingsScreen, LanguageScreen, ThemeScreen, PrivacyScreen, SecurityScreen, AboutScreen,
} from '../components/mobile/screensExtra';
import AppDownloadCTA from '../components/AppDownloadCTA';
import { apiGet, cn } from '../lib/utils';

interface UxScreen {
  id: number;
  name: string;
  slug: string;
  platform: string;
  flow: string;
  description: string;
  components: string;
  sort_order: number;
}

const screenMap: Record<string, (props: { onNav?: (t: AppTab) => void }) => ReactNode> = {
  splash: () => <SplashScreen />,
  onboarding_1: () => <OnboardingScreen page={1} />,
  onboarding_2: () => <OnboardingScreen page={2} />,
  onboarding_3: () => <OnboardingScreen page={3} />,
  auth: () => <AuthScreen />,
  signup: () => <SignupScreen />,
  dashboard: ({ onNav }) => <DashboardScreen onNav={onNav} />,
  charging: () => <ChargingScreen />,
  stations: ({ onNav }) => <StationScreen onNav={onNav} />,
  map: ({ onNav }) => <MapScreen onNav={onNav} />,
  analytics: ({ onNav }) => <AnalyticsScreen onNav={onNav} />,
  payments: () => <PaymentsScreen />,
  profile: ({ onNav }) => <ProfileScreen onNav={onNav} />,
  tokens: () => <DesignTokensMini />,
  find_charger: ({ onNav }) => <FindChargerScreen onNav={onNav} />,
  charger_details: () => <ChargerDetailsScreen />,
  qr_scan: () => <QrScanScreen />,
  start_charging: () => <StartChargingScreen />,
  charging_live: () => <ChargingLiveScreen />,
  pause_resume: () => <PauseResumeScreen />,
  stop_charging: () => <StopChargingScreen />,
  charging_summary: () => <ChargingSummaryScreen />,
  payment_methods: () => <PaymentMethodsScreen />,
  wallet: () => <WalletScreen />,
  subscription: () => <SubscriptionScreen />,
  history: ({ onNav }) => <HistoryScreen onNav={onNav} />,
  notifications: () => <NotificationsScreen />,
  favorites: () => <FavoritesScreen />,
  vehicles: () => <VehiclesScreen />,
  rfid: () => <RfidScreen />,
  support: () => <SupportScreen />,
  chat_support: () => <ChatSupportScreen />,
  tickets: () => <TicketsScreen />,
  settings: () => <SettingsScreen />,
  language: () => <LanguageScreen />,
  theme: () => <ThemeScreen />,
  privacy: () => <PrivacyScreen />,
  security: () => <SecurityScreen />,
  about: () => <AboutScreen />,
};

const interactiveTabs: Record<AppTab, string> = {
  home: 'dashboard',
  chargers: 'stations',
  map: 'find_charger',
  analytics: 'history',
  profile: 'profile',
};

export default function MobileApp() {
  const [screens, setScreens] = useState<UxScreen[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [activeSlug, setActiveSlug] = useState('dashboard');
  const [flowFilter, setFlowFilter] = useState('all');

  useEffect(() => {
    apiGet<UxScreen[]>('/api/ux-screens?platform=mobile')
      .then((data) => {
        setScreens(data);
        if (data[0]) setActiveSlug(data.find((s) => s.slug === 'dashboard')?.slug || data[0].slug);
      })
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <div className="p-10"><LoadingState label="Loading complete mobile UX…" /></div>;
  if (error) return <div className="p-10"><ErrorState message={error} /></div>;

  const flows = ['all', ...Array.from(new Set(screens.map((s) => s.flow)))];
  const filtered = flowFilter === 'all' ? screens : screens.filter((s) => s.flow === flowFilter);
  const active = screens.find((s) => s.slug === activeSlug) || screens[0];
  const ActiveUI = screenMap[activeSlug] || (() => <SplashScreen />);

  const handleNav = (tab: AppTab) => setActiveSlug(interactiveTabs[tab]);

  const parseComponents = (raw: string) => {
    try { return JSON.parse(raw) as string[]; } catch { return []; }
  };

  const completion = Math.round((screens.filter((s) => s.slug !== 'tokens').length / 36) * 100);

  return (
    <div className="max-w-7xl mx-auto px-6 md:px-10 py-12 md:py-16">
      <SectionHeader
        eyebrow="Mobile App UX · 100% customer journey"
        title="Complete KYNETIK application"
        description="Full driver app: onboarding, find & charge, wallet, RFID, vehicles, support, settings — premium dark Tesla-grade UI ready for investor demo."
      />

      <div className="mb-8 glass-card rounded-2xl p-5 flex flex-wrap items-center gap-6">
        <div>
          <p className="text-[10px] text-kyn-metal uppercase tracking-wider">Screen coverage</p>
          <p className="font-display text-3xl font-bold text-kyn-green">{screens.length}</p>
        </div>
        <div className="flex-1 min-w-[180px]">
          <div className="flex justify-between text-[10px] text-kyn-metal mb-1">
            <span>Completion</span>
            <span className="text-kyn-green font-semibold">{Math.min(completion, 100)}%</span>
          </div>
          <div className="h-2 rounded-full bg-kyn-graphite overflow-hidden">
            <div className="h-full bg-kyn-green rounded-full" style={{ width: `${Math.min(completion, 100)}%` }} />
          </div>
        </div>
        <div className="text-xs text-kyn-silver">
          Flows: entry · charge · account · support · system
        </div>
      </div>

      <div className="grid lg:grid-cols-[320px_1fr] gap-10 mb-16">
        <div className="flex justify-center lg:sticky lg:top-8 lg:self-start">
          <motion.div key={activeSlug} initial={{ opacity: 0.6, scale: 0.98 }} animate={{ opacity: 1, scale: 1 }}>
            <PhoneFrame label={active?.name}>
              <ActiveUI onNav={handleNav} />
            </PhoneFrame>
          </motion.div>
        </div>

        <div>
          <div className="flex flex-wrap gap-2 mb-6">
            {flows.map((f) => (
              <button
                key={f}
                type="button"
                onClick={() => setFlowFilter(f)}
                className={cn(
                  'px-3 py-1.5 rounded-full text-xs font-semibold capitalize',
                  flowFilter === f ? 'bg-kyn-green text-kyn-black' : 'bg-kyn-steel text-kyn-silver'
                )}
              >
                {f.replace(/_/g, ' ')}
              </button>
            ))}
          </div>

          <div className="grid sm:grid-cols-2 gap-3 mb-8 max-h-[560px] overflow-y-auto pr-1">
            {filtered.map((s) => (
              <button
                key={s.id}
                type="button"
                onClick={() => setActiveSlug(s.slug)}
                className={cn(
                  'text-left glass-card rounded-2xl p-4 transition-all hover:border-kyn-green/30',
                  activeSlug === s.slug && 'border-kyn-green/40 glow-green'
                )}
              >
                <div className="flex items-center justify-between gap-2">
                  <p className="font-display font-semibold text-sm">{s.name}</p>
                  <span className="text-[9px] uppercase tracking-wider text-kyn-green shrink-0">{s.flow}</span>
                </div>
                <p className="text-xs text-kyn-metal mt-2 leading-relaxed line-clamp-2">{s.description}</p>
              </button>
            ))}
          </div>

          {active && (
            <div className="glass-card rounded-2xl p-6">
              <p className="text-xs text-kyn-green uppercase tracking-widest font-semibold">Screen spec</p>
              <h3 className="font-display text-xl font-bold mt-1">{active.name}</h3>
              <p className="text-sm text-kyn-silver mt-2">{active.description}</p>
              <div className="mt-4 flex flex-wrap gap-2">
                {parseComponents(active.components).map((c) => (
                  <span key={c} className="px-2.5 py-1 rounded-lg bg-kyn-steel border border-white/8 text-[10px] text-kyn-silver">{c}</span>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      <p className="text-kyn-green text-xs font-semibold tracking-[0.2em] uppercase mb-4">Full gallery</p>
      <div className="flex gap-6 overflow-x-auto pb-6 snap-x">
        {screens.filter((s) => s.slug !== 'tokens').map((s, i) => {
          const UI = screenMap[s.slug] || (() => <SplashScreen />);
          return (
            <motion.button
              key={s.id}
              type="button"
              onClick={() => setActiveSlug(s.slug)}
              className="snap-center shrink-0 text-left"
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: Math.min(i * 0.02, 0.4) }}
            >
              <PhoneFrame width={180} label={s.name}>
                <UI onNav={handleNav} />
              </PhoneFrame>
            </motion.button>
          );
        })}
      </div>

      <div className="mt-16 -mx-6 md:-mx-10">
        <AppDownloadCTA accent="#00e676" />
      </div>
    </div>
  );
}

import { useEffect, useMemo, useState, type ComponentType, type ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  ArrowRight, Users, Target, Package, Wrench, GitBranch, BarChart3,
  Handshake, Award, LifeBuoy, Wallet, Menu, X, CheckCircle2, Briefcase,
  Home, Building2, Factory, Hotel, Landmark, HardHat, Phone, Mail,
  MessageCircle, Smartphone, Cloud, GraduationCap, TrendingUp, Zap,
  FileText, Shield, Rocket, ChevronRight, Headphones, Settings2
} from 'lucide-react';
import BrandLogo from '../components/BrandLogo';
import LoadingState from '../components/LoadingState';
import { apiGet, cn } from '../lib/utils';

interface Item {
  id: number;
  type: string;
  category: string;
  title: string;
  subtitle: string;
  body: string;
  meta: string | null;
  sort_order: number;
}

const TOC = [
  { id: 'team', label: 'Équipe', icon: Users },
  { id: 'segments', label: 'Segments', icon: Target },
  { id: 'packs', label: 'Packages', icon: Package },
  { id: 'services', label: 'Services', icon: Wrench },
  { id: 'journey', label: 'Parcours client', icon: GitBranch },
  { id: 'kpis', label: 'KPIs', icon: BarChart3 },
  { id: 'partners', label: 'Partenaires', icon: Handshake },
  { id: 'tiers', label: 'Programme', icon: Award },
  { id: 'support', label: 'Support', icon: LifeBuoy },
  { id: 'revenue', label: 'Revenus', icon: Wallet },
];

const segmentIcons: Record<string, ComponentType<{ size?: number; className?: string }>> = {
  Résidentiel: Home,
  PME: Building2,
  'Grandes entreprises': Factory,
  'Hôtels & Tourisme': Hotel,
  'Promoteurs immobiliers': HardHat,
  Collectivités: Landmark,
};

const supportIcons: Record<string, ComponentType<{ size?: number; className?: string }>> = {
  Téléphone: Phone,
  Email: Mail,
  'WhatsApp Business': MessageCircle,
  'Portail App': Smartphone,
  'Cloud Tickets': Cloud,
};

function Fade({ children, className, delay = 0 }: { children: ReactNode; className?: string; delay?: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-50px' }}
      transition={{ duration: 0.55, delay, ease: [0.22, 1, 0.36, 1] }}
      className={className}
    >
      {children}
    </motion.div>
  );
}

function SectionLabel({ children }: { children: ReactNode }) {
  return (
    <p className="inline-flex items-center gap-2 text-kyn-green text-[11px] font-semibold tracking-[0.28em] uppercase mb-4">
      <span className="w-6 h-px bg-kyn-green/70" />
      {children}
    </p>
  );
}

export default function SalesSystem() {
  const [items, setItems] = useState<Item[]>([]);
  const [loading, setLoading] = useState(true);
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    apiGet<Item[]>('/api/marketing-content?type=sales_system')
      .then((d) => setItems((d || []).sort((a, b) => a.sort_order - b.sort_order)))
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const by = (cat: string) => items.filter((i) => i.category === cat);

  const roles = by('role');
  const segments = by('segment');
  const packs = by('pack');
  const services = by('service');
  const journey = by('journey');
  const kpis = by('kpi');
  const partners = by('partner_type');
  const tiers = by('tier');
  const support = by('support');
  const revenue = by('revenue');

  const packFallback = [
    { title: 'Pack Home', subtitle: 'Particuliers', body: 'Chargeur + installation + configuration + garantie + formation utilisateur.', meta: 'B2C' },
    { title: 'Pack Business', subtitle: 'PME & sites pro', body: 'Plusieurs chargeurs + Cloud + dashboard + support.', meta: 'B2B' },
    { title: 'Pack Enterprise', subtitle: 'Grands comptes', body: 'Étude + design + installation + maintenance + reporting.', meta: 'ENT' },
  ];

  const displayPacks = packs.length ? packs : packFallback.map((p, i) => ({ id: i, ...p, type: 'sales_system', category: 'pack', sort_order: i } as Item));

  if (loading) {
    return (
      <div className="min-h-screen bg-kyn-black flex items-center justify-center">
        <LoadingState label="Chargement Sales System…" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-kyn-black text-white overflow-x-hidden">
      <header
        className={cn(
          'fixed top-0 inset-x-0 z-50 transition-all duration-300',
          scrolled ? 'bg-kyn-black/90 backdrop-blur-xl border-b border-white/5' : 'bg-transparent'
        )}
      >
        <div className="max-w-7xl mx-auto px-5 md:px-8 h-16 md:h-20 flex items-center justify-between gap-4">
          <Link to="/" className="flex items-center gap-3">
            <BrandLogo height={30} />
            <span className="hidden sm:inline text-[10px] font-semibold tracking-[0.2em] uppercase text-kyn-green border border-kyn-green/30 rounded-full px-2 py-0.5">
              Phase 23 · Sales
            </span>
          </Link>
          <nav className="hidden xl:flex items-center gap-5 text-[11px] font-medium text-kyn-silver">
            {TOC.slice(0, 6).map((t) => (
              <a key={t.id} href={`#${t.id}`} className="hover:text-white transition-colors">
                {t.label}
              </a>
            ))}
          </nav>
          <div className="flex items-center gap-2">
            <Link
              to="/quote"
              className="hidden sm:inline-flex items-center gap-2 px-4 py-2 rounded-full bg-kyn-green text-kyn-black text-xs font-bold"
            >
              Demander un devis <ArrowRight size={14} />
            </Link>
            <button type="button" className="xl:hidden p-2 text-kyn-silver" onClick={() => setMenuOpen(!menuOpen)} aria-label="Menu">
              {menuOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </div>
        {menuOpen && (
          <div className="xl:hidden border-t border-white/5 bg-kyn-void/98 backdrop-blur-xl px-5 py-4 grid grid-cols-2 gap-2">
            {TOC.map((t) => (
              <a
                key={t.id}
                href={`#${t.id}`}
                onClick={() => setMenuOpen(false)}
                className="flex items-center gap-2 rounded-xl border border-white/8 px-3 py-2.5 text-xs text-kyn-silver hover:border-kyn-green/30"
              >
                <t.icon size={14} className="text-kyn-green" /> {t.label}
              </a>
            ))}
          </div>
        )}
      </header>

      {/* HERO */}
      <section className="relative pt-28 md:pt-36 pb-16 md:pb-24 overflow-hidden">
        <div className="absolute inset-0 grid-bg opacity-30" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,rgba(0,230,118,0.14),transparent_50%)]" />
        <div className="absolute bottom-0 inset-x-0 h-40 bg-gradient-to-t from-kyn-black to-transparent" />
        <div className="relative z-10 max-w-7xl mx-auto px-5 md:px-8">
          <Fade>
            <p className="text-kyn-green text-xs font-semibold tracking-[0.32em] uppercase mb-5">Phase 23 · Commercial System</p>
            <h1 className="font-display text-4xl sm:text-5xl md:text-7xl font-bold leading-[1.05] max-w-4xl">
              Sales System &
              <br />
              <span className="text-kyn-green text-glow">Commercial Strategy</span>
            </h1>
            <p className="mt-6 text-lg md:text-xl text-kyn-silver max-w-2xl leading-relaxed">
              Relier produit, marketing et résultats financiers — une machine commerciale qui vend des
              <strong className="text-white font-semibold"> solutions et des services récurrents</strong>, pas seulement des bornes.
            </p>
            <div className="mt-9 flex flex-wrap gap-3">
              <a href="#packs" className="inline-flex items-center gap-2 px-6 py-3.5 rounded-full bg-kyn-green text-kyn-black text-sm font-bold glow-green">
                Voir les packages <ArrowRight size={16} />
              </a>
              <Link to="/brand-launch" className="inline-flex items-center gap-2 px-6 py-3.5 rounded-full border border-white/15 text-sm font-semibold hover:border-kyn-green/40">
                Brand Launch GTM
              </Link>
              <Link to="/installers" className="inline-flex items-center gap-2 px-6 py-3.5 rounded-full border border-white/15 text-sm font-semibold hover:border-kyn-green/40">
                Réseau partenaires
              </Link>
            </div>
          </Fade>

          <div className="mt-14 grid grid-cols-2 lg:grid-cols-4 gap-3">
            {[
              { t: 'Équipe lean', d: '4 rôles scalables', icon: Users },
              { t: '6 segments', d: 'B2C → Collectivités', icon: Target },
              { t: '3 packages', d: 'Home · Business · ENT', icon: Package },
              { t: '6 flux revenus', d: 'HW + SaaS + Services', icon: Wallet },
            ].map(({ t, d, icon: Icon }, i) => (
              <Fade key={t} delay={i * 0.05}>
                <div className="rounded-2xl border border-white/10 bg-kyn-void/80 p-5 h-full">
                  <Icon className="text-kyn-green mb-3" size={18} />
                  <p className="font-display font-semibold">{t}</p>
                  <p className="text-xs text-kyn-metal mt-1">{d}</p>
                </div>
              </Fade>
            ))}
          </div>
        </div>
      </section>

      {/* TEAM */}
      <section id="team" className="py-20 md:py-28 border-t border-white/5 scroll-mt-24">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <Fade>
            <SectionLabel>01 · Structure commerciale</SectionLabel>
            <h2 className="font-display text-3xl md:text-5xl font-bold max-w-2xl">Une équipe simple, prête à scaler</h2>
            <p className="mt-4 text-kyn-silver max-w-xl">Au démarrage : quatre fonctions. Ensuite, spécialisation par segment et région.</p>
          </Fade>
          <div className="mt-12 grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {(roles.length
              ? roles
              : [
                  { title: 'Business Development Manager', body: 'Partenariats et marchés.', meta: 'BDM', subtitle: '', id: 1, type: '', category: '', sort_order: 0 },
                  { title: 'Sales Engineer', body: 'Besoin + offre technique.', meta: 'SE', subtitle: '', id: 2, type: '', category: '', sort_order: 0 },
                  { title: 'Customer Success', body: 'Post-install et upsell.', meta: 'CS', subtitle: '', id: 3, type: '', category: '', sort_order: 0 },
                  { title: 'Technical Support', body: 'Interventions et tickets.', meta: 'TS', subtitle: '', id: 4, type: '', category: '', sort_order: 0 },
                ]
            ).map((r, i) => (
              <Fade key={r.title} delay={i * 0.05}>
                <div className="rounded-2xl border border-white/10 bg-gradient-to-b from-white/[0.04] to-transparent p-6 h-full hover:border-kyn-green/30 transition-colors">
                  <div className="w-11 h-11 rounded-xl bg-kyn-green/10 border border-kyn-green/25 flex items-center justify-center text-kyn-green font-display font-bold text-sm mb-4">
                    {r.meta || `0${i + 1}`}
                  </div>
                  <h3 className="font-display font-semibold text-lg leading-snug">{r.title}</h3>
                  <p className="mt-3 text-sm text-kyn-metal leading-relaxed">{r.body}</p>
                </div>
              </Fade>
            ))}
          </div>
        </div>
      </section>

      {/* SEGMENTS */}
      <section id="segments" className="py-20 md:py-28 bg-kyn-void border-y border-white/5 scroll-mt-24">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <Fade>
            <SectionLabel>02 · Segmentation</SectionLabel>
            <h2 className="font-display text-3xl md:text-5xl font-bold">Un marché, six réalités</h2>
            <p className="mt-4 text-kyn-silver max-w-xl">Pas d’offre unique : chaque segment a ses produits, arguments et cycle de vente.</p>
          </Fade>
          <div className="mt-12 grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {segments.map((s, i) => {
              const Icon = segmentIcons[s.title] || Target;
              const products = (s.meta || '').split(',').filter(Boolean);
              return (
                <Fade key={s.id} delay={i * 0.04}>
                  <div className="rounded-2xl border border-white/10 bg-black/40 p-6 h-full flex flex-col hover:border-kyn-green/30 transition-colors">
                    <div className="flex items-start justify-between gap-3">
                      <div className="w-10 h-10 rounded-xl bg-kyn-green/10 border border-kyn-green/20 flex items-center justify-center text-kyn-green">
                        <Icon size={18} />
                      </div>
                      <div className="flex flex-wrap gap-1 justify-end">
                        {products.map((p) => (
                          <span key={p} className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-kyn-green/10 text-kyn-green border border-kyn-green/20">
                            {p.trim()}
                          </span>
                        ))}
                      </div>
                    </div>
                    <h3 className="font-display text-xl font-bold mt-4">{s.title}</h3>
                    <p className="text-xs text-kyn-green/80 mt-1">{s.subtitle}</p>
                    <p className="mt-3 text-sm text-kyn-metal leading-relaxed flex-1">{s.body}</p>
                    <Link to="/products" className="mt-4 inline-flex items-center gap-1 text-xs font-semibold text-kyn-green">
                      Voir les produits <ChevronRight size={14} />
                    </Link>
                  </div>
                </Fade>
              );
            })}
          </div>
        </div>
      </section>

      {/* PACKS */}
      <section id="packs" className="py-20 md:py-28 scroll-mt-24">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <Fade>
            <SectionLabel>03 · Commercial packages</SectionLabel>
            <h2 className="font-display text-3xl md:text-5xl font-bold">Trois packs clairs pour vendre vite</h2>
          </Fade>
          <div className="mt-12 grid lg:grid-cols-3 gap-5">
            {displayPacks.map((p, i) => {
              const featured = i === 1;
              return (
                <Fade key={p.title} delay={i * 0.06}>
                  <div
                    className={cn(
                      'relative rounded-3xl border p-7 md:p-8 h-full flex flex-col',
                      featured
                        ? 'border-kyn-green/40 bg-gradient-to-b from-kyn-green/10 to-kyn-void shadow-[0_0_60px_rgba(0,230,118,0.08)]'
                        : 'border-white/10 bg-kyn-void'
                    )}
                  >
                    {featured && (
                      <span className="absolute -top-3 left-6 text-[10px] font-bold uppercase tracking-wider px-3 py-1 rounded-full bg-kyn-green text-kyn-black">
                        Recommandé B2B
                      </span>
                    )}
                    <p className="text-[11px] uppercase tracking-wider text-kyn-metal font-semibold">{p.meta || p.subtitle}</p>
                    <h3 className="font-display text-2xl md:text-3xl font-bold mt-2">{p.title}</h3>
                    <p className="text-sm text-kyn-green mt-1">{p.subtitle}</p>
                    <p className="mt-5 text-kyn-silver leading-relaxed flex-1">{p.body}</p>
                    <ul className="mt-6 space-y-2.5">
                      {(i === 0
                        ? ['Chargeur adapté', 'Installation', 'Configuration', 'Garantie', 'Formation user']
                        : i === 1
                          ? ['Multi-chargeurs', 'KYNETIK Cloud', 'Dashboard ops', 'Support prioritaire']
                          : ['Étude de site', 'Design infrastructure', 'Déploiement', 'Maintenance', 'Reporting']
                      ).map((f) => (
                        <li key={f} className="flex items-center gap-2 text-sm text-kyn-silver">
                          <CheckCircle2 size={14} className="text-kyn-green shrink-0" /> {f}
                        </li>
                      ))}
                    </ul>
                    <Link
                      to="/quote"
                      className={cn(
                        'mt-8 inline-flex items-center justify-center gap-2 w-full py-3.5 rounded-full text-sm font-bold transition-colors',
                        featured ? 'bg-kyn-green text-kyn-black hover:bg-kyn-green-glow' : 'border border-white/15 hover:border-kyn-green/40'
                      )}
                    >
                      Configurer un devis <ArrowRight size={16} />
                    </Link>
                  </div>
                </Fade>
              );
            })}
          </div>
        </div>
      </section>

      {/* SERVICES */}
      <section id="services" className="py-20 md:py-28 bg-kyn-void border-y border-white/5 scroll-mt-24">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <Fade>
            <SectionLabel>04 · Services complémentaires</SectionLabel>
            <h2 className="font-display text-3xl md:text-5xl font-bold">Au-delà de la vente hardware</h2>
            <p className="mt-4 text-kyn-silver max-w-xl">Chaque service augmente la marge et la rétention.</p>
          </Fade>
          <div className="mt-12 grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {services.map((s, i) => (
              <Fade key={s.id} delay={i * 0.04}>
                <div className="rounded-2xl border border-white/10 bg-black/30 p-5 flex gap-4 hover:border-kyn-green/25 transition-colors">
                  <div className="w-10 h-10 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-kyn-green shrink-0">
                    <Settings2 size={16} />
                  </div>
                  <div>
                    <p className="font-display font-semibold">{s.title}</p>
                    <p className="text-sm text-kyn-metal mt-1.5 leading-relaxed">{s.body}</p>
                  </div>
                </div>
              </Fade>
            ))}
          </div>
        </div>
      </section>

      {/* JOURNEY */}
      <section id="journey" className="py-20 md:py-28 scroll-mt-24">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <Fade>
            <SectionLabel>05 · Customer journey</SectionLabel>
            <h2 className="font-display text-3xl md:text-5xl font-bold">Du premier clic au contrat de maintenance</h2>
          </Fade>
          <div className="mt-12 relative">
            <div className="hidden lg:block absolute top-8 left-8 right-8 h-px bg-gradient-to-r from-kyn-green/0 via-kyn-green/40 to-kyn-green/0" />
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
              {journey.map((j, i) => (
                <Fade key={j.id} delay={i * 0.03}>
                  <div className="relative rounded-2xl border border-white/10 bg-kyn-void p-5 h-full">
                    <div className="w-8 h-8 rounded-full bg-kyn-green text-kyn-black text-xs font-bold flex items-center justify-center mb-3 relative z-10">
                      {j.meta || i + 1}
                    </div>
                    <h3 className="font-display font-semibold text-sm">{j.title}</h3>
                    <p className="mt-2 text-xs text-kyn-metal leading-relaxed">{j.body}</p>
                  </div>
                </Fade>
              ))}
            </div>
          </div>
          <Fade delay={0.1}>
            <div className="mt-10 rounded-2xl border border-kyn-green/20 bg-kyn-green/5 p-6 flex flex-wrap items-center justify-between gap-4">
              <div>
                <p className="font-semibold">Outils déjà en place dans le produit digital</p>
                <p className="text-sm text-kyn-metal mt-1">Quote wizard · Leads CRM · Portal tickets · Cloud ops · Academy</p>
              </div>
              <div className="flex flex-wrap gap-2">
                <Link to="/quote" className="px-4 py-2 rounded-full bg-kyn-green text-kyn-black text-xs font-bold">
                  Quote
                </Link>
                <Link to="/portal" className="px-4 py-2 rounded-full border border-white/15 text-xs font-semibold">
                  Portal
                </Link>
                <Link to="/console" className="px-4 py-2 rounded-full border border-white/15 text-xs font-semibold">
                  Cloud
                </Link>
              </div>
            </div>
          </Fade>
        </div>
      </section>

      {/* KPIs */}
      <section id="kpis" className="py-20 md:py-28 bg-kyn-void border-y border-white/5 scroll-mt-24">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <Fade>
            <SectionLabel>06 · KPIs commerciaux</SectionLabel>
            <h2 className="font-display text-3xl md:text-5xl font-bold">Ce que l’on mesure chaque mois</h2>
          </Fade>
          <div className="mt-12 grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {kpis.map((k, i) => (
              <Fade key={k.id} delay={i * 0.03}>
                <div className="rounded-2xl border border-white/10 bg-black/40 p-5 h-full">
                  <p className="text-[10px] uppercase tracking-wider text-kyn-green font-semibold">{k.meta}</p>
                  <h3 className="font-display font-semibold mt-2 leading-snug">{k.title}</h3>
                  <p className="text-xs text-kyn-metal mt-2 leading-relaxed">{k.body}</p>
                </div>
              </Fade>
            ))}
          </div>
          <Fade delay={0.1}>
            <div className="mt-8 grid md:grid-cols-3 gap-4">
              {[
                { label: 'Cible win rate', value: '≥ 30%', hint: 'Devis → contrats' },
                { label: 'Cible LTV / CAC', value: '≥ 4×', hint: 'Saine unit economics' },
                { label: 'Cible NPS', value: '≥ 50', hint: 'Post-installation' },
              ].map((x) => (
                <div key={x.label} className="rounded-2xl border border-kyn-green/20 bg-kyn-green/5 p-6 text-center">
                  <p className="text-xs text-kyn-metal uppercase tracking-wider">{x.label}</p>
                  <p className="font-display text-3xl font-bold text-kyn-green mt-2">{x.value}</p>
                  <p className="text-xs text-kyn-silver mt-1">{x.hint}</p>
                </div>
              ))}
            </div>
          </Fade>
        </div>
      </section>

      {/* PARTNERS */}
      <section id="partners" className="py-20 md:py-28 scroll-mt-24">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-start">
            <Fade>
              <SectionLabel>07 · Partenaires stratégiques</SectionLabel>
              <h2 className="font-display text-3xl md:text-4xl font-bold">Un réseau qui multiplie la force de vente</h2>
              <p className="mt-4 text-kyn-silver leading-relaxed">
                Auto, électricité, BTP, parkings, solaire — chaque partenaire apporte des leads qualifiés et de la capacité terrain.
              </p>
              <div className="mt-8 grid sm:grid-cols-2 gap-3">
                {partners.map((p) => (
                  <div key={p.id} className="rounded-xl border border-white/10 bg-kyn-void p-4">
                    <p className="text-[10px] text-kyn-green font-semibold uppercase tracking-wider">{p.meta}</p>
                    <p className="font-semibold mt-1 text-sm">{p.title}</p>
                    <p className="text-xs text-kyn-metal mt-1.5">{p.body}</p>
                  </div>
                ))}
              </div>
            </Fade>

            <Fade delay={0.08} className="scroll-mt-24" >
              <div id="tiers" className="rounded-3xl border border-white/10 bg-gradient-to-br from-kyn-steel/80 to-kyn-void p-7 md:p-9">
                <SectionLabel>08 · Programme partenaire</SectionLabel>
                <h3 className="font-display text-2xl md:text-3xl font-bold mb-6">Trois niveaux de partenariat</h3>
                <div className="space-y-4">
                  {tiers.map((t, i) => (
                    <div key={t.id} className="flex gap-4 rounded-2xl border border-white/10 bg-black/30 p-5">
                      <div className="w-10 h-10 rounded-full bg-kyn-green/15 border border-kyn-green/30 flex items-center justify-center text-kyn-green font-bold text-sm shrink-0">
                        {i + 1}
                      </div>
                      <div>
                        <p className="font-display font-bold">{t.title}</p>
                        <p className="text-xs text-kyn-green mt-0.5">{t.subtitle}</p>
                        <p className="text-sm text-kyn-metal mt-2">{t.body}</p>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="mt-6 flex flex-wrap gap-2">
                  <Link to="/installers" className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-kyn-green text-kyn-black text-xs font-bold">
                    Devenir installateur <ArrowRight size={14} />
                  </Link>
                  <Link to="/distributors" className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full border border-white/15 text-xs font-semibold">
                    Distributeurs
                  </Link>
                  <Link to="/academy-landing" className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full border border-white/15 text-xs font-semibold">
                    Academy
                  </Link>
                </div>
              </div>
            </Fade>
          </div>
        </div>
      </section>

      {/* SUPPORT */}
      <section id="support" className="py-20 md:py-28 bg-kyn-void border-y border-white/5 scroll-mt-24">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <Fade>
            <SectionLabel>09 · Support client</SectionLabel>
            <h2 className="font-display text-3xl md:text-5xl font-bold">Toujours joignable, toujours traçable</h2>
          </Fade>
          <div className="mt-12 grid sm:grid-cols-2 lg:grid-cols-5 gap-3">
            {support.map((s, i) => {
              const Icon = supportIcons[s.title] || Headphones;
              return (
                <Fade key={s.id} delay={i * 0.04}>
                  <div className="rounded-2xl border border-white/10 bg-black/30 p-5 text-center h-full hover:border-kyn-green/25 transition-colors">
                    <div className="w-11 h-11 mx-auto rounded-xl bg-kyn-green/10 border border-kyn-green/20 flex items-center justify-center text-kyn-green mb-3">
                      <Icon size={18} />
                    </div>
                    <p className="font-semibold text-sm">{s.title}</p>
                    <p className="text-[11px] text-kyn-metal mt-2 leading-relaxed">{s.body}</p>
                  </div>
                </Fade>
              );
            })}
          </div>
          <div className="mt-8 text-center">
            <Link to="/support" className="inline-flex items-center gap-2 text-sm font-semibold text-kyn-green">
              Ouvrir le centre de support <ArrowRight size={16} />
            </Link>
          </div>
        </div>
      </section>

      {/* REVENUE */}
      <section id="revenue" className="py-20 md:py-28 scroll-mt-24">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <Fade>
            <SectionLabel>10 · Objectif global</SectionLabel>
            <h2 className="font-display text-3xl md:text-5xl font-bold max-w-3xl">
              Une plateforme de revenus, pas une boutique de bornes
            </h2>
            <p className="mt-4 text-kyn-silver max-w-2xl">
              Hardware ouvre la porte. Cloud, maintenance, Academy et energy services construisent la récurrence.
            </p>
          </Fade>
          <div className="mt-12 grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {revenue.map((r, i) => (
              <Fade key={r.id} delay={i * 0.04}>
                <div className="rounded-2xl border border-white/10 bg-kyn-void p-6 flex items-start gap-4 hover:border-kyn-green/30 transition-colors">
                  <div className="w-10 h-10 rounded-xl bg-kyn-green/10 border border-kyn-green/20 flex items-center justify-center text-kyn-green font-display text-xs font-bold shrink-0">
                    {r.meta}
                  </div>
                  <div>
                    <p className="font-display font-semibold text-lg">{r.title}</p>
                    <p className="text-xs text-kyn-green mt-0.5">{r.subtitle}</p>
                    <p className="text-sm text-kyn-metal mt-2">{r.body}</p>
                  </div>
                </div>
              </Fade>
            ))}
          </div>
        </div>
      </section>

      {/* NEXT PHASE */}
      <section className="py-20 border-t border-white/5">
        <div className="max-w-4xl mx-auto px-5 md:px-8 text-center">
          <Fade>
            <p className="text-kyn-green text-xs font-semibold tracking-[0.3em] uppercase mb-4">Phase 24 · Next</p>
            <h2 className="font-display text-3xl md:text-4xl font-bold">Technical & Operational Blueprint</h2>
            <p className="mt-4 text-kyn-silver max-w-xl mx-auto">
              SOPs · workflows ventes/install/maintenance · stock · garantie · qualité · risques · KPIs ops — pour opérer au quotidien.
            </p>
            <div className="mt-10 flex flex-wrap justify-center gap-3">
              <Link to="/quote" className="inline-flex items-center gap-2 px-7 py-3.5 rounded-full bg-kyn-green text-kyn-black text-sm font-bold">
                Lancer un devis <ArrowRight size={16} />
              </Link>
              <Link to="/brand-launch" className="inline-flex items-center gap-2 px-7 py-3.5 rounded-full border border-white/15 text-sm font-semibold">
                Phase 22 Brand
              </Link>
              <Link to="/grow" className="inline-flex items-center gap-2 px-7 py-3.5 rounded-full border border-white/15 text-sm font-semibold">
                Marketing hub
              </Link>
              <Link to="/investors" className="inline-flex items-center gap-2 px-7 py-3.5 rounded-full border border-white/15 text-sm font-semibold">
                Investisseurs
              </Link>
            </div>
          </Fade>
        </div>
      </section>

            <section className="py-16 border-t border-white/5 text-center">
        <p className="text-kyn-green text-xs font-semibold tracking-[0.3em] uppercase mb-3">Phase 24</p>
        <h2 className="font-display text-2xl font-bold mb-4">Technical & Operational Blueprint</h2>
        <Link to="/ops" className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-kyn-green text-kyn-black text-sm font-bold">
          Ouvrir le blueprint ops <ArrowRight size={16} />
        </Link>
      </section>
      <footer className="border-t border-white/5 py-8">
        <div className="max-w-7xl mx-auto px-5 md:px-8 flex flex-wrap justify-between gap-4 items-center">
          <BrandLogo height={26} />
          <p className="text-[11px] text-kyn-metal">Phase 23 · Sales System & Commercial Strategy</p>
          <div className="flex gap-3 text-[11px] text-kyn-metal">
            <Link to="/" className="hover:text-white">Site</Link>
            <Link to="/console" className="hover:text-white">Cloud</Link>
            <Link to="/academy-landing" className="hover:text-white">Academy</Link>
          </div>
        </div>
      </footer>
    </div>
  );
}

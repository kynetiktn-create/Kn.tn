import { useEffect, useMemo, useState, type ComponentType, type ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  ArrowRight, BookOpen, Building2, CheckCircle2, ChevronRight, Cloud, Code2,
  Cpu, Database, FileText, Gauge, Globe2, GraduationCap, Layers, Lock,
  Menu, Monitor, Network, Radar, Server, Shield, Smartphone, Sparkles,
  Target, Users, Workflow, X, Zap, BarChart3, KeyRound, Scale, Rocket
} from 'lucide-react';
import BrandLogo from '../components/BrandLogo';
import LoadingState from '../components/LoadingState';
import { apiGet, cn } from '../lib/utils';

interface DocRow {
  id: number;
  chapter: string;
  type: string;
  title: string;
  subtitle: string | null;
  body: string;
  meta: string | null;
  sort_order: number;
}

const TOC = [
  { id: 'cover', n: '00', label: 'Cover' },
  { id: 'executive', n: '01', label: 'Executive Summary' },
  { id: 'vision', n: '02', label: 'Vision 2036' },
  { id: 'ecosystem', n: '03', label: 'Product-Tech Ecosystem' },
  { id: 'architecture', n: '04', label: 'System Architecture' },
  { id: 'platforms', n: '05', label: 'Digital Platforms' },
  { id: 'hardware', n: '06', label: 'Hardware Portfolio' },
  { id: 'data', n: '07', label: 'Data Models' },
  { id: 'security', n: '08', label: 'Security & Governance' },
  { id: 'lifecycle', n: '09', label: 'Product Lifecycle' },
  { id: 'quality', n: '10', label: 'Quality Standards' },
  { id: 'rbac', n: '11', label: 'Roles & Permissions' },
  { id: 'kpis', n: '12', label: 'Performance Metrics' },
  { id: 'roadmap', n: '13', label: 'Investment Readiness' },
  { id: 'appendix', n: '14', label: 'Appendix' },
];

function Section({ id, number, title, kicker, children }: {
  id: string; number: string; title: string; kicker?: string; children: ReactNode;
}) {
  return (
    <section id={id} className="scroll-mt-28 py-16 md:py-20 border-t border-white/[0.06]">
      <div className="flex items-start gap-4 mb-8">
        <span className="font-mono text-xs text-sky-400/90 tracking-widest pt-1.5">{number}</span>
        <div>
          {kicker && <p className="text-[11px] uppercase tracking-[0.28em] text-sky-400/80 mb-2">{kicker}</p>}
          <h2 className="font-display text-2xl md:text-3xl font-bold text-white tracking-tight">{title}</h2>
        </div>
      </div>
      {children}
    </section>
  );
}

function DocTable({ headers, rows }: { headers: string[]; rows: string[][] }) {
  return (
    <div className="overflow-x-auto rounded-xl border border-white/10 bg-[#0a0f18]/80">
      <table className="w-full text-left text-sm min-w-[640px]">
        <thead>
          <tr className="border-b border-white/10 text-[11px] uppercase tracking-wider text-sky-300/80">
            {headers.map((h) => (
              <th key={h} className="px-4 py-3 font-semibold">{h}</th>
            ))}
          </tr>
        </thead>
        <tbody className="divide-y divide-white/[0.05]">
          {rows.map((row, i) => (
            <tr key={i} className="text-slate-300 hover:bg-white/[0.02]">
              {row.map((cell, j) => (
                <td key={j} className={cn('px-4 py-3', j === 0 && 'text-white font-medium')}>{cell}</td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function Pill({ children }: { children: ReactNode }) {
  return (
    <span className="inline-flex items-center px-2.5 py-1 rounded-md border border-sky-400/20 bg-sky-400/5 text-[11px] text-sky-200 font-medium">
      {children}
    </span>
  );
}

function ArchNode({ icon: Icon, label, sub }: { icon: ComponentType<{ size?: number; className?: string }>; label: string; sub: string }) {
  return (
    <div className="rounded-xl border border-white/10 bg-gradient-to-b from-white/[0.04] to-transparent p-4 text-center">
      <div className="w-10 h-10 mx-auto rounded-lg bg-sky-400/10 border border-sky-400/25 flex items-center justify-center text-sky-300 mb-3">
        <Icon size={18} />
      </div>
      <p className="text-sm font-semibold text-white">{label}</p>
      <p className="text-[11px] text-slate-400 mt-1">{sub}</p>
    </div>
  );
}

export default function MasterDocumentation() {
  const [docs, setDocs] = useState<DocRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [menuOpen, setMenuOpen] = useState(false);
  const [active, setActive] = useState('cover');

  useEffect(() => {
    apiGet<DocRow[]>('/api/master-docs')
      .then(setDocs)
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    const obs = new IntersectionObserver(
      (entries) => {
        const visible = entries.filter((e) => e.isIntersecting).sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
        if (visible?.target?.id) setActive(visible.target.id);
      },
      { rootMargin: '-20% 0px -55% 0px', threshold: [0.1, 0.4] }
    );
    TOC.forEach((t) => {
      const el = document.getElementById(t.id);
      if (el) obs.observe(el);
    });
    return () => obs.disconnect();
  }, [loading]);

  const byChapter = useMemo(() => {
    const m: Record<string, DocRow[]> = {};
    docs.forEach((d) => {
      if (!m[d.chapter]) m[d.chapter] = [];
      m[d.chapter].push(d);
    });
    return m;
  }, [docs]);

  const principles = byChapter.principles || [];
  const platforms = byChapter.platforms || [];
  const kpis = byChapter.kpis || [];
  const risks = byChapter.risks || [];

  if (loading) {
    return (
      <div className="min-h-screen bg-[#050a12] flex items-center justify-center">
        <LoadingState label="Loading Master Documentation v2.0…" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#050a12] text-slate-200">
      {/* Top bar */}
      <header className="fixed top-0 inset-x-0 z-50 border-b border-white/5 bg-[#050a12]/90 backdrop-blur-xl">
        <div className="max-w-[1400px] mx-auto px-4 md:px-6 h-14 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <BrandLogo height={26} />
            <span className="hidden sm:inline text-[10px] font-semibold tracking-[0.2em] uppercase text-sky-300 border border-sky-400/25 rounded-full px-2 py-0.5">
              Master Docs v2.0
            </span>
          </div>
          <div className="hidden md:flex items-center gap-4 text-[11px] text-slate-400">
            <span>Confidential · Investor Ready</span>
            <span className="text-white/20">|</span>
            <span>Vision 2036</span>
            <Link to="/design-system" className="text-sky-300 hover:text-white">Design System</Link>
          </div>
          <button type="button" className="lg:hidden p-2 text-slate-300" onClick={() => setMenuOpen(!menuOpen)}>
            {menuOpen ? <X size={18} /> : <Menu size={18} />}
          </button>
        </div>
      </header>

      <div className="max-w-[1400px] mx-auto px-4 md:px-6 pt-14 flex gap-8">
        {/* TOC sidebar */}
        <aside className={cn(
          'lg:w-64 shrink-0 lg:sticky lg:top-20 lg:h-[calc(100vh-6rem)] lg:overflow-y-auto py-8',
          menuOpen ? 'fixed inset-0 z-40 bg-[#050a12] p-6 pt-20 overflow-y-auto' : 'hidden lg:block'
        )}>
          <p className="text-[10px] uppercase tracking-[0.25em] text-slate-500 mb-4">Table of Contents</p>
          <nav className="space-y-0.5">
            {TOC.map((t) => (
              <a
                key={t.id}
                href={`#${t.id}`}
                onClick={() => setMenuOpen(false)}
                className={cn(
                  'flex items-center gap-3 px-3 py-2 rounded-lg text-xs transition-colors',
                  active === t.id
                    ? 'bg-sky-400/10 text-sky-200 border border-sky-400/20'
                    : 'text-slate-400 hover:text-white hover:bg-white/[0.03]'
                )}
              >
                <span className="font-mono text-[10px] text-slate-500 w-5">{t.n}</span>
                {t.label}
              </a>
            ))}
          </nav>
          <div className="mt-8 rounded-xl border border-white/8 bg-white/[0.02] p-4">
            <p className="text-[10px] uppercase tracking-wider text-slate-500 mb-2">Document control</p>
            <p className="text-xs text-slate-300">Version 2.0</p>
            <p className="text-xs text-slate-500 mt-1">Classification: Internal + Investor</p>
            <p className="text-xs text-slate-500 mt-1">Owner: Product & Technology</p>
          </div>
        </aside>

        {/* Main document */}
        <main className="flex-1 min-w-0 pb-24">
          {/* COVER */}
          <section id="cover" className="scroll-mt-28 min-h-[88vh] flex flex-col justify-center py-16 relative">
            <div className="absolute inset-0 pointer-events-none">
              <div className="absolute top-10 right-0 w-[480px] h-[480px] rounded-full bg-sky-500/10 blur-[120px]" />
              <div className="absolute bottom-0 left-10 w-[320px] h-[320px] rounded-full bg-cyan-400/5 blur-[100px]" />
            </div>
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="relative z-10 max-w-3xl">
              <div className="flex flex-wrap gap-2 mb-8">
                <Pill>Product-Tech OS</Pill>
                <Pill>Enterprise Grade</Pill>
                <Pill>Vision 2036</Pill>
              </div>
              <p className="text-sky-300/90 text-xs font-semibold tracking-[0.35em] uppercase mb-5">
                Master Product Documentation
              </p>
              <h1 className="font-display text-4xl sm:text-5xl md:text-6xl font-bold text-white leading-[1.05] tracking-tight">
                KYNETIK
                <br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-sky-300 via-cyan-200 to-white">
                  Product System v2.0
                </span>
              </h1>
              <p className="mt-6 text-lg md:text-xl text-slate-300 leading-relaxed max-w-2xl">
                The definitive operating document for KYNETIK as a unified Product-Tech company —
                hardware, cloud, applications, academy, APIs and AI under one governed system.
              </p>
              <p className="mt-4 text-sm text-slate-400 max-w-xl leading-relaxed">
                Written for founders, product leadership, engineering, investors and strategic partners.
                Style benchmark: Apple · Tesla · AWS · Stripe · Google Cloud.
              </p>
              <div className="mt-10 grid grid-cols-2 md:grid-cols-4 gap-3">
                {[
                  { l: 'Platforms', v: '12+' },
                  { l: 'Product lines', v: 'NOVA–PRO' },
                  { l: 'Protocol', v: 'OCPP' },
                  { l: 'Horizon', v: '2036' },
                ].map((s) => (
                  <div key={s.l} className="rounded-xl border border-white/10 bg-white/[0.02] p-4">
                    <p className="font-display text-xl font-bold text-white">{s.v}</p>
                    <p className="text-[11px] text-slate-500 mt-1 uppercase tracking-wider">{s.l}</p>
                  </div>
                ))}
              </div>
              <a href="#executive" className="mt-10 inline-flex items-center gap-2 text-sm text-sky-300 hover:text-white">
                Begin reading <ArrowRight size={14} />
              </a>
            </motion.div>
          </section>

          {/* 01 EXECUTIVE */}
          <Section id="executive" number="01" title="Executive Summary" kicker="Strategic overview">
            <div className="prose-doc space-y-5 max-w-3xl text-[15px] leading-relaxed text-slate-300">
              <p>
                KYNETIK is not a website, a charger SKU, or a mobile app in isolation. It is a
                <strong className="text-white font-semibold"> vertically integrated electric mobility operating system</strong> —
                spanning intelligent AC/DC charging hardware, a multi-tenant cloud control plane,
                customer and operator software, installer tooling, academy certification, open APIs,
                OCPP infrastructure, analytics and applied AI.
              </p>
              <p>
                This Master Document defines how those surfaces form one coherent product company:
                shared design language, shared data model, shared security posture, shared release
                governance, and shared KPIs from Tunisia to regional and international scale.
              </p>
            </div>
            <div className="mt-10 grid md:grid-cols-3 gap-4">
              {[
                { icon: Target, t: 'Mission', d: 'Make electric energy simple, intelligent and bankable for homes, workplaces and nations.' },
                { icon: Rocket, t: 'Ambition', d: 'Become the reference Product-Tech platform for EV infrastructure across North Africa and beyond.' },
                { icon: Scale, t: 'Standard', d: 'Ship with the rigor of global infrastructure software: reliability, clarity, auditability.' },
              ].map(({ icon: Icon, t, d }) => (
                <div key={t} className="rounded-2xl border border-white/10 bg-gradient-to-b from-[#0c1420] to-[#080c14] p-5">
                  <Icon className="text-sky-300 mb-3" size={18} />
                  <p className="font-semibold text-white">{t}</p>
                  <p className="text-sm text-slate-400 mt-2 leading-relaxed">{d}</p>
                </div>
              ))}
            </div>
          </Section>

          {/* 02 VISION */}
          <Section id="vision" number="02" title="Vision 2036" kicker="Long-range north star">
            <div className="rounded-2xl border border-sky-400/20 bg-gradient-to-br from-sky-500/10 via-transparent to-transparent p-6 md:p-8 mb-8">
              <p className="font-display text-xl md:text-2xl text-white font-semibold leading-snug max-w-3xl">
                “By 2036, KYNETIK powers the digital backbone of electric mobility —
                where every kilowatt is measured, optimized, trusted and monetized.”
              </p>
            </div>
            <DocTable
              headers={['Horizon', 'Focus', 'Outcomes']}
              rows={[
                ['2025–2027', 'Foundation', 'NOVA/PRIME/GO hardware, Cloud v1, App, Installer ops, Academy core'],
                ['2028–2031', 'Scale', 'National corridors, fleet OS, roaming, multi-country tenants, AI ops'],
                ['2032–2036', 'Platform power', 'Regional standard, energy markets, partner ecosystem, IPO-grade ops'],
              ]}
            />
            {principles.length > 0 && (
              <div className="mt-8 grid sm:grid-cols-2 gap-3">
                {principles.map((p) => (
                  <div key={p.id} className="rounded-xl border border-white/8 bg-white/[0.02] p-4">
                    <p className="text-sm font-semibold text-white">{p.title}</p>
                    <p className="text-xs text-slate-400 mt-1 leading-relaxed">{p.body}</p>
                  </div>
                ))}
              </div>
            )}
          </Section>

          {/* 03 ECOSYSTEM */}
          <Section id="ecosystem" number="03" title="Product-Tech Ecosystem" kicker="One company · many surfaces">
            <p className="text-slate-300 max-w-3xl mb-8 text-[15px] leading-relaxed">
              KYNETIK is structured as a product operating system. Every surface below is a first-class product
              with owners, SLAs, metrics and a place in the architecture — not a marketing page afterthought.
            </p>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {[
                { icon: Globe2, t: 'Website', d: 'Brand, demand gen, product education' },
                { icon: Smartphone, t: 'Mobile App', d: 'Drivers, home users, session control' },
                { icon: Cloud, t: 'KYNETIK Cloud', d: 'Multi-tenant energy control plane' },
                { icon: GraduationCap, t: 'Academy', d: 'Certification & workforce enablement' },
                { icon: Users, t: 'Customer Portal', d: 'Billing, assets, support, downloads' },
                { icon: Workflow, t: 'Installer Portal', d: 'Jobs, field ops, commissioning' },
                { icon: Building2, t: 'Admin Platform', d: 'Enterprise command center' },
                { icon: Code2, t: 'REST API', d: 'Partner & system integration' },
                { icon: Network, t: 'OCPP Server', d: 'Charger protocol backbone' },
                { icon: BarChart3, t: 'Analytics', d: 'Energy, revenue, utilization' },
                { icon: Radar, t: 'Monitoring', d: 'Uptime, alerts, NOC workflows' },
                { icon: Sparkles, t: 'AI Layer', d: 'Advisor, prediction, optimization' },
              ].map(({ icon: Icon, t, d }) => (
                <div key={t} className="flex gap-3 rounded-xl border border-white/8 bg-[#0a101a] p-4">
                  <div className="w-9 h-9 rounded-lg bg-sky-400/10 border border-sky-400/20 flex items-center justify-center text-sky-300 shrink-0">
                    <Icon size={16} />
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-white">{t}</p>
                    <p className="text-xs text-slate-400 mt-0.5">{d}</p>
                  </div>
                </div>
              ))}
            </div>
            {platforms.length > 0 && (
              <div className="mt-8">
                <DocTable
                  headers={['Platform', 'Primary users', 'Core jobs-to-be-done']}
                  rows={platforms.map((p) => [p.title, p.subtitle || '—', p.body])}
                />
              </div>
            )}
          </Section>

          {/* 04 ARCHITECTURE */}
          <Section id="architecture" number="04" title="System Architecture" kicker="Reference model">
            <p className="text-slate-300 max-w-3xl mb-8 text-[15px] leading-relaxed">
              Layered architecture inspired by AWS and Google Cloud reference models: edge devices,
              connectivity, control plane, data plane, experience plane, intelligence plane.
            </p>
            <div className="rounded-2xl border border-white/10 bg-[#070c14] p-5 md:p-8">
              <p className="text-[10px] uppercase tracking-[0.25em] text-slate-500 mb-5 text-center">KYNETIK Reference Architecture</p>
              <div className="space-y-3">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                  <ArchNode icon={Smartphone} label="Experience" sub="App · Web · Portals" />
                  <ArchNode icon={Building2} label="Operations" sub="Admin · Installer · NOC" />
                  <ArchNode icon={GraduationCap} label="Enablement" sub="Academy · Docs · Dev" />
                  <ArchNode icon={Code2} label="Ecosystem" sub="API · Webhooks · SSO" />
                </div>
                <div className="h-px bg-gradient-to-r from-transparent via-sky-400/40 to-transparent" />
                <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
                  <ArchNode icon={Sparkles} label="Intelligence Plane" sub="AI Advisor · Forecasting · Anomaly" />
                  <ArchNode icon={BarChart3} label="Data & Analytics" sub="Sessions · Energy · Revenue · CO₂" />
                  <ArchNode icon={Shield} label="Security Plane" sub="IAM · Secrets · Audit · Compliance" />
                </div>
                <div className="h-px bg-gradient-to-r from-transparent via-sky-400/40 to-transparent" />
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                  <ArchNode icon={Cloud} label="Control Plane" sub="OCPP Broker · Orchestration · Billing" />
                  <ArchNode icon={Database} label="Persistence" sub="Postgres · Object · Event log" />
                </div>
                <div className="h-px bg-gradient-to-r from-transparent via-sky-400/40 to-transparent" />
                <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                  <ArchNode icon={Zap} label="NOVA" sub="AC wall · home/SME" />
                  <ArchNode icon={Zap} label="PRIME" sub="AC · workplace white" />
                  <ArchNode icon={Zap} label="GO" sub="Portable / flexible" />
                  <ArchNode icon={Server} label="PRO / EDGE" sub="DC & commercial" />
                </div>
              </div>
            </div>
            <div className="mt-8 grid md:grid-cols-2 gap-4">
              <div className="rounded-xl border border-white/10 p-5 bg-white/[0.02]">
                <p className="text-sm font-semibold text-white mb-3 flex items-center gap-2"><Network size={14} className="text-sky-300" /> Protocol spine</p>
                <ul className="space-y-2 text-sm text-slate-400">
                  <li className="flex gap-2"><CheckCircle2 size={14} className="text-sky-300 mt-0.5 shrink-0" /> OCPP 1.6J / 2.0.1 charger channel</li>
                  <li className="flex gap-2"><CheckCircle2 size={14} className="text-sky-300 mt-0.5 shrink-0" /> REST + webhooks for partners</li>
                  <li className="flex gap-2"><CheckCircle2 size={14} className="text-sky-300 mt-0.5 shrink-0" /> TLS everywhere · signed OTA</li>
                </ul>
              </div>
              <div className="rounded-xl border border-white/10 p-5 bg-white/[0.02]">
                <p className="text-sm font-semibold text-white mb-3 flex items-center gap-2"><Cpu size={14} className="text-sky-300" /> Design principles</p>
                <ul className="space-y-2 text-sm text-slate-400">
                  <li className="flex gap-2"><CheckCircle2 size={14} className="text-sky-300 mt-0.5 shrink-0" /> One identity system across products</li>
                  <li className="flex gap-2"><CheckCircle2 size={14} className="text-sky-300 mt-0.5 shrink-0" /> Multi-tenant from day one</li>
                  <li className="flex gap-2"><CheckCircle2 size={14} className="text-sky-300 mt-0.5 shrink-0" /> Observability as a product feature</li>
                </ul>
              </div>
            </div>
          </Section>

          {/* 05 PLATFORMS */}
          <Section id="platforms" number="05" title="Digital Platforms" kicker="Surface contracts">
            <DocTable
              headers={['Surface', 'Owner', 'SLA posture', 'Key integrations']}
              rows={[
                ['Mobile App', 'Product · Consumer', 'App store grade · crash-free > 99.5%', 'Cloud sessions · Wallet · Map'],
                ['Customer Portal', 'Product · Accounts', 'Business hours + critical alerts', 'Billing · Tickets · Assets'],
                ['Installer Portal', 'Ops · Field', 'Field-critical · offline-tolerant UX', 'Jobs · Calendar · Commissioning'],
                ['Admin Platform', 'Platform · Enterprise', 'NOC-grade monitoring', 'RBAC · CMS · Infra · Finance'],
                ['Cloud Console', 'Energy · Operators', '24/7 control plane', 'OCPP · Alerts · Reports'],
                ['Developer Platform', 'Platform · API', 'Public status page · versioned APIs', 'Keys · Webhooks · SDKs'],
                ['Academy', 'People · Enablement', 'Content SLA · certification integrity', 'LMS · Badges · Partner CRM'],
                ['AI Suite', 'Data · Intelligence', 'Human-in-loop for critical actions', 'Telemetry · Advisor · PM'],
              ]}
            />
          </Section>

          {/* 06 HARDWARE */}
          <Section id="hardware" number="06" title="Hardware Portfolio" kicker="Physical product system">
            <p className="text-slate-300 max-w-3xl mb-6 text-[15px] leading-relaxed">
              Hardware is treated as a versioned product family with shared industrial design DNA,
              shared electronics roadmap where possible, and mandatory Cloud-native connectivity.
            </p>
            <DocTable
              headers={['Line', 'Positioning', 'Power class', 'Primary segment', 'Cloud']}
              rows={[
                ['NOVA', 'Matte black signature AC', '7–22 kW AC', 'Home · SME', 'Full'],
                ['PRIME', 'Pearl white hospitality AC', '7–22 kW AC', 'Workplace · Hotels', 'Full'],
                ['GO', 'Portable / flexible AC', 'Compact AC', 'Travel · Light fleet', 'Full'],
                ['PRO / EDGE', 'Commercial & DC path', 'High power / pedestal', 'Public · Depot', 'Full'],
              ]}
            />
            <div className="mt-6 flex flex-wrap gap-2">
              {['Socket & Tethered configs', 'OCPP mandatory', 'RFID + App auth', 'Smart load ready', 'OTA firmware'].map((t) => (
                <Pill key={t}>{t}</Pill>
              ))}
            </div>
          </Section>

          {/* 07 DATA */}
          <Section id="data" number="07" title="Canonical Data Models" kicker="Single source of truth">
            <p className="text-slate-300 max-w-3xl mb-6 text-[15px] leading-relaxed">
              All products read/write against a shared domain model. Naming is stable across API, DB, analytics and UI.
            </p>
            <DocTable
              headers={['Entity', 'Description', 'Key relations']}
              rows={[
                ['Organization', 'Tenant (CPO, fleet, enterprise, installer co.)', 'Users · Sites · Billing accounts'],
                ['Site', 'Physical location with grid constraints', 'Organization · ChargePoints · Tariffs'],
                ['ChargePoint', 'Hardware unit / EVSE logical asset', 'Site · Connectors · Firmware'],
                ['Connector', 'Physical plug/cable endpoint', 'ChargePoint · Sessions'],
                ['Session', 'A charging transaction lifecycle', 'Connector · User · Vehicle · Invoice'],
                ['User', 'Human identity with roles', 'Org membership · Vehicles · Wallets'],
                ['Vehicle', 'EV profile & identifiers', 'User · Preferred connectors'],
                ['Tariff', 'Pricing rules & energy products', 'Site · Session billing'],
                ['Ticket', 'Support / field incident', 'Asset · User · Installer job'],
                ['InstallationJob', 'Field deployment workflow', 'Site · Installer · Checklist'],
                ['Course / Credential', 'Academy learning objects', 'User · Partner certification'],
                ['ApiClient', 'Machine identity for integrations', 'Scopes · Webhooks · Usage'],
              ]}
            />
          </Section>

          {/* 08 SECURITY */}
          <Section id="security" number="08" title="Security, Compliance & Governance" kicker="Trust architecture">
            <div className="grid md:grid-cols-2 gap-4 mb-8">
              {[
                { icon: Lock, t: 'Security', items: ['TLS 1.3 in transit', 'Encrypted secrets & keys', 'Hardened OTA packages', 'Penetration test cadence'] },
                { icon: KeyRound, t: 'Identity', items: ['SSO-ready enterprise auth', 'MFA for privileged roles', 'Service accounts for APIs', 'Least-privilege defaults'] },
                { icon: FileText, t: 'Governance', items: ['Change advisory for prod', 'Audit logs immutable', 'Data retention policies', 'Incident response runbooks'] },
                { icon: Shield, t: 'Compliance posture', items: ['Security questionnaire pack', 'Vendor risk reviews', 'Privacy by design', 'Regional data options'] },
              ].map(({ icon: Icon, t, items }) => (
                <div key={t} className="rounded-2xl border border-white/10 bg-[#0a101a] p-5">
                  <div className="flex items-center gap-2 mb-3">
                    <Icon size={16} className="text-sky-300" />
                    <p className="font-semibold text-white">{t}</p>
                  </div>
                  <ul className="space-y-2">
                    {items.map((i) => (
                      <li key={i} className="text-sm text-slate-400 flex gap-2">
                        <ChevronRight size={14} className="text-sky-400/70 mt-0.5 shrink-0" /> {i}
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
            {risks.length > 0 && (
              <DocTable
                headers={['Risk domain', 'Control', 'Owner']}
                rows={risks.map((r) => [r.title, r.body, r.subtitle || 'Platform'])}
              />
            )}
          </Section>

          {/* 09 LIFECYCLE */}
          <Section id="lifecycle" number="09" title="Product Lifecycle" kicker="How work becomes product">
            <div className="grid md:grid-cols-5 gap-2 mb-8">
              {['Discover', 'Define', 'Design', 'Build', 'Operate'].map((s, i) => (
                <div key={s} className="rounded-xl border border-white/10 bg-white/[0.02] p-4 text-center relative">
                  <p className="font-mono text-[10px] text-sky-400 mb-1">0{i + 1}</p>
                  <p className="text-sm font-semibold text-white">{s}</p>
                </div>
              ))}
            </div>
            <DocTable
              headers={['Stage', 'Artifacts', 'Exit criteria']}
              rows={[
                ['Discover', 'Research, JTBD, market signals', 'Problem validated · opportunity brief'],
                ['Define', 'PRD, success metrics, scope', 'Approved problem/solution fit'],
                ['Design', 'UX flows, DS components, specs', 'Design review + accessibility check'],
                ['Build', 'Code, tests, feature flags', 'QA gate · security review · staging sign-off'],
                ['Operate', 'Monitoring, support, iteration', 'SLA met · learnings → backlog'],
              ]}
            />
          </Section>

          {/* 10 QUALITY */}
          <Section id="quality" number="10" title="Quality Standards" kicker="Non-negotiables">
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {[
                { t: 'Design quality', d: 'Tokens, components, contrast, motion discipline from Design Bible' },
                { t: 'Engineering quality', d: 'Typed APIs, tests on critical paths, no silent failures' },
                { t: 'Reliability', d: 'Error budgets, uptime targets, graceful degradation' },
                { t: 'Performance', d: 'Core web vitals, API p95 budgets, mobile battery awareness' },
                { t: 'Accessibility', d: 'Keyboard paths, semantics, readable energy data' },
                { t: 'Documentation', d: 'Every public API and operator workflow is documented' },
              ].map((q) => (
                <div key={q.t} className="rounded-xl border border-white/8 p-4 bg-[#0a101a]">
                  <p className="text-sm font-semibold text-white">{q.t}</p>
                  <p className="text-xs text-slate-400 mt-2 leading-relaxed">{q.d}</p>
                </div>
              ))}
            </div>
          </Section>

          {/* 11 RBAC */}
          <Section id="rbac" number="11" title="Roles & Permissions" kicker="Who can do what">
            <DocTable
              headers={['Role', 'Scope', 'Typical powers']}
              rows={[
                ['Super Admin', 'Global', 'Tenant ops, feature flags, security policies'],
                ['Org Admin', 'Organization', 'Users, sites, billing, API clients'],
                ['Operator / NOC', 'Sites fleet', 'Remote start/stop, alerts, firmware windows'],
                ['Installer Lead', 'Field org', 'Jobs, commissioning, photo evidence'],
                ['Installer Tech', 'Assigned jobs', 'Checklist execution, status updates'],
                ['Finance', 'Org financials', 'Invoices, payouts, tariff approval'],
                ['Driver / End user', 'Self', 'Charge, pay, view history, manage vehicles'],
                ['Developer', 'API client', 'Scoped keys, webhooks, sandbox'],
                ['Academy Learner', 'Self', 'Courses, exams, credentials'],
                ['Read-only Investor', 'Dashboards', 'Aggregated KPIs, no control actions'],
              ]}
            />
          </Section>

          {/* 12 KPIs */}
          <Section id="kpis" number="12" title="Performance Metrics" kicker="How we measure excellence">
            <DocTable
              headers={['Domain', 'KPI', 'Target posture']}
              rows={
                kpis.length
                  ? kpis.map((k) => [k.subtitle || 'Product', k.title, k.body])
                  : [
                      ['Reliability', 'Platform uptime', '≥ 99.9% monthly'],
                      ['Energy ops', 'Charger online ratio', '≥ 98% for managed fleets'],
                      ['Experience', 'Session success rate', '≥ 97% start→complete without support'],
                      ['Field', 'First-time fix rate', '≥ 85% installer interventions'],
                      ['Growth', 'Activation to first charge', '< 7 days median after install'],
                      ['Business', 'Gross margin per kWh network', 'Improving quarter over quarter'],
                      ['AI', 'Alert precision', 'Reduce false positives quarter over quarter'],
                      ['Academy', 'Certification completion', '≥ 70% of enrolled installers'],
                    ]
              }
            />
          </Section>

          {/* 13 INVESTMENT */}
          <Section id="roadmap" number="13" title="Investment Readiness" kicker="Why this is fundable infrastructure">
            <div className="grid md:grid-cols-3 gap-4 mb-8">
              {[
                { t: 'Defensibility', d: 'Hardware + Cloud + Field + Academy flywheel creates switching costs and brand trust.' },
                { t: 'Scalability', d: 'Multi-tenant software margins with recurring Cloud, roaming and services revenue.' },
                { t: 'Governance', d: 'Documented systems, RBAC, metrics and lifecycle reduce execution risk for capital partners.' },
              ].map((c) => (
                <div key={c.t} className="rounded-2xl border border-sky-400/15 bg-sky-400/[0.04] p-5">
                  <p className="font-semibold text-white">{c.t}</p>
                  <p className="text-sm text-slate-400 mt-2 leading-relaxed">{c.d}</p>
                </div>
              ))}
            </div>
            <div className="rounded-2xl border border-white/10 p-6 md:p-8 bg-gradient-to-br from-[#0c1524] to-[#070b12]">
              <p className="text-xs uppercase tracking-[0.25em] text-sky-300 mb-3">Capital narrative</p>
              <p className="font-display text-xl md:text-2xl text-white font-semibold leading-snug max-w-3xl">
                KYNETIK is building the operating system for electric mobility infrastructure —
                with the product discipline of Stripe, the energy ambition of Tesla, and the platform rigor of AWS.
              </p>
              <div className="mt-6 flex flex-wrap gap-3">
                <Link to="/investor" className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-sky-400 text-slate-950 text-xs font-bold">
                  Investor deck system <ArrowRight size={14} />
                </Link>
                <Link to="/cloud-platform" className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full border border-white/15 text-xs font-medium text-white">
                  Cloud platform
                </Link>
                <Link to="/product-system" className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full border border-white/15 text-xs font-medium text-white">
                  Hardware system
                </Link>
              </div>
            </div>
          </Section>

          {/* 14 APPENDIX */}
          <Section id="appendix" number="14" title="Appendix" kicker="Related systems">
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {[
                { to: '/design-bible', t: 'Design Bible', d: 'Visual & interaction law' },
                { to: '/product-spec', t: 'Product Specification', d: 'Detailed PRD surfaces' },
                { to: '/ux-journeys', t: 'UX Journeys', d: 'End-to-end user flows' },
                { to: '/developers', t: 'Developer Platform', d: 'API · SDKs · status' },
                { to: '/admin', t: 'Admin Platform', d: 'Enterprise command' },
                { to: '/portal', t: 'Customer Portal', d: 'Account experience' },
                { to: '/installer', t: 'Installer Ops', d: 'Field execution' },
                { to: '/ai-platform', t: 'AI Platform', d: 'Intelligence layer' },
                { to: '/handoff', t: 'Dev Handoff', d: 'Implementation package' },
              ].map((l) => (
                <Link key={l.to} to={l.to} className="group rounded-xl border border-white/8 bg-white/[0.02] p-4 hover:border-sky-400/30 transition-colors">
                  <p className="text-sm font-semibold text-white group-hover:text-sky-200">{l.t}</p>
                  <p className="text-xs text-slate-500 mt-1">{l.d}</p>
                </Link>
              ))}
            </div>
            <div className="mt-12 pt-8 border-t border-white/5 flex flex-wrap items-center justify-between gap-4">
              <div>
                <p className="text-xs text-slate-500">KYNETIK Master Product Documentation</p>
                <p className="text-sm text-slate-300 mt-1">Version 2.0 · Product & Technology Office</p>
              </div>
              <div className="flex items-center gap-2 text-xs text-slate-500">
                <BookOpen size={14} className="text-sky-300" />
                End of controlled document
              </div>
            </div>
          </Section>
        </main>
      </div>
    </div>
  );
}

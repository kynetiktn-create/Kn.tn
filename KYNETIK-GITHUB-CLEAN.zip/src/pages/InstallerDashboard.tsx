import { useCallback, useEffect, useMemo, useState, type ComponentType, type ReactNode } from 'react';
import { motion } from 'framer-motion';
import {
  Wrench, CalendarDays, AlertTriangle, Ticket, PlugZap, Users,
  Zap, MapPin, Clock, CheckCircle2, CircleDot, ArrowUpRight,
  Phone, Navigation, FileText, Camera, ClipboardList, Bell,
  Search, Filter, ChevronRight, Activity, ShieldCheck, Menu, X,
  Play, Pause, MoreHorizontal, RefreshCw, Star
} from 'lucide-react';
import BrandLogo from '../components/BrandLogo';
import LoadingState from '../components/LoadingState';
import { cn } from '../lib/utils';

interface Job {
  id: number;
  title: string;
  customer: string;
  city: string;
  model: string;
  status: string;
  assignee: string;
  priority: string;
  scheduled_at: string;
  notes: string;
}

interface Maintenance {
  id: number;
  title: string;
  site: string;
  model: string;
  issue: string;
  priority: string;
  status: string;
  due_at: string;
  assignee: string;
}

interface TicketRow {
  id: number;
  ticket_no: string;
  name: string;
  subject: string;
  priority: string;
  category: string;
  status: string;
}

interface Charger {
  id: number;
  serial: string;
  model: string;
  customer: string;
  city: string;
  installed_at: string;
  status: string;
  warranty: string;
}

interface Appointment {
  id: number;
  customer: string;
  type: string;
  city: string;
  time_slot: string;
  model: string;
  status: string;
  contact: string;
}

interface DashboardData {
  jobs: Job[];
  assigned: Job[];
  schedule: Job[];
  maintenance: Maintenance[];
  tickets: TicketRow[];
  chargers: Charger[];
  appointments: Appointment[];
  kpis: {
    assigned: number;
    today: number;
    maintenance: number;
    openTickets: number;
    installed: number;
    appointments: number;
  };
}

const priorityStyle: Record<string, string> = {
  critical: 'bg-red-500/15 text-red-400 border-red-500/30',
  high: 'bg-orange-500/15 text-orange-300 border-orange-500/30',
  medium: 'bg-amber-500/15 text-amber-200 border-amber-500/25',
  normal: 'bg-white/5 text-kyn-silver border-white/10',
  low: 'bg-white/5 text-kyn-metal border-white/10',
};

const statusStyle: Record<string, string> = {
  pending: 'text-amber-300 bg-amber-500/10 border-amber-500/25',
  scheduled: 'text-sky-300 bg-sky-500/10 border-sky-500/25',
  in_progress: 'text-kyn-green bg-kyn-green/10 border-kyn-green/30',
  open: 'text-orange-300 bg-orange-500/10 border-orange-500/25',
  assigned: 'text-kyn-green bg-kyn-green/10 border-kyn-green/25',
  completed: 'text-kyn-metal bg-white/5 border-white/10',
  done: 'text-kyn-metal bg-white/5 border-white/10',
  confirmed: 'text-kyn-green bg-kyn-green/10 border-kyn-green/25',
  online: 'text-kyn-green bg-kyn-green/10 border-kyn-green/25',
  offline: 'text-red-300 bg-red-500/10 border-red-500/25',
  warning: 'text-amber-300 bg-amber-500/10 border-amber-500/25',
};

function Badge({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <span className={cn('inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold border capitalize', className)}>
      {children}
    </span>
  );
}

function GlassCard({
  children,
  className,
  title,
  action,
  icon: Icon,
}: {
  children: ReactNode;
  className?: string;
  title?: string;
  action?: ReactNode;
  icon?: ComponentType<{ size?: number; className?: string }>;
}) {
  return (
    <section className={cn('rounded-2xl border border-white/8 bg-white/[0.03] backdrop-blur-xl overflow-hidden', className)}>
      {(title || action) && (
        <div className="flex items-center justify-between gap-3 px-5 py-4 border-b border-white/5">
          <div className="flex items-center gap-2.5 min-w-0">
            {Icon && (
              <div className="w-8 h-8 rounded-xl bg-kyn-green/10 border border-kyn-green/20 flex items-center justify-center text-kyn-green shrink-0">
                <Icon size={15} />
              </div>
            )}
            <h2 className="font-display font-semibold text-sm md:text-base truncate">{title}</h2>
          </div>
          {action}
        </div>
      )}
      <div className="p-4 md:p-5">{children}</div>
    </section>
  );
}

function Kpi({
  label,
  value,
  hint,
  icon: Icon,
  delay = 0,
}: {
  label: string;
  value: number | string;
  hint: string;
  icon: ComponentType<{ size?: number; className?: string }>;
  delay?: number;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay, duration: 0.4 }}
      className="rounded-2xl border border-white/8 bg-gradient-to-b from-white/[0.05] to-transparent p-4 md:p-5"
    >
      <div className="flex items-start justify-between gap-3">
        <div className="w-10 h-10 rounded-xl bg-kyn-green/10 border border-kyn-green/20 flex items-center justify-center text-kyn-green">
          <Icon size={18} />
        </div>
        <span className="text-[10px] text-kyn-metal uppercase tracking-wider">{hint}</span>
      </div>
      <p className="mt-4 font-display text-3xl font-bold text-white">{value}</p>
      <p className="mt-1 text-xs text-kyn-silver">{label}</p>
    </motion.div>
  );
}

export default function InstallerDashboard() {
  const [data, setData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [query, setQuery] = useState('');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [activeNav, setActiveNav] = useState('overview');
  const [refreshing, setRefreshing] = useState(false);

  const load = useCallback(async () => {
    try {
      setRefreshing(true);
      const res = await fetch('/api/installer-dashboard');
      if (!res.ok) throw new Error('Failed to load dashboard');
      const json = await res.json();
      setData(json);
      setError('');
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Load error');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const filteredAssigned = useMemo(() => {
    const list = data?.assigned || [];
    if (!query.trim()) return list;
    const q = query.toLowerCase();
    return list.filter(
      (j) =>
        j.title?.toLowerCase().includes(q) ||
        j.customer?.toLowerCase().includes(q) ||
        j.city?.toLowerCase().includes(q) ||
        j.model?.toLowerCase().includes(q)
    );
  }, [data, query]);

  const nav = [
    { id: 'overview', label: 'Overview', icon: Activity },
    { id: 'installations', label: 'Installations', icon: Wrench },
    { id: 'schedule', label: "Today's Schedule", icon: CalendarDays },
    { id: 'maintenance', label: 'Maintenance', icon: AlertTriangle },
    { id: 'tickets', label: 'Support Tickets', icon: Ticket },
    { id: 'chargers', label: 'Installed Chargers', icon: PlugZap },
    { id: 'appointments', label: 'Appointments', icon: Users },
  ];

  const quickActions = [
    { icon: Navigation, label: 'Start route', desc: 'Open next job navigation' },
    { icon: Camera, label: 'Site photos', desc: 'Upload install evidence' },
    { icon: ClipboardList, label: 'Commissioning', desc: 'OCPP checklist & handover' },
    { icon: FileText, label: 'Field report', desc: 'Generate PDF report' },
    { icon: Phone, label: 'Call customer', desc: 'Contact next appointment' },
    { icon: ShieldCheck, label: 'Safety form', desc: 'Lock-out / tag-out log' },
  ];

  if (loading) {
    return (
      <div className="min-h-screen bg-kyn-black flex items-center justify-center">
        <LoadingState label="Loading installer workspace…" />
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="min-h-screen bg-kyn-black flex flex-col items-center justify-center gap-4 p-8">
        <p className="text-red-400 text-sm">{error || 'No data'}</p>
        <button type="button" onClick={load} className="px-4 py-2 rounded-full bg-kyn-green text-kyn-black text-xs font-bold">
          Retry
        </button>
      </div>
    );
  }

  const { kpis } = data;

  return (
    <div className="min-h-screen bg-kyn-black text-white flex">
      {/* Sidebar */}
      <aside
        className={cn(
          'fixed inset-y-0 left-0 z-40 w-64 border-r border-white/5 bg-kyn-void/95 backdrop-blur-xl transition-transform lg:translate-x-0 lg:static',
          sidebarOpen ? 'translate-x-0' : '-translate-x-full'
        )}
      >
        <div className="h-16 md:h-[4.5rem] px-5 flex items-center border-b border-white/5">
          <BrandLogo height={28} />
        </div>
        <div className="px-4 py-4">
          <div className="rounded-2xl border border-kyn-green/20 bg-kyn-green/5 p-3 mb-4">
            <p className="text-[10px] uppercase tracking-wider text-kyn-green font-semibold">Installer OS</p>
            <p className="text-sm font-display font-semibold mt-1">Field Command</p>
            <p className="text-[11px] text-kyn-metal mt-1">Youssef K. · Certified L2</p>
          </div>
          <nav className="space-y-1">
            {nav.map(({ id, label, icon: Icon }) => (
              <button
                key={id}
                type="button"
                onClick={() => {
                  setActiveNav(id);
                  setSidebarOpen(false);
                  document.getElementById(`sec-${id}`)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
                }}
                className={cn(
                  'w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm transition-all',
                  activeNav === id
                    ? 'bg-kyn-green/10 text-kyn-green border border-kyn-green/20'
                    : 'text-kyn-silver hover:bg-white/5 hover:text-white border border-transparent'
                )}
              >
                <Icon size={16} />
                <span className="truncate">{label}</span>
              </button>
            ))}
          </nav>
        </div>
        <div className="absolute bottom-0 inset-x-0 p-4 border-t border-white/5">
          <div className="rounded-xl bg-black/40 border border-white/8 p-3 text-[11px] text-kyn-metal">
            <div className="flex items-center gap-2 text-kyn-green mb-1">
              <span className="w-1.5 h-1.5 rounded-full bg-kyn-green animate-pulse" /> Cloud synced
            </div>
            OCPP commissioning · SLA tracking · offline-ready queue
          </div>
        </div>
      </aside>

      {sidebarOpen && (
        <button type="button" className="fixed inset-0 z-30 bg-black/60 lg:hidden" onClick={() => setSidebarOpen(false)} aria-label="Close menu" />
      )}

      {/* Main */}
      <div className="flex-1 min-w-0 flex flex-col">
        <header className="sticky top-0 z-20 border-b border-white/5 bg-kyn-black/80 backdrop-blur-xl">
          <div className="h-16 md:h-[4.5rem] px-4 md:px-6 flex items-center gap-3">
            <button type="button" className="lg:hidden p-2 rounded-lg border border-white/10 text-kyn-silver" onClick={() => setSidebarOpen(true)}>
              <Menu size={18} />
            </button>
            <div className="min-w-0 flex-1">
              <p className="text-[10px] uppercase tracking-[0.2em] text-kyn-green font-semibold">Installer Dashboard</p>
              <h1 className="font-display font-bold text-base md:text-lg truncate">Assigned work & field operations</h1>
            </div>
            <div className="hidden md:flex items-center gap-2 flex-1 max-w-md">
              <div className="relative w-full">
                <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-kyn-metal" />
                <input
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="Search jobs, customers, cities…"
                  className="w-full rounded-xl bg-white/5 border border-white/10 pl-9 pr-3 py-2 text-sm text-white placeholder:text-kyn-metal focus:outline-none focus:border-kyn-green/40"
                />
              </div>
            </div>
            <button
              type="button"
              onClick={load}
              className="p-2.5 rounded-xl border border-white/10 text-kyn-silver hover:text-white hover:border-kyn-green/30"
              title="Refresh"
            >
              <RefreshCw size={16} className={refreshing ? 'animate-spin' : ''} />
            </button>
            <button type="button" className="relative p-2.5 rounded-xl border border-white/10 text-kyn-silver hover:text-white">
              <Bell size={16} />
              <span className="absolute top-2 right-2 w-1.5 h-1.5 rounded-full bg-kyn-green" />
            </button>
            <div className="hidden sm:flex w-9 h-9 rounded-xl bg-kyn-green/15 border border-kyn-green/30 items-center justify-center text-kyn-green text-xs font-bold">
              YK
            </div>
          </div>
        </header>

        <main className="flex-1 overflow-y-auto">
          <div className="max-w-[1400px] mx-auto px-4 md:px-6 py-6 md:py-8 space-y-6">
            {/* KPIs */}
            <div id="sec-overview" className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-3 md:gap-4">
              <Kpi label="Assigned installations" value={kpis.assigned} hint="Active" icon={Wrench} delay={0} />
              <Kpi label="Today's schedule" value={kpis.today} hint="Jobs" icon={CalendarDays} delay={0.04} />
              <Kpi label="Pending maintenance" value={kpis.maintenance} hint="Open" icon={AlertTriangle} delay={0.08} />
              <Kpi label="Support tickets" value={kpis.openTickets} hint="Queue" icon={Ticket} delay={0.12} />
              <Kpi label="Installed chargers" value={kpis.installed} hint="Fleet" icon={PlugZap} delay={0.16} />
              <Kpi label="Appointments" value={kpis.appointments} hint="Booked" icon={Users} delay={0.2} />
            </div>

            {/* Quick actions */}
            <GlassCard title="Quick Actions" icon={Zap} action={<span className="text-[10px] text-kyn-metal uppercase tracking-wider">Field toolkit</span>}>
              <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-3">
                {quickActions.map(({ icon: Icon, label, desc }) => (
                  <button
                    key={label}
                    type="button"
                    className="group text-left rounded-2xl border border-white/8 bg-black/30 p-4 hover:border-kyn-green/35 hover:bg-kyn-green/[0.04] transition-all"
                  >
                    <div className="w-9 h-9 rounded-xl bg-kyn-green/10 border border-kyn-green/20 flex items-center justify-center text-kyn-green mb-3 group-hover:shadow-[0_0_20px_rgba(0,230,118,0.25)]">
                      <Icon size={16} />
                    </div>
                    <p className="text-sm font-semibold">{label}</p>
                    <p className="text-[11px] text-kyn-metal mt-1 leading-snug">{desc}</p>
                  </button>
                ))}
              </div>
            </GlassCard>

            <div className="grid xl:grid-cols-5 gap-6">
              {/* Assigned installations */}
              <div id="sec-installations" className="xl:col-span-3 space-y-6">
                <GlassCard
                  title="Assigned Installations"
                  icon={Wrench}
                  action={
                    <div className="flex items-center gap-2">
                      <span className="hidden sm:inline-flex items-center gap-1 text-[10px] text-kyn-metal px-2 py-1 rounded-lg border border-white/10">
                        <Filter size={11} /> Priority
                      </span>
                      <Badge className="bg-kyn-green/10 text-kyn-green border-kyn-green/25">{filteredAssigned.length} active</Badge>
                    </div>
                  }
                >
                  <div className="md:hidden mb-3">
                    <div className="relative">
                      <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-kyn-metal" />
                      <input
                        value={query}
                        onChange={(e) => setQuery(e.target.value)}
                        placeholder="Search…"
                        className="w-full rounded-xl bg-white/5 border border-white/10 pl-9 pr-3 py-2 text-sm focus:outline-none focus:border-kyn-green/40"
                      />
                    </div>
                  </div>
                  <div className="space-y-3">
                    {filteredAssigned.map((job, i) => (
                      <motion.article
                        key={job.id}
                        initial={{ opacity: 0, y: 8 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: i * 0.04 }}
                        className="rounded-2xl border border-white/8 bg-black/25 p-4 hover:border-kyn-green/25 transition-colors"
                      >
                        <div className="flex flex-wrap items-start justify-between gap-3">
                          <div className="min-w-0">
                            <div className="flex flex-wrap items-center gap-2 mb-1.5">
                              <Badge className={priorityStyle[job.priority] || priorityStyle.normal}>{job.priority}</Badge>
                              <Badge className={statusStyle[job.status] || statusStyle.pending}>{job.status.replace('_', ' ')}</Badge>
                            </div>
                            <h3 className="font-display font-semibold text-sm md:text-base">{job.title}</h3>
                            <p className="text-xs text-kyn-metal mt-1 flex flex-wrap items-center gap-x-3 gap-y-1">
                              <span className="inline-flex items-center gap-1"><Users size={11} /> {job.customer}</span>
                              <span className="inline-flex items-center gap-1"><MapPin size={11} /> {job.city}</span>
                              <span className="inline-flex items-center gap-1"><PlugZap size={11} /> {job.model}</span>
                            </p>
                          </div>
                          <div className="text-right shrink-0">
                            <p className="text-[10px] text-kyn-metal uppercase tracking-wider">Schedule</p>
                            <p className="text-xs font-semibold text-kyn-silver mt-0.5 inline-flex items-center gap-1">
                              <Clock size={11} className="text-kyn-green" /> {job.scheduled_at}
                            </p>
                            <p className="text-[11px] text-kyn-metal mt-1">{job.assignee}</p>
                          </div>
                        </div>
                        {job.notes && <p className="mt-3 text-xs text-kyn-silver/90 border-t border-white/5 pt-3">{job.notes}</p>}
                        <div className="mt-3 flex flex-wrap gap-2">
                          <button type="button" className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-kyn-green text-kyn-black text-[11px] font-bold">
                            <Play size={11} /> Start job
                          </button>
                          <button type="button" className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-white/10 text-[11px] text-kyn-silver hover:border-kyn-green/30">
                            <Navigation size={11} /> Navigate
                          </button>
                          <button type="button" className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-white/10 text-[11px] text-kyn-silver">
                            <MoreHorizontal size={11} /> Details
                          </button>
                        </div>
                      </motion.article>
                    ))}
                    {!filteredAssigned.length && (
                      <p className="text-sm text-kyn-metal text-center py-8">No assigned installations match your search.</p>
                    )}
                  </div>
                </GlassCard>

                {/* Installed chargers */}
                <div id="sec-chargers">
                  <GlassCard
                    title="Installed Chargers"
                    icon={PlugZap}
                    action={<Badge className="bg-white/5 text-kyn-silver border-white/10">{data.chargers.length} units</Badge>}
                  >
                    <div className="overflow-x-auto -mx-1">
                      <table className="w-full text-left text-xs min-w-[640px]">
                        <thead className="text-kyn-metal uppercase tracking-wider text-[10px]">
                          <tr className="border-b border-white/5">
                            <th className="pb-3 font-medium px-1">Serial</th>
                            <th className="pb-3 font-medium">Model</th>
                            <th className="pb-3 font-medium">Customer</th>
                            <th className="pb-3 font-medium">City</th>
                            <th className="pb-3 font-medium">Installed</th>
                            <th className="pb-3 font-medium">Status</th>
                            <th className="pb-3 font-medium">Warranty</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-white/5">
                          {data.chargers.map((c) => (
                            <tr key={c.id} className="text-kyn-silver">
                              <td className="py-3 px-1 font-mono text-kyn-green text-[11px]">{c.serial}</td>
                              <td className="py-3 font-medium text-white">{c.model}</td>
                              <td className="py-3">{c.customer}</td>
                              <td className="py-3">{c.city}</td>
                              <td className="py-3">{c.installed_at}</td>
                              <td className="py-3">
                                <Badge className={statusStyle[c.status] || statusStyle.online}>{c.status}</Badge>
                              </td>
                              <td className="py-3">{c.warranty}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </GlassCard>
                </div>
              </div>

              {/* Right column */}
              <div className="xl:col-span-2 space-y-6">
                {/* Today's schedule */}
                <div id="sec-schedule">
                  <GlassCard title="Today's Schedule" icon={CalendarDays} action={<span className="text-[10px] text-kyn-green font-semibold">LIVE DAY</span>}>
                    <div className="relative space-y-0">
                      <div className="absolute left-[15px] top-2 bottom-2 w-px bg-gradient-to-b from-kyn-green/50 via-white/10 to-transparent" />
                      {data.schedule.map((item, idx) => (
                        <div key={item.id} className="relative pl-10 pb-5 last:pb-0">
                          <div
                            className={cn(
                              'absolute left-2 top-1 w-3.5 h-3.5 rounded-full border-2',
                              idx === 0 ? 'bg-kyn-green border-kyn-green shadow-[0_0_12px_rgba(0,230,118,0.6)]' : 'bg-kyn-void border-white/25'
                            )}
                          />
                          <div className="rounded-xl border border-white/8 bg-black/30 p-3">
                            <div className="flex items-center justify-between gap-2">
                              <p className="text-[11px] font-semibold text-kyn-green">{item.scheduled_at?.split(' ').slice(-1)[0] || item.scheduled_at}</p>
                              <Badge className={statusStyle[item.status] || statusStyle.scheduled}>{item.status.replace('_', ' ')}</Badge>
                            </div>
                            <p className="text-sm font-medium mt-1">{item.title}</p>
                            <p className="text-[11px] text-kyn-metal mt-1">{item.city} · {item.customer}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </GlassCard>
                </div>

                {/* Maintenance */}
                <div id="sec-maintenance">
                  <GlassCard title="Pending Maintenance" icon={AlertTriangle} action={<Badge className="bg-orange-500/10 text-orange-300 border-orange-500/25">{data.maintenance.filter(m => m.status !== 'done').length}</Badge>}>
                    <div className="space-y-3">
                      {data.maintenance.map((m) => (
                        <div key={m.id} className="rounded-xl border border-white/8 bg-black/25 p-3.5">
                          <div className="flex items-start justify-between gap-2">
                            <div>
                              <p className="text-sm font-semibold">{m.title}</p>
                              <p className="text-[11px] text-kyn-metal mt-1">{m.site} · {m.model}</p>
                            </div>
                            <Badge className={priorityStyle[m.priority] || priorityStyle.medium}>{m.priority}</Badge>
                          </div>
                          <p className="text-xs text-kyn-silver mt-2">{m.issue}</p>
                          <div className="mt-3 flex items-center justify-between text-[11px] text-kyn-metal">
                            <span className="inline-flex items-center gap-1"><Clock size={11} /> Due {m.due_at}</span>
                            <span>{m.assignee}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </GlassCard>
                </div>

                {/* Tickets */}
                <div id="sec-tickets">
                  <GlassCard title="Recent Support Tickets" icon={Ticket}>
                    <div className="space-y-2.5">
                      {data.tickets.slice(0, 6).map((t) => (
                        <button
                          key={t.id}
                          type="button"
                          className="w-full text-left rounded-xl border border-white/8 bg-black/25 p-3 hover:border-kyn-green/25 transition-colors"
                        >
                          <div className="flex items-center justify-between gap-2">
                            <span className="font-mono text-[10px] text-kyn-green">{t.ticket_no}</span>
                            <Badge className={priorityStyle[t.priority] || priorityStyle.normal}>{t.priority}</Badge>
                          </div>
                          <p className="text-sm font-medium mt-1.5 line-clamp-1">{t.subject}</p>
                          <div className="mt-2 flex items-center justify-between text-[11px] text-kyn-metal">
                            <span>{t.name}</span>
                            <span className="inline-flex items-center gap-1 capitalize">
                              <CircleDot size={10} className="text-kyn-green" /> {t.status}
                            </span>
                          </div>
                        </button>
                      ))}
                    </div>
                  </GlassCard>
                </div>

                {/* Appointments */}
                <div id="sec-appointments">
                  <GlassCard title="Customer Appointments" icon={Users}>
                    <div className="space-y-3">
                      {data.appointments.map((a) => (
                        <div key={a.id} className="rounded-xl border border-white/8 bg-black/25 p-3.5 flex gap-3">
                          <div className="w-12 shrink-0 rounded-xl bg-kyn-green/10 border border-kyn-green/20 flex flex-col items-center justify-center text-center py-2">
                            <span className="text-[9px] text-kyn-metal uppercase">Slot</span>
                            <span className="text-[10px] font-bold text-kyn-green leading-tight px-1">{a.time_slot.split(' ')[0]}</span>
                          </div>
                          <div className="min-w-0 flex-1">
                            <div className="flex items-start justify-between gap-2">
                              <p className="text-sm font-semibold truncate">{a.customer}</p>
                              <Badge className={statusStyle[a.status] || statusStyle.confirmed}>{a.status}</Badge>
                            </div>
                            <p className="text-[11px] text-kyn-metal mt-1">{a.type} · {a.model}</p>
                            <p className="text-[11px] text-kyn-silver mt-1 flex items-center gap-1">
                              <MapPin size={10} /> {a.city} · {a.contact}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </GlassCard>
                </div>
              </div>
            </div>

            {/* Footer strip */}
            <div className="rounded-2xl border border-white/8 bg-gradient-to-r from-kyn-green/10 via-transparent to-transparent p-5 flex flex-wrap items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-kyn-green/15 border border-kyn-green/25 flex items-center justify-center text-kyn-green">
                  <Star size={18} />
                </div>
                <div>
                  <p className="font-display font-semibold text-sm">KYNETIK Certified Installer Workspace</p>
                  <p className="text-xs text-kyn-metal">Premium dark field OS · Electric green ops language · Cloud-connected</p>
                </div>
              </div>
              <div className="flex flex-wrap gap-2 text-[11px] text-kyn-metal">
                <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border border-white/10"><CheckCircle2 size={12} className="text-kyn-green" /> Desktop ready</span>
                <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border border-white/10"><CheckCircle2 size={12} className="text-kyn-green" /> Tablet responsive</span>
                <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border border-white/10"><CheckCircle2 size={12} className="text-kyn-green" /> Live Supabase data</span>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}

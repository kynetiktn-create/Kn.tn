import { useEffect, useMemo, useState, type ComponentType, type ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  Activity, AlertTriangle, ArrowLeft, Brain, CalendarClock, CheckCircle2,
  ChevronRight, Cpu, Gauge, RefreshCw, ShieldAlert, Thermometer,
  Wrench, Zap, Clock, Target, TrendingDown, Radio,
} from 'lucide-react';
import BrandLogo from '../components/BrandLogo';
import LoadingState from '../components/LoadingState';
import ErrorState from '../components/ErrorState';
import { apiGet, cn } from '../lib/utils';

interface PMItem {
  id: number;
  type: string;
  charger_id: string;
  title: string;
  subtitle: string;
  value: string;
  unit: string;
  status: string;
  severity: string;
  confidence: number;
  body: string;
  meta: string;
  sort_order: number;
}

function severityTone(sev: string) {
  const s = (sev || '').toLowerCase();
  if (s === 'critical') return 'text-red-400 bg-red-500/10 border-red-500/25';
  if (s === 'warning') return 'text-amber-300 bg-amber-500/10 border-amber-500/25';
  if (s === 'success' || s === 'healthy') return 'text-kyn-green bg-kyn-green/10 border-kyn-green/25';
  return 'text-sky-300 bg-sky-500/10 border-sky-500/25';
}

function GlassCard({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <div
      className={cn(
        'rounded-2xl border border-white/8 bg-gradient-to-b from-white/[0.05] to-white/[0.015] backdrop-blur-xl',
        className
      )}
    >
      {children}
    </div>
  );
}

function SectionTitle({
  icon: Icon,
  title,
  badge,
}: {
  icon: ComponentType<{ size?: number; className?: string }>;
  title: string;
  badge?: string;
}) {
  return (
    <div className="flex items-center justify-between gap-3 mb-4">
      <div className="flex items-center gap-2.5">
        <div className="w-8 h-8 rounded-xl bg-kyn-green/10 border border-kyn-green/20 flex items-center justify-center text-kyn-green">
          <Icon size={15} />
        </div>
        <h2 className="font-display font-semibold text-sm md:text-base tracking-tight">{title}</h2>
      </div>
      {badge && (
        <span className="text-[10px] font-semibold uppercase tracking-wider text-kyn-green bg-kyn-green/10 border border-kyn-green/20 px-2 py-0.5 rounded-full">
          {badge}
        </span>
      )}
    </div>
  );
}

function HealthRing({ score }: { score: number }) {
  const r = 72;
  const c = 2 * Math.PI * r;
  const offset = c - (Math.min(100, Math.max(0, score)) / 100) * c;
  const color = score >= 80 ? '#00e676' : score >= 60 ? '#fbbf24' : '#f87171';
  return (
    <div className="relative w-44 h-44 mx-auto">
      <svg className="w-full h-full -rotate-90" viewBox="0 0 160 160">
        <circle cx="80" cy="80" r={r} fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth="10" />
        <circle
          cx="80"
          cy="80"
          r={r}
          fill="none"
          stroke={color}
          strokeWidth="10"
          strokeLinecap="round"
          strokeDasharray={c}
          strokeDashoffset={offset}
          className="drop-shadow-[0_0_14px_rgba(0,230,118,0.45)]"
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="font-display text-4xl font-bold" style={{ color }}>
          {score}
        </span>
        <span className="text-[10px] uppercase tracking-[0.2em] text-kyn-metal mt-1">Health</span>
      </div>
    </div>
  );
}

function ConfidenceMeter({ score }: { score: number }) {
  const pct = Math.min(100, Math.max(0, score));
  return (
    <div className="space-y-3">
      <div className="flex items-end justify-between">
        <div>
          <p className="text-[10px] uppercase tracking-widest text-kyn-metal">AI Confidence Score</p>
          <p className="font-display text-4xl font-bold text-kyn-green text-glow mt-1">{pct.toFixed(0)}%</p>
        </div>
        <Brain className="text-kyn-green" size={22} />
      </div>
      <div className="h-2.5 rounded-full bg-white/5 overflow-hidden border border-white/5">
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: `${pct}%` }}
          transition={{ duration: 1, ease: [0.22, 1, 0.36, 1] }}
          className="h-full rounded-full bg-gradient-to-r from-kyn-green-dim via-kyn-green to-kyn-green-glow"
        />
      </div>
      <div className="grid grid-cols-3 gap-2 text-[10px]">
        <div className="rounded-lg bg-white/[0.03] border border-white/5 px-2 py-1.5 text-center">
          <p className="text-kyn-metal">Model</p>
          <p className="text-white font-medium mt-0.5">KYN-PM v2.4</p>
        </div>
        <div className="rounded-lg bg-white/[0.03] border border-white/5 px-2 py-1.5 text-center">
          <p className="text-kyn-metal">Samples</p>
          <p className="text-white font-medium mt-0.5">1.2M hrs</p>
        </div>
        <div className="rounded-lg bg-white/[0.03] border border-white/5 px-2 py-1.5 text-center">
          <p className="text-kyn-metal">Latency</p>
          <p className="text-white font-medium mt-0.5">~420ms</p>
        </div>
      </div>
    </div>
  );
}

function TempGauge({ celsius }: { celsius: number }) {
  const max = 90;
  const pct = Math.min(100, (celsius / max) * 100);
  const hot = celsius >= 65;
  const warm = celsius >= 50;
  const color = hot ? '#f87171' : warm ? '#fbbf24' : '#00e676';
  return (
    <div>
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Thermometer size={16} style={{ color }} />
          <span className="text-xs text-kyn-metal uppercase tracking-wider">Core temperature</span>
        </div>
        <span className="font-display text-2xl font-bold" style={{ color }}>
          {celsius}°C
        </span>
      </div>
      <div className="h-3 rounded-full bg-white/5 border border-white/5 overflow-hidden">
        <div
          className="h-full rounded-full transition-all duration-700"
          style={{
            width: `${pct}%`,
            background: `linear-gradient(90deg, #00e676, ${color})`,
          }}
        />
      </div>
      <div className="mt-2 flex justify-between text-[10px] text-kyn-metal">
        <span>Safe below 50°C</span>
        <span>Watch 50–65°C</span>
        <span>Critical above 65°C</span>
      </div>
    </div>
  );
}

export default function PredictiveMaintenance() {
  const [items, setItems] = useState<PMItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [selectedCharger, setSelectedCharger] = useState('all');
  const [refreshing, setRefreshing] = useState(false);

  const load = async () => {
    try {
      const data = await apiGet<PMItem[]>('/api/predictive-maintenance');
      setItems(Array.isArray(data) ? data : []);
      setError('');
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to load');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  const byType = (type: string) =>
    items
      .filter((i) => i.type === type)
      .filter((i) => selectedCharger === 'all' || i.charger_id === selectedCharger || i.charger_id === 'fleet');

  const chargers = useMemo(() => {
    const ids = Array.from(
      new Set(items.map((i) => i.charger_id).filter((id) => id && id !== 'fleet'))
    );
    return ids;
  }, [items]);

  const healthItems = byType('health');
  const tempItems = byType('temperature');
  const wearItems = byType('wear');
  const failureItems = byType('failure');
  const timelineItems = byType('timeline');
  const confidenceItems = byType('confidence');

  const primaryHealth = healthItems[0];
  const healthScore = Number(primaryHealth?.value || 86);
  const primaryTemp = tempItems[0];
  const tempValue = Number(primaryTemp?.value || 42);
  const confidenceScore = Number(confidenceItems[0]?.confidence ?? confidenceItems[0]?.value ?? 91);

  if (loading) {
    return (
      <div className="min-h-screen bg-kyn-black flex items-center justify-center">
        <LoadingState label="Loading predictive maintenance…" />
      </div>
    );
  }

  if (error && !items.length) {
    return (
      <div className="min-h-screen bg-kyn-black flex items-center justify-center p-8">
        <ErrorState message={error} />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-kyn-black text-white">
      {/* Top bar */}
      <header className="sticky top-0 z-40 border-b border-white/5 bg-kyn-black/80 backdrop-blur-xl">
        <div className="max-w-7xl mx-auto px-5 md:px-8 h-16 flex items-center justify-between gap-4">
          <div className="flex items-center gap-4 min-w-0">
            <Link to="/ai" className="text-kyn-metal hover:text-white transition-colors shrink-0">
              <ArrowLeft size={18} />
            </Link>
            <BrandLogo height={28} />
            <div className="hidden sm:block h-6 w-px bg-white/10" />
            <div className="min-w-0">
              <p className="text-[10px] uppercase tracking-[0.25em] text-kyn-green font-semibold">AI Ops</p>
              <h1 className="font-display font-semibold text-sm md:text-base truncate">Predictive Maintenance</h1>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <select
              value={selectedCharger}
              onChange={(e) => setSelectedCharger(e.target.value)}
              className="hidden md:block bg-kyn-steel/80 border border-white/10 rounded-xl text-xs px-3 py-2 text-kyn-silver focus:outline-none focus:border-kyn-green/40"
            >
              <option value="all">All chargers</option>
              {chargers.map((id) => (
                <option key={id} value={id}>
                  {id}
                </option>
              ))}
            </select>
            <button
              type="button"
              onClick={() => {
                setRefreshing(true);
                load();
              }}
              className="inline-flex items-center gap-2 px-3 py-2 rounded-xl border border-white/10 text-xs text-kyn-silver hover:text-white hover:border-kyn-green/30 transition-colors"
            >
              <RefreshCw size={13} className={refreshing ? 'animate-spin text-kyn-green' : ''} />
              <span className="hidden sm:inline">Refresh</span>
            </button>
            <span className="hidden sm:inline-flex items-center gap-1.5 text-[10px] text-kyn-green bg-kyn-green/10 border border-kyn-green/20 px-2.5 py-1.5 rounded-full font-semibold">
              <span className="w-1.5 h-1.5 rounded-full bg-kyn-green animate-pulse" /> LIVE
            </span>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-5 md:px-8 py-8 md:py-10 space-y-6">
        {/* Hero summary */}
        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}>
          <GlassCard className="p-6 md:p-8 relative overflow-hidden">
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,rgba(0,230,118,0.1),transparent_50%)]" />
            <div className="relative grid lg:grid-cols-[1.2fr_0.8fr] gap-8 items-center">
              <div>
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-kyn-green/30 bg-kyn-green/10 text-kyn-green text-[11px] font-semibold mb-4">
                  <Wrench size={12} /> Predictive Maintenance Engine
                </div>
                <h2 className="font-display text-2xl md:text-4xl font-bold leading-tight">
                  Anticipate failures before
                  <br />
                  <span className="text-kyn-green text-glow">they stop a session</span>
                </h2>
                <p className="mt-4 text-sm md:text-base text-kyn-silver max-w-xl leading-relaxed">
                  KYNETIK AI monitors thermal stress, connector wear and electrical anomalies across your fleet —
                  ranking risk and scheduling maintenance with operator-grade confidence scores.
                </p>
                <div className="mt-6 flex flex-wrap gap-3 text-[11px] text-kyn-metal">
                  <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/5 border border-white/8">
                    <Radio size={11} className="text-kyn-green" /> OCPP telemetry
                  </span>
                  <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/5 border border-white/8">
                    <Cpu size={11} className="text-kyn-green" /> Edge + Cloud model
                  </span>
                  <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/5 border border-white/8">
                    <Target size={11} className="text-kyn-green" /> Failure window 7–45 days
                  </span>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                {[
                  { l: 'Fleet health', v: `${healthScore}`, s: '/100' },
                  { l: 'AI confidence', v: `${Number(confidenceScore).toFixed(0)}`, s: '%' },
                  { l: 'Open risks', v: String(failureItems.length || 3), s: 'alerts' },
                  { l: 'Jobs queued', v: String(timelineItems.length || 4), s: 'tasks' },
                ].map((k) => (
                  <div key={k.l} className="rounded-2xl border border-white/8 bg-black/30 p-4">
                    <p className="text-[10px] uppercase tracking-wider text-kyn-metal">{k.l}</p>
                    <p className="font-display text-2xl font-bold mt-1 text-white">
                      {k.v}
                      <span className="text-xs text-kyn-metal font-medium ml-1">{k.s}</span>
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </GlassCard>
        </motion.div>

        {/* Mobile charger filter */}
        <div className="md:hidden">
          <select
            value={selectedCharger}
            onChange={(e) => setSelectedCharger(e.target.value)}
            className="w-full bg-kyn-steel/80 border border-white/10 rounded-xl text-xs px-3 py-3 text-kyn-silver"
          >
            <option value="all">All chargers</option>
            {chargers.map((id) => (
              <option key={id} value={id}>
                {id}
              </option>
            ))}
          </select>
        </div>

        {/* Row: Health + Temperature + Confidence */}
        <div className="grid lg:grid-cols-3 gap-4">
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.05 }}>
            <GlassCard className="p-5 h-full">
              <SectionTitle icon={Activity} title="Charger Health" badge="Live" />
              <HealthRing score={healthScore} />
              <div className="mt-4 space-y-2">
                {(healthItems.length ? healthItems : [
                  { id: 0, title: 'Overall condition', value: String(healthScore), status: 'healthy', severity: 'success', body: 'Within nominal operating envelope', subtitle: '', charger_id: '', type: '', unit: '', confidence: 0, meta: '', sort_order: 0 },
                ]).slice(0, 3).map((h) => (
                  <div key={h.id + h.title} className="flex items-center justify-between rounded-xl bg-black/25 border border-white/5 px-3 py-2.5">
                    <div className="min-w-0">
                      <p className="text-xs font-medium truncate">{h.title}</p>
                      <p className="text-[10px] text-kyn-metal truncate">{h.body || h.subtitle}</p>
                    </div>
                    <span className={cn('text-[10px] px-2 py-0.5 rounded-full border capitalize shrink-0 ml-2', severityTone(h.severity || h.status))}>
                      {h.status || h.severity || h.value}
                    </span>
                  </div>
                ))}
              </div>
            </GlassCard>
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
            <GlassCard className="p-5 h-full">
              <SectionTitle icon={Thermometer} title="Temperature" badge="Thermal" />
              <TempGauge celsius={tempValue} />
              <div className="mt-5 space-y-2">
                {(tempItems.length ? tempItems : []).slice(0, 4).map((t) => (
                  <div key={t.id} className="flex items-center justify-between text-xs rounded-xl border border-white/5 bg-white/[0.02] px-3 py-2.5">
                    <div>
                      <p className="font-medium">{t.title}</p>
                      <p className="text-[10px] text-kyn-metal mt-0.5">{t.charger_id}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-display font-semibold" style={{ color: Number(t.value) >= 65 ? '#f87171' : Number(t.value) >= 50 ? '#fbbf24' : '#00e676' }}>
                        {t.value}{t.unit || '°C'}
                      </p>
                      <p className="text-[10px] text-kyn-metal">{t.status}</p>
                    </div>
                  </div>
                ))}
                {!tempItems.length && (
                  <p className="text-xs text-kyn-metal">No temperature probes in filter.</p>
                )}
              </div>
            </GlassCard>
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }}>
            <GlassCard className="p-5 h-full">
              <SectionTitle icon={Brain} title="AI Confidence Score" badge="Model" />
              <ConfidenceMeter score={Number(confidenceScore)} />
              <div className="mt-5 rounded-xl border border-kyn-green/20 bg-kyn-green/5 p-3">
                <p className="text-[11px] text-kyn-silver leading-relaxed">
                  {confidenceItems[0]?.body ||
                    'Ensemble model blends thermal drift, session abort rate, contactor cycles and grid voltage noise. Confidence reflects prediction stability over the last 14 days.'}
                </p>
              </div>
            </GlassCard>
          </motion.div>
        </div>

        {/* Component Wear */}
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.18 }}>
          <GlassCard className="p-5 md:p-6">
            <SectionTitle icon={Gauge} title="Component Wear" badge="Lifecycle" />
            <div className="grid sm:grid-cols-2 xl:grid-cols-4 gap-3">
              {(wearItems.length
                ? wearItems
                : [
                    { id: 1, title: 'Contactor', value: '38', unit: '%', status: 'nominal', severity: 'success', body: 'Cycle life remaining', charger_id: '—', type: 'wear', subtitle: '', confidence: 0, meta: '', sort_order: 0 },
                    { id: 2, title: 'Cable / Connector', value: '54', unit: '%', status: 'watch', severity: 'warning', body: 'Insertion wear index', charger_id: '—', type: 'wear', subtitle: '', confidence: 0, meta: '', sort_order: 0 },
                    { id: 3, title: 'Relay board', value: '22', unit: '%', status: 'nominal', severity: 'success', body: 'Switching stress', charger_id: '—', type: 'wear', subtitle: '', confidence: 0, meta: '', sort_order: 0 },
                    { id: 4, title: 'Cooling path', value: '47', unit: '%', status: 'watch', severity: 'warning', body: 'Dust / thermal resistance', charger_id: '—', type: 'wear', subtitle: '', confidence: 0, meta: '', sort_order: 0 },
                  ]
              ).map((w, i) => {
                const wear = Number(w.value) || 0;
                const tone = wear >= 70 ? '#f87171' : wear >= 45 ? '#fbbf24' : '#00e676';
                return (
                  <div key={w.id || i} className="rounded-2xl border border-white/8 bg-black/25 p-4">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <p className="font-display font-semibold text-sm">{w.title}</p>
                        <p className="text-[10px] text-kyn-metal mt-0.5">{w.charger_id}</p>
                      </div>
                      <span className={cn('text-[9px] px-2 py-0.5 rounded-full border capitalize', severityTone(w.severity || w.status))}>
                        {w.status}
                      </span>
                    </div>
                    <p className="mt-4 font-display text-3xl font-bold" style={{ color: tone }}>
                      {w.value}
                      <span className="text-sm text-kyn-metal">{w.unit || '%'}</span>
                    </p>
                    <div className="mt-3 h-1.5 rounded-full bg-white/5 overflow-hidden">
                      <div className="h-full rounded-full" style={{ width: `${Math.min(100, wear)}%`, background: tone }} />
                    </div>
                    <p className="mt-3 text-[11px] text-kyn-silver leading-relaxed">{w.body}</p>
                  </div>
                );
              })}
            </div>
          </GlassCard>
        </motion.div>

        {/* Failure Prediction + Timeline */}
        <div className="grid lg:grid-cols-2 gap-4">
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
            <GlassCard className="p-5 md:p-6 h-full">
              <SectionTitle icon={ShieldAlert} title="Failure Prediction" badge="Risk" />
              <div className="space-y-3">
                {(failureItems.length
                  ? failureItems
                  : []
                ).map((f) => (
                  <div
                    key={f.id}
                    className="rounded-2xl border border-white/8 bg-black/30 p-4 hover:border-white/15 transition-colors"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <p className="font-semibold text-sm">{f.title}</p>
                          <span className={cn('text-[9px] px-2 py-0.5 rounded-full border capitalize', severityTone(f.severity))}>
                            {f.severity || f.status}
                          </span>
                        </div>
                        <p className="text-[11px] text-kyn-metal mt-1">{f.charger_id} · {f.subtitle}</p>
                      </div>
                      <div className="text-right shrink-0">
                        <p className="text-[10px] text-kyn-metal uppercase tracking-wider">Window</p>
                        <p className="font-display font-bold text-kyn-green">{f.value}{f.unit ? ` ${f.unit}` : ''}</p>
                      </div>
                    </div>
                    <p className="mt-3 text-xs text-kyn-silver leading-relaxed">{f.body}</p>
                    <div className="mt-3 flex items-center justify-between">
                      <span className="text-[10px] text-kyn-metal inline-flex items-center gap-1">
                        <Brain size={11} className="text-kyn-green" />
                        Confidence {Number(f.confidence || 0).toFixed(0)}%
                      </span>
                      <button type="button" className="text-[11px] font-semibold text-kyn-green inline-flex items-center gap-1">
                        Create work order <ChevronRight size={12} />
                      </button>
                    </div>
                  </div>
                ))}
                {!failureItems.length && (
                  <div className="rounded-2xl border border-kyn-green/20 bg-kyn-green/5 p-6 text-center">
                    <CheckCircle2 className="mx-auto text-kyn-green mb-2" size={22} />
                    <p className="text-sm font-medium">No critical failure windows</p>
                    <p className="text-xs text-kyn-metal mt-1">Fleet predictions are within safe thresholds.</p>
                  </div>
                )}
              </div>
            </GlassCard>
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.25 }}>
            <GlassCard className="p-5 md:p-6 h-full">
              <SectionTitle icon={CalendarClock} title="Maintenance Timeline" badge="Schedule" />
              <div className="relative pl-4 space-y-0">
                <div className="absolute left-[11px] top-2 bottom-2 w-px bg-gradient-to-b from-kyn-green/50 via-white/10 to-transparent" />
                {(timelineItems.length ? timelineItems : []).map((t, idx) => (
                  <div key={t.id} className="relative pl-6 pb-5 last:pb-0">
                    <div
                      className={cn(
                        'absolute left-0 top-1.5 w-[9px] h-[9px] rounded-full border-2',
                        idx === 0 ? 'bg-kyn-green border-kyn-green shadow-[0_0_12px_rgba(0,230,118,0.6)]' : 'bg-kyn-black border-white/25'
                      )}
                    />
                    <div className="rounded-xl border border-white/8 bg-black/25 p-3.5">
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <p className="text-sm font-semibold">{t.title}</p>
                          <p className="text-[10px] text-kyn-metal mt-0.5 inline-flex items-center gap-1">
                            <Clock size={10} /> {t.value}{t.unit ? ` ${t.unit}` : ''} · {t.charger_id}
                          </p>
                        </div>
                        <span className={cn('text-[9px] px-2 py-0.5 rounded-full border capitalize shrink-0', severityTone(t.severity || t.status))}>
                          {t.status || t.severity}
                        </span>
                      </div>
                      <p className="mt-2 text-[11px] text-kyn-silver leading-relaxed">{t.body}</p>
                    </div>
                  </div>
                ))}
                {!timelineItems.length && (
                  <p className="text-xs text-kyn-metal pl-6">No scheduled maintenance in this filter.</p>
                )}
              </div>
            </GlassCard>
          </motion.div>
        </div>

        {/* Footer actions */}
        <GlassCard className="p-5 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-kyn-green/10 border border-kyn-green/20 flex items-center justify-center text-kyn-green">
              <TrendingDown size={18} />
            </div>
            <div>
              <p className="font-display font-semibold text-sm">Reduce unplanned downtime</p>
              <p className="text-[11px] text-kyn-metal">Export risk report or open Cloud Console work orders</p>
            </div>
          </div>
          <div className="flex flex-wrap gap-2">
            <Link
              to="/console"
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-full border border-white/12 text-xs font-semibold text-kyn-silver hover:text-white"
            >
              Open Console
            </Link>
            <Link
              to="/ai"
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-full bg-kyn-green text-kyn-black text-xs font-bold"
            >
              Back to AI Dashboard <ChevronRight size={13} />
            </Link>
          </div>
        </GlassCard>
      </main>
    </div>
  );
}

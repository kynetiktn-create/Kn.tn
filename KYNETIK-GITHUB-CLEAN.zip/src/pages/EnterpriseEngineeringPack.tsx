import { useEffect, useMemo, useState, type ComponentType, type ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  ArrowRight, Menu, X, FileCode2, Network, Database, Server,
  FlaskConical, BookOpen, Shield, CheckCircle2, ChevronRight,
  Layers, Terminal, Gauge, Lock, Cloud, Sparkles, Download,
  Building2, Code2, GitBranch, Activity, Eye, BadgeCheck
} from 'lucide-react';
import BrandLogo from '../components/BrandLogo';
import LoadingState from '../components/LoadingState';
import { apiGet, cn } from '../lib/utils';

interface Item {
  id: number;
  type: string;
  category: string;
  title: string;
  subtitle: string;
  body: string;
  meta: string | null;
  sort_order: number;
}

type DocId = 'sad' | 'openapi' | 'schema' | 'devops' | 'test' | 'ops_manual' | 'cyber';

const DOCS: {
  id: DocId;
  code: string;
  title: string;
  fr: string;
  blurb: string;
  icon: ComponentType<{ size?: number; className?: string }>;
  accent: string;
  links: { to: string; label: string }[];
}[] = [
  {
    id: 'sad',
    code: 'SAD',
    title: 'Software Architecture Document',
    fr: 'Architecture logicielle détaillée',
    blurb: 'C4 views, bounded contexts, OCPP plane, integration patterns and NFR targets for the KYNETIK platform.',
    icon: Network,
    accent: 'sky',
    links: [
      { to: '/architecture', label: 'Enterprise architecture' },
      { to: '/developers', label: 'Developer portal' },
    ],
  },
  {
    id: 'openapi',
    code: 'API',
    title: 'API Specification (OpenAPI)',
    fr: 'Définition complète des API',
    blurb: 'REST contract for stations, sessions, energy, webhooks and quotes — auth, errors and versioning.',
    icon: FileCode2,
    accent: 'violet',
    links: [
      { to: '/developers', label: 'API docs' },
      { to: '/developers/playground', label: 'Playground' },
    ],
  },
  {
    id: 'schema',
    code: 'DB',
    title: 'Database Schema',
    fr: 'Modèle de données détaillé',
    blurb: 'Multi-tenant identity, devices, sessions, billing, field ops and platform tables with integrity rules.',
    icon: Database,
    accent: 'emerald',
    links: [
      { to: '/database', label: 'Database architecture' },
      { to: '/architecture', label: 'Data layer' },
    ],
  },
  {
    id: 'devops',
    code: 'OPS',
    title: 'Infrastructure & DevOps Guide',
    fr: 'Déploiement, CI/CD, backups, supervision',
    blurb: 'Environments, pipelines, release gates, DR, observability and secrets hygiene.',
    icon: Server,
    accent: 'amber',
    links: [
      { to: '/architecture', label: 'DevOps section' },
      { to: '/ops', label: 'Operational blueprint' },
    ],
  },
  {
    id: 'test',
    code: 'QA',
    title: 'Test Strategy',
    fr: 'Tests fonctionnels, techniques et sécurité',
    blurb: 'Pyramid, OCPP conformance, load, security tests, UAT gates and PRD traceability.',
    icon: FlaskConical,
    accent: 'rose',
    links: [
      { to: '/prd', label: 'PRD acceptance' },
      { to: '/docs-suite', label: 'Quality volume' },
    ],
  },
  {
    id: 'ops_manual',
    code: 'RUN',
    title: 'Operations Manual',
    fr: "Guide d'exploitation de la plateforme",
    blurb: 'NOC model, daily checks, incident response, change management and charger lifecycle ops.',
    icon: BookOpen,
    accent: 'teal',
    links: [
      { to: '/ops', label: 'Ops blueprint' },
      { to: '/maintenance', label: 'Maintenance UI' },
    ],
  },
  {
    id: 'cyber',
    code: 'SEC',
    title: 'Cybersecurity & Compliance',
    fr: 'Sécurité, accès et conformité',
    blurb: 'Principles, IAM, data protection, appsec, OCPP security, audit and compliance roadmap.',
    icon: Shield,
    accent: 'red',
    links: [
      { to: '/architecture', label: 'Security architecture' },
      { to: '/docs-suite', label: 'Security volume' },
    ],
  },
];

const accentMap: Record<string, { text: string; bg: string; border: string; ring: string; soft: string }> = {
  sky: { text: 'text-sky-300', bg: 'bg-sky-400/10', border: 'border-sky-400/30', ring: 'ring-sky-400/40', soft: 'from-sky-500/10' },
  violet: { text: 'text-violet-300', bg: 'bg-violet-400/10', border: 'border-violet-400/30', ring: 'ring-violet-400/40', soft: 'from-violet-500/10' },
  emerald: { text: 'text-emerald-300', bg: 'bg-emerald-400/10', border: 'border-emerald-400/30', ring: 'ring-emerald-400/40', soft: 'from-emerald-500/10' },
  amber: { text: 'text-amber-300', bg: 'bg-amber-400/10', border: 'border-amber-400/30', ring: 'ring-amber-400/40', soft: 'from-amber-500/10' },
  rose: { text: 'text-rose-300', bg: 'bg-rose-400/10', border: 'border-rose-400/30', ring: 'ring-rose-400/40', soft: 'from-rose-500/10' },
  teal: { text: 'text-teal-300', bg: 'bg-teal-400/10', border: 'border-teal-400/30', ring: 'ring-teal-400/40', soft: 'from-teal-500/10' },
  red: { text: 'text-red-300', bg: 'bg-red-400/10', border: 'border-red-400/30', ring: 'ring-red-400/40', soft: 'from-red-500/10' },
};

function Fade({ children, className, delay = 0 }: { children: ReactNode; className?: string; delay?: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 18 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-40px' }}
      transition={{ duration: 0.45, delay }}
      className={className}
    >
      {children}
    </motion.div>
  );
}

export default function EnterpriseEngineeringPack() {
  const [items, setItems] = useState<Item[]>([]);
  const [loading, setLoading] = useState(true);
  const [active, setActive] = useState<DocId>('sad');
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    apiGet<Item[]>('/api/marketing-content?type=eng_pack')
      .then((d) => setItems(Array.isArray(d) ? d : []))
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 16);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const doc = DOCS.find((d) => d.id === active) || DOCS[0];
  const a = accentMap[doc.accent];

  const sections = useMemo(
    () =>
      items
        .filter((i) => i.category === active)
        .sort((x, y) => (x.sort_order ?? 0) - (y.sort_order ?? 0)),
    [items, active]
  );

  const counts = useMemo(() => {
    const m: Record<string, number> = {};
    for (const d of DOCS) m[d.id] = items.filter((i) => i.category === d.id).length;
    return m;
  }, [items]);

  if (loading) {
    return (
      <div className="min-h-screen bg-[#04060a] flex items-center justify-center">
        <LoadingState label="Loading engineering pack…" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#04060a] text-slate-100">
      <header
        className={cn(
          'fixed top-0 inset-x-0 z-50 transition-all',
          scrolled ? 'bg-[#04060a]/90 backdrop-blur-xl border-b border-white/[0.06]' : 'bg-transparent'
        )}
      >
        <div className="max-w-[1440px] mx-auto px-4 md:px-6 h-14 md:h-16 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <BrandLogo height={28} />
            <div className="hidden md:block h-5 w-px bg-white/10" />
            <div className="hidden md:flex items-center gap-2 min-w-0">
              <Layers size={14} className="text-sky-400 shrink-0" />
              <span className="text-xs font-medium text-slate-300 truncate">Enterprise Engineering Pack</span>
              <span className="text-[10px] font-mono px-1.5 py-0.5 rounded border border-white/10 text-slate-500">Phase 27</span>
            </div>
          </div>
          <nav className="hidden lg:flex items-center gap-1 text-[11px] text-slate-400">
            <Link to="/prd" className="px-2.5 py-1.5 rounded-lg hover:text-white hover:bg-white/5">PRD</Link>
            <Link to="/architecture" className="px-2.5 py-1.5 rounded-lg hover:text-white hover:bg-white/5">Architecture</Link>
            <Link to="/docs-suite" className="px-2.5 py-1.5 rounded-lg hover:text-white hover:bg-white/5">Docs Suite</Link>
            <Link to="/database" className="px-2.5 py-1.5 rounded-lg hover:text-white hover:bg-white/5">Database</Link>
          </nav>
          <div className="flex items-center gap-2">
            <Link
              to="/developers"
              className="hidden sm:inline-flex items-center gap-1.5 text-xs font-semibold px-3 py-2 rounded-full bg-kyn-green text-kyn-black hover:bg-kyn-green-glow transition-colors"
            >
              API Portal <ArrowRight size={14} />
            </Link>
            <button type="button" className="lg:hidden p-2 rounded-lg border border-white/10" onClick={() => setMenuOpen((v) => !v)} aria-label="Menu">
              {menuOpen ? <X size={18} /> : <Menu size={18} />}
            </button>
          </div>
        </div>
        <AnimatePresence>
          {menuOpen && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="lg:hidden border-t border-white/10 bg-[#04060a] overflow-hidden"
            >
              <div className="px-4 py-3 grid grid-cols-1 gap-1 max-h-[70vh] overflow-y-auto">
                {DOCS.map((d) => (
                  <button
                    key={d.id}
                    type="button"
                    onClick={() => {
                      setActive(d.id);
                      setMenuOpen(false);
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                    className={cn(
                      'text-left px-3 py-2.5 rounded-xl text-sm border',
                      active === d.id ? 'border-sky-400/40 bg-sky-400/10 text-white' : 'border-transparent text-slate-400'
                    )}
                  >
                    <span className="font-mono text-[10px] text-slate-500 mr-2">{d.code}</span>
                    {d.title}
                  </button>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </header>

      {/* Hero */}
      <section className="relative pt-28 md:pt-32 pb-12 md:pb-16 overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(56,189,248,0.12),transparent_55%)]" />
        <div className="absolute inset-0 bg-[linear-gradient(to_bottom,transparent,rgba(4,6,10,0.95))]" />
        <div className="relative max-w-[1440px] mx-auto px-4 md:px-6">
          <Fade>
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-sky-400/25 bg-sky-400/10 text-sky-300 text-[11px] font-semibold tracking-wide mb-5">
              <BadgeCheck size={13} />
              Engineering · Investor & partner ready
            </div>
            <h1 className="font-display text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight max-w-4xl leading-[1.08]">
              Enterprise Engineering Pack
              <span className="block text-sky-300 mt-2">Seven documents that close the gap</span>
            </h1>
            <p className="mt-5 text-slate-400 text-base md:text-lg max-w-2xl leading-relaxed">
              SAD · OpenAPI · Database Schema · DevOps · Test Strategy · Operations Manual · Cybersecurity & Compliance —
              the pack engineering teams, investors and technical partners expect after vision, design and PRD.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              {[
                { n: '7', l: 'Core documents' },
                { n: String(items.length), l: 'Controlled sections' },
                { n: '99.5%+', l: 'Availability target' },
                { n: 'OCPP', l: '1.6J ready' },
              ].map((s) => (
                <div key={s.l} className="px-4 py-3 rounded-2xl border border-white/10 bg-white/[0.03] min-w-[120px]">
                  <p className="font-display text-xl font-bold text-white">{s.n}</p>
                  <p className="text-[11px] text-slate-500 mt-0.5">{s.l}</p>
                </div>
              ))}
            </div>
          </Fade>

          {/* Doc picker grid */}
          <Fade delay={0.08} className="mt-10 md:mt-12">
            <div className="grid sm:grid-cols-2 xl:grid-cols-4 gap-3">
              {DOCS.map((d) => {
                const Icon = d.icon;
                const ac = accentMap[d.accent];
                const on = active === d.id;
                return (
                  <button
                    key={d.id}
                    type="button"
                    onClick={() => {
                      setActive(d.id);
                      document.getElementById('doc-body')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
                    }}
                    className={cn(
                      'text-left rounded-2xl border p-4 transition-all group',
                      on
                        ? cn(ac.border, ac.bg, 'ring-1', ac.ring)
                        : 'border-white/10 bg-white/[0.02] hover:border-white/20 hover:bg-white/[0.04]'
                    )}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className={cn('w-9 h-9 rounded-xl border flex items-center justify-center', ac.border, ac.bg, ac.text)}>
                        <Icon size={18} />
                      </div>
                      <span className="text-[10px] font-mono text-slate-500">{d.code}</span>
                    </div>
                    <p className="mt-3 text-sm font-semibold text-white leading-snug group-hover:text-white">{d.title}</p>
                    <p className="mt-1 text-[11px] text-slate-500 leading-relaxed line-clamp-2">{d.fr}</p>
                    <p className="mt-3 text-[10px] text-slate-500 font-medium">
                      {counts[d.id] || 0} sections
                      {on && <ChevronRight size={12} className="inline ml-1 -mt-0.5" />}
                    </p>
                  </button>
                );
              })}
            </div>
          </Fade>
        </div>
      </section>

      {/* Document body */}
      <section id="doc-body" className="scroll-mt-24 pb-20">
        <div className="max-w-[1440px] mx-auto px-4 md:px-6">
          <div className="grid lg:grid-cols-[240px_1fr] gap-6 lg:gap-10">
            {/* Side nav desktop */}
            <aside className="hidden lg:block">
              <div className="sticky top-24 space-y-1">
                <p className="text-[10px] uppercase tracking-[0.2em] text-slate-500 font-semibold px-3 mb-2">Documents</p>
                {DOCS.map((d) => {
                  const Icon = d.icon;
                  const ac = accentMap[d.accent];
                  const on = active === d.id;
                  return (
                    <button
                      key={d.id}
                      type="button"
                      onClick={() => setActive(d.id)}
                      className={cn(
                        'w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-left text-xs transition-colors',
                        on ? cn(ac.bg, ac.text, 'font-semibold') : 'text-slate-400 hover:text-white hover:bg-white/5'
                      )}
                    >
                      <Icon size={14} className="shrink-0" />
                      <span className="truncate">{d.code} · {d.title.split(' ')[0]}</span>
                    </button>
                  );
                })}
                <div className="pt-4 mt-4 border-t border-white/10 px-3 space-y-2">
                  <p className="text-[10px] uppercase tracking-[0.2em] text-slate-500 font-semibold">Related</p>
                  <Link to="/prd" className="block text-xs text-slate-400 hover:text-kyn-green">PRD v1.0</Link>
                  <Link to="/docs-suite" className="block text-xs text-slate-400 hover:text-kyn-green">Docs Suite v3</Link>
                  <Link to="/product-spec" className="block text-xs text-slate-400 hover:text-kyn-green">Product Spec</Link>
                </div>
              </div>
            </aside>

            <div>
              <AnimatePresence mode="wait">
                <motion.div
                  key={doc.id}
                  initial={{ opacity: 0, y: 12 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -8 }}
                  transition={{ duration: 0.28 }}
                >
                  {/* Doc header */}
                  <div className={cn('relative rounded-3xl border overflow-hidden mb-8', a.border)}>
                    <div className={cn('absolute inset-0 bg-gradient-to-br to-transparent opacity-80', a.soft)} />
                    <div className="relative p-6 md:p-8">
                      <div className="flex flex-wrap items-start justify-between gap-4">
                        <div>
                          <div className="flex items-center gap-2 mb-3">
                            <span className={cn('text-[11px] font-mono font-bold px-2 py-0.5 rounded border', a.border, a.bg, a.text)}>
                              {doc.code}
                            </span>
                            <span className="text-[11px] text-slate-500">Controlled document · living</span>
                          </div>
                          <h2 className="font-display text-2xl md:text-3xl font-bold tracking-tight">{doc.title}</h2>
                          <p className="mt-1 text-sm text-slate-400">{doc.fr}</p>
                          <p className="mt-4 text-slate-300 max-w-2xl leading-relaxed text-sm md:text-[15px]">{doc.blurb}</p>
                        </div>
                        <div className={cn('w-14 h-14 rounded-2xl border flex items-center justify-center shrink-0', a.border, a.bg, a.text)}>
                          <doc.icon size={28} />
                        </div>
                      </div>
                      <div className="mt-6 flex flex-wrap gap-2">
                        {doc.links.map((l) => (
                          <Link
                            key={l.to}
                            to={l.to}
                            className="inline-flex items-center gap-1.5 text-xs font-medium px-3 py-1.5 rounded-full border border-white/12 text-slate-300 hover:border-white/25 hover:text-white transition-colors"
                          >
                            {l.label} <ArrowRight size={12} />
                          </Link>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Meta strip per doc */}
                  <div className="grid sm:grid-cols-3 gap-3 mb-8">
                    {(
                      doc.id === 'sad'
                        ? [
                            { i: Layers, t: 'C4 + domains', d: 'Context to components' },
                            { i: Cloud, t: 'OCPP plane', d: 'CSMS integration' },
                            { i: Gauge, t: 'NFR locked', d: 'Latency · uptime · DR' },
                          ]
                        : doc.id === 'openapi'
                          ? [
                              { i: Terminal, t: 'REST /v1', d: 'Stations · sessions' },
                              { i: Lock, t: 'Bearer auth', d: 'Keys + JWT' },
                              { i: GitBranch, t: 'Versioned', d: '90-day deprecations' },
                            ]
                          : doc.id === 'schema'
                            ? [
                                { i: Building2, t: 'Multi-tenant', d: 'Org isolation' },
                                { i: Database, t: 'Core entities', d: 'Devices → billing' },
                                { i: Eye, t: 'PII tagged', d: 'Retention ready' },
                              ]
                            : doc.id === 'devops'
                              ? [
                                  { i: GitBranch, t: 'CI/CD', d: 'PR → prod gates' },
                                  { i: Server, t: 'DR drills', d: 'RPO / RTO' },
                                  { i: Activity, t: 'Observability', d: 'Logs · metrics' },
                                ]
                              : doc.id === 'test'
                                ? [
                                    { i: FlaskConical, t: 'Pyramid', d: 'Unit → E2E' },
                                    { i: Network, t: 'OCPP suite', d: 'Conformance' },
                                    { i: Shield, t: 'Security', d: 'IDOR · pen-test' },
                                  ]
                                : doc.id === 'ops_manual'
                                  ? [
                                      { i: Activity, t: 'NOC daily', d: 'Checklist driven' },
                                      { i: BookOpen, t: 'Incidents', d: 'SEV + postmortem' },
                                      { i: CheckCircle2, t: 'SLAs', d: 'Comms templates' },
                                    ]
                                  : [
                                      { i: Shield, t: 'Least privilege', d: 'RBAC + MFA' },
                                      { i: Lock, t: 'Encryption', d: 'Transit + rest' },
                                      { i: BadgeCheck, t: 'Compliance', d: 'GDPR · ISO map' },
                                    ]
                    ).map((c) => (
                      <div key={c.t} className="rounded-2xl border border-white/10 bg-white/[0.02] p-4 flex gap-3">
                        <div className={cn('w-9 h-9 rounded-xl border flex items-center justify-center shrink-0', a.border, a.bg, a.text)}>
                          <c.i size={16} />
                        </div>
                        <div>
                          <p className="text-sm font-semibold text-white">{c.t}</p>
                          <p className="text-[11px] text-slate-500 mt-0.5">{c.d}</p>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Sections */}
                  <div className="space-y-3">
                    <div className="flex items-center justify-between gap-3 mb-2">
                      <h3 className="text-xs font-semibold tracking-[0.2em] uppercase text-slate-500">Document sections</h3>
                      <span className="text-[11px] text-slate-600 font-mono">{sections.length} items</span>
                    </div>
                    {sections.length === 0 ? (
                      <div className="rounded-2xl border border-dashed border-white/10 p-10 text-center text-slate-500 text-sm">
                        No sections loaded — check API seed.
                      </div>
                    ) : (
                      sections.map((s, idx) => (
                        <Fade key={s.id} delay={Math.min(idx * 0.03, 0.2)}>
                          <article className="rounded-2xl border border-white/10 bg-gradient-to-b from-white/[0.035] to-transparent p-5 md:p-6 hover:border-white/18 transition-colors">
                            <div className="flex flex-wrap items-start gap-3 justify-between">
                              <div className="min-w-0">
                                <div className="flex flex-wrap items-center gap-2 mb-1.5">
                                  {s.meta && (
                                    <span className={cn('text-[10px] font-mono px-1.5 py-0.5 rounded border', a.border, a.bg, a.text)}>
                                      {s.meta}
                                    </span>
                                  )}
                                  <span className="text-[10px] text-slate-600 uppercase tracking-wider">{s.subtitle}</span>
                                </div>
                                <h4 className="font-display text-lg font-semibold text-white tracking-tight">{s.title}</h4>
                              </div>
                              <span className="text-[10px] font-mono text-slate-600 tabular-nums">§{String(idx + 1).padStart(2, '0')}</span>
                            </div>
                            <p className="mt-3 text-sm text-slate-400 leading-relaxed">{s.body}</p>
                          </article>
                        </Fade>
                      ))
                    )}
                  </div>

                  {/* OpenAPI sample block */}
                  {doc.id === 'openapi' && (
                    <div className="mt-8 rounded-2xl border border-violet-400/25 bg-[#0a0c12] overflow-hidden">
                      <div className="flex items-center justify-between px-4 py-2.5 border-b border-white/5 bg-white/[0.02]">
                        <span className="text-[11px] font-mono text-violet-300">openapi snippet · remote-start</span>
                        <Code2 size={14} className="text-slate-500" />
                      </div>
                      <pre className="p-4 md:p-5 text-[11px] md:text-xs leading-relaxed text-slate-300 overflow-x-auto font-mono">{`POST /v1/sessions/remote-start
Authorization: Bearer kyn_live_***
Content-Type: application/json

{
  "station_id": "stn_tn_lac2_01",
  "connector_id": 1,
  "id_tag": "RFID-88421",
  "charging_profile": "smart_offpeak"
}

→ 200 { "session_id": "ses_…", "status": "Accepted" }`}</pre>
                    </div>
                  )}

                  {/* Schema ER shorthand */}
                  {doc.id === 'schema' && (
                    <div className="mt-8 rounded-2xl border border-emerald-400/25 bg-emerald-400/[0.04] p-5 md:p-6">
                      <p className="text-[11px] font-semibold tracking-[0.2em] uppercase text-emerald-300 mb-3">Core relationship chain</p>
                      <p className="font-mono text-xs md:text-sm text-slate-300 leading-relaxed break-words">
                        organization → membership → user
                        <br />
                        organization → site → charge_point → connector
                        <br />
                        connector → charging_session → meter_values
                        <br />
                        organization → tariff → invoice → payment
                        <br />
                        charge_point → work_order / ticket → audit_log
                      </p>
                    </div>
                  )}
                </motion.div>
              </AnimatePresence>

              {/* Bottom CTA */}
              <div className="mt-14 rounded-3xl border border-white/10 bg-gradient-to-br from-sky-500/10 via-transparent to-kyn-green/5 p-6 md:p-10">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                  <div>
                    <div className="inline-flex items-center gap-2 text-kyn-green text-xs font-semibold mb-2">
                      <Sparkles size={14} /> Engineering dossier
                    </div>
                    <h3 className="font-display text-2xl md:text-3xl font-bold tracking-tight max-w-lg">
                      Ready for engineering handoff & technical diligence
                    </h3>
                    <p className="mt-2 text-sm text-slate-400 max-w-md">
                      Pair this pack with the PRD, Docs Suite and live Cloud/App prototypes for a complete KYNETIK enterprise file.
                    </p>
                  </div>
                  <div className="flex flex-col sm:flex-row gap-2 shrink-0">
                    <Link
                      to="/prd"
                      className="inline-flex items-center justify-center gap-2 px-5 py-3 rounded-full bg-kyn-green text-kyn-black text-sm font-bold"
                    >
                      Open PRD <ArrowRight size={16} />
                    </Link>
                    <Link
                      to="/docs-suite"
                      className="inline-flex items-center justify-center gap-2 px-5 py-3 rounded-full border border-white/15 text-sm font-semibold text-white hover:bg-white/5"
                    >
                      Docs Suite
                    </Link>
                    <Link
                      to="/grow"
                      className="inline-flex items-center justify-center gap-2 px-5 py-3 rounded-full border border-white/15 text-sm font-semibold text-white hover:bg-white/5"
                    >
                      <Download size={14} /> Sales pack
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <footer className="border-t border-white/[0.06] py-8">
        <div className="max-w-[1440px] mx-auto px-4 md:px-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <p className="text-[11px] text-slate-600">© KYNETIK · Enterprise Engineering Pack · Phase 27 · SAD · API · DB · DevOps · QA · Run · Sec</p>
          <div className="flex flex-wrap gap-3 text-[11px] text-slate-500">
            <Link to="/architecture" className="hover:text-white">Architecture</Link>
            <Link to="/database" className="hover:text-white">Database</Link>
            <Link to="/ops" className="hover:text-white">Ops</Link>
            <Link to="/ocpp" className="hover:text-white">OCPP CSMS</Link>
            <Link to="/developers" className="hover:text-white">API</Link>
          </div>
        </div>
      </footer>
    </div>
  );
}

import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  ArrowRight, Code2, Palette, LayoutGrid, Image, Box, Grid3x3,
  Download, Check, Copy, Layers, BookOpen
} from 'lucide-react';
import BrandLogo from '../components/BrandLogo';
import LoadingState from '../components/LoadingState';
import ErrorState from '../components/ErrorState';
import { apiGet, cn } from '../lib/utils';

interface Item {
  id: number;
  category: string;
  title: string;
  body: string;
  meta: string | null;
  sort_order: number;
}

const tokens = [
  { name: 'kyn-black', value: '#050505', css: '--color-kyn-black' },
  { name: 'kyn-void', value: '#0A0A0B', css: '--color-kyn-void' },
  { name: 'kyn-green', value: '#00E676', css: '--color-kyn-green' },
  { name: 'kyn-green-glow', value: '#39FF14', css: '--color-kyn-green-glow' },
  { name: 'kyn-white', value: '#F5F5F7', css: '--color-kyn-white' },
  { name: 'kyn-metal', value: '#8A8A96', css: '--color-kyn-metal' },
  { name: 'kyn-silver', value: '#C8C8D0', css: '--color-kyn-silver' },
  { name: 'kyn-steel', value: '#1A1A1E', css: '--color-kyn-steel' },
];

const spacing = ['4', '8', '12', '16', '24', '32', '48', '64', '80', '128'];

const routes = [
  { path: '/', name: 'Homepage / Cloud SaaS' },
  { path: '/product-system', name: 'Product System' },
  { path: '/console', name: 'Cloud Dashboard' },
  { path: '/app-landing', name: 'App Landing' },
  { path: '/app', name: 'Mobile UX library' },
  { path: '/academy', name: 'Academy' },
  { path: '/prototype', name: 'Interactive Prototype' },
  { path: '/showcase', name: 'Final Showcase' },
  { path: '/design-system', name: 'Design System hub' },
];

export default function Handoff() {
  const [items, setItems] = useState<Item[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [copied, setCopied] = useState('');

  useEffect(() => {
    apiGet<Item[]>('/api/handoff')
      .then(setItems)
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, []);

  const byCat = (c: string) => items.filter((i) => i.category === c);

  const copy = async (text: string, id: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(id);
      setTimeout(() => setCopied(''), 1500);
    } catch {
      setCopied('');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-kyn-black flex items-center justify-center">
        <LoadingState label="Loading handoff package…" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-kyn-black flex items-center justify-center p-8">
        <ErrorState message={error} />
      </div>
    );
  }

  const tokenCss = tokens.map((t) => `${t.css}: ${t.value};`).join('\n');

  return (
    <div className="min-h-screen bg-kyn-black text-white">
      <header className="sticky top-0 z-50 border-b border-white/5 bg-kyn-black/90 backdrop-blur-xl">
        <div className="max-w-7xl mx-auto px-5 md:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <BrandLogo height={28} />
            <span className="text-[10px] font-semibold tracking-[0.2em] uppercase text-kyn-green border border-kyn-green/30 rounded-full px-2 py-0.5">
              Handoff
            </span>
          </div>
          <div className="flex items-center gap-3">
            <Link to="/prototype" className="text-xs text-kyn-silver hover:text-white">Prototype</Link>
            <Link to="/dev-handoff" className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-kyn-green text-kyn-black text-xs font-bold">
              Showcase <ArrowRight size={12} />
            </Link>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-5 md:px-8 py-12 md:py-16">
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}>
          <p className="text-kyn-green text-xs font-semibold tracking-[0.3em] uppercase mb-3">
            Phase 13 · Developer Handoff
          </p>
          <h1 className="font-display text-3xl md:text-5xl font-bold max-w-3xl">
            Build-ready package for engineering
          </h1>
          <p className="mt-4 text-kyn-silver max-w-2xl">
            Design tokens, component inventory, grid rules, asset map and route index —
            everything a frontend team needs to implement KYNETIK without guesswork.
          </p>
        </motion.div>

        {/* Quick packs */}
        <div className="mt-12 grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            { icon: Palette, t: 'Design Tokens', d: 'Colors, type, space, radius' },
            { icon: Box, t: 'Components', d: 'Buttons, cards, nav, forms' },
            { icon: Grid3x3, t: 'Layout Grid', d: '12-col · breakpoints' },
            { icon: Image, t: 'Assets', d: 'Logos, product PNGs, photos' },
          ].map(({ icon: Icon, t, d }) => (
            <div key={t} className="rounded-2xl border border-white/8 bg-white/[0.02] p-5">
              <Icon className="text-kyn-green mb-3" size={20} />
              <p className="font-display font-semibold">{t}</p>
              <p className="text-xs text-kyn-metal mt-1">{d}</p>
            </div>
          ))}
        </div>

        {/* Tokens */}
        <section className="mt-16">
          <div className="flex flex-wrap items-center justify-between gap-3 mb-6">
            <h2 className="font-display text-2xl font-bold">Color tokens</h2>
            <button
              type="button"
              onClick={() => copy(tokenCss, 'css')}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-white/15 text-xs font-semibold hover:border-kyn-green/40"
            >
              {copied === 'css' ? <Check size={14} className="text-kyn-green" /> : <Copy size={14} />}
              Copy CSS variables
            </button>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {tokens.map((t) => (
              <button
                key={t.name}
                type="button"
                onClick={() => copy(t.value, t.name)}
                className="text-left rounded-2xl border border-white/8 overflow-hidden hover:border-white/20 transition-colors"
              >
                <div className="h-16" style={{ background: t.value }} />
                <div className="p-3">
                  <p className="text-sm font-semibold">{t.name}</p>
                  <p className="text-[11px] font-mono text-kyn-green mt-0.5">{t.value}</p>
                  <p className="text-[10px] text-kyn-metal mt-1">{t.css}</p>
                </div>
              </button>
            ))}
          </div>
        </section>

        {/* Type + space */}
        <section className="mt-16 grid lg:grid-cols-2 gap-6">
          <div className="rounded-2xl border border-white/8 p-6">
            <h3 className="font-display font-bold text-lg mb-4">Typography</h3>
            <div className="space-y-4">
              <div>
                <p className="text-[10px] text-kyn-metal uppercase tracking-wider">Display</p>
                <p className="font-display text-3xl font-bold mt-1">Space Grotesk Bold</p>
                <p className="text-xs text-kyn-metal mt-1">H1 48–72 · H2 28–36 · tracking tight</p>
              </div>
              <div>
                <p className="text-[10px] text-kyn-metal uppercase tracking-wider">Body</p>
                <p className="text-xl font-medium mt-1">Inter Regular / Medium</p>
                <p className="text-xs text-kyn-metal mt-1">16/1.6 body · 12–14 UI · 10 caption</p>
              </div>
            </div>
          </div>
          <div className="rounded-2xl border border-white/8 p-6">
            <h3 className="font-display font-bold text-lg mb-4">Spacing scale (px)</h3>
            <div className="space-y-2">
              {spacing.map((s) => (
                <div key={s} className="flex items-center gap-3">
                  <span className="w-10 text-[11px] font-mono text-kyn-metal">{s}</span>
                  <div className="h-2 rounded-sm bg-kyn-green/80" style={{ width: `${Number(s) * 1.5}px` }} />
                </div>
              ))}
            </div>
            <p className="mt-4 text-xs text-kyn-metal">Default radius: 16px (rounded-2xl). Pills: 9999px.</p>
          </div>
        </section>

        {/* Components from DB */}
        <section className="mt-16">
          <h2 className="font-display text-2xl font-bold mb-6">Component inventory</h2>
          <div className="grid md:grid-cols-2 gap-3">
            {byCat('component').map((c) => (
              <div key={c.id} className="rounded-2xl border border-white/8 p-5 flex gap-4">
                <LayoutGrid className="text-kyn-green shrink-0" size={18} />
                <div>
                  <p className="font-semibold">{c.title}</p>
                  <p className="text-sm text-kyn-metal mt-1">{c.body}</p>
                  {c.meta && <p className="text-[11px] font-mono text-kyn-green mt-2">{c.meta}</p>}
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Grid + responsive */}
        <section className="mt-16 grid lg:grid-cols-2 gap-6">
          <div className="rounded-2xl border border-white/8 p-6">
            <div className="flex items-center gap-2 mb-4">
              <Grid3x3 className="text-kyn-green" size={18} />
              <h3 className="font-display font-bold text-lg">Grid system</h3>
            </div>
            <ul className="space-y-2 text-sm text-kyn-silver">
              <li>• Desktop content max-width: 1280px (7xl)</li>
              <li>• 12-column mental model · gap 16–24px</li>
              <li>• Marketing sections: full-bleed + inner container</li>
              <li>• App phone frame: 280×580 logical</li>
              <li>• Dashboard: sidebar 288px + fluid main</li>
            </ul>
          </div>
          <div className="rounded-2xl border border-white/8 p-6">
            <div className="flex items-center gap-2 mb-4">
              <Code2 className="text-kyn-green" size={18} />
              <h3 className="font-display font-bold text-lg">Stack</h3>
            </div>
            <ul className="space-y-2 text-sm text-kyn-silver">
              <li>• Vite + React 19 + TypeScript</li>
              <li>• Tailwind CSS v4 · @theme tokens</li>
              <li>• framer-motion · lucide-react · react-router</li>
              <li>• Supabase via Vercel API routes</li>
              <li>• Assets in <span className="font-mono text-kyn-green">/public/images</span></li>
            </ul>
          </div>
        </section>

        {/* Assets */}
        <section className="mt-16">
          <h2 className="font-display text-2xl font-bold mb-6">Asset map</h2>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {byCat('asset').map((a) => (
              <div key={a.id} className="rounded-2xl border border-white/8 p-5">
                <Image className="text-kyn-green mb-2" size={16} />
                <p className="font-semibold text-sm">{a.title}</p>
                <p className="text-xs text-kyn-metal mt-1">{a.body}</p>
                {a.meta && <p className="text-[10px] font-mono text-kyn-green mt-2 break-all">{a.meta}</p>}
              </div>
            ))}
          </div>
        </section>

        {/* Rules from DB */}
        <section className="mt-16">
          <h2 className="font-display text-2xl font-bold mb-6">Implementation rules</h2>
          <div className="space-y-2">
            {byCat('rule').map((r, i) => (
              <div key={r.id} className="rounded-xl border border-white/8 px-4 py-3 flex gap-3 text-sm">
                <span className="text-kyn-green font-mono text-xs mt-0.5">0{i + 1}</span>
                <div>
                  <p className="font-semibold">{r.title}</p>
                  <p className="text-kyn-metal text-xs mt-0.5">{r.body}</p>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Routes */}
        <section className="mt-16">
          <h2 className="font-display text-2xl font-bold mb-6">Route index</h2>
          <div className="rounded-2xl border border-white/10 overflow-hidden">
            <table className="w-full text-left text-sm">
              <thead className="bg-white/[0.03] text-xs uppercase tracking-wider text-kyn-metal">
                <tr>
                  <th className="px-4 py-3 font-medium">Path</th>
                  <th className="px-4 py-3 font-medium">Screen</th>
                  <th className="px-4 py-3 font-medium"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {routes.map((r) => (
                  <tr key={r.path} className="text-kyn-silver">
                    <td className="px-4 py-3 font-mono text-kyn-green text-xs">{r.path}</td>
                    <td className="px-4 py-3">{r.name}</td>
                    <td className="px-4 py-3 text-right">
                      <Link to={r.path} className="text-xs text-white hover:text-kyn-green inline-flex items-center gap-1">
                        Open <ArrowRight size={12} />
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        <section className="mt-16 rounded-3xl border border-kyn-green/20 bg-kyn-green/5 p-8 md:p-10 text-center">
          <BookOpen className="mx-auto text-kyn-green mb-4" size={28} />
          <h2 className="font-display text-2xl font-bold">Ready for sprint zero</h2>
          <p className="mt-3 text-kyn-silver max-w-lg mx-auto text-sm">
            Use the interactive prototype to validate flows, then implement against tokens and the route map.
          </p>
          <div className="mt-8 flex flex-wrap justify-center gap-3">
            <Link to="/prototype" className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-kyn-green text-kyn-black text-sm font-bold">
              Prototype <ArrowRight size={14} />
            </Link>
            <Link to="/showcase" className="inline-flex items-center gap-2 px-6 py-3 rounded-full border border-white/15 text-sm font-medium">
              Final Showcase
            </Link>
          </div>
        </section>
      </main>
    </div>
  );
}

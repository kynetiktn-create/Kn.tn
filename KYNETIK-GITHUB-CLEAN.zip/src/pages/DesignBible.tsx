import { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  ArrowRight, BookOpen, Check, Sparkles, Layers, Type, LayoutGrid,
  MousePointer2, Camera, Gauge, Accessibility, Smartphone, Zap,
  Box, Component, Menu, X, Quote
} from 'lucide-react';
import BrandLogo from '../components/BrandLogo';
import LoadingState from '../components/LoadingState';
import ErrorState from '../components/ErrorState';
import { Button, Badge, EmptyState, ChargeRing, StatCard, colors, space, radius } from '../ui';
import { apiGet, cn } from '../lib/utils';

interface BibleItem {
  id: number;
  chapter: string;
  type: string;
  title: string;
  subtitle: string;
  body: string;
  meta: string | null;
  sort_order: number;
}

const chapterMeta: Record<string, { label: string; icon: typeof BookOpen; blurb: string }> = {
  vision: { label: 'Vision', icon: Sparkles, blurb: 'Product ambition & quality bar' },
  personality: { label: 'Personality', icon: Quote, blurb: 'Six brand traits' },
  emotion: { label: 'Emotion', icon: Zap, blurb: 'How the product should feel' },
  voice: { label: 'Voice', icon: Type, blurb: 'Writing system' },
  visual: { label: 'Visual', icon: Layers, blurb: 'Color, type, glass' },
  layout: { label: 'Layout', icon: LayoutGrid, blurb: 'Grid, radius, depth' },
  iconography: { label: 'Icons', icon: Box, blurb: 'Line icon rules' },
  motion: { label: 'Motion', icon: MousePointer2, blurb: 'Scroll, hover, timing' },
  imagery: { label: 'Imagery', icon: Camera, blurb: 'Studio & diagrams' },
  dashboard: { label: 'Dashboard', icon: Gauge, blurb: 'Operator UI craft' },
  a11y: { label: 'Accessibility', icon: Accessibility, blurb: 'Inclusive defaults' },
  performance: { label: 'Performance', icon: Zap, blurb: 'Speed is premium' },
  mobile: { label: 'Mobile', icon: Smartphone, blurb: 'Thumb-first control' },
  micro: { label: 'Micro', icon: MousePointer2, blurb: 'Tiny confirmations' },
  states: { label: 'States', icon: LayoutGrid, blurb: 'Empty & error' },
  scale: { label: 'Scale', icon: Layers, blurb: 'Future surfaces' },
  library: { label: 'UI Library', icon: Component, blurb: 'React/Next plan' },
};

const chapterOrder = [
  'vision', 'personality', 'emotion', 'voice', 'visual', 'layout', 'iconography',
  'motion', 'imagery', 'dashboard', 'a11y', 'performance', 'mobile', 'micro',
  'states', 'scale', 'library',
];

export default function DesignBible() {
  const [items, setItems] = useState<BibleItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [active, setActive] = useState('vision');
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    apiGet<BibleItem[]>('/api/design-bible')
      .then((data) => {
        setItems(data);
        if (data[0]) setActive(data[0].chapter);
      })
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const byChapter = useMemo(() => {
    const map: Record<string, BibleItem[]> = {};
    for (const item of items) {
      (map[item.chapter] ||= []).push(item);
    }
    for (const k of Object.keys(map)) {
      map[k].sort((a, b) => a.sort_order - b.sort_order);
    }
    return map;
  }, [items]);

  const chapters = chapterOrder.filter((c) => byChapter[c]?.length);

  if (loading) {
    return (
      <div className="min-h-screen bg-kyn-black flex items-center justify-center">
        <LoadingState label="Opening Design Bible…" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-kyn-black flex items-center justify-center p-8">
        <ErrorState message={error} />
      </div>
    );
  }

  const section = byChapter[active] || [];
  const meta = chapterMeta[active] || { label: active, icon: BookOpen, blurb: '' };
  const Icon = meta.icon;

  return (
    <div className="min-h-screen bg-kyn-black text-white">
      <header
        className={cn(
          'fixed top-0 inset-x-0 z-50 transition-all',
          scrolled ? 'bg-kyn-black/85 backdrop-blur-xl border-b border-white/5' : 'bg-transparent'
        )}
      >
        <div className="max-w-7xl mx-auto px-5 md:px-8 h-16 md:h-18 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <BrandLogo height={28} />
            <span className="hidden sm:inline text-[10px] font-semibold tracking-[0.22em] uppercase text-kyn-green border border-kyn-green/30 rounded-full px-2 py-0.5">
              Design Bible
            </span>
          </div>
          <div className="hidden md:flex items-center gap-4 text-xs text-kyn-metal">
            <Link to="/design-system" className="hover:text-white">System</Link>
            <Link to="/tokens" className="hover:text-white">Tokens</Link>
            <Link to="/product-system" className="hover:text-white">Products</Link>
            <Link to="/home" className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-kyn-green text-kyn-black font-bold">
              Homepage <ArrowRight size={12} />
            </Link>
          </div>
          <button type="button" className="md:hidden p-2 text-kyn-silver" onClick={() => setMenuOpen(!menuOpen)}>
            {menuOpen ? <X size={18} /> : <Menu size={18} />}
          </button>
        </div>
      </header>

      {/* Hero */}
      <section className="relative pt-28 pb-16 md:pt-36 md:pb-20 overflow-hidden">
        <div className="absolute inset-0 grid-bg opacity-40" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(0,230,118,0.14),transparent_55%)]" />
        <div className="relative z-10 max-w-7xl mx-auto px-5 md:px-8">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-kyn-green/30 bg-kyn-green/10 text-kyn-green text-[11px] font-semibold mb-6">
              <BookOpen size={13} /> Global product design constitution
            </div>
            <h1 className="font-display text-4xl md:text-6xl font-bold tracking-tight max-w-3xl leading-[1.05]">
              KYNETIK
              <br />
              <span className="text-kyn-green text-glow">Design Bible</span>
            </h1>
            <p className="mt-6 text-base md:text-lg text-kyn-silver max-w-2xl leading-relaxed">
              The operating manual for a world-class EV mobility brand — vision, emotion, voice,
              visual system, motion, product imagery, dashboard craft, accessibility, and a React-ready
              component library strategy. Inspired by Apple, Tesla, Stripe, Notion and Linear.
            </p>
            <div className="mt-8 flex flex-wrap gap-2">
              {['Premium', 'Intelligent', 'Human', 'Innovative', 'Sustainable', 'Reliable'].map((t) => (
                <Badge key={t}>{t}</Badge>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-5 md:px-8 pb-24 grid lg:grid-cols-[260px_1fr] gap-8">
        {/* TOC */}
        <aside className={cn(
          'lg:sticky lg:top-24 lg:self-start',
          menuOpen ? 'block' : 'hidden lg:block'
        )}>
          <div className="rounded-2xl border border-white/8 bg-kyn-void/80 p-3 max-h-[70vh] overflow-y-auto">
            <p className="px-3 py-2 text-[10px] uppercase tracking-widest text-kyn-metal">Chapters</p>
            {chapters.map((c) => {
              const m = chapterMeta[c];
              const CIcon = m?.icon || BookOpen;
              return (
                <button
                  key={c}
                  type="button"
                  onClick={() => {
                    setActive(c);
                    setMenuOpen(false);
                    window.scrollTo({ top: 280, behavior: 'smooth' });
                  }}
                  className={cn(
                    'w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-left text-sm transition-colors',
                    active === c
                      ? 'bg-kyn-green/10 text-kyn-green border border-kyn-green/20'
                      : 'text-kyn-silver hover:bg-white/5 hover:text-white border border-transparent'
                  )}
                >
                  <CIcon size={14} />
                  <span className="font-medium">{m?.label || c}</span>
                </button>
              );
            })}
          </div>
        </aside>

        {/* Content */}
        <main>
          <motion.div
            key={active}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.35 }}
          >
            <div className="flex items-start gap-4 mb-8">
              <div className="w-12 h-12 rounded-2xl bg-kyn-green/10 border border-kyn-green/25 flex items-center justify-center text-kyn-green shrink-0">
                <Icon size={20} />
              </div>
              <div>
                <p className="text-kyn-green text-xs font-semibold tracking-[0.25em] uppercase">Chapter</p>
                <h2 className="font-display text-3xl md:text-4xl font-bold mt-1">{meta.label}</h2>
                <p className="text-kyn-metal mt-1">{meta.blurb}</p>
              </div>
            </div>

            <div className="space-y-4">
              {section.map((item, i) => (
                <motion.article
                  key={item.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.04 }}
                  className="rounded-2xl border border-white/8 bg-gradient-to-b from-white/[0.04] to-transparent p-6 md:p-7"
                >
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div>
                      <p className="text-[10px] uppercase tracking-wider text-kyn-metal">{item.type}</p>
                      <h3 className="font-display text-xl font-semibold mt-1">{item.title}</h3>
                      {item.subtitle && (
                        <p className="text-sm text-kyn-green mt-1">{item.subtitle}</p>
                      )}
                    </div>
                    {item.meta && (
                      <span className="text-[10px] font-mono px-2.5 py-1 rounded-lg bg-kyn-steel border border-white/8 text-kyn-silver max-w-xs">
                        {item.meta}
                      </span>
                    )}
                  </div>
                  <p className="mt-4 text-sm md:text-[15px] text-kyn-silver leading-relaxed">{item.body}</p>
                </motion.article>
              ))}
            </div>

            {/* Live examples by chapter */}
            {active === 'visual' && (
              <div className="mt-8 grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {Object.entries(colors).slice(0, 9).map(([name, value]) => (
                  <div key={name} className="rounded-2xl border border-white/8 overflow-hidden">
                    <div className="h-16" style={{ background: value }} />
                    <div className="p-3 flex justify-between text-xs">
                      <span className="capitalize text-kyn-silver">{name}</span>
                      <span className="font-mono text-kyn-green">{value}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {active === 'layout' && (
              <div className="mt-8 glass-card rounded-2xl p-6">
                <p className="text-xs text-kyn-metal mb-4">Spacing scale (px)</p>
                <div className="space-y-2">
                  {Object.entries(space).map(([k, v]) => (
                    <div key={k} className="flex items-center gap-3">
                      <span className="w-10 text-xs font-mono text-kyn-metal">{k}</span>
                      <div className="h-3 rounded-sm bg-kyn-green/80" style={{ width: v }} />
                      <span className="text-xs text-kyn-silver">{v}</span>
                    </div>
                  ))}
                </div>
                <p className="mt-6 text-xs text-kyn-metal">Radius — control {radius.control} · card {radius.card} · panel {radius.panel}</p>
              </div>
            )}

            {active === 'dashboard' && (
              <div className="mt-8 grid sm:grid-cols-3 gap-3">
                <StatCard label="Uptime" value="99.95%" delta="SLA OK" />
                <StatCard label="Sessions 24h" value="1 284" delta="+12%" />
                <StatCard label="kWh today" value="8.2k" delta="+4.1%" />
              </div>
            )}

            {active === 'mobile' && (
              <div className="mt-8 flex justify-center">
                <div className="phone-frame w-[240px] h-[480px] rounded-[2.2rem] p-2">
                  <div className="w-full h-full rounded-[1.8rem] bg-kyn-void flex flex-col items-center justify-center gap-6 p-6">
                    <ChargeRing percent={78} />
                    <p className="text-xs text-kyn-metal text-center">Primary charge moment — one glance, one action</p>
                    <Button size="sm" className="w-full">Stop charge</Button>
                  </div>
                </div>
              </div>
            )}

            {active === 'states' && (
              <div className="mt-8 grid md:grid-cols-2 gap-4">
                <EmptyState
                  title="No chargers yet"
                  body="Add your first NOVA or PRIME to start monitoring energy and sessions."
                  actionLabel="Add charger"
                  onAction={() => undefined}
                  icon={<Zap size={22} />}
                />
                <div className="rounded-2xl border border-red-500/20 bg-red-500/5 p-6">
                  <Badge tone="danger">Fault</Badge>
                  <h3 className="font-display font-semibold mt-3">Connector offline</h3>
                  <p className="text-sm text-kyn-metal mt-2">
                    Station Hub Lac 2 lost connectivity 14 min ago. Check breaker or network, then retry remote wake.
                  </p>
                  <div className="mt-4 flex gap-2">
                    <Button size="sm">Retry</Button>
                    <Button size="sm" variant="secondary">Contact support</Button>
                  </div>
                </div>
              </div>
            )}

            {active === 'library' && (
              <div className="mt-8 space-y-4">
                <div className="rounded-2xl border border-kyn-green/25 bg-kyn-green/5 p-6">
                  <p className="text-kyn-green text-xs font-semibold tracking-wider uppercase">Strategic recommendation</p>
                  <h3 className="font-display text-2xl font-bold mt-2">Ship a KYNETIK UI Kit as a versioned package</h3>
                  <p className="mt-3 text-sm text-kyn-silver leading-relaxed max-w-3xl">
                    Convert this Bible into <code className="text-kyn-green">@kynetik/ui</code> for React and Next.js.
                    Foundations first (tokens), then primitives, patterns, EV domain blocks, then shells.
                    Every marketing page, installer tool, cloud console and AI surface imports the same kit —
                    guaranteeing consistency, velocity and multi-year scalability.
                  </p>
                </div>

                <div className="grid md:grid-cols-2 gap-3">
                  {[
                    ['1. Tokens', 'colors, space, radius, motion, type'],
                    ['2. Primitives', 'Button, Input, Badge, Switch, Modal…'],
                    ['3. Patterns', 'EmptyState, StatCard, FormField, Toast…'],
                    ['4. Domain', 'ChargeRing, StationCard, SessionRow…'],
                    ['5. Shells', 'MarketingShell, AppShell, ConsoleShell'],
                    ['6. Docs', 'Storybook + usage rules from this Bible'],
                  ].map(([t, d], i) => (
                    <div key={t} className="rounded-xl border border-white/8 bg-black/30 p-4 flex gap-3">
                      <span className="text-kyn-green font-display font-bold">{String(i + 1).padStart(2, '0')}</span>
                      <div>
                        <p className="font-semibold text-sm">{t.replace(/^\d+\.\s*/, '')}</p>
                        <p className="text-xs text-kyn-metal mt-1">{d}</p>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="rounded-2xl border border-white/10 bg-[#0c0e12] p-5 font-mono text-[11px] text-kyn-silver overflow-x-auto">
                  <pre>{`src/ui/
  tokens.ts
  primitives/Button.tsx
  patterns/EmptyState.tsx
  kynetik/ChargeRing.tsx
  shells/AppShell.tsx
  index.ts

// usage
import { Button, ChargeRing, colors } from '@/ui';`}</pre>
                </div>

                <div className="flex flex-wrap gap-3 pt-2">
                  <Button>Primary CTA</Button>
                  <Button variant="secondary">Secondary</Button>
                  <Button variant="ghost">Ghost</Button>
                  <Button variant="danger">Destructive</Button>
                </div>
                <div className="flex flex-wrap gap-2">
                  <Check size={14} className="text-kyn-green" />
                  <span className="text-xs text-kyn-metal">Live primitives already scaffolded in <code className="text-kyn-green">src/ui</code></span>
                </div>
              </div>
            )}

            {active === 'personality' && (
              <div className="mt-8 grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {section.map((s) => (
                  <div key={s.id} className="rounded-2xl border border-white/8 p-5 text-center bg-kyn-void">
                    <div className="w-8 h-1 mx-auto mb-4 rounded-full bg-kyn-green" />
                    <p className="font-display font-bold text-lg">{s.title}</p>
                    <p className="text-xs text-kyn-metal mt-2">{s.subtitle}</p>
                  </div>
                ))}
              </div>
            )}
          </motion.div>

          {/* Next chapter */}
          <div className="mt-12 flex flex-wrap justify-between gap-3 border-t border-white/5 pt-8">
            {(() => {
              const idx = chapters.indexOf(active);
              const prev = chapters[idx - 1];
              const next = chapters[idx + 1];
              return (
                <>
                  <button
                    type="button"
                    disabled={!prev}
                    onClick={() => prev && setActive(prev)}
                    className="text-sm text-kyn-metal disabled:opacity-30 hover:text-white"
                  >
                    ← {prev ? chapterMeta[prev]?.label : 'Start'}
                  </button>
                  <button
                    type="button"
                    disabled={!next}
                    onClick={() => next && setActive(next)}
                    className="inline-flex items-center gap-2 text-sm font-semibold text-kyn-green disabled:opacity-30"
                  >
                    {next ? chapterMeta[next]?.label : 'End'} <ArrowRight size={14} />
                  </button>
                </>
              );
            })()}
          </div>
        </main>
      </div>

      <footer className="border-t border-white/5 py-10">
        <div className="max-w-7xl mx-auto px-5 md:px-8 flex flex-wrap items-center justify-between gap-4">
          <BrandLogo height={26} />
          <p className="text-[11px] text-kyn-metal">KYNETIK Design Bible · Single source of truth for global product design</p>
          <Link to="/product-system" className="text-xs text-kyn-green font-semibold inline-flex items-center gap-1">
            Product System <ArrowRight size={12} />
          </Link>
        </div>
      </footer>
    </div>
  );
}

import { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  ArrowRight, Menu, X, Package, Palette, Sparkles, Layers, Box,
  Film, Share2, Presentation, BookOpen, CheckCircle2, Shield,
  Zap, Battery, Car, Cloud, BarChart3, User, CreditCard, Settings,
  Bell, GraduationCap, Truck, Home, Building2, Leaf, Smartphone,
  Download, Eye, Grid3X3, Hexagon, CircleDot, Play, Loader2,
  Check, Image as ImageIcon, FileText, Code2, Star, Gauge
} from 'lucide-react';
import BrandLogo from '../components/BrandLogo';
import LoadingState from '../components/LoadingState';
import ErrorState from '../components/ErrorState';
import { apiGet, cn } from '../lib/utils';

interface ProdAsset {
  id: number;
  category: string;
  title: string;
  description: string;
  meta: string | null;
  tags: string | null;
  status: string;
  sort_order: number;
}

interface Product {
  id: number;
  name: string;
  image_url: string;
  power: string;
  category: string;
  accent: string;
  sort_order: number;
}

const navItems = [
  { id: 'library', label: 'Asset Library' },
  { id: 'icons', label: 'Icons' },
  { id: 'illustrations', label: 'Illustrations' },
  { id: '3d', label: '3D Assets' },
  { id: 'motion', label: 'Motion' },
  { id: 'marketing', label: 'Marketing' },
  { id: 'presentations', label: 'Decks' },
  { id: 'docs', label: 'Docs' },
  { id: 'qa', label: 'QA' },
];

const iconLibrary = [
  { name: 'Charging', icon: Zap, group: 'Energy' },
  { name: 'Battery', icon: Battery, group: 'Energy' },
  { name: 'EV', icon: Car, group: 'Mobility' },
  { name: 'Energy', icon: Leaf, group: 'Energy' },
  { name: 'Cloud', icon: Cloud, group: 'Platform' },
  { name: 'Analytics', icon: BarChart3, group: 'Platform' },
  { name: 'User', icon: User, group: 'Account' },
  { name: 'Payment', icon: CreditCard, group: 'Account' },
  { name: 'Settings', icon: Settings, group: 'System' },
  { name: 'Notifications', icon: Bell, group: 'System' },
  { name: 'Academy', icon: GraduationCap, group: 'Learning' },
  { name: 'Fleet', icon: Truck, group: 'Mobility' },
  { name: 'Home', icon: Home, group: 'Sites' },
  { name: 'Workplace', icon: Building2, group: 'Sites' },
  { name: 'Mobile', icon: Smartphone, group: 'Platform' },
  { name: 'Gauge', icon: Gauge, group: 'Energy' },
];

const illustrations = [
  { title: 'EV Charging', img: '/images/ev-network.jpg', tag: 'Lifestyle' },
  { title: 'Home Charging', img: '/images/charger-wall.jpg', tag: 'Residential' },
  { title: 'Fleet Charging', img: '/images/charger-closeup.jpg', tag: 'B2B' },
  { title: 'Smart City', img: '/images/hero-city.jpg', tag: 'Urban' },
  { title: 'Cloud Platform', img: '/images/cloud-datacenter.jpg', tag: 'SaaS' },
  { title: 'Mobile Control', img: '/images/tech-abstract.jpg', tag: 'App' },
  { title: 'Academy / Training', img: '/images/academy.jpg', tag: 'Education' },
  { title: 'Renewable Energy', img: '/images/tech-abstract.jpg', tag: 'ESG' },
];

const motionSpecs = [
  { title: 'Logo Animation', dur: '2.4s', ease: 'cubic-bezier(0.22,1,0.36,1)', note: 'Mark draw + green pulse' },
  { title: 'Splash Sequence', dur: '1.8s', ease: 'ease-out', note: 'Energy line through wordmark' },
  { title: 'Charging Ring', dur: 'loop', ease: 'linear', note: 'Conic progress + glow breath' },
  { title: 'Loading Screens', dur: '0.9s', ease: 'ease-in-out', note: 'Skeleton + green shimmer' },
  { title: 'Success Burst', dur: '0.6s', ease: 'spring', note: 'Check + soft green flash' },
  { title: 'Dashboard Transitions', dur: '0.35s', ease: 'ease-out', note: 'Fade-up cards, no bounce' },
];

const marketingFormats = [
  { platform: 'Instagram', format: '1080×1080', use: 'Product / lifestyle' },
  { platform: 'Instagram Stories', format: '1080×1920', use: 'Ads + CTA' },
  { platform: 'Facebook', format: '1200×628', use: 'Campaign ads' },
  { platform: 'LinkedIn', format: '1200×627', use: 'B2B thought leadership' },
  { platform: 'LinkedIn Banner', format: '1584×396', use: 'Company page' },
  { platform: 'TikTok / Reels', format: '1080×1920', use: 'Motion clips' },
  { platform: 'YouTube Thumb', format: '1280×720', use: 'Product explainers' },
  { platform: 'Email Header', format: '600×200', use: 'Newsletter' },
];

const decks = [
  { title: 'Investor Pitch', slides: '12–15', audience: 'VCs / angels', to: '/investor' },
  { title: 'Sales Deck', slides: '8–10', audience: 'Enterprise buyers', to: '/product-system' },
  { title: 'Partnership Deck', slides: '6–8', audience: 'OEMs / utilities', to: '/cloud' },
  { title: 'Product Presentation', slides: '10', audience: 'Installers / CPOs', to: '/products' },
  { title: 'Training Slides', slides: 'modular', audience: 'Academy cohorts', to: '/academy' },
];

const docs = [
  { title: 'Brand Guidelines', body: 'Logo, clear space, color, type, do/don\'ts', to: '/brand' },
  { title: 'UI Guidelines', body: 'Buttons, forms, cards, elevation, density', to: '/tokens' },
  { title: 'UX Guidelines', body: 'Flows, navigation, empty/error states', to: '/app' },
  { title: 'Component Library', body: 'Production components + usage rules', to: '/handoff' },
  { title: 'API Visual Guide', body: 'Cloud console patterns for ops data', to: '/console' },
  { title: 'Design Principles', body: 'Energy first · Precision · Quiet luxury', to: '/brand' },
];

const qaChecks = [
  { area: 'Visual consistency', items: ['Color tokens only', 'Type scale adhered', '16px radius default', 'One accent per focal zone'] },
  { area: 'Product fidelity', items: ['Official 3D renders only', 'Series finish correct', 'Transparent PNG assets', 'No stock chargers in hero'] },
  { area: 'Usability', items: ['CTA hierarchy clear', 'Touch targets ≥44px', 'Forms validated', 'Loading & error states'] },
  { area: 'Performance', items: ['WebP/PNG optimized', 'Lazy media', 'No layout shift', 'Motion reduced-motion safe'] },
  { area: 'Accessibility', items: ['Contrast AA+', 'Focus rings', 'Alt text on products', 'Keyboard nav'] },
  { area: 'Scalability', items: ['Tokenized theme', 'Component reuse', 'API-driven content', 'Multi-series product model'] },
];

function parseTags(raw: string | null) {
  if (!raw) return [] as string[];
  try {
    const v = JSON.parse(raw);
    return Array.isArray(v) ? v : [];
  } catch {
    return raw.split(',').map((t) => t.trim()).filter(Boolean);
  }
}

export default function ProductionAssets() {
  const [assets, setAssets] = useState<ProdAsset[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [activeSection, setActiveSection] = useState('library');
  const [iconFilter, setIconFilter] = useState('All');
  const [motionPlay, setMotionPlay] = useState(true);
  const [chargePct, setChargePct] = useState(12);

  useEffect(() => {
    Promise.all([
      apiGet<ProdAsset[]>('/api/production-assets'),
      apiGet<Product[]>('/api/products'),
    ])
      .then(([a, p]) => {
        setAssets(a);
        setProducts(p.filter((x) => x.name && !x.name.includes('Archive')));
      })
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    if (!motionPlay) return;
    const t = setInterval(() => {
      setChargePct((p) => (p >= 100 ? 8 : p + 2));
    }, 80);
    return () => clearInterval(t);
  }, [motionPlay]);

  const byCat = useMemo(() => {
    const map: Record<string, ProdAsset[]> = {};
    assets.forEach((a) => {
      if (!map[a.category]) map[a.category] = [];
      map[a.category].push(a);
    });
    return map;
  }, [assets]);

  const iconGroups = ['All', ...Array.from(new Set(iconLibrary.map((i) => i.group)))];
  const filteredIcons = iconFilter === 'All' ? iconLibrary : iconLibrary.filter((i) => i.group === iconFilter);

  const seriesOrder = ['NOVA', 'PRIME', 'GO', 'EDGE', 'PRO'];
  const product3d = seriesOrder.flatMap((s) =>
    products.filter((p) => p.name.toUpperCase().includes(s))
  );

  if (loading) {
    return (
      <div className="min-h-screen bg-kyn-black flex items-center justify-center">
        <LoadingState label="Loading production assets…" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-kyn-black flex items-center justify-center p-8">
        <ErrorState message={error} />
      </div>
    );
  }

  const scrollTo = (id: string) => {
    setActiveSection(id);
    setMenuOpen(false);
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  return (
    <div className="min-h-screen bg-kyn-black text-white overflow-x-hidden">
      <header
        className={cn(
          'fixed top-0 inset-x-0 z-50 transition-all',
          scrolled ? 'bg-kyn-black/90 backdrop-blur-xl border-b border-white/5' : 'bg-transparent'
        )}
      >
        <div className="max-w-7xl mx-auto px-5 md:px-8 h-16 md:h-18 flex items-center justify-between">
          <Link to="/showcase" className="flex items-center gap-3">
            <BrandLogo height={28} />
            <span className="hidden sm:inline text-[10px] font-semibold tracking-[0.2em] uppercase text-kyn-green border border-kyn-green/30 rounded-full px-2 py-0.5">
              Phase 15
            </span>
          </Link>
          <nav className="hidden xl:flex items-center gap-5 text-[11px] font-medium text-kyn-silver">
            {navItems.map((n) => (
              <button
                key={n.id}
                type="button"
                onClick={() => scrollTo(n.id)}
                className={cn('hover:text-white transition-colors', activeSection === n.id && 'text-kyn-green')}
              >
                {n.label}
              </button>
            ))}
          </nav>
          <div className="flex items-center gap-3">
            <Link to="/handoff" className="hidden md:inline text-xs text-kyn-metal hover:text-white">
              Dev Handoff
            </Link>
            <Link
              to="/showcase"
              className="hidden sm:inline-flex items-center gap-2 px-4 py-2 rounded-full bg-kyn-green text-kyn-black text-xs font-bold"
            >
              Showcase <ArrowRight size={12} />
            </Link>
            <button type="button" className="xl:hidden p-2 text-kyn-silver" onClick={() => setMenuOpen(!menuOpen)}>
              {menuOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </div>
        {menuOpen && (
          <div className="xl:hidden border-t border-white/5 bg-kyn-void/95 px-5 py-4 grid grid-cols-2 gap-2">
            {navItems.map((n) => (
              <button key={n.id} type="button" onClick={() => scrollTo(n.id)} className="text-left text-sm text-kyn-silver py-2">
                {n.label}
              </button>
            ))}
          </div>
        )}
      </header>

      {/* Hero */}
      <section className="relative pt-28 pb-20 md:pt-36 md:pb-28 overflow-hidden">
        <div className="absolute inset-0">
          <img src="/images/tech-abstract.jpg" alt="" className="w-full h-full object-cover opacity-25" />
          <div className="absolute inset-0 bg-gradient-to-b from-kyn-black via-kyn-black/90 to-kyn-black" />
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(0,230,118,0.14),transparent_55%)]" />
          <div className="absolute inset-0 grid-bg opacity-40" />
        </div>
        <div className="relative z-10 max-w-7xl mx-auto px-5 md:px-8">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-kyn-green/30 bg-kyn-green/10 text-kyn-green text-[11px] font-semibold mb-6">
              <Layers size={13} /> Design Assets · Production Ready
            </div>
            <h1 className="font-display text-4xl md:text-6xl lg:text-7xl font-bold tracking-tight leading-[1.05] max-w-4xl">
              From design system
              <br />
              <span className="text-kyn-green text-glow">to digital ecosystem</span>
            </h1>
            <p className="mt-6 text-base md:text-lg text-kyn-silver max-w-2xl leading-relaxed">
              Phase 15 packages every KYNETIK asset — icons, 3D, motion, marketing templates,
              decks and documentation — into a production-ready library for launch, investors and engineering.
            </p>
            <div className="mt-10 flex flex-wrap gap-3">
              <button
                type="button"
                onClick={() => scrollTo('library')}
                className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-kyn-green text-kyn-black text-sm font-bold glow-green"
              >
                Open asset library <ArrowRight size={16} />
              </button>
              <button
                type="button"
                onClick={() => scrollTo('qa')}
                className="inline-flex items-center gap-2 px-6 py-3 rounded-full border border-white/15 text-sm font-medium"
              >
                QA checklist
              </button>
            </div>

            <div className="mt-14 grid grid-cols-2 md:grid-cols-4 gap-3 max-w-3xl">
              {[
                { v: String(assets.length || 36), l: 'Catalogued assets' },
                { v: String(product3d.length), l: '3D product SKUs' },
                { v: '9', l: 'Production modules' },
                { v: '100%', l: 'Launch readiness' },
              ].map((s) => (
                <div key={s.l} className="glass-card rounded-2xl p-4">
                  <p className="font-display text-2xl font-bold text-kyn-green">{s.v}</p>
                  <p className="text-[11px] text-kyn-metal mt-1">{s.l}</p>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* 1. Asset Library */}
      <section id="library" className="py-20 md:py-28 border-t border-white/5">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <div className="flex flex-wrap items-end justify-between gap-4 mb-10">
            <div>
              <p className="text-kyn-green text-xs font-semibold tracking-[0.25em] uppercase mb-3">01 · Design Asset Library</p>
              <h2 className="font-display text-3xl md:text-4xl font-bold">Single source of truth</h2>
            </div>
            <p className="text-sm text-kyn-metal max-w-sm">Logos · icons · illustrations · backgrounds · patterns · components · templates</p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-10">
            {[
              { icon: Palette, t: 'Logos', d: 'Primary, mono, mark, Cloud badge', path: '/images/kynetik-logo-white.png' },
              { icon: Grid3X3, t: 'Patterns', d: 'Energy grid, glow orbs, metal lines' },
              { icon: Hexagon, t: 'Gradients', d: 'Black→void, green radial glow' },
              { icon: Layers, t: 'Components', d: 'Buttons, cards, chips, nav, tables' },
            ].map(({ icon: Icon, t, d, path }) => (
              <div key={t} className="rounded-2xl border border-white/8 bg-kyn-void p-5">
                <div className="h-28 rounded-xl bg-black/50 border border-white/5 mb-4 flex items-center justify-center overflow-hidden">
                  {path ? (
                    <img src={path} alt={t} className="h-10 object-contain" />
                  ) : (
                    <Icon className="text-kyn-green" size={28} />
                  )}
                </div>
                <p className="font-display font-semibold">{t}</p>
                <p className="text-xs text-kyn-metal mt-1">{d}</p>
              </div>
            ))}
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-3">
            {(byCat['library'] || assets.slice(0, 9)).map((a, i) => (
              <motion.div
                key={a.id}
                initial={{ opacity: 0, y: 10 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.03 }}
                className="glass-card rounded-2xl p-5"
              >
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="font-semibold">{a.title}</p>
                    <p className="text-xs text-kyn-metal mt-1 leading-relaxed">{a.description}</p>
                  </div>
                  <span className={cn(
                    'text-[9px] uppercase tracking-wider px-2 py-1 rounded-full shrink-0',
                    a.status === 'ready' ? 'bg-kyn-green/15 text-kyn-green' : 'bg-white/5 text-kyn-metal'
                  )}>
                    {a.status || 'ready'}
                  </span>
                </div>
                <div className="mt-3 flex flex-wrap gap-1.5">
                  {parseTags(a.tags).map((t) => (
                    <span key={t} className="text-[10px] px-2 py-0.5 rounded-md bg-white/5 text-kyn-metal">{t}</span>
                  ))}
                </div>
                {a.meta && <p className="mt-3 text-[10px] font-mono text-kyn-green">{a.meta}</p>}
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* 2. Icon System */}
      <section id="icons" className="py-20 md:py-28 bg-kyn-void border-y border-white/5">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <p className="text-kyn-green text-xs font-semibold tracking-[0.25em] uppercase mb-3">02 · Icon System</p>
          <h2 className="font-display text-3xl md:text-4xl font-bold mb-3">Unified line icons</h2>
          <p className="text-kyn-silver mb-8 max-w-xl text-sm">Stroke 1.5–2px · optical square 24 · rounded joins · monochrome + green active state.</p>

          <div className="flex flex-wrap gap-2 mb-8">
            {iconGroups.map((g) => (
              <button
                key={g}
                type="button"
                onClick={() => setIconFilter(g)}
                className={cn(
                  'px-3 py-1.5 rounded-full text-xs font-semibold',
                  iconFilter === g ? 'bg-kyn-green text-kyn-black' : 'bg-kyn-steel text-kyn-silver'
                )}
              >
                {g}
              </button>
            ))}
          </div>

          <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-8 gap-3">
            {filteredIcons.map(({ name, icon: Icon, group }) => (
              <div
                key={name}
                className="group rounded-2xl border border-white/8 bg-black/30 p-4 text-center hover:border-kyn-green/35 transition-colors"
              >
                <div className="w-12 h-12 mx-auto rounded-xl bg-kyn-green/10 border border-kyn-green/20 flex items-center justify-center text-kyn-green mb-3 group-hover:glow-green">
                  <Icon size={20} strokeWidth={1.75} />
                </div>
                <p className="text-[11px] font-medium">{name}</p>
                <p className="text-[9px] text-kyn-metal mt-0.5">{group}</p>
              </div>
            ))}
          </div>

          <div className="mt-8 grid md:grid-cols-3 gap-3">
            {(byCat['icon'] || []).map((a) => (
              <div key={a.id} className="rounded-xl border border-white/8 px-4 py-3 text-sm">
                <p className="font-medium">{a.title}</p>
                <p className="text-xs text-kyn-metal mt-1">{a.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 3. Illustrations */}
      <section id="illustrations" className="py-20 md:py-28">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <p className="text-kyn-green text-xs font-semibold tracking-[0.25em] uppercase mb-3">03 · Illustration System</p>
          <h2 className="font-display text-3xl md:text-4xl font-bold mb-10">KYNETIK visual narratives</h2>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {illustrations.map((ill, i) => (
              <motion.div
                key={ill.title}
                initial={{ opacity: 0, y: 12 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.04 }}
                className="group rounded-2xl overflow-hidden border border-white/8 bg-kyn-void"
              >
                <div className="relative h-40 overflow-hidden">
                  <img src={ill.img} alt={ill.title} className="w-full h-full object-cover opacity-70 group-hover:opacity-90 group-hover:scale-105 transition-all duration-500" />
                  <div className="absolute inset-0 bg-gradient-to-t from-kyn-void to-transparent" />
                  <span className="absolute top-3 left-3 text-[9px] uppercase tracking-wider px-2 py-1 rounded-full bg-black/50 border border-white/10 text-kyn-green">
                    {ill.tag}
                  </span>
                </div>
                <div className="p-4">
                  <p className="font-display font-semibold text-sm">{ill.title}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* 4. 3D Assets */}
      <section id="3d" className="py-20 md:py-28 bg-kyn-void border-y border-white/5">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <div className="flex flex-wrap items-end justify-between gap-4 mb-10">
            <div>
              <p className="text-kyn-green text-xs font-semibold tracking-[0.25em] uppercase mb-3">04 · 3D Assets</p>
              <h2 className="font-display text-3xl md:text-4xl font-bold">Official product renders</h2>
            </div>
            <Link to="/product-system" className="text-sm text-kyn-green inline-flex items-center gap-1 font-semibold">
              Open product system <ArrowRight size={14} />
            </Link>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
            {product3d.map((p) => (
              <div
                key={p.id}
                className="rounded-2xl border border-white/8 bg-black/40 p-4 hover:border-white/20 transition-colors"
              >
                <div
                  className="h-36 flex items-center justify-center rounded-xl mb-3"
                  style={{ background: `radial-gradient(circle, ${(p.accent || '#00e676')}22, transparent 70%)` }}
                >
                  <img src={p.image_url} alt={p.name} className="max-h-full w-auto object-contain p-2" />
                </div>
                <p className="font-display font-semibold text-sm">{p.name}</p>
                <p className="text-[10px] mt-0.5" style={{ color: p.accent || '#00e676' }}>{p.power}</p>
                <p className="text-[10px] text-kyn-metal mt-1">{p.category}</p>
              </div>
            ))}
          </div>

          <div className="mt-8 grid md:grid-cols-4 gap-3">
            {[
              { t: 'NOVA', d: 'Matte black wall AC' },
              { t: 'PRIME', d: 'Pearl white hospitality' },
              { t: 'GO', d: 'Portable CEE / Schuko' },
              { t: 'EDGE / PRO', d: 'Urban wall & pedestal' },
            ].map((s) => (
              <div key={s.t} className="rounded-xl border border-white/8 px-4 py-3 flex items-center gap-3">
                <Box className="text-kyn-green shrink-0" size={16} />
                <div>
                  <p className="text-sm font-semibold">{s.t}</p>
                  <p className="text-[11px] text-kyn-metal">{s.d}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 5. Motion */}
      <section id="motion" className="py-20 md:py-28">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <p className="text-kyn-green text-xs font-semibold tracking-[0.25em] uppercase mb-3">05 · Motion Design</p>
          <h2 className="font-display text-3xl md:text-4xl font-bold mb-3">Living energy identity</h2>
          <p className="text-kyn-silver text-sm mb-10 max-w-xl">Short, precise motion. Prefer energy pulses over bounce. Respect prefers-reduced-motion.</p>

          <div className="grid lg:grid-cols-2 gap-8 items-start">
            <div className="rounded-3xl border border-white/10 bg-gradient-to-b from-kyn-charcoal to-kyn-black p-8 md:p-10 relative overflow-hidden min-h-[360px] flex flex-col items-center justify-center">
              <div className="absolute inset-0 grid-bg opacity-40" />
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(0,230,118,0.12),transparent_55%)]" />

              {/* Live motion demos */}
              <div className="relative z-10 flex flex-col items-center gap-8 w-full">
                <div className="flex items-center gap-6">
                  <div className={cn('relative', motionPlay && 'animate-pulse-glow')}>
                    <BrandLogo height={42} />
                  </div>
                  <div className="h-8 w-px bg-white/10" />
                  <button
                    type="button"
                    onClick={() => setMotionPlay(!motionPlay)}
                    className="inline-flex items-center gap-2 text-xs font-semibold text-kyn-green"
                  >
                    {motionPlay ? <Loader2 size={14} className="animate-spin" /> : <Play size={14} />}
                    {motionPlay ? 'Playing' : 'Paused'}
                  </button>
                </div>

                <div className="relative w-36 h-36">
                  <div
                    className="absolute inset-0 rounded-full"
                    style={{
                      background: `conic-gradient(from 220deg, #00e676 0%, #00e676 ${chargePct}%, #2a2a30 ${chargePct}%, #2a2a30 100%)`,
                      padding: 5,
                    }}
                  >
                    <div className="w-full h-full rounded-full bg-kyn-black flex flex-col items-center justify-center">
                      <span className="font-display text-3xl font-bold text-kyn-green text-glow">{chargePct}%</span>
                      <span className="text-[10px] text-kyn-metal">Charging</span>
                    </div>
                  </div>
                </div>

                <div className="w-full max-w-xs space-y-2">
                  <div className="h-2 rounded-full bg-kyn-graphite overflow-hidden">
                    <div
                      className={cn('h-full rounded-full bg-gradient-to-r from-kyn-green-dim to-kyn-green', motionPlay && 'animate-pulse')}
                      style={{ width: `${Math.min(100, chargePct)}%` }}
                    />
                  </div>
                  <div className="flex justify-between text-[10px] text-kyn-metal">
                    <span>Splash loader</span>
                    <span>Success</span>
                  </div>
                  <div className="flex items-center justify-center gap-2 text-kyn-green text-xs font-semibold pt-2">
                    <CheckCircle2 size={14} /> Session started
                  </div>
                </div>
              </div>
            </div>

            <div className="space-y-3">
              {motionSpecs.map((m) => (
                <div key={m.title} className="rounded-2xl border border-white/8 bg-white/[0.02] p-5 flex flex-wrap items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <Film size={16} className="text-kyn-green" />
                    <div>
                      <p className="font-semibold text-sm">{m.title}</p>
                      <p className="text-xs text-kyn-metal mt-0.5">{m.note}</p>
                    </div>
                  </div>
                  <div className="text-right text-[10px] font-mono text-kyn-green">
                    <p>{m.dur}</p>
                    <p className="text-kyn-metal">{m.ease}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* 6. Marketing templates */}
      <section id="marketing" className="py-20 md:py-28 bg-kyn-void border-y border-white/5">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <div className="flex flex-wrap items-end justify-between gap-4 mb-10">
            <div>
              <p className="text-kyn-green text-xs font-semibold tracking-[0.25em] uppercase mb-3">06 · Marketing Templates</p>
              <h2 className="font-display text-3xl md:text-4xl font-bold">Campaign-ready formats</h2>
            </div>
            <Link to="/social" className="text-sm text-kyn-green font-semibold inline-flex items-center gap-1">
              Social kit <ArrowRight size={14} />
            </Link>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            {marketingFormats.map((f) => (
              <div key={f.platform + f.format} className="rounded-2xl border border-white/8 bg-black/30 p-5">
                <Share2 size={16} className="text-kyn-green mb-3" />
                <p className="font-display font-semibold">{f.platform}</p>
                <p className="text-xs font-mono text-kyn-green mt-1">{f.format}</p>
                <p className="text-xs text-kyn-metal mt-2">{f.use}</p>
              </div>
            ))}
          </div>

          {/* Mini poster previews */}
          <div className="grid md:grid-cols-3 gap-4">
            {[
              { t: 'Product launch', sub: 'PRIME Series', img: '/images/products/prime-hero.png' },
              { t: 'Portable GO', sub: 'Charge anywhere', img: '/images/products/go-cee.png' },
              { t: 'Cloud SaaS', sub: 'Enterprise ops', img: '/images/cloud-datacenter.jpg' },
            ].map((p) => (
              <div key={p.t} className="rounded-2xl border border-white/10 overflow-hidden bg-kyn-black aspect-square relative poster-shadow">
                <div className="absolute inset-0 grid-bg opacity-50" />
                <div className="absolute -right-6 -top-6 w-32 h-32 rounded-full bg-kyn-green/15 blur-2xl" />
                <div className="relative z-10 h-full p-6 flex flex-col">
                  <BrandLogo height={22} />
                  <div className="flex-1 flex items-center justify-center py-4">
                    <img src={p.img} alt={p.t} className="max-h-36 w-auto object-contain" />
                  </div>
                  <p className="font-display font-bold text-lg">{p.t}</p>
                  <p className="text-xs text-kyn-metal mt-1">{p.sub}</p>
                  <span className="mt-4 inline-flex self-start px-3 py-1.5 rounded-full bg-kyn-green text-kyn-black text-[10px] font-bold">
                    Learn more
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 7. Presentations */}
      <section id="presentations" className="py-20 md:py-28">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <p className="text-kyn-green text-xs font-semibold tracking-[0.25em] uppercase mb-3">07 · Presentation Templates</p>
          <h2 className="font-display text-3xl md:text-4xl font-bold mb-10">Boardroom & field decks</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {decks.map((d) => (
              <Link
                key={d.title}
                to={d.to}
                className="group rounded-2xl border border-white/8 bg-kyn-void p-6 hover:border-kyn-green/30 transition-all"
              >
                <Presentation className="text-kyn-green mb-4" size={20} />
                <p className="font-display font-semibold text-lg group-hover:text-kyn-green transition-colors">{d.title}</p>
                <p className="text-xs text-kyn-metal mt-2">{d.audience}</p>
                <div className="mt-4 flex items-center justify-between text-[11px]">
                  <span className="text-kyn-silver">{d.slides} slides</span>
                  <span className="text-kyn-green inline-flex items-center gap-1">Open <ArrowRight size={12} /></span>
                </div>
              </Link>
            ))}
            <div className="rounded-2xl border border-kyn-green/25 bg-kyn-green/5 p-6 flex flex-col justify-center">
              <FileText className="text-kyn-green mb-3" size={20} />
              <p className="font-display font-semibold">Master slide kit</p>
              <p className="text-xs text-kyn-metal mt-2">Dark 16:9 · energy line footer · large numbers · minimal copy</p>
            </div>
          </div>
        </div>
      </section>

      {/* 8. Documentation */}
      <section id="docs" className="py-20 md:py-28 bg-kyn-void border-y border-white/5">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <p className="text-kyn-green text-xs font-semibold tracking-[0.25em] uppercase mb-3">08 · Documentation</p>
          <h2 className="font-display text-3xl md:text-4xl font-bold mb-10">Guidelines for every team</h2>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {docs.map((d) => (
              <Link
                key={d.title}
                to={d.to}
                className="rounded-2xl border border-white/8 bg-black/30 p-6 hover:border-kyn-green/30 transition-colors group"
              >
                <BookOpen size={18} className="text-kyn-green mb-3" />
                <p className="font-display font-semibold group-hover:text-kyn-green transition-colors">{d.title}</p>
                <p className="text-sm text-kyn-metal mt-2">{d.body}</p>
              </Link>
            ))}
          </div>

          <div className="mt-8 grid md:grid-cols-3 gap-3">
            {(byCat['documentation'] || []).map((a) => (
              <div key={a.id} className="rounded-xl border border-white/8 px-4 py-3">
                <p className="text-sm font-medium">{a.title}</p>
                <p className="text-xs text-kyn-metal mt-1">{a.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 9. QA */}
      <section id="qa" className="py-20 md:py-28">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <p className="text-kyn-green text-xs font-semibold tracking-[0.25em] uppercase mb-3">09 · Quality Assurance</p>
          <h2 className="font-display text-3xl md:text-4xl font-bold mb-3">Launch gate checklist</h2>
          <p className="text-kyn-silver text-sm mb-10 max-w-xl">Every surface reviewed for consistency, usability, performance and scalability.</p>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4 mb-12">
            {qaChecks.map((q) => (
              <div key={q.area} className="rounded-2xl border border-white/8 bg-kyn-void p-6">
                <div className="flex items-center gap-2 mb-4">
                  <Shield size={16} className="text-kyn-green" />
                  <p className="font-display font-semibold">{q.area}</p>
                </div>
                <ul className="space-y-2">
                  {q.items.map((item) => (
                    <li key={item} className="flex items-start gap-2 text-sm text-kyn-silver">
                      <Check size={14} className="text-kyn-green mt-0.5 shrink-0" />
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          {/* Ecosystem readiness scoreboard */}
          <div className="rounded-3xl border border-kyn-green/25 bg-gradient-to-br from-kyn-green/10 via-kyn-void to-kyn-black p-8 md:p-10">
            <div className="flex flex-wrap items-start justify-between gap-6 mb-8">
              <div>
                <p className="text-xs uppercase tracking-[0.25em] text-kyn-green font-semibold">Final readiness</p>
                <h3 className="font-display text-2xl md:text-3xl font-bold mt-2">KYNETIK Digital Ecosystem</h3>
              </div>
              <div className="text-right">
                <p className="font-display text-5xl font-bold text-kyn-green text-glow">A+</p>
                <p className="text-xs text-kyn-metal mt-1">Production grade</p>
              </div>
            </div>
            <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-3">
              {[
                { t: 'Brand identity', to: '/brand' },
                { t: 'Website', to: '/' },
                { t: 'Mobile app', to: '/app-landing' },
                { t: 'Cloud SaaS', to: '/console' },
                { t: 'Academy', to: '/academy' },
                { t: 'Product catalog', to: '/product-system' },
                { t: 'Investor deck', to: '/investor' },
                { t: 'Motion system', to: '#motion' },
                { t: 'Components', to: '/handoff' },
                { t: 'Documentation', to: '#docs' },
              ].map((item) => (
                <Link
                  key={item.t}
                  to={item.to}
                  className="rounded-xl bg-black/40 border border-white/10 px-3 py-3 text-xs font-medium flex items-center gap-2 hover:border-kyn-green/40"
                >
                  <CheckCircle2 size={14} className="text-kyn-green shrink-0" />
                  {item.t}
                </Link>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-24 relative border-t border-white/5">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(0,230,118,0.1),transparent_55%)]" />
        <div className="relative z-10 max-w-3xl mx-auto px-5 text-center">
          <Star className="mx-auto text-kyn-green mb-6" size={28} />
          <h2 className="font-display text-3xl md:text-5xl font-bold">
            Ready for development,
            <br />
            <span className="text-kyn-green text-glow">investors & launch</span>
          </h2>
          <p className="mt-5 text-kyn-silver max-w-xl mx-auto">
            KYNETIK is no longer a set of screens — it is a complete digital product ecosystem.
          </p>
          <div className="mt-10 flex flex-wrap justify-center gap-3">
            <Link to="/showcase" className="inline-flex items-center gap-2 px-7 py-3.5 rounded-full bg-kyn-green text-kyn-black text-sm font-bold glow-green">
              Final Showcase <ArrowRight size={16} />
            </Link>
            <Link to="/handoff" className="inline-flex items-center gap-2 px-7 py-3.5 rounded-full border border-white/15 text-sm font-medium">
              <Code2 size={15} /> Developer Handoff
            </Link>
            <Link to="/prototype" className="inline-flex items-center gap-2 px-7 py-3.5 rounded-full border border-white/15 text-sm font-medium">
              <Play size={15} /> Prototype
            </Link>
          </div>
        </div>
      </section>

      <footer className="border-t border-white/5 py-8">
        <div className="max-w-7xl mx-auto px-5 md:px-8 flex flex-wrap justify-between gap-4 items-center">
          <BrandLogo height={24} />
          <p className="text-[11px] text-kyn-metal">Phase 15 · Design Assets & Production Ready · KYNETIK</p>
        </div>
      </footer>
    </div>
  );
}

import { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  MapPin, Navigation, Zap, Leaf, Wallet, Activity, Play, Square,
  Clock, Gauge, Filter, ExternalLink, Radio, CheckCircle2
} from 'lucide-react';
import { apiGet, cn } from '../../lib/utils';
import { GlassCard, PageHeader, MiniBars, statusColor, type Charger, type Session } from './types';

interface Station {
  id: number;
  name: string;
  city: string;
  address?: string;
  status: string;
  model?: string;
  lat: number;
  lng: number;
  power_kw?: number;
  connector_status?: string;
}

export function MapView() {
  const [stations, setStations] = useState<Station[]>([]);
  const [filter, setFilter] = useState<'all' | 'available' | 'charging' | 'offline'>('all');
  const [selected, setSelected] = useState<Station | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    apiGet<Station[]>('/api/charge-points')
      .then((data) => {
        setStations(data || []);
        setSelected(data?.[0] || null);
      })
      .catch(() => setStations([]))
      .finally(() => setLoading(false));
  }, []);

  const filtered = useMemo(() => {
    if (filter === 'all') return stations;
    return stations.filter((s) => (s.status || '').toLowerCase().includes(filter));
  }, [stations, filter]);

  // Project lat/lng to a simple Tunisia-ish canvas
  const points = useMemo(() => {
    if (!filtered.length) return [];
    const lats = filtered.map((s) => s.lat);
    const lngs = filtered.map((s) => s.lng);
    const minLat = Math.min(...lats) - 0.05;
    const maxLat = Math.max(...lats) + 0.05;
    const minLng = Math.min(...lngs) - 0.05;
    const maxLng = Math.max(...lngs) + 0.05;
    return filtered.map((s) => ({
      s,
      x: ((s.lng - minLng) / Math.max(maxLng - minLng, 0.001)) * 100,
      y: (1 - (s.lat - minLat) / Math.max(maxLat - minLat, 0.001)) * 100,
    }));
  }, [filtered]);

  const counts = {
    all: stations.length,
    available: stations.filter((s) => s.status === 'available').length,
    charging: stations.filter((s) => s.status === 'charging').length,
    offline: stations.filter((s) => s.status === 'offline').length,
  };

  return (
    <div>
      <PageHeader
        title="Find stations"
        subtitle="KYNETIK network map · availability · navigate"
        action={
          <div className="flex flex-wrap gap-2">
            {(['all', 'available', 'charging', 'offline'] as const).map((f) => (
              <button
                key={f}
                type="button"
                onClick={() => setFilter(f)}
                className={cn(
                  'px-3 py-1.5 rounded-full text-[11px] font-semibold border capitalize',
                  filter === f ? 'bg-kyn-green text-kyn-black border-kyn-green' : 'border-white/10 text-kyn-silver'
                )}
              >
                {f} · {counts[f]}
              </button>
            ))}
          </div>
        }
      />

      <div className="grid lg:grid-cols-[1.4fr_1fr] gap-5">
        <GlassCard className="relative min-h-[420px] overflow-hidden p-0">
          <div
            className="absolute inset-0 opacity-40"
            style={{
              backgroundImage:
                'linear-gradient(rgba(0,230,118,0.07) 1px, transparent 1px), linear-gradient(90deg, rgba(0,230,118,0.07) 1px, transparent 1px)',
              backgroundSize: '32px 32px',
            }}
          />
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(0,230,118,0.08),transparent_60%)]" />
          {loading && (
            <div className="absolute inset-0 flex items-center justify-center text-sm text-kyn-metal z-10">Loading map…</div>
          )}
          {!loading && points.map(({ s, x, y }) => {
            const active = selected?.id === s.id;
            const tone =
              s.status === 'charging' ? 'bg-sky-400' :
              s.status === 'available' ? 'bg-kyn-green' :
              s.status === 'offline' ? 'bg-kyn-metal' : 'bg-amber-400';
            return (
              <button
                key={s.id}
                type="button"
                onClick={() => setSelected(s)}
                className="absolute z-10 -translate-x-1/2 -translate-y-1/2 group"
                style={{ left: `${x}%`, top: `${y}%` }}
                title={s.name}
              >
                <span className={cn('block w-3.5 h-3.5 rounded-full border-2 border-kyn-black shadow-lg', tone, active && 'scale-150 ring-4 ring-white/20')} />
                {active && (
                  <span className="absolute left-1/2 -translate-x-1/2 top-5 whitespace-nowrap rounded-lg bg-kyn-void/95 border border-white/10 px-2 py-1 text-[10px] font-semibold">
                    {s.name}
                  </span>
                )}
              </button>
            );
          })}
          <div className="absolute bottom-3 left-3 right-3 flex flex-wrap gap-2 text-[10px] text-kyn-metal z-10">
            <span className="inline-flex items-center gap-1.5 px-2 py-1 rounded-full bg-black/50 border border-white/10"><span className="w-2 h-2 rounded-full bg-kyn-green" /> Available</span>
            <span className="inline-flex items-center gap-1.5 px-2 py-1 rounded-full bg-black/50 border border-white/10"><span className="w-2 h-2 rounded-full bg-sky-400" /> Charging</span>
            <span className="inline-flex items-center gap-1.5 px-2 py-1 rounded-full bg-black/50 border border-white/10"><span className="w-2 h-2 rounded-full bg-kyn-metal" /> Offline</span>
          </div>
        </GlassCard>

        <div className="space-y-3 max-h-[520px] overflow-y-auto pr-1">
          {selected && (
            <GlassCard className="p-5 border-kyn-green/30">
              <p className="text-[10px] uppercase tracking-wider text-kyn-green font-semibold">Selected</p>
              <h3 className="font-display text-lg font-bold mt-1">{selected.name}</h3>
              <p className="text-sm text-kyn-metal mt-1">{selected.city}{selected.address ? ` · ${selected.address}` : ''}</p>
              <div className="mt-3 flex flex-wrap gap-2">
                <span className={cn('text-[10px] px-2 py-1 rounded-full border capitalize', statusColor(selected.status))}>{selected.status}</span>
                {selected.model && <span className="text-[10px] px-2 py-1 rounded-full border border-white/10 text-kyn-metal">{selected.model}</span>}
              </div>
              <div className="mt-4 flex flex-wrap gap-2">
                <a
                  href={`https://www.google.com/maps/dir/?api=1&destination=${selected.lat},${selected.lng}`}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-1.5 px-3 py-2 rounded-full bg-kyn-green text-kyn-black text-xs font-bold"
                >
                  <Navigation size={12} /> Navigate
                </a>
                <Link to="/portal/chargers" className="inline-flex items-center gap-1.5 px-3 py-2 rounded-full border border-white/15 text-xs font-semibold">
                  My chargers
                </Link>
              </div>
            </GlassCard>
          )}
          {filtered.map((s) => (
            <button
              key={s.id}
              type="button"
              onClick={() => setSelected(s)}
              className={cn(
                'w-full text-left rounded-2xl border px-4 py-3 transition-colors',
                selected?.id === s.id ? 'border-kyn-green/40 bg-kyn-green/5' : 'border-white/8 bg-white/[0.02] hover:border-white/15'
              )}
            >
              <div className="flex items-start justify-between gap-2">
                <div>
                  <p className="font-semibold text-sm">{s.name}</p>
                  <p className="text-[11px] text-kyn-metal mt-0.5 flex items-center gap-1"><MapPin size={10} /> {s.city}</p>
                </div>
                <span className={cn('text-[10px] px-2 py-0.5 rounded-full border capitalize shrink-0', statusColor(s.status))}>{s.status}</span>
              </div>
            </button>
          ))}
          {!loading && !filtered.length && (
            <p className="text-sm text-kyn-metal text-center py-10">No stations for this filter.</p>
          )}
        </div>
      </div>
    </div>
  );
}

export function EnergyView({ sessions, chargers }: { sessions: Session[]; chargers: Charger[] }) {
  const monthEnergy = sessions.reduce((a, s) => a + Number(s.energy_kwh || 0), 0);
  const monthCost = sessions.reduce((a, s) => a + Number(s.cost_dt || 0), 0);
  const co2 = monthEnergy * 0.25;
  const avg = sessions.length ? monthEnergy / sessions.length : 0;

  // last 14 days bars from sessions
  const bars = useMemo(() => {
    const days = Array.from({ length: 14 }, () => 0);
    const now = Date.now();
    for (const s of sessions) {
      const t = new Date(s.started_at).getTime();
      const day = Math.floor((now - t) / 86400000);
      if (day >= 0 && day < 14) days[13 - day] += Number(s.energy_kwh || 0);
    }
    return days.map((v) => Math.max(v, 0.05));
  }, [sessions]);

  return (
    <div>
      <PageHeader title="Energy & impact" subtitle="Consumption, cost tracking and CO₂ saved this period." />
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {[
          { label: 'Energy', value: `${monthEnergy.toFixed(1)} kWh`, icon: Zap, sub: 'this period' },
          { label: 'Cost', value: `${monthCost.toFixed(1)} DT`, icon: Wallet, sub: 'estimated' },
          { label: 'CO₂ avoided', value: `−${co2.toFixed(1)} kg`, icon: Leaf, sub: 'grid factor 0.25' },
          { label: 'Avg session', value: `${avg.toFixed(1)} kWh`, icon: Activity, sub: `${sessions.length} sessions` },
        ].map(({ label, value, icon: Icon, sub }) => (
          <GlassCard key={label} className="p-5">
            <div className="flex items-start justify-between">
              <p className="text-[11px] uppercase tracking-wider text-kyn-metal">{label}</p>
              <Icon size={16} className="text-kyn-green" />
            </div>
            <p className="font-display text-2xl font-bold mt-2">{value}</p>
            <p className="text-[11px] text-kyn-metal mt-1">{sub}</p>
          </GlassCard>
        ))}
      </div>

      <div className="grid lg:grid-cols-2 gap-5">
        <GlassCard className="p-6">
          <p className="text-sm font-semibold mb-4">14-day energy</p>
          <MiniBars values={bars} />
          <p className="text-[11px] text-kyn-metal mt-3">Derived from charging history in Supabase.</p>
        </GlassCard>
        <GlassCard className="p-6">
          <p className="text-sm font-semibold mb-4">By charger</p>
          <div className="space-y-3">
            {chargers.map((c) => (
              <div key={c.id} className="flex items-center justify-between gap-3 border-b border-white/5 pb-3">
                <div className="flex items-center gap-3 min-w-0">
                  <img src={c.image_url} alt="" className="w-10 h-10 object-contain" />
                  <div className="min-w-0">
                    <p className="text-sm font-medium truncate">{c.name}</p>
                    <p className="text-[11px] text-kyn-metal">{c.location}</p>
                  </div>
                </div>
                <p className="text-sm font-semibold text-kyn-green shrink-0">{Number(c.energy_month_kwh).toFixed(1)} kWh</p>
              </div>
            ))}
          </div>
        </GlassCard>
      </div>
    </div>
  );
}

export function ControlPanel({
  charger,
  onAction,
}: {
  charger: Charger;
  onAction: (id: number, action: string, extra?: Record<string, unknown>) => void;
}) {
  const [schedule, setSchedule] = useState('22:00');
  const [limit, setLimit] = useState(Math.min(22, Math.max(6, Number(charger.power_kw) || 11)));
  const [toast, setToast] = useState('');
  const charging = (charger.status || '').toLowerCase().includes('charg');

  const run = (action: string, extra?: Record<string, unknown>) => {
    onAction(charger.id, action, extra);
    setToast(action);
    setTimeout(() => setToast(''), 2000);
  };

  return (
    <GlassCard className="p-6">
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="text-[10px] uppercase tracking-wider text-kyn-green font-semibold">Live control</p>
          <h3 className="font-display text-xl font-bold mt-1">{charger.name}</h3>
          <p className="text-xs text-kyn-metal mt-1">{charger.model} · {charger.location}</p>
        </div>
        <span className={cn('text-[10px] px-2 py-1 rounded-full border capitalize', statusColor(charger.online ? charger.status : 'offline'))}>
          {charger.online ? charger.status : 'offline'}
        </span>
      </div>

      <div className="mt-5 grid grid-cols-3 gap-2 text-center">
        <div className="rounded-xl bg-black/30 border border-white/8 p-3">
          <p className="text-[10px] text-kyn-metal">Power</p>
          <p className="font-display font-bold text-kyn-green">{charger.power_kw} kW</p>
        </div>
        <div className="rounded-xl bg-black/30 border border-white/8 p-3">
          <p className="text-[10px] text-kyn-metal">Month</p>
          <p className="font-display font-bold">{charger.energy_month_kwh} kWh</p>
        </div>
        <div className="rounded-xl bg-black/30 border border-white/8 p-3">
          <p className="text-[10px] text-kyn-metal">FW</p>
          <p className="font-display font-bold text-sm">{charger.firmware}</p>
        </div>
      </div>

      <div className="mt-5 grid grid-cols-2 gap-2">
        <button
          type="button"
          disabled={!charger.online || charging}
          onClick={() => run('Start')}
          className="rounded-xl bg-kyn-green text-kyn-black font-bold text-xs py-3 inline-flex items-center justify-center gap-1.5 disabled:opacity-40"
        >
          <Play size={14} /> Start charging
        </button>
        <button
          type="button"
          disabled={!charger.online || !charging}
          onClick={() => run('Stop')}
          className="rounded-xl border border-white/15 font-bold text-xs py-3 inline-flex items-center justify-center gap-1.5 hover:border-red-400/40 hover:text-red-300 disabled:opacity-40"
        >
          <Square size={14} /> Stop
        </button>
      </div>

      <div className="mt-5 space-y-4">
        <div>
          <label className="text-[11px] uppercase tracking-wider text-kyn-metal flex items-center gap-1.5 mb-2">
            <Clock size={12} /> Schedule charging
          </label>
          <div className="flex gap-2">
            <input
              type="time"
              value={schedule}
              onChange={(e) => setSchedule(e.target.value)}
              className="flex-1 rounded-xl bg-black/40 border border-white/10 px-3 py-2.5 text-sm focus:outline-none focus:border-kyn-green/40"
            />
            <button
              type="button"
              onClick={() => run('Schedule', { time: schedule })}
              className="px-4 rounded-xl border border-white/12 text-xs font-semibold hover:border-kyn-green/40"
            >
              Set
            </button>
          </div>
        </div>
        <div>
          <label className="text-[11px] uppercase tracking-wider text-kyn-metal flex items-center gap-1.5 mb-2">
            <Gauge size={12} /> Power limitation · {limit} kW
          </label>
          <input
            type="range"
            min={6}
            max={22}
            step={1}
            value={limit}
            onChange={(e) => setLimit(Number(e.target.value))}
            className="w-full accent-[#00e676]"
          />
          <button
            type="button"
            onClick={() => run('PowerLimit', { kw: limit })}
            className="mt-2 w-full rounded-xl border border-white/12 text-xs font-semibold py-2.5 hover:border-kyn-green/40"
          >
            Apply limit
          </button>
        </div>
      </div>

      {toast && (
        <p className="mt-4 text-xs text-kyn-green text-center inline-flex items-center justify-center gap-1 w-full">
          <CheckCircle2 size={12} /> {toast} sent
        </p>
      )}
      <p className="mt-3 text-[10px] text-kyn-metal text-center flex items-center justify-center gap-1">
        <Radio size={10} /> Commands via Cloud / OCPP when online
      </p>
    </GlassCard>
  );
}

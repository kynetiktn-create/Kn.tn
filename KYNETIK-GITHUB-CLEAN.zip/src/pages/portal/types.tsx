import type { ReactNode } from 'react';
import { cn } from '../../lib/utils';

export interface Charger {
  id: number; name: string; model: string; serial_number: string; status: string;
  online: boolean; firmware: string; last_activity: string; location: string;
  image_url: string; power_kw: number; energy_month_kwh: number;
}
export interface Session {
  id: number; started_at: string; duration_min: number; energy_kwh: number;
  cost_dt: number; location: string; charger_name: string; status: string; vehicle: string;
}
export interface Vehicle {
  id: number; name: string; model: string; battery_kwh: number; photo_url: string;
  default_charger: string; pref_max_soc: number; pref_schedule: string; sessions_count: number;
}
export interface Subscription {
  id: number; plan_name: string; price_dt: number; billing_cycle: string; status: string;
  renews_at: string; features: string; payment_method: string;
}
export interface Invoice {
  id: number; number: string; issued_at: string; amount_dt: number; status: string; description: string;
}
export interface Warranty {
  id: number; product_name: string; serial_number: string; status: string;
  activated_at: string; expires_at: string; certificate_url: string;
}
export interface Ticket {
  id: number; subject: string; description: string; status: string; priority: string;
  charger_name: string; appointment_at: string; technician: string; created_at: string;
}
export interface NotificationItem {
  id: number; title: string; body: string; type: string; read: boolean; created_at: string;
}
export interface DownloadItem {
  id: number; title: string; category: string; file_type: string; size_label: string; url: string;
}
export interface Profile {
  id: number; full_name: string; email: string; phone: string; company: string;
  address: string; city: string; country: string; language: string; two_fa: boolean;
  notify_email: boolean; notify_push: boolean; notify_sms: boolean;
}
export type PortalData = {
  chargers: Charger[];
  sessions: Session[];
  vehicles: Vehicle[];
  billing: { subscription: Subscription | null; invoices: Invoice[] };
  tickets: Ticket[];
  notifications: NotificationItem[];
  downloads: DownloadItem[];
  account: { profile: Profile | null; warranties: Warranty[] };
};

export function parseList(s?: string | null): string[] {
  if (!s) return [];
  try { const v = JSON.parse(s); return Array.isArray(v) ? v : []; } catch { return []; }
}

export function fmtDate(iso: string) {
  try {
    return new Date(iso).toLocaleString('fr-TN', {
      day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit',
    });
  } catch { return iso; }
}

export function statusColor(status: string) {
  const s = (status || '').toLowerCase();
  if (s.includes('charg') || s === 'active' || s === 'in_progress' || s === 'healthy') return 'text-kyn-green bg-kyn-green/10 border-kyn-green/25';
  if (s.includes('available') || s === 'paid' || s === 'resolved' || s === 'online') return 'text-emerald-300 bg-emerald-400/10 border-emerald-400/20';
  if (s.includes('sched')) return 'text-sky-300 bg-sky-400/10 border-sky-400/20';
  if (s.includes('off') || s.includes('error') || s === 'open' || s === 'locked') return 'text-amber-300 bg-amber-400/10 border-amber-400/20';
  return 'text-kyn-metal bg-white/5 border-white/10';
}

export function GlassCard({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <div className={cn('rounded-2xl border border-white/8 bg-white/[0.03] backdrop-blur-xl', className)}>
      {children}
    </div>
  );
}

export function PageHeader({ title, subtitle, action }: { title: string; subtitle?: string; action?: ReactNode }) {
  return (
    <div className="flex flex-wrap items-end justify-between gap-4 mb-8">
      <div>
        <h1 className="font-display text-2xl md:text-3xl font-bold tracking-tight">{title}</h1>
        {subtitle && <p className="text-sm text-kyn-metal mt-1">{subtitle}</p>}
      </div>
      {action}
    </div>
  );
}

export function MiniBars({ values, color = '#00e676' }: { values: number[]; color?: string }) {
  const max = Math.max(...values, 1);
  return (
    <div className="flex items-end gap-1 h-16">
      {values.map((v, i) => (
        <div
          key={i}
          className="flex-1 rounded-t-sm opacity-80"
          style={{ height: `${(v / max) * 100}%`, background: `linear-gradient(to top, ${color}55, ${color})` }}
        />
      ))}
    </div>
  );
}

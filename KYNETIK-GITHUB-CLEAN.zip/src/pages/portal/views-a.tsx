import { useEffect, useState, type FormEvent } from 'react';
import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Plug, Activity, Leaf, Zap, ChevronRight, Wifi, WifiOff, RotateCcw, Lock, Cpu, Stethoscope,
  Wallet, CheckCircle2, Clock, Wrench, Plus, X, FileText, ExternalLink, User, KeyRound,
  Settings2, Mail, Bell, Phone, Globe2, AlertTriangle, CreditCard, Download
} from 'lucide-react';
import { apiGet, apiPost, cn } from '../../lib/utils';
import {
  type PortalData, type Charger, type Session, type Vehicle, type Subscription, type Invoice,
  type Warranty, type Ticket, type NotificationItem, type DownloadItem, type Profile,
  parseList, fmtDate, statusColor, GlassCard, PageHeader, MiniBars,
} from './types';
import { ControlPanel } from './views-extra';

export function DashboardView({ data, onRefresh }: { data: PortalData; onRefresh: () => void }) {
  const profile = data.account.profile;
  const activeSessions = data.sessions.filter((s) => s.status === 'active');
  const monthEnergy = data.sessions.reduce((a, s) => a + Number(s.energy_kwh || 0), 0);
  const monthCost = data.sessions.reduce((a, s) => a + Number(s.cost_dt || 0), 0);
  const co2 = monthEnergy * 0.25;
  const online = data.chargers.filter((c) => c.online).length;
  const chart = [12, 18, 14, 22, 19, 28, 24, 31, 26, 20, 17, 23, 29, 33];

  return (
    <div>
      <PageHeader
        title={`Bonjour ${profile?.full_name?.split(' ')[0] || 'Client'} 👋`}
        subtitle="Votre énergie, sous contrôle — Tesla-grade account experience."
        action={
          <button type="button" onClick={onRefresh} className="text-xs px-4 py-2 rounded-full border border-white/10 text-kyn-silver hover:text-white">
            Actualiser
          </button>
        }
      />

      <div className="grid sm:grid-cols-2 xl:grid-cols-4 gap-4 mb-6">
        {[
          { label: 'Bornes actives', value: `${online}/${data.chargers.length}`, icon: Plug, sub: 'online' },
          { label: 'Sessions en cours', value: String(activeSessions.length), icon: Activity, sub: 'live' },
          { label: 'Énergie du mois', value: `${monthEnergy.toFixed(1)} kWh`, icon: Zap, sub: 'total' },
          { label: 'CO₂ évité', value: `−${co2.toFixed(1)} kg`, icon: Leaf, sub: 'impact' },
        ].map(({ label, value, icon: Icon, sub }) => (
          <GlassCard key={label} className="p-5">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-[11px] uppercase tracking-wider text-kyn-metal">{label}</p>
                <p className="font-display text-2xl font-bold mt-2">{value}</p>
                <p className="text-[11px] text-kyn-green mt-1">{sub}</p>
              </div>
              <div className="w-10 h-10 rounded-xl bg-kyn-green/10 border border-kyn-green/20 flex items-center justify-center text-kyn-green">
                <Icon size={18} />
              </div>
            </div>
          </GlassCard>
        ))}
      </div>

      <div className="grid lg:grid-cols-3 gap-4 mb-6">
        <GlassCard className="lg:col-span-2 p-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <p className="font-semibold">Consommation récente</p>
              <p className="text-xs text-kyn-metal mt-0.5">kWh · 14 derniers points</p>
            </div>
            <span className="text-sm font-display font-bold text-kyn-green">{monthCost.toFixed(2)} DT</span>
          </div>
          <MiniBars values={chart} />
          <div className="mt-4 grid grid-cols-3 gap-3">
            <div className="rounded-xl bg-black/30 border border-white/5 p-3">
              <p className="text-[10px] text-kyn-metal">Coût mois</p>
              <p className="font-semibold mt-1">{monthCost.toFixed(2)} DT</p>
            </div>
            <div className="rounded-xl bg-black/30 border border-white/5 p-3">
              <p className="text-[10px] text-kyn-metal">Moy. session</p>
              <p className="font-semibold mt-1">
                {data.sessions.length ? (monthEnergy / data.sessions.length).toFixed(1) : '0'} kWh
              </p>
            </div>
            <div className="rounded-xl bg-black/30 border border-white/5 p-3">
              <p className="text-[10px] text-kyn-metal">Plan Cloud</p>
              <p className="font-semibold mt-1">{data.billing.subscription?.plan_name || '—'}</p>
            </div>
          </div>
        </GlassCard>

        <GlassCard className="p-6">
          <p className="font-semibold mb-4">Session active</p>
          {activeSessions[0] ? (
            <div>
              <div className="relative mx-auto w-36 h-36 mb-4">
                <div className="absolute inset-0 rounded-full" style={{ background: 'conic-gradient(from 210deg, #00e676 0 72%, #2a2a30 0)' }} />
                <div className="absolute inset-[6px] rounded-full bg-kyn-void flex flex-col items-center justify-center">
                  <span className="font-display text-3xl font-bold text-kyn-green">72%</span>
                  <span className="text-[10px] text-kyn-metal">charging</span>
                </div>
              </div>
              <p className="text-sm font-medium text-center">{activeSessions[0].charger_name}</p>
              <p className="text-xs text-kyn-metal text-center mt-1">
                {activeSessions[0].energy_kwh} kWh · {activeSessions[0].duration_min} min
              </p>
            </div>
          ) : (
            <div className="h-full min-h-[200px] flex flex-col items-center justify-center text-center text-kyn-metal text-sm">
              <Zap className="text-kyn-green mb-3" size={22} />
              Aucune session en cours
            </div>
          )}
        </GlassCard>
      </div>

      <div className="grid lg:grid-cols-2 gap-4">
        <GlassCard className="p-6">
          <div className="flex items-center justify-between mb-4">
            <p className="font-semibold">Mes bornes</p>
            <Link to="/portal/chargers" className="text-xs text-kyn-green inline-flex items-center gap-1">
              Voir tout <ChevronRight size={12} />
            </Link>
          </div>
          <div className="space-y-3">
            {data.chargers.map((c) => (
              <div key={c.id} className="flex items-center gap-3 rounded-xl border border-white/6 bg-black/25 p-3">
                <img src={c.image_url} alt={c.model} className="w-12 h-14 object-contain" />
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-sm truncate">{c.name}</p>
                  <p className="text-[11px] text-kyn-metal truncate">{c.model} · {c.location}</p>
                </div>
                <span className={cn('text-[10px] px-2 py-1 rounded-full border capitalize', statusColor(c.online ? c.status : 'offline'))}>
                  {c.online ? c.status : 'offline'}
                </span>
              </div>
            ))}
          </div>
        </GlassCard>

        <GlassCard className="p-6">
          <div className="flex items-center justify-between mb-4">
            <p className="font-semibold">Activité récente</p>
            <Link to="/portal/history" className="text-xs text-kyn-green inline-flex items-center gap-1">
              Historique <ChevronRight size={12} />
            </Link>
          </div>
          <div className="space-y-3">
            {data.sessions.slice(0, 5).map((s) => (
              <div key={s.id} className="flex items-start justify-between gap-3 border-b border-white/5 pb-3 last:border-0 last:pb-0">
                <div>
                  <p className="text-sm font-medium">{s.charger_name}</p>
                  <p className="text-[11px] text-kyn-metal mt-0.5">{fmtDate(s.started_at)} · {s.location}</p>
                </div>
                <div className="text-right shrink-0">
                  <p className="text-sm font-semibold text-kyn-green">{s.energy_kwh} kWh</p>
                  <p className="text-[11px] text-kyn-metal">{s.cost_dt} DT</p>
                </div>
              </div>
            ))}
          </div>
        </GlassCard>
      </div>
    </div>
  );
}

export function ChargersView({ chargers, onAction }: { chargers: Charger[]; onAction: (id: number, action: string, extra?: Record<string, unknown>) => void }) {
  const [selected, setSelected] = useState<Charger | null>(chargers[0] || null);
  const [toast, setToast] = useState('');

  useEffect(() => {
    if (!chargers.length) { setSelected(null); return; }
    setSelected((prev) => chargers.find((c) => c.id === prev?.id) || chargers[0]);
  }, [chargers]);

  const run = (id: number, action: string, extra?: Record<string, unknown>) => {
    onAction(id, action, extra);
    setToast(`${action} envoyé`);
    setTimeout(() => setToast(''), 2200);
  };

  return (
    <div>
      <PageHeader title="My Chargers" subtitle="Contrôle distant, diagnostics et firmware — style Tesla Account." />
      <div className="grid lg:grid-cols-[1fr_360px] gap-5">
        <div className="grid sm:grid-cols-2 gap-4">
          {chargers.map((c) => (
            <button
              key={c.id}
              type="button"
              onClick={() => setSelected(c)}
              className={cn(
                'text-left rounded-2xl border p-5 transition-all hover:-translate-y-0.5',
                selected?.id === c.id ? 'border-kyn-green/40 bg-kyn-green/5 glow-green' : 'border-white/8 bg-white/[0.03]'
              )}
            >
              <div className="h-36 flex items-center justify-center mb-4 rounded-xl bg-[radial-gradient(circle,rgba(0,230,118,0.1),transparent_70%)]">
                <img src={c.image_url} alt={c.model} className="max-h-full object-contain p-2" />
              </div>
              <div className="flex items-start justify-between gap-2">
                <div>
                  <p className="font-display font-bold">{c.name}</p>
                  <p className="text-xs text-kyn-metal mt-0.5">{c.model}</p>
                </div>
                {c.online ? <Wifi size={14} className="text-kyn-green" /> : <WifiOff size={14} className="text-kyn-metal" />}
              </div>
              <div className="mt-3 flex flex-wrap gap-2">
                <span className={cn('text-[10px] px-2 py-1 rounded-full border capitalize', statusColor(c.online ? c.status : 'offline'))}>
                  {c.online ? c.status : 'offline'}
                </span>
                <span className="text-[10px] px-2 py-1 rounded-full border border-white/10 text-kyn-metal">FW {c.firmware}</span>
              </div>
              <p className="text-[11px] text-kyn-metal mt-3">S/N {c.serial_number}</p>
              <p className="text-[11px] text-kyn-metal">Dernière activité · {c.last_activity}</p>
            </button>
          ))}
        </div>

        {selected && (
          <div className="space-y-4 h-fit sticky top-24">
            <ControlPanel charger={selected} onAction={run} />
            <GlassCard className="p-5">
              <p className="text-[10px] uppercase tracking-wider text-kyn-metal font-semibold mb-3">More actions</p>
              <div className="grid grid-cols-2 gap-2">
                {[
                  { a: 'Restart', icon: RotateCcw },
                  { a: 'Remote Lock', icon: Lock },
                  { a: 'Firmware Update', icon: Cpu },
                  { a: 'Diagnostics', icon: Stethoscope },
                ].map(({ a, icon: Icon }) => (
                  <button
                    key={a}
                    type="button"
                    onClick={() => run(selected.id, a)}
                    className="rounded-xl border border-white/10 bg-black/30 px-3 py-2.5 text-[11px] font-semibold hover:border-kyn-green/40 hover:text-kyn-green flex items-center justify-center gap-1.5"
                  >
                    <Icon size={12} /> {a}
                  </button>
                ))}
              </div>
              <div className="mt-3 text-xs text-kyn-metal space-y-1">
                <p>S/N {selected.serial_number}</p>
                <p>Last activity · {selected.last_activity}</p>
              </div>
              {toast && <p className="mt-3 text-xs text-kyn-green text-center">{toast} ✓</p>}
            </GlassCard>
          </div>
        )}
      </div>
    </div>
  );
}

export function HistoryView({ sessions }: { sessions: Session[] }) {
  const [period, setPeriod] = useState('month');
  const [filtered, setFiltered] = useState<Session[]>(sessions);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setLoading(true);
    apiGet<Session[]>(`/api/portal-sessions?period=${period}`)
      .then(setFiltered)
      .catch(() => setFiltered(sessions))
      .finally(() => setLoading(false));
  }, [period]);

  const exportCsv = () => {
    const header = 'Date,Duration,Energy,Cost,Location,Charger,Vehicle,Status\n';
    const rows = filtered.map((s) =>
      [s.started_at, s.duration_min, s.energy_kwh, s.cost_dt, `"${s.location}"`, `"${s.charger_name}"`, `"${s.vehicle}"`, s.status].join(',')
    ).join('\n');
    const blob = new Blob([header + rows], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `kynetik-sessions-${period}.csv`; a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div>
      <PageHeader
        title="Charging History"
        subtitle="Timeline complète de vos sessions — export CSV / PDF."
        action={
          <div className="flex flex-wrap gap-2">
            <button type="button" onClick={exportCsv} className="px-4 py-2 rounded-full bg-kyn-green text-kyn-black text-xs font-bold">Export CSV</button>
            <button type="button" onClick={() => window.print()} className="px-4 py-2 rounded-full border border-white/15 text-xs font-semibold">Export PDF</button>
          </div>
        }
      />
      <div className="flex flex-wrap gap-2 mb-6">
        {['today', 'week', 'month', 'year', 'all'].map((p) => (
          <button key={p} type="button" onClick={() => setPeriod(p)}
            className={cn('px-4 py-2 rounded-full text-xs font-semibold capitalize', period === p ? 'bg-kyn-green text-kyn-black' : 'bg-kyn-steel text-kyn-silver')}>
            {p === 'all' ? 'All' : p}
          </button>
        ))}
      </div>
      <GlassCard className="overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm min-w-[720px]">
            <thead className="text-[11px] uppercase tracking-wider text-kyn-metal border-b border-white/5 bg-white/[0.02]">
              <tr>{['Date', 'Duration', 'Energy', 'Cost', 'Location', 'Charger', 'Status'].map((h) => (
                <th key={h} className="px-4 py-3 font-medium">{h}</th>
              ))}</tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {loading ? (
                <tr><td colSpan={7} className="px-4 py-10 text-center text-kyn-metal">Chargement…</td></tr>
              ) : filtered.length === 0 ? (
                <tr><td colSpan={7} className="px-4 py-10 text-center text-kyn-metal">Aucune session</td></tr>
              ) : filtered.map((s) => (
                <tr key={s.id} className="text-kyn-silver hover:bg-white/[0.02]">
                  <td className="px-4 py-3 text-white">{fmtDate(s.started_at)}</td>
                  <td className="px-4 py-3">{s.duration_min} min</td>
                  <td className="px-4 py-3 text-kyn-green font-medium">{s.energy_kwh} kWh</td>
                  <td className="px-4 py-3">{s.cost_dt} DT</td>
                  <td className="px-4 py-3">{s.location}</td>
                  <td className="px-4 py-3">{s.charger_name}</td>
                  <td className="px-4 py-3"><span className={cn('text-[10px] px-2 py-1 rounded-full border capitalize', statusColor(s.status))}>{s.status}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </GlassCard>
    </div>
  );
}

export function VehiclesView({ vehicles }: { vehicles: Vehicle[] }) {
  return (
    <div>
      <PageHeader title="Vehicles" subtitle="Gérez vos EVs, préférences de charge et borne par défaut." />
      <div className="grid md:grid-cols-2 gap-5">
        {vehicles.map((v) => (
          <GlassCard key={v.id} className="overflow-hidden">
            <div className="h-40 relative">
              <img src={v.photo_url} alt={v.model} className="w-full h-full object-cover opacity-70" />
              <div className="absolute inset-0 bg-gradient-to-t from-kyn-void via-transparent to-transparent" />
              <div className="absolute bottom-4 left-5">
                <p className="font-display text-xl font-bold">{v.name}</p>
                <p className="text-xs text-kyn-silver">{v.model}</p>
              </div>
            </div>
            <div className="p-5 grid grid-cols-2 gap-3 text-sm">
              <div className="rounded-xl bg-black/30 border border-white/5 p-3"><p className="text-[10px] text-kyn-metal">Batterie</p><p className="font-semibold mt-1">{v.battery_kwh} kWh</p></div>
              <div className="rounded-xl bg-black/30 border border-white/5 p-3"><p className="text-[10px] text-kyn-metal">Max SoC</p><p className="font-semibold mt-1">{v.pref_max_soc}%</p></div>
              <div className="rounded-xl bg-black/30 border border-white/5 p-3 col-span-2"><p className="text-[10px] text-kyn-metal">Préférences</p><p className="font-medium mt-1">{v.pref_schedule}</p></div>
              <div className="rounded-xl bg-black/30 border border-white/5 p-3"><p className="text-[10px] text-kyn-metal">Borne défaut</p><p className="font-semibold mt-1 text-kyn-green">{v.default_charger}</p></div>
              <div className="rounded-xl bg-black/30 border border-white/5 p-3"><p className="text-[10px] text-kyn-metal">Sessions</p><p className="font-semibold mt-1">{v.sessions_count}</p></div>
            </div>
          </GlassCard>
        ))}
      </div>
    </div>
  );
}

import { useEffect, useState, type FormEvent } from 'react';
import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Plug, CheckCircle2, Clock, Wrench, Plus, X, FileText, ExternalLink, User, KeyRound,
  Settings2, Mail, Bell, Phone, Globe2, AlertTriangle, CreditCard, Zap, Cpu, Wallet
} from 'lucide-react';
import { cn } from '../../lib/utils';
import {
  type Subscription, type Invoice, type Warranty, type Ticket, type Charger,
  type NotificationItem, type DownloadItem, type Profile,
  parseList, fmtDate, statusColor, GlassCard, PageHeader,
} from './types';

export function SubscriptionView({
  subscription, invoices, onUpgrade,
}: {
  subscription: Subscription | null;
  invoices: Invoice[];
  onUpgrade: () => void;
}) {
  const features = parseList(subscription?.features);
  return (
    <div>
      <PageHeader title="Subscription" subtitle="Plan Cloud, factures et paiements — expérience Stripe Customer Portal." />
      <div className="grid lg:grid-cols-3 gap-5">
        <GlassCard className="lg:col-span-2 p-6 md:p-8">
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div>
              <p className="text-xs text-kyn-green uppercase tracking-wider font-semibold">Current plan</p>
              <h3 className="font-display text-3xl font-bold mt-2">{subscription?.plan_name || '—'}</h3>
              <p className="text-kyn-metal text-sm mt-2">
                {subscription?.price_dt} DT / {subscription?.billing_cycle} · Renouvellement {subscription?.renews_at}
              </p>
            </div>
            <span className={cn('text-xs px-3 py-1.5 rounded-full border capitalize', statusColor(subscription?.status || ''))}>
              {subscription?.status}
            </span>
          </div>
          <div className="mt-6 grid sm:grid-cols-2 gap-2">
            {features.map((f) => (
              <div key={f} className="flex items-center gap-2 text-sm text-kyn-silver">
                <CheckCircle2 size={14} className="text-kyn-green" /> {f}
              </div>
            ))}
          </div>
          <div className="mt-8 flex flex-wrap gap-3">
            <button type="button" onClick={onUpgrade} className="px-5 py-2.5 rounded-full bg-kyn-green text-kyn-black text-xs font-bold">Upgrade Plan</button>
            <button type="button" className="px-5 py-2.5 rounded-full border border-white/15 text-xs font-semibold">Renew / Manage</button>
          </div>
          <p className="mt-6 text-xs text-kyn-metal flex items-center gap-2">
            <Wallet size={12} className="text-kyn-green" /> Payment method · {subscription?.payment_method}
          </p>
        </GlassCard>

        <GlassCard className="p-6">
          <p className="font-semibold mb-4">Invoices</p>
          <div className="space-y-3">
            {invoices.map((inv) => (
              <div key={inv.id} className="rounded-xl border border-white/8 bg-black/25 p-3">
                <div className="flex justify-between gap-2">
                  <p className="text-sm font-medium">{inv.number}</p>
                  <span className={cn('text-[10px] px-2 py-0.5 rounded-full border capitalize', statusColor(inv.status))}>{inv.status}</span>
                </div>
                <p className="text-[11px] text-kyn-metal mt-1">{inv.description}</p>
                <div className="mt-2 flex justify-between text-xs">
                  <span className="text-kyn-metal">{inv.issued_at}</span>
                  <span className="font-semibold text-kyn-green">{inv.amount_dt} DT</span>
                </div>
              </div>
            ))}
          </div>
        </GlassCard>
      </div>
    </div>
  );
}

export function WarrantyView({ warranties }: { warranties: Warranty[] }) {
  return (
    <div>
      <PageHeader title="Warranty" subtitle="Statut, activation, expiration et certificats." />
      <div className="grid md:grid-cols-3 gap-4">
        {warranties.map((w) => (
          <GlassCard key={w.id} className="p-6">
            <div className="flex items-start justify-between gap-2">
              <div className="w-10 h-10 rounded-xl bg-kyn-green/10 border border-kyn-green/20 flex items-center justify-center text-kyn-green">✓</div>
              <span className={cn('text-[10px] px-2 py-1 rounded-full border capitalize', statusColor(w.status))}>{w.status}</span>
            </div>
            <h3 className="font-display font-bold text-lg mt-4">{w.product_name}</h3>
            <p className="text-xs text-kyn-metal mt-1">S/N {w.serial_number}</p>
            <div className="mt-5 space-y-2 text-sm">
              <div className="flex justify-between"><span className="text-kyn-metal">Activation</span><span>{w.activated_at}</span></div>
              <div className="flex justify-between"><span className="text-kyn-metal">Expiration</span><span>{w.expires_at}</span></div>
            </div>
            <div className="mt-6 flex flex-col gap-2">
              <a href={w.certificate_url} className="text-center rounded-xl bg-kyn-green/10 border border-kyn-green/25 text-kyn-green text-xs font-semibold py-2.5">Download certificate</a>
              <Link to="/portal/service" className="text-center rounded-xl border border-white/10 text-xs font-semibold py-2.5">Request support</Link>
            </div>
          </GlassCard>
        ))}
      </div>
    </div>
  );
}

export function ServiceView({ tickets, chargers, onCreate }: {
  tickets: Ticket[];
  chargers: Charger[];
  onCreate: (payload: Partial<Ticket>) => Promise<void>;
}) {
  const [open, setOpen] = useState(false);
  const [subject, setSubject] = useState('');
  const [description, setDescription] = useState('');
  const [charger_name, setCharger] = useState(chargers[0]?.name || '');
  const [priority, setPriority] = useState('medium');
  const [appointment_at, setAppt] = useState('');
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState('');

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!subject.trim()) { setErr('Sujet requis'); return; }
    setSaving(true); setErr('');
    try {
      await onCreate({ subject, description, charger_name, priority, appointment_at, status: appointment_at ? 'scheduled' : 'open' });
      setOpen(false); setSubject(''); setDescription(''); setAppt('');
    } catch (ex: unknown) {
      setErr(ex instanceof Error ? ex.message : 'Erreur');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div>
      <PageHeader
        title="Service Requests"
        subtitle="Tickets maintenance, techniciens et rendez-vous."
        action={
          <button type="button" onClick={() => setOpen(true)} className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-kyn-green text-kyn-black text-xs font-bold">
            <Plus size={14} /> New ticket
          </button>
        }
      />
      <div className="space-y-3">
        {tickets.map((t) => (
          <GlassCard key={t.id} className="p-5">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <p className="font-semibold">{t.subject}</p>
                <p className="text-sm text-kyn-metal mt-1 max-w-2xl">{t.description}</p>
                <div className="mt-3 flex flex-wrap gap-3 text-[11px] text-kyn-metal">
                  <span className="inline-flex items-center gap-1"><Plug size={11} /> {t.charger_name}</span>
                  {t.technician && <span className="inline-flex items-center gap-1"><Wrench size={11} /> {t.technician}</span>}
                  {t.appointment_at && <span className="inline-flex items-center gap-1"><Clock size={11} /> {t.appointment_at}</span>}
                  <span>{fmtDate(t.created_at)}</span>
                </div>
              </div>
              <div className="flex flex-col items-end gap-2">
                <span className={cn('text-[10px] px-2 py-1 rounded-full border capitalize', statusColor(t.status))}>{t.status.replace('_', ' ')}</span>
                <span className="text-[10px] text-kyn-metal capitalize">Priority · {t.priority}</span>
              </div>
            </div>
          </GlassCard>
        ))}
      </div>

      <AnimatePresence>
        {open && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-[80] bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
            <motion.form
              initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: 12, opacity: 0 }}
              onSubmit={submit}
              className="w-full max-w-lg rounded-2xl border border-white/10 bg-kyn-void p-6"
            >
              <div className="flex items-center justify-between mb-5">
                <h3 className="font-display font-bold text-lg">Create maintenance ticket</h3>
                <button type="button" onClick={() => setOpen(false)} className="text-kyn-metal"><X size={18} /></button>
              </div>
              <div className="space-y-3">
                <input value={subject} onChange={(e) => setSubject(e.target.value)} placeholder="Sujet" className="w-full rounded-xl bg-kyn-steel border border-white/10 px-3 py-2.5 text-sm outline-none focus:border-kyn-green/40" />
                <textarea value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Description" rows={3} className="w-full rounded-xl bg-kyn-steel border border-white/10 px-3 py-2.5 text-sm outline-none focus:border-kyn-green/40" />
                <select value={charger_name} onChange={(e) => setCharger(e.target.value)} className="w-full rounded-xl bg-kyn-steel border border-white/10 px-3 py-2.5 text-sm">
                  {chargers.map((c) => <option key={c.id} value={c.name}>{c.name}</option>)}
                </select>
                <div className="grid grid-cols-2 gap-3">
                  <select value={priority} onChange={(e) => setPriority(e.target.value)} className="rounded-xl bg-kyn-steel border border-white/10 px-3 py-2.5 text-sm">
                    <option value="low">Low</option>
                    <option value="medium">Medium</option>
                    <option value="high">High</option>
                  </select>
                  <input type="datetime-local" value={appointment_at} onChange={(e) => setAppt(e.target.value)} className="rounded-xl bg-kyn-steel border border-white/10 px-3 py-2.5 text-sm" />
                </div>
                {err && <p className="text-xs text-red-400">{err}</p>}
                <button disabled={saving} type="submit" className="w-full rounded-xl bg-kyn-green text-kyn-black font-bold text-sm py-3 disabled:opacity-60">
                  {saving ? 'Envoi…' : 'Créer le ticket'}
                </button>
              </div>
            </motion.form>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export function NotificationsView({
  notifications, onRead,
}: {
  notifications: NotificationItem[];
  onRead: (id: number) => void;
}) {
  const iconFor = (type: string) => {
    if (type === 'charging') return Zap;
    if (type === 'firmware') return Cpu;
    if (type === 'maintenance') return Wrench;
    if (type === 'error') return AlertTriangle;
    if (type === 'subscription') return CreditCard;
    return Bell;
  };

  return (
    <div>
      <PageHeader title="Notifications" subtitle="Charge, erreurs, maintenance, firmware et abonnement." />
      <div className="space-y-3">
        {notifications.map((n) => {
          const Icon = iconFor(n.type);
          return (
            <button
              key={n.id}
              type="button"
              onClick={() => !n.read && onRead(n.id)}
              className={cn(
                'w-full text-left rounded-2xl border p-4 flex gap-4 transition-colors',
                n.read ? 'border-white/6 bg-white/[0.02]' : 'border-kyn-green/25 bg-kyn-green/5'
              )}
            >
              <div className="w-10 h-10 rounded-xl bg-kyn-green/10 border border-kyn-green/20 flex items-center justify-center text-kyn-green shrink-0">
                <Icon size={16} />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between gap-3">
                  <p className="font-semibold text-sm">{n.title}</p>
                  {!n.read && <span className="w-2 h-2 rounded-full bg-kyn-green mt-1.5 shrink-0" />}
                </div>
                <p className="text-sm text-kyn-metal mt-1">{n.body}</p>
                <p className="text-[11px] text-kyn-metal mt-2">{fmtDate(n.created_at)}</p>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}

export function DownloadsView({ downloads }: { downloads: DownloadItem[] }) {
  const cats = ['All', ...Array.from(new Set(downloads.map((d) => d.category)))];
  const [cat, setCat] = useState('All');
  const list = cat === 'All' ? downloads : downloads.filter((d) => d.category === cat);

  return (
    <div>
      <PageHeader title="Downloads" subtitle="Datasheets, manuels, certificats, garanties et factures." />
      <div className="flex flex-wrap gap-2 mb-6">
        {cats.map((c) => (
          <button key={c} type="button" onClick={() => setCat(c)}
            className={cn('px-3 py-1.5 rounded-full text-xs font-semibold', cat === c ? 'bg-kyn-green text-kyn-black' : 'bg-kyn-steel text-kyn-silver')}>
            {c}
          </button>
        ))}
      </div>
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {list.map((d) => (
          <GlassCard key={d.id} className="p-5 flex flex-col">
            <div className="flex items-start justify-between gap-3">
              <div className="w-10 h-10 rounded-xl bg-kyn-green/10 border border-kyn-green/20 flex items-center justify-center text-kyn-green">
                <FileText size={16} />
              </div>
              <span className="text-[10px] text-kyn-metal">{d.file_type} · {d.size_label}</span>
            </div>
            <p className="font-semibold mt-4">{d.title}</p>
            <p className="text-xs text-kyn-metal mt-1">{d.category}</p>
            <a href={d.url || '#'} className="mt-auto pt-5 inline-flex items-center gap-1 text-xs font-semibold text-kyn-green">
              Download <ExternalLink size={12} />
            </a>
          </GlassCard>
        ))}
      </div>
    </div>
  );
}

export function ProfileView({
  profile, onSave,
}: {
  profile: Profile | null;
  onSave: (p: Profile) => Promise<void>;
}) {
  const [form, setForm] = useState<Profile | null>(profile);
  const [saved, setSaved] = useState(false);
  const [saving, setSaving] = useState(false);

  useEffect(() => setForm(profile), [profile]);
  if (!form) return <p className="text-kyn-metal">Profil introuvable</p>;

  const set = (key: keyof Profile, value: string | boolean) => setForm({ ...form, [key]: value });

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      await onSave(form);
      setSaved(true);
      setTimeout(() => setSaved(false), 2000);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div>
      <PageHeader title="Profile" subtitle="Informations, sécurité, langue et notifications." />
      <form onSubmit={submit} className="grid lg:grid-cols-2 gap-5">
        <GlassCard className="p-6 space-y-3">
          <p className="font-semibold mb-2 flex items-center gap-2"><User size={16} className="text-kyn-green" /> Personal information</p>
          {([
            ['full_name', 'Nom complet'],
            ['email', 'Email'],
            ['phone', 'Téléphone'],
            ['company', 'Société'],
            ['address', 'Adresse'],
            ['city', 'Ville'],
            ['country', 'Pays'],
          ] as const).map(([key, label]) => (
            <label key={key} className="block">
              <span className="text-[11px] text-kyn-metal">{label}</span>
              <input
                value={String(form[key] ?? '')}
                onChange={(e) => set(key, e.target.value)}
                className="mt-1 w-full rounded-xl bg-kyn-steel border border-white/10 px-3 py-2.5 text-sm outline-none focus:border-kyn-green/40"
              />
            </label>
          ))}
        </GlassCard>

        <div className="space-y-5">
          <GlassCard className="p-6 space-y-4">
            <p className="font-semibold flex items-center gap-2"><KeyRound size={16} className="text-kyn-green" /> Security</p>
            <div className="flex items-center justify-between rounded-xl border border-white/8 bg-black/25 px-4 py-3">
              <div>
                <p className="text-sm font-medium">Two-factor authentication</p>
                <p className="text-[11px] text-kyn-metal">Protection type Apple ID / Stripe</p>
              </div>
              <button type="button" onClick={() => set('two_fa', !form.two_fa)}
                className={cn('w-12 h-7 rounded-full relative transition-colors', form.two_fa ? 'bg-kyn-green' : 'bg-kyn-graphite')}>
                <span className={cn('absolute top-0.5 w-6 h-6 rounded-full bg-white transition-all', form.two_fa ? 'left-5' : 'left-0.5')} />
              </button>
            </div>
            <label className="block">
              <span className="text-[11px] text-kyn-metal flex items-center gap-1"><Globe2 size={11} /> Language</span>
              <select value={form.language} onChange={(e) => set('language', e.target.value)}
                className="mt-1 w-full rounded-xl bg-kyn-steel border border-white/10 px-3 py-2.5 text-sm">
                <option>Français</option>
                <option>English</option>
                <option>العربية</option>
              </select>
            </label>
          </GlassCard>

          <GlassCard className="p-6 space-y-3">
            <p className="font-semibold flex items-center gap-2"><Settings2 size={16} className="text-kyn-green" /> Notification settings</p>
            {([
              ['notify_email', 'Email alerts', Mail],
              ['notify_push', 'Push notifications', Bell],
              ['notify_sms', 'SMS alerts', Phone],
            ] as const).map(([key, label, Icon]) => (
              <div key={key} className="flex items-center justify-between rounded-xl border border-white/8 bg-black/25 px-4 py-3">
                <div className="flex items-center gap-2 text-sm">
                  <Icon size={14} className="text-kyn-green" /> {label}
                </div>
                <button type="button" onClick={() => set(key, !form[key])}
                  className={cn('w-12 h-7 rounded-full relative transition-colors', form[key] ? 'bg-kyn-green' : 'bg-kyn-graphite')}>
                  <span className={cn('absolute top-0.5 w-6 h-6 rounded-full bg-white transition-all', form[key] ? 'left-5' : 'left-0.5')} />
                </button>
              </div>
            ))}
          </GlassCard>

          <button type="submit" disabled={saving}
            className="w-full rounded-full bg-kyn-green text-kyn-black font-bold text-sm py-3 disabled:opacity-60">
            {saving ? 'Saving…' : saved ? 'Saved ✓' : 'Save profile'}
          </button>
        </div>
      </form>
    </div>
  );
}

import { useEffect, useMemo, useState } from 'react';
import { Link, NavLink, Navigate, Route, Routes, useLocation, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  LayoutDashboard, Plug, History, Car, CreditCard, ShieldCheck, Wrench,
  Bell, Download, User, Menu, X, LogOut, Search, Sparkles, Map as MapIcon, Leaf
} from 'lucide-react';
import BrandLogo from '../../components/BrandLogo';
import LoadingState from '../../components/LoadingState';
import { apiGet, apiPost, cn } from '../../lib/utils';
import type { Charger, PortalData, Profile, Ticket } from './types';
import { DashboardView, ChargersView, HistoryView, VehiclesView } from './views-a';
import {
  SubscriptionView, WarrantyView, ServiceView, NotificationsView, DownloadsView, ProfileView,
} from './views-b';
import { MapView, EnergyView } from './views-extra';

const navItems = [
  { to: '/portal', end: true, label: 'Dashboard', icon: LayoutDashboard },
  { to: '/portal/chargers', label: 'My Chargers', icon: Plug },
  { to: '/portal/energy', label: 'Energy & CO₂', icon: Leaf },
  { to: '/portal/history', label: 'History', icon: History },
  { to: '/portal/map', label: 'Map', icon: MapIcon },
  { to: '/portal/vehicles', label: 'Vehicles', icon: Car },
  { to: '/portal/subscription', label: 'Payments', icon: CreditCard },
  { to: '/portal/warranty', label: 'Warranty', icon: ShieldCheck },
  { to: '/portal/service', label: 'Service', icon: Wrench },
  { to: '/portal/notifications', label: 'Notifications', icon: Bell },
  { to: '/portal/downloads', label: 'Downloads', icon: Download },
  { to: '/portal/profile', label: 'Account', icon: User },
];

export default function CustomerPortal() {
  const [data, setData] = useState<PortalData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [menuOpen, setMenuOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  const load = async () => {
    try {
      const [chargers, sessions, vehicles, billing, tickets, notifications, downloads, account] = await Promise.all([
        apiGet<PortalData['chargers']>('/api/portal-chargers'),
        apiGet<PortalData['sessions']>('/api/portal-sessions'),
        apiGet<PortalData['vehicles']>('/api/portal-vehicles'),
        apiGet<PortalData['billing']>('/api/portal-billing'),
        apiGet<PortalData['tickets']>('/api/portal-tickets'),
        apiGet<PortalData['notifications']>('/api/portal-notifications'),
        apiGet<PortalData['downloads']>('/api/portal-downloads'),
        apiGet<PortalData['account']>('/api/portal-account'),
      ]);
      setData({ chargers, sessions, vehicles, billing, tickets, notifications, downloads, account });
      setError('');
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : 'Failed to load portal');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { void load(); }, []);

  const unread = data?.notifications.filter((n) => !n.read).length || 0;
  const title = useMemo(() => {
    if (location.pathname === '/portal') return 'Dashboard';
    const item = navItems.find((n) => n.to !== '/portal' && location.pathname.startsWith(n.to));
    return item?.label || 'Portal';
  }, [location.pathname]);

  const chargerAction = async (id: number, action: string, extra?: Record<string, unknown>) => {
    const c = data?.chargers.find((x) => x.id === id);
    if (!c) return;
    const patch: Partial<Charger> & Record<string, unknown> = { last_activity: "À l'instant" };
    if (action === 'Restart') patch.status = 'available';
    if (action === 'Remote Lock') patch.status = 'locked';
    if (action === 'Firmware Update') patch.firmware = '2.4.2';
    if (action === 'Diagnostics') patch.status = c.online ? 'healthy' : 'offline';
    if (action === 'Start') {
      patch.status = 'charging';
      patch.power_kw = Number(extra?.kw ?? c.power_kw ?? 11) || 11;
      patch.online = true;
    }
    if (action === 'Stop') {
      patch.status = 'available';
      patch.power_kw = 0;
    }
    if (action === 'Schedule') {
      patch.status = 'scheduled';
    }
    if (action === 'PowerLimit') {
      const kw = Number(extra?.kw ?? 11);
      patch.power_kw = kw;
      if ((c.status || '').toLowerCase().includes('charg')) patch.status = 'charging';
    }
    await fetch('/api/portal-chargers', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id, ...patch }),
    });
    await load();
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-kyn-black flex items-center justify-center">
        <LoadingState label="Opening KYNETIK Account…" />
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="min-h-screen bg-kyn-black flex flex-col items-center justify-center gap-4 p-6">
        <p className="text-red-400 text-sm">{error || 'Error'}</p>
        <button type="button" onClick={() => { setLoading(true); void load(); }} className="px-4 py-2 rounded-full bg-kyn-green text-kyn-black text-xs font-bold">
          Retry
        </button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-kyn-black text-white flex">
      <aside className="hidden lg:flex w-72 flex-col border-r border-white/5 bg-kyn-void sticky top-0 h-screen">
        <div className="p-6 border-b border-white/5">
          <BrandLogo height={30} />
          <p className="mt-3 text-[10px] uppercase tracking-[0.25em] text-kyn-green">Customer Portal</p>
        </div>
        <nav className="flex-1 overflow-y-auto p-3 space-y-1">
          {navItems.map(({ to, label, icon: Icon, end }) => (
            <NavLink
              key={to}
              to={to}
              end={!!end}
              className={({ isActive }) =>
                cn(
                  'flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm transition-all',
                  isActive
                    ? 'bg-kyn-green/10 text-kyn-green border border-kyn-green/20'
                    : 'text-kyn-silver hover:bg-white/5 hover:text-white border border-transparent'
                )
              }
            >
              <Icon size={16} />
              <span className="flex-1">{label}</span>
              {label === 'Notifications' && unread > 0 && (
                <span className="text-[10px] min-w-5 h-5 px-1 rounded-full bg-kyn-green text-kyn-black font-bold flex items-center justify-center">
                  {unread}
                </span>
              )}
            </NavLink>
          ))}
        </nav>
        <div className="p-4 border-t border-white/5 space-y-2">
          <div className="rounded-xl border border-white/8 bg-white/[0.03] p-3">
            <p className="text-sm font-medium">{data.account.profile?.full_name}</p>
            <p className="text-[11px] text-kyn-metal truncate">{data.account.profile?.email}</p>
          </div>
          <Link to="/" className="flex items-center gap-2 text-xs text-kyn-metal hover:text-white px-2 py-2">
            <LogOut size={14} /> Back to site
          </Link>
        </div>
      </aside>

      <div className="flex-1 min-w-0 flex flex-col">
        <header className="sticky top-0 z-40 border-b border-white/5 bg-kyn-black/80 backdrop-blur-xl">
          <div className="h-16 px-4 md:px-8 flex items-center justify-between gap-3">
            <div className="flex items-center gap-3 min-w-0">
              <button type="button" className="lg:hidden p-2 text-kyn-silver" onClick={() => setMenuOpen(true)}>
                <Menu size={20} />
              </button>
              <div className="lg:hidden"><BrandLogo height={24} /></div>
              <div className="hidden md:block">
                <p className="text-[10px] uppercase tracking-[0.2em] text-kyn-metal">KYNETIK Account</p>
                <p className="text-sm font-semibold truncate">{title}</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <div className="hidden sm:flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.03] px-3 py-1.5 text-xs text-kyn-metal">
                <Search size={13} /> Search account
              </div>
              <button
                type="button"
                onClick={() => navigate('/portal/notifications')}
                className="relative p-2 rounded-xl border border-white/10 text-kyn-silver hover:text-white"
              >
                <Bell size={16} />
                {unread > 0 && <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 rounded-full bg-kyn-green" />}
              </button>
              <div className="w-8 h-8 rounded-full bg-kyn-green/15 border border-kyn-green/30 text-kyn-green text-xs font-bold flex items-center justify-center">
                {(data.account.profile?.full_name || 'K').split(' ').map((p) => p[0]).slice(0, 2).join('')}
              </div>
            </div>
          </div>
        </header>

        <AnimatePresence>
          {menuOpen && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="lg:hidden fixed inset-0 z-50 bg-black/70" onClick={() => setMenuOpen(false)}>
              <motion.div
                initial={{ x: -280 }} animate={{ x: 0 }} exit={{ x: -280 }}
                transition={{ type: 'spring', stiffness: 320, damping: 32 }}
                className="w-72 h-full bg-kyn-void border-r border-white/10 p-4 overflow-y-auto"
                onClick={(e) => e.stopPropagation()}
              >
                <div className="flex items-center justify-between mb-6">
                  <BrandLogo height={26} />
                  <button type="button" onClick={() => setMenuOpen(false)}><X size={18} /></button>
                </div>
                <div className="space-y-1">
                  {navItems.map(({ to, label, icon: Icon, end }) => (
                    <NavLink
                      key={to}
                      to={to}
                      end={!!end}
                      onClick={() => setMenuOpen(false)}
                      className={({ isActive }) =>
                        cn('flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm', isActive ? 'bg-kyn-green/10 text-kyn-green' : 'text-kyn-silver')
                      }
                    >
                      <Icon size={16} /> {label}
                    </NavLink>
                  ))}
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        <main className="flex-1 px-4 md:px-8 py-6 md:py-8 max-w-7xl w-full mx-auto">
          <AnimatePresence mode="wait">
            <motion.div
              key={location.pathname}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -6 }}
              transition={{ duration: 0.25 }}
            >
              <Routes>
                <Route index element={<DashboardView data={data} onRefresh={() => { void load(); }} />} />
                <Route path="chargers" element={<ChargersView chargers={data.chargers} onAction={(id, action, extra) => { void chargerAction(id, action, extra); }} />} />
                <Route path="energy" element={<EnergyView sessions={data.sessions} chargers={data.chargers} />} />
                <Route path="map" element={<MapView />} />
                <Route path="history" element={<HistoryView sessions={data.sessions} />} />
                <Route path="vehicles" element={<VehiclesView vehicles={data.vehicles} />} />
                <Route
                  path="subscription"
                  element={
                    <SubscriptionView
                      subscription={data.billing.subscription}
                      invoices={data.billing.invoices}
                      onUpgrade={() => {
                        void (async () => {
                          if (!data.billing.subscription) return;
                          await fetch('/api/portal-billing', {
                            method: 'PUT',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({
                              table: 'portal_subscriptions',
                              id: data.billing.subscription.id,
                              plan_name: 'KYNETIK Cloud Enterprise',
                              price_dt: 129,
                            }),
                          });
                          await load();
                        })();
                      }}
                    />
                  }
                />
                <Route path="warranty" element={<WarrantyView warranties={data.account.warranties} />} />
                <Route
                  path="service"
                  element={
                    <ServiceView
                      tickets={data.tickets}
                      chargers={data.chargers}
                      onCreate={async (payload: Partial<Ticket>) => {
                        await apiPost('/api/portal-tickets', payload);
                        await load();
                      }}
                    />
                  }
                />
                <Route
                  path="notifications"
                  element={
                    <NotificationsView
                      notifications={data.notifications}
                      onRead={(id) => {
                        void (async () => {
                          await fetch('/api/portal-notifications', {
                            method: 'PUT',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ id, read: true }),
                          });
                          await load();
                        })();
                      }}
                    />
                  }
                />
                <Route path="downloads" element={<DownloadsView downloads={data.downloads} />} />
                <Route
                  path="profile"
                  element={
                    <ProfileView
                      profile={data.account.profile}
                      onSave={async (p: Profile) => {
                        await fetch('/api/portal-account', {
                          method: 'PUT',
                          headers: { 'Content-Type': 'application/json' },
                          body: JSON.stringify({ table: 'portal_profiles', ...p }),
                        });
                        await load();
                      }}
                    />
                  }
                />
                <Route path="*" element={<Navigate to="/portal" replace />} />
              </Routes>
            </motion.div>
          </AnimatePresence>
        </main>

        <footer className="border-t border-white/5 px-4 md:px-8 py-4 text-[11px] text-kyn-metal flex flex-wrap justify-between gap-2">
          <span className="inline-flex items-center gap-1"><Sparkles size={11} className="text-kyn-green" /> KYNETIK Account · Premium Customer Portal</span>
          <span>Inspired by Tesla · Apple · Stripe</span>
        </footer>
      </div>
    </div>
  );
}

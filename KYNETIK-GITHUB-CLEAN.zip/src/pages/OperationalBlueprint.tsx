import { useEffect, useMemo, useState, type ComponentType, type ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  ArrowRight, Building2, ClipboardList, Wrench, ShieldCheck, Package,
  BadgeCheck, HardHat, BarChart3, AlertTriangle, Map, LifeBuoy, FileText,
  Menu, X, CheckCircle2, Users, Briefcase, Cpu, Megaphone, GitBranch,
  Settings, Truck, Phone, Cloud, Smartphone, Database, Lock, Rocket,
  ChevronRight, Gauge, Boxes, BookOpen, Target
} from 'lucide-react';
import BrandLogo from '../components/BrandLogo';
import LoadingState from '../components/LoadingState';
import { apiGet, cn } from '../lib/utils';

interface Item {
  id: number;
  type: string;
  category: string;
  title: string;
  subtitle: string;
  body: string;
  meta: string | null;
  sort_order: number;
}

const TOC = [
  { id: 'org', label: 'Organisation' },
  { id: 'sop-sales', label: 'SOP Commercial' },
  { id: 'sop-install', label: 'SOP Installation' },
  { id: 'sop-maint', label: 'SOP Maintenance' },
  { id: 'warranty', label: 'Garantie' },
  { id: 'spare', label: 'Pièces' },
  { id: 'qc', label: 'Quality Control' },
  { id: 'hse', label: 'HSE' },
  { id: 'kpis', label: 'KPIs Ops' },
  { id: 'risks', label: 'Risques' },
  { id: 'deploy', label: 'Déploiement' },
  { id: 'support', label: 'Support L1–L3' },
  { id: 'docs', label: 'Documentation' },
];

function Fade({ children, className, delay = 0 }: { children: ReactNode; className?: string; delay?: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-40px' }}
      transition={{ duration: 0.5, delay }}
      className={className}
    >
      {children}
    </motion.div>
  );
}

function Section({
  id, kicker, title, children, icon: Icon,
}: {
  id: string; kicker: string; title: string; children: ReactNode;
  icon: ComponentType<{ size?: number; className?: string }>;
}) {
  return (
    <section id={id} className="scroll-mt-28 py-16 md:py-20 border-t border-white/[0.06]">
      <div className="max-w-7xl mx-auto px-5 md:px-8">
        <div className="flex items-start gap-4 mb-8">
          <div className="w-11 h-11 rounded-xl bg-kyn-green/10 border border-kyn-green/25 flex items-center justify-center text-kyn-green shrink-0">
            <Icon size={20} />
          </div>
          <div>
            <p className="text-[11px] uppercase tracking-[0.28em] text-kyn-green font-semibold mb-1">{kicker}</p>
            <h2 className="font-display text-2xl md:text-3xl font-bold">{title}</h2>
          </div>
        </div>
        {children}
      </div>
    </section>
  );
}

const orgIcons: Record<string, ComponentType<{ size?: number; className?: string }>> = {
  DG: Building2,
  COM: Briefcase,
  TECH: Wrench,
  DIG: Cpu,
  MKT: Megaphone,
};

export default function OperationalBlueprint() {
  const [items, setItems] = useState<Item[]>([]);
  const [loading, setLoading] = useState(true);
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    apiGet<Item[]>('/api/marketing-content?type=ops_blueprint')
      .then((d) => setItems((d || []).sort((a, b) => a.sort_order - b.sort_order)))
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const by = (cat: string) => items.filter((i) => i.category === cat);

  const org = by('org');
  const sopSales = by('sop_sales');
  const sopInstall = by('sop_install');
  const sopMaint = by('sop_maint');
  const warranty = by('warranty');
  const spare = by('spare');
  const qc = by('qc');
  const hse = by('hse');
  const kpis = by('kpi');
  const risks = by('risk');
  const deploy = by('deploy');
  const support = by('support_lvl');
  const docs = by('docs');

  const installPre = sopInstall.filter((i) => i.meta === 'PRE');
  const installDur = sopInstall.filter((i) => i.meta === 'DUR');
  const installPost = sopInstall.filter((i) => i.meta === 'POST');
  const maintPrev = sopMaint.filter((i) => i.meta === 'PREV');
  const maintCorr = sopMaint.filter((i) => i.meta === 'CORR');
  const hsePre = hse.filter((i) => i.meta === 'PRE');
  const hseDoc = hse.filter((i) => i.meta === 'DOC');

  const riskTech = risks.filter((i) => i.meta === 'TECH');
  const riskCom = risks.filter((i) => i.meta === 'COM');
  const riskSec = risks.filter((i) => i.meta === 'SEC');

  if (loading) {
    return (
      <div className="min-h-screen bg-kyn-black flex items-center justify-center">
        <LoadingState label="Loading operational blueprint…" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-kyn-black text-white">
      <header
        className={cn(
          'fixed top-0 inset-x-0 z-50 transition-all',
          scrolled ? 'bg-kyn-black/90 backdrop-blur-xl border-b border-white/5' : 'bg-transparent'
        )}
      >
        <div className="max-w-7xl mx-auto px-5 md:px-8 h-16 flex items-center justify-between gap-4">
          <Link to="/" className="flex items-center gap-3">
            <BrandLogo height={28} />
            <span className="hidden sm:inline text-[10px] font-semibold tracking-[0.2em] uppercase text-amber-300 border border-amber-400/30 rounded-full px-2 py-0.5">
              Phase 24 · Ops Blueprint
            </span>
          </Link>
          <nav className="hidden xl:flex items-center gap-4 text-[11px] font-medium text-kyn-silver">
            {TOC.slice(0, 6).map((t) => (
              <a key={t.id} href={`#${t.id}`} className="hover:text-white">{t.label}</a>
            ))}
          </nav>
          <div className="flex items-center gap-2">
            <Link
              to="/sales"
              className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border border-white/12 text-xs font-semibold hover:border-kyn-green/40"
            >
              Sales
            </Link>
            <Link
              to="/quote"
              className="hidden md:inline-flex items-center gap-1.5 px-4 py-2 rounded-full bg-kyn-green text-kyn-black text-xs font-bold"
            >
              Devis <ArrowRight size={13} />
            </Link>
            <button type="button" className="xl:hidden p-2 text-kyn-silver" onClick={() => setMenuOpen(!menuOpen)} aria-label="Menu">
              {menuOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </div>
        {menuOpen && (
          <div className="xl:hidden border-t border-white/5 bg-kyn-void/98 px-5 py-4 grid grid-cols-2 gap-2 max-h-[70vh] overflow-y-auto">
            {TOC.map((t) => (
              <a key={t.id} href={`#${t.id}`} onClick={() => setMenuOpen(false)} className="text-sm text-kyn-silver py-2">
                {t.label}
              </a>
            ))}
          </div>
        )}
      </header>

      {/* Hero */}
      <section className="relative pt-28 md:pt-36 pb-16 overflow-hidden">
        <div className="absolute inset-0 grid-bg opacity-30" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(251,191,36,0.12),transparent_55%)]" />
        <div className="relative z-10 max-w-7xl mx-auto px-5 md:px-8">
          <Fade>
            <p className="text-amber-300 text-xs font-semibold tracking-[0.3em] uppercase mb-4">
              Technical & Operational Blueprint
            </p>
            <h1 className="font-display text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold max-w-4xl leading-[1.05]">
              KYNETIK
              <br />
              <span className="text-amber-300">Operational Ready.</span>
            </h1>
            <p className="mt-6 text-lg text-kyn-silver max-w-2xl leading-relaxed">
              Organisation, SOPs, qualité, HSE, stock, support L1–L3 et KPIs — le référentiel
              d&apos;exploitation pour investisseurs, banques et équipes terrain.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <a href="#sop-install" className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-kyn-green text-kyn-black text-sm font-bold">
                Voir les SOPs <ArrowRight size={16} />
              </a>
              <Link to="/installer" className="inline-flex items-center gap-2 px-6 py-3 rounded-full border border-white/15 text-sm font-semibold">
                Installer Dashboard
              </Link>
              <Link to="/console" className="inline-flex items-center gap-2 px-6 py-3 rounded-full border border-white/15 text-sm font-semibold">
                Cloud Console
              </Link>
            </div>
          </Fade>

          <div className="mt-12 grid grid-cols-2 md:grid-cols-4 gap-3">
            {[
              { t: 'SOPs', d: 'Vente · Install · Maintenance', icon: ClipboardList },
              { t: 'QC', d: '0 livraison sans validation', icon: BadgeCheck },
              { t: 'HSE', d: 'EPI · VAT · normes', icon: HardHat },
              { t: 'SLA', d: 'Support L1 → L3', icon: LifeBuoy },
            ].map(({ t, d, icon: Icon }, i) => (
              <Fade key={t} delay={i * 0.05}>
                <div className="rounded-2xl border border-white/10 bg-kyn-void/80 p-5 h-full">
                  <Icon className="text-amber-300 mb-3" size={18} />
                  <p className="font-display font-bold">{t}</p>
                  <p className="text-xs text-kyn-metal mt-1">{d}</p>
                </div>
              </Fade>
            ))}
          </div>
        </div>
      </section>

      {/* 1 Organisation */}
      <Section id="org" kicker="01 · Organisation" title="Structure de l'entreprise" icon={Building2}>
        <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-4">
          {org.map((o, i) => {
            const Icon = orgIcons[o.meta || ''] || Users;
            return (
              <Fade key={o.id} delay={i * 0.04}>
                <div className="rounded-2xl border border-white/10 bg-gradient-to-b from-white/[0.04] to-transparent p-5 h-full">
                  <div className="w-10 h-10 rounded-xl bg-amber-400/10 border border-amber-400/25 flex items-center justify-center text-amber-300 mb-4">
                    <Icon size={18} />
                  </div>
                  <p className="text-[10px] uppercase tracking-wider text-kyn-metal mb-1">{o.meta}</p>
                  <h3 className="font-display font-semibold text-sm leading-snug">{o.title}</h3>
                  <p className="text-xs text-kyn-metal mt-3 leading-relaxed">{o.body}</p>
                </div>
              </Fade>
            );
          })}
        </div>
      </Section>

      {/* 2 SOP Commercial */}
      <Section id="sop-sales" kicker="02 · SOP Commercial" title="Processus commercial standard" icon={GitBranch}>
        <div className="relative">
          <div className="hidden md:block absolute top-8 left-8 right-8 h-px bg-gradient-to-r from-kyn-green/40 via-white/10 to-kyn-green/40" />
          <div className="grid sm:grid-cols-3 lg:grid-cols-5 xl:grid-cols-9 gap-3">
            {sopSales.map((s, i) => (
              <Fade key={s.id} delay={i * 0.03}>
                <div className="relative rounded-2xl border border-white/10 bg-kyn-void p-4 text-center h-full">
                  <div className="w-8 h-8 mx-auto rounded-full bg-kyn-green text-kyn-black text-xs font-bold flex items-center justify-center mb-3 relative z-10">
                    {s.meta || i + 1}
                  </div>
                  <p className="text-xs font-semibold leading-snug">{s.title}</p>
                  <p className="text-[10px] text-kyn-metal mt-2 leading-relaxed">{s.body}</p>
                </div>
              </Fade>
            ))}
          </div>
        </div>
        <div className="mt-8 flex flex-wrap gap-3">
          <Link to="/quote" className="inline-flex items-center gap-2 text-sm text-kyn-green font-semibold">
            Ouvrir le parcours devis <ChevronRight size={16} />
          </Link>
          <Link to="/sales" className="inline-flex items-center gap-2 text-sm text-kyn-silver hover:text-white">
            Sales System
          </Link>
        </div>
      </Section>

      {/* 3 SOP Installation */}
      <Section id="sop-install" kicker="03 · SOP Installation" title="Avant · Pendant · Après" icon={Wrench}>
        <div className="grid lg:grid-cols-3 gap-5">
          {[
            { title: 'Avant', items: installPre, color: 'border-sky-400/30 bg-sky-400/5' },
            { title: 'Pendant', items: installDur, color: 'border-kyn-green/30 bg-kyn-green/5' },
            { title: 'Après', items: installPost, color: 'border-amber-400/30 bg-amber-400/5' },
          ].map((col) => (
            <div key={col.title} className={cn('rounded-3xl border p-6', col.color)}>
              <h3 className="font-display text-xl font-bold mb-5">{col.title}</h3>
              <ul className="space-y-4">
                {col.items.map((it) => (
                  <li key={it.id} className="flex gap-3">
                    <CheckCircle2 size={16} className="text-kyn-green shrink-0 mt-0.5" />
                    <div>
                      <p className="text-sm font-semibold">{it.title.replace(/^Avant — |^Pendant — |^Après — /, '')}</p>
                      <p className="text-xs text-kyn-metal mt-1">{it.body}</p>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        <div className="mt-6">
          <Link to="/installation-details" className="inline-flex items-center gap-2 text-sm text-kyn-green font-semibold">
            Voir le module Installation Details <ArrowRight size={14} />
          </Link>
        </div>
      </Section>

      {/* 4 SOP Maintenance */}
      <Section id="sop-maint" kicker="04 · SOP Maintenance" title="Préventive & corrective" icon={Settings}>
        <div className="grid md:grid-cols-2 gap-5">
          <div className="rounded-3xl border border-white/10 bg-kyn-void p-6 md:p-8">
            <p className="text-kyn-green text-xs font-semibold tracking-wider uppercase mb-2">Préventive</p>
            <h3 className="font-display text-2xl font-bold mb-6">Garder le réseau sain</h3>
            <ul className="space-y-4">
              {maintPrev.map((m) => (
                <li key={m.id} className="flex gap-3 border-b border-white/5 pb-4 last:border-0">
                  <Gauge size={16} className="text-kyn-green shrink-0 mt-0.5" />
                  <div>
                    <p className="text-sm font-semibold">{m.title.replace('Préventive — ', '')}</p>
                    <p className="text-xs text-kyn-metal mt-1">{m.body}</p>
                  </div>
                </li>
              ))}
            </ul>
          </div>
          <div className="rounded-3xl border border-white/10 bg-kyn-void p-6 md:p-8">
            <p className="text-amber-300 text-xs font-semibold tracking-wider uppercase mb-2">Corrective</p>
            <h3 className="font-display text-2xl font-bold mb-6">Résoudre vite, tracer tout</h3>
            <ul className="space-y-4">
              {maintCorr.map((m) => (
                <li key={m.id} className="flex gap-3 border-b border-white/5 pb-4 last:border-0">
                  <Wrench size={16} className="text-amber-300 shrink-0 mt-0.5" />
                  <div>
                    <p className="text-sm font-semibold">{m.title.replace('Corrective — ', '')}</p>
                    <p className="text-xs text-kyn-metal mt-1">{m.body}</p>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        </div>
        <div className="mt-6 flex flex-wrap gap-4">
          <Link to="/maintenance" className="text-sm text-kyn-green font-semibold inline-flex items-center gap-1">
            Maintenance ops <ChevronRight size={14} />
          </Link>
          <Link to="/predictive-maintenance" className="text-sm text-kyn-silver hover:text-white inline-flex items-center gap-1">
            Predictive AI <ChevronRight size={14} />
          </Link>
        </div>
      </Section>

      {/* 5 Warranty */}
      <Section id="warranty" kicker="05 · Warranty Management" title="Gestion de la garantie" icon={ShieldCheck}>
        <div className="grid lg:grid-cols-2 gap-6">
          <div className="rounded-3xl border border-white/10 bg-kyn-void p-6 md:p-8">
            {warranty.filter((w) => w.meta === 'STD').map((w) => (
              <div key={w.id}>
                <h3 className="font-display text-xl font-bold">{w.title}</h3>
                <p className="mt-3 text-kyn-silver leading-relaxed">{w.body}</p>
              </div>
            ))}
            <ul className="mt-6 space-y-2 text-sm text-kyn-metal">
              {['Produits', 'Pièces', "Main-d'œuvre (selon contrat)"].map((x) => (
                <li key={x} className="flex items-center gap-2">
                  <CheckCircle2 size={14} className="text-kyn-green" /> {x}
                </li>
              ))}
            </ul>
          </div>
          <div className="rounded-3xl border border-kyn-green/25 bg-kyn-green/5 p-6 md:p-8">
            <p className="text-kyn-green text-xs font-semibold tracking-wider uppercase mb-4">Workflow</p>
            <div className="flex flex-wrap gap-2">
              {['Client', 'Ticket', 'Diagnostic', 'Validation', 'Intervention', 'Clôture'].map((step, i) => (
                <div key={step} className="flex items-center gap-2">
                  <span className="px-3 py-2 rounded-xl bg-kyn-black/50 border border-white/10 text-xs font-semibold">
                    {step}
                  </span>
                  {i < 5 && <ChevronRight size={14} className="text-kyn-metal" />}
                </div>
              ))}
            </div>
            <p className="mt-6 text-sm text-kyn-silver">
              {warranty.find((w) => w.meta === 'FLOW')?.body}
            </p>
            <Link to="/support" className="mt-6 inline-flex items-center gap-2 text-sm font-semibold text-kyn-green">
              Ouvrir un ticket <ArrowRight size={14} />
            </Link>
          </div>
        </div>
      </Section>

      {/* 6 Spare parts */}
      <Section id="spare" kicker="06 · Spare Parts" title="Gestion des pièces de rechange" icon={Boxes}>
        <p className="text-kyn-silver text-sm max-w-2xl mb-8">
          Chaque pièce : référence · quantité minimale · quantité disponible · délai de réapprovisionnement.
        </p>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {spare.map((s, i) => (
            <Fade key={s.id} delay={i * 0.04}>
              <div className="rounded-2xl border border-white/10 bg-kyn-void p-5 flex gap-4">
                <div className="w-12 h-12 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-[10px] font-bold text-amber-300 shrink-0">
                  {s.meta}
                </div>
                <div>
                  <p className="font-semibold text-sm">{s.title}</p>
                  <p className="text-xs text-kyn-metal mt-1">{s.body}</p>
                  <div className="mt-3 flex gap-2 text-[10px] text-kyn-metal">
                    <span className="px-2 py-0.5 rounded bg-white/5 border border-white/8">Min stock</span>
                    <span className="px-2 py-0.5 rounded bg-white/5 border border-white/8">Lead time</span>
                  </div>
                </div>
              </div>
            </Fade>
          ))}
        </div>
      </Section>

      {/* 7 QC */}
      <Section id="qc" kicker="07 · Quality Control" title="Contrôle avant livraison" icon={BadgeCheck}>
        <div className="rounded-3xl border border-white/10 bg-gradient-to-br from-kyn-green/10 via-kyn-void to-kyn-black p-6 md:p-10">
          <p className="text-kyn-green font-semibold text-sm mb-6">Objectif : 0 produit livré sans validation QC.</p>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {qc.map((q, i) => (
              <div key={q.id} className="rounded-2xl border border-white/10 bg-black/40 p-5">
                <div className="flex items-center gap-3 mb-3">
                  <span className="w-7 h-7 rounded-full bg-kyn-green text-kyn-black text-xs font-bold flex items-center justify-center">
                    {q.meta || i + 1}
                  </span>
                  <h3 className="font-semibold text-sm">{q.title}</h3>
                </div>
                <p className="text-xs text-kyn-metal leading-relaxed">{q.body}</p>
              </div>
            ))}
          </div>
        </div>
      </Section>

      {/* 8 HSE */}
      <Section id="hse" kicker="08 · HSE" title="Health, Safety & Environment" icon={HardHat}>
        <div className="grid md:grid-cols-2 gap-5">
          <div className="rounded-3xl border border-white/10 bg-kyn-void p-6">
            <h3 className="font-display font-bold text-lg mb-5">Avant chaque intervention</h3>
            <ul className="space-y-3">
              {hsePre.map((h) => (
                <li key={h.id} className="flex gap-3 text-sm">
                  <HardHat size={16} className="text-amber-300 shrink-0 mt-0.5" />
                  <div>
                    <p className="font-semibold">{h.title}</p>
                    <p className="text-xs text-kyn-metal mt-0.5">{h.body}</p>
                  </div>
                </li>
              ))}
            </ul>
          </div>
          <div className="rounded-3xl border border-white/10 bg-kyn-void p-6">
            <h3 className="font-display font-bold text-lg mb-5">Documentation</h3>
            <ul className="space-y-3">
              {hseDoc.map((h) => (
                <li key={h.id} className="flex gap-3 text-sm">
                  <FileText size={16} className="text-kyn-green shrink-0 mt-0.5" />
                  <div>
                    <p className="font-semibold">{h.title}</p>
                    <p className="text-xs text-kyn-metal mt-0.5">{h.body}</p>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </Section>

      {/* 9 KPIs */}
      <Section id="kpis" kicker="09 · Operational KPIs" title="Suivi mensuel obligatoire" icon={BarChart3}>
        <div className="overflow-x-auto rounded-2xl border border-white/10">
          <table className="w-full text-left text-sm min-w-[640px]">
            <thead>
              <tr className="border-b border-white/10 bg-white/[0.03] text-[11px] uppercase tracking-wider text-kyn-metal">
                <th className="px-5 py-3 font-semibold">Domaine</th>
                <th className="px-5 py-3 font-semibold">KPI</th>
                <th className="px-5 py-3 font-semibold">Détail</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {kpis.map((k) => (
                <tr key={k.id} className="hover:bg-white/[0.02]">
                  <td className="px-5 py-3.5">
                    <span className="text-xs font-semibold text-amber-300">{k.meta}</span>
                  </td>
                  <td className="px-5 py-3.5 font-semibold text-white">{k.title}</td>
                  <td className="px-5 py-3.5 text-kyn-metal text-xs">{k.body}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="mt-4 text-xs text-kyn-metal">Cloud availability target: &gt; 99,5%</p>
      </Section>

      {/* 10 Risks */}
      <Section id="risks" kicker="10 · Risk Management" title="Gestion des risques" icon={AlertTriangle}>
        <div className="grid md:grid-cols-3 gap-5">
          {[
            { title: 'Techniques', items: riskTech, tone: 'border-red-500/20' },
            { title: 'Commerciaux', items: riskCom, tone: 'border-amber-400/20' },
            { title: 'Cybersécurité', items: riskSec, tone: 'border-sky-400/20' },
          ].map((col) => (
            <div key={col.title} className={cn('rounded-3xl border bg-kyn-void p-6', col.tone)}>
              <h3 className="font-display font-bold mb-5">{col.title}</h3>
              <ul className="space-y-4">
                {col.items.map((r) => (
                  <li key={r.id}>
                    <p className="text-sm font-semibold flex items-center gap-2">
                      <AlertTriangle size={14} className="text-amber-300" /> {r.title}
                    </p>
                    <p className="text-xs text-kyn-metal mt-1.5 pl-6">{r.body}</p>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        <div className="mt-6 flex flex-wrap gap-2 text-xs text-kyn-metal">
          {['MFA', 'Backups', 'RBAC', 'Audit logs', 'Canary OTA'].map((t) => (
            <span key={t} className="px-3 py-1.5 rounded-full border border-white/10 bg-white/[0.03] flex items-center gap-1.5">
              <Lock size={12} className="text-kyn-green" /> {t}
            </span>
          ))}
        </div>
      </Section>

      {/* 11 Deploy roadmap */}
      <Section id="deploy" kicker="11 · Roadmap déploiement" title="De Grand Tunis à l'Afrique du Nord" icon={Map}>
        <div className="relative">
          <div className="hidden lg:block absolute top-1/2 left-0 right-0 h-0.5 bg-gradient-to-r from-kyn-green via-amber-300/50 to-sky-400 -translate-y-1/2" />
          <div className="grid sm:grid-cols-2 lg:grid-cols-6 gap-4">
            {deploy.map((d, i) => (
              <Fade key={d.id} delay={i * 0.05}>
                <div className="relative rounded-2xl border border-white/10 bg-kyn-black p-5 text-center">
                  <div className="w-10 h-10 mx-auto rounded-full bg-kyn-green text-kyn-black font-bold text-sm flex items-center justify-center mb-3 relative z-10 shadow-[0_0_20px_rgba(0,230,118,0.3)]">
                    {d.meta}
                  </div>
                  <p className="font-display font-semibold text-sm">{d.title.replace(/^Phase \d+ — /, '')}</p>
                  <p className="text-[11px] text-kyn-metal mt-2">{d.body}</p>
                </div>
              </Fade>
            ))}
          </div>
        </div>
      </Section>

      {/* 12 Support */}
      <Section id="support" kicker="12 · Support Center" title="Organisation L1 · L2 · L3" icon={LifeBuoy}>
        <div className="grid md:grid-cols-3 gap-4">
          {support.map((s, i) => (
            <Fade key={s.id} delay={i * 0.06}>
              <div className="rounded-3xl border border-white/10 bg-kyn-void p-6 h-full relative overflow-hidden">
                <div className="absolute top-0 right-0 text-[80px] font-display font-bold text-white/[0.03] leading-none pr-2">
                  {s.meta}
                </div>
                <p className="text-kyn-green text-xs font-bold tracking-wider mb-2">{s.meta}</p>
                <h3 className="font-display text-xl font-bold relative z-10">{s.title}</h3>
                <p className="mt-3 text-sm text-kyn-metal relative z-10">{s.body}</p>
              </div>
            </Fade>
          ))}
        </div>
        <p className="mt-6 text-sm text-kyn-silver">
          Objectif : réponse rapide · résolution efficace · suivi complet des incidents.
        </p>
        <div className="mt-4 flex flex-wrap gap-3">
          <Link to="/support" className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-kyn-green text-kyn-black text-xs font-bold">
            Support Center <ArrowRight size={14} />
          </Link>
          <Link to="/portal" className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full border border-white/15 text-xs font-semibold">
            Portail client
          </Link>
        </div>
      </Section>

      {/* 13 Docs */}
      <Section id="docs" kicker="13 · Documentation technique" title="Pack documentaire par produit" icon={BookOpen}>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {docs.map((d, i) => (
            <Fade key={d.id} delay={i * 0.04}>
              <div className="rounded-2xl border border-white/10 bg-kyn-void p-5 flex items-start gap-4 hover:border-kyn-green/30 transition-colors">
                <div className="w-10 h-10 rounded-xl bg-kyn-green/10 border border-kyn-green/20 flex items-center justify-center text-kyn-green shrink-0">
                  <FileText size={18} />
                </div>
                <div>
                  <p className="font-semibold text-sm">{d.title}</p>
                  <p className="text-xs text-kyn-metal mt-1">{d.body}</p>
                </div>
              </div>
            </Fade>
          ))}
        </div>
        <div className="mt-6">
          <Link to="/resources" className="inline-flex items-center gap-2 text-sm text-kyn-green font-semibold">
            Resource center <ArrowRight size={14} />
          </Link>
        </div>
      </Section>

      {/* Bilan stack */}
      <section className="py-16 border-t border-white/5">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <Fade>
            <p className="text-kyn-green text-xs font-semibold tracking-[0.3em] uppercase mb-4">Bilan</p>
            <h2 className="font-display text-3xl md:text-4xl font-bold max-w-2xl">
              Base complète — design, produit, go-to-market et ops.
            </h2>
          </Fade>
          <div className="mt-10 grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {[
              { t: 'Design System', to: '/design-system', icon: BadgeCheck },
              { t: 'Mobile App', to: '/kynetik-app', icon: Smartphone },
              { t: 'Cloud Platform', to: '/console', icon: Cloud },
              { t: 'Site Web', to: '/', icon: Rocket },
              { t: 'Marketing', to: '/brand-launch', icon: Megaphone },
              { t: 'Commercial', to: '/sales', icon: Target },
              { t: 'Ops Blueprint', to: '/ops', icon: ClipboardList },
              { t: 'Resources', to: '/resources', icon: FileText },
            ].map(({ t, to, icon: Icon }) => (
              <Link
                key={t}
                to={to}
                className="group rounded-2xl border border-white/10 bg-kyn-void p-5 hover:border-kyn-green/35 transition-colors flex items-center gap-3"
              >
                <Icon size={18} className="text-kyn-green shrink-0" />
                <span className="text-sm font-semibold group-hover:text-kyn-green transition-colors">{t}</span>
                <CheckCircle2 size={14} className="text-kyn-green/50 ml-auto" />
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Phase 25 */}
      <section className="py-20 border-t border-white/5 relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(0,230,118,0.1),transparent_55%)]" />
        <div className="relative z-10 max-w-3xl mx-auto px-5 text-center">
          <Database className="mx-auto text-kyn-green mb-6" size={28} />
          <h2 className="font-display text-3xl md:text-5xl font-bold">
            Next: Enterprise Architecture
          </h2>
          <p className="mt-4 text-kyn-silver">
            Phase 25 — Cloud stack, OCPP, IoT, IA, DevOps, sécurité et scalabilité pour des milliers de bornes.
          </p>
          <div className="mt-8 flex flex-wrap justify-center gap-3">
            <Link to="/architecture" className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-kyn-green text-kyn-black text-sm font-bold">
              Master Documentation <ArrowRight size={16} />
            </Link>
            <Link to="/delivery" className="inline-flex items-center gap-2 px-6 py-3 rounded-full border border-white/15 text-sm font-semibold">
              Delivery Architecture
            </Link>
          </div>
        </div>
      </section>

      <footer className="border-t border-white/5 py-8">
        <div className="max-w-7xl mx-auto px-5 md:px-8 flex flex-wrap justify-between gap-4 items-center">
          <BrandLogo height={26} />
          <p className="text-[11px] text-kyn-metal">Phase 24 · Technical & Operational Blueprint</p>
          <div className="flex gap-3 text-[11px] text-kyn-metal">
            <Link to="/sales" className="hover:text-white">Sales</Link>
            <Link to="/installer" className="hover:text-white">Installer</Link>
            <Link to="/console" className="hover:text-white">Cloud</Link>
          </div>
        </div>
      </footer>
    </div>
  );
}

import { useCallback, useEffect, useMemo, useRef, useState, type ChangeEvent, type ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  ArrowLeft, ArrowRight, Camera, Check, CheckCircle2, ClipboardList,
  ImagePlus, Loader2, MapPin, Navigation, Package, PenLine, Phone,
  Trash2, User, Building2, Mail, Home, Zap, AlertCircle, X
} from 'lucide-react';
import BrandLogo from '../components/BrandLogo';
import LoadingState from '../components/LoadingState';
import { cn } from '../lib/utils';

interface Product {
  id: number;
  name: string;
  power: string;
  image_url: string;
  category?: string;
  tagline?: string;
}

interface Accessory {
  id: string;
  label: string;
  qty: number;
  selected: boolean;
}

interface ChecklistItem {
  id: string;
  label: string;
  done: boolean;
}

interface PhotoItem {
  id: string;
  name: string;
  dataUrl: string;
}

const DEFAULT_ACCESSORIES: Accessory[] = [
  { id: 'cable-type2', label: 'Câble Type 2 (5 m)', qty: 1, selected: true },
  { id: 'breaker', label: 'Disjoncteur différentiel type A/B', qty: 1, selected: true },
  { id: 'mount-kit', label: 'Kit de fixation murale', qty: 1, selected: true },
  { id: 'conduit', label: 'Goulotte / conduit protection', qty: 1, selected: false },
  { id: 'rfid', label: 'Badge RFID supplémentaire (x2)', qty: 2, selected: false },
  { id: 'pedestal', label: 'Socle / pied de montage', qty: 1, selected: false },
  { id: 'sim', label: 'Carte SIM 4G KYNETIK', qty: 1, selected: true },
  { id: 'label', label: 'Plaque identification & QR', qty: 1, selected: true },
];

const DEFAULT_CHECKLIST: ChecklistItem[] = [
  { id: 'site-survey', label: 'Visite technique / validation emplacement', done: false },
  { id: 'power-check', label: 'Vérification alimentation électrique', done: false },
  { id: 'earth', label: 'Contrôle de la terre / impédance', done: false },
  { id: 'mount', label: 'Fixation mécanique de la borne', done: false },
  { id: 'wiring', label: 'Câblage puissance & protections', done: false },
  { id: 'network', label: 'Connexion WiFi / 4G / Ethernet', done: false },
  { id: 'ocpp', label: 'Enregistrement OCPP sur KYNETIK Cloud', done: false },
  { id: 'test-session', label: 'Session de charge de test réussie', done: false },
  { id: 'safety', label: 'Contrôles sécurité & étiquetage', done: false },
  { id: 'handover', label: 'Formation client & remise documentation', done: false },
];

function SectionCard({
  id,
  step,
  title,
  subtitle,
  icon: Icon,
  children,
  accent = false,
}: {
  id?: string;
  step: string;
  title: string;
  subtitle?: string;
  icon: typeof User;
  children: ReactNode;
  accent?: boolean;
}) {
  return (
    <motion.section
      id={id}
      initial={{ opacity: 0, y: 16 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-40px' }}
      className={cn(
        'rounded-2xl border p-5 md:p-7',
        accent
          ? 'border-kyn-green/30 bg-gradient-to-b from-kyn-green/10 to-kyn-void'
          : 'border-white/8 bg-kyn-void/80'
      )}
    >
      <div className="flex items-start gap-3 mb-5">
        <div className="w-10 h-10 rounded-xl bg-kyn-green/10 border border-kyn-green/25 flex items-center justify-center text-kyn-green shrink-0">
          <Icon size={18} />
        </div>
        <div className="min-w-0">
          <p className="text-[10px] uppercase tracking-[0.22em] text-kyn-green font-semibold">{step}</p>
          <h2 className="font-display text-lg md:text-xl font-bold mt-0.5">{title}</h2>
          {subtitle && <p className="text-sm text-kyn-metal mt-1">{subtitle}</p>}
        </div>
      </div>
      {children}
    </motion.section>
  );
}

function Field({
  label,
  children,
  className,
}: {
  label: string;
  children: ReactNode;
  className?: string;
}) {
  return (
    <label className={cn('block', className)}>
      <span className="text-[11px] uppercase tracking-wider text-kyn-metal font-medium">{label}</span>
      <div className="mt-1.5">{children}</div>
    </label>
  );
}

const inputClass =
  'w-full rounded-xl bg-black/40 border border-white/10 px-3.5 py-2.5 text-sm text-white placeholder:text-kyn-metal/70 focus:outline-none focus:border-kyn-green/50 focus:ring-1 focus:ring-kyn-green/30 transition-colors';

function fileToDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ''));
    reader.onerror = () => reject(new Error('Lecture fichier impossible'));
    reader.readAsDataURL(file);
  });
}

export default function InstallationDetails() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [successId, setSuccessId] = useState<number | null>(null);
  const [gpsLoading, setGpsLoading] = useState(false);
  const [gpsError, setGpsError] = useState('');

  // Customer
  const [customerName, setCustomerName] = useState('Khalifa Ben Ali');
  const [customerEmail, setCustomerEmail] = useState('khalifa@example.tn');
  const [customerPhone, setCustomerPhone] = useState('+216 20 000 000');
  const [customerCompany, setCustomerCompany] = useState('KYNETIK Demo');

  // Address
  const [addressLine, setAddressLine] = useState('12 Avenue de la République');
  const [city, setCity] = useState('La Marsa');
  const [postalCode, setPostalCode] = useState('2070');
  const [country, setCountry] = useState('Tunisie');

  // GPS
  const [gpsLat, setGpsLat] = useState<string>('36.8781');
  const [gpsLng, setGpsLng] = useState<string>('10.3247');

  // Charger
  const [chargerId, setChargerId] = useState<number | null>(null);

  // Accessories & checklist
  const [accessories, setAccessories] = useState<Accessory[]>(DEFAULT_ACCESSORIES);
  const [checklist, setChecklist] = useState<ChecklistItem[]>(DEFAULT_CHECKLIST);

  // Photos
  const [photosBefore, setPhotosBefore] = useState<PhotoItem[]>([]);
  const [photosAfter, setPhotosAfter] = useState<PhotoItem[]>([]);

  // Signature
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const drawing = useRef(false);
  const [hasSignature, setHasSignature] = useState(false);
  const [notes, setNotes] = useState('');

  useEffect(() => {
    fetch('/api/products')
      .then((r) => r.json())
      .then((data: Product[]) => {
        const list = Array.isArray(data) ? data.filter((p) => p.name && !String(p.name).startsWith('_')) : [];
        setProducts(list);
        const preferred =
          list.find((p) => p.name.toLowerCase().includes('nova')) ||
          list.find((p) => p.name.toLowerCase().includes('prime')) ||
          list[0];
        if (preferred) setChargerId(preferred.id);
      })
      .catch((e) => setError(e.message || 'Chargement produits impossible'))
      .finally(() => setLoading(false));
  }, []);

  const selectedCharger = useMemo(
    () => products.find((p) => p.id === chargerId) || null,
    [products, chargerId]
  );

  const checklistProgress = useMemo(() => {
    if (!checklist.length) return 0;
    return Math.round((checklist.filter((c) => c.done).length / checklist.length) * 100);
  }, [checklist]);

  const captureGps = () => {
    setGpsError('');
    if (!navigator.geolocation) {
      setGpsError('Géolocalisation non supportée sur cet appareil.');
      return;
    }
    setGpsLoading(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setGpsLat(pos.coords.latitude.toFixed(6));
        setGpsLng(pos.coords.longitude.toFixed(6));
        setGpsLoading(false);
      },
      (err) => {
        setGpsError(err.message || 'Impossible d’obtenir la position GPS.');
        setGpsLoading(false);
      },
      { enableHighAccuracy: true, timeout: 12000 }
    );
  };

  const toggleAccessory = (id: string) => {
    setAccessories((prev) =>
      prev.map((a) => (a.id === id ? { ...a, selected: !a.selected } : a))
    );
  };

  const setAccessoryQty = (id: string, qty: number) => {
    setAccessories((prev) =>
      prev.map((a) => (a.id === id ? { ...a, qty: Math.max(1, qty) } : a))
    );
  };

  const toggleCheck = (id: string) => {
    setChecklist((prev) => prev.map((c) => (c.id === id ? { ...c, done: !c.done } : c)));
  };

  const addPhotos = async (files: FileList | null, kind: 'before' | 'after') => {
    if (!files?.length) return;
    const items: PhotoItem[] = [];
    for (const file of Array.from(files).slice(0, 6)) {
      if (!file.type.startsWith('image/')) continue;
      try {
        const dataUrl = await fileToDataUrl(file);
        items.push({
          id: `${kind}-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
          name: file.name,
          dataUrl,
        });
      } catch {
        /* skip */
      }
    }
    if (kind === 'before') setPhotosBefore((p) => [...p, ...items].slice(0, 8));
    else setPhotosAfter((p) => [...p, ...items].slice(0, 8));
  };

  const removePhoto = (kind: 'before' | 'after', id: string) => {
    if (kind === 'before') setPhotosBefore((p) => p.filter((x) => x.id !== id));
    else setPhotosAfter((p) => p.filter((x) => x.id !== id));
  };

  const getCtx = () => {
    const canvas = canvasRef.current;
    if (!canvas) return null;
    const ctx = canvas.getContext('2d');
    if (!ctx) return null;
    return { canvas, ctx };
  };

  const initCanvas = useCallback(() => {
    const pair = getCtx();
    if (!pair) return;
    const { canvas, ctx } = pair;
    const rect = canvas.getBoundingClientRect();
    const dpr = window.devicePixelRatio || 1;
    canvas.width = Math.floor(rect.width * dpr);
    canvas.height = Math.floor(rect.height * dpr);
    ctx.scale(dpr, dpr);
    ctx.fillStyle = '#0a0a0b';
    ctx.fillRect(0, 0, rect.width, rect.height);
    ctx.strokeStyle = 'rgba(255,255,255,0.06)';
    ctx.strokeRect(0.5, 0.5, rect.width - 1, rect.height - 1);
    ctx.lineWidth = 2;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.strokeStyle = '#00e676';
    setHasSignature(false);
  }, []);

  useEffect(() => {
    if (!loading) {
      const t = setTimeout(initCanvas, 50);
      return () => clearTimeout(t);
    }
  }, [loading, initCanvas]);

  const pointerPos = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current!;
    const rect = canvas.getBoundingClientRect();
    return { x: e.clientX - rect.left, y: e.clientY - rect.top };
  };

  const onPointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const pair = getCtx();
    if (!pair) return;
    drawing.current = true;
    const { x, y } = pointerPos(e);
    pair.ctx.beginPath();
    pair.ctx.moveTo(x, y);
    e.currentTarget.setPointerCapture(e.pointerId);
  };

  const onPointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!drawing.current) return;
    const pair = getCtx();
    if (!pair) return;
    const { x, y } = pointerPos(e);
    pair.ctx.lineTo(x, y);
    pair.ctx.stroke();
    setHasSignature(true);
  };

  const onPointerUp = () => {
    drawing.current = false;
  };

  const clearSignature = () => initCanvas();

  const validate = () => {
    if (!customerName.trim()) return 'Le nom du client est requis.';
    if (!addressLine.trim() || !city.trim()) return 'L’adresse d’installation est incomplète.';
    if (!selectedCharger) return 'Sélectionnez une borne.';
    if (checklistProgress < 100) return 'Complétez toute la checklist d’installation.';
    if (!hasSignature) return 'La signature client est requise.';
    return '';
  };

  const completeInstallation = async () => {
    setError('');
    setSuccessId(null);
    const v = validate();
    if (v) {
      setError(v);
      return;
    }

    const signature = canvasRef.current?.toDataURL('image/png') || '';
    const payload = {
      table: 'installations',
      customer_name: customerName.trim(),
      customer_email: customerEmail.trim(),
      customer_phone: customerPhone.trim(),
      customer_company: customerCompany.trim(),
      address_line: addressLine.trim(),
      city: city.trim(),
      postal_code: postalCode.trim(),
      country: country.trim(),
      gps_lat: gpsLat ? Number(gpsLat) : null,
      gps_lng: gpsLng ? Number(gpsLng) : null,
      charger_name: selectedCharger!.name,
      charger_power: selectedCharger!.power,
      charger_image: selectedCharger!.image_url,
      accessories: JSON.stringify(accessories.filter((a) => a.selected)),
      checklist: JSON.stringify(checklist),
      photos_before: JSON.stringify(
        photosBefore.map((p) => ({ id: p.id, name: p.name, dataUrl: p.dataUrl.slice(0, 200) + '…' }))
      ),
      photos_after: JSON.stringify(
        photosAfter.map((p) => ({ id: p.id, name: p.name, dataUrl: p.dataUrl.slice(0, 200) + '…' }))
      ),
      signature_data: signature.slice(0, 5000),
      status: 'completed',
      notes: notes.trim(),
      completed_at: new Date().toISOString(),
    };

    setSaving(true);
    try {
      const res = await fetch('/api/installer-dashboard', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Échec de l’enregistrement');
      setSuccessId(data.id);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Erreur de sauvegarde');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-kyn-black flex items-center justify-center">
        <LoadingState label="Chargement fiche installation…" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-kyn-black text-white">
      {/* Top bar */}
      <header className="sticky top-0 z-40 border-b border-white/5 bg-kyn-black/90 backdrop-blur-xl">
        <div className="max-w-5xl mx-auto px-4 md:px-6 h-16 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <Link
              to="/installer"
              className="p-2 rounded-lg border border-white/10 text-kyn-silver hover:text-white hover:border-white/20"
              aria-label="Retour"
            >
              <ArrowLeft size={16} />
            </Link>
            <BrandLogo height={26} />
            <div className="hidden sm:block min-w-0">
              <p className="text-[10px] uppercase tracking-[0.2em] text-kyn-green font-semibold">Installer</p>
              <p className="text-sm font-display font-semibold truncate">Installation Details</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <span className="hidden md:inline text-[11px] text-kyn-metal">Checklist {checklistProgress}%</span>
            <div className="hidden md:block w-24 h-1.5 rounded-full bg-white/10 overflow-hidden">
              <div className="h-full bg-kyn-green rounded-full transition-all" style={{ width: `${checklistProgress}%` }} />
            </div>
            <button
              type="button"
              onClick={completeInstallation}
              disabled={saving}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-kyn-green text-kyn-black text-xs font-bold disabled:opacity-60"
            >
              {saving ? <Loader2 size={14} className="animate-spin" /> : <CheckCircle2 size={14} />}
              Terminer
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-4 md:px-6 py-8 md:py-12 space-y-5">
        <div className="mb-2">
          <p className="text-kyn-green text-xs font-semibold tracking-[0.28em] uppercase">Field operations</p>
          <h1 className="font-display text-3xl md:text-4xl font-bold mt-2">Fiche d’installation</h1>
          <p className="text-kyn-metal mt-2 max-w-2xl text-sm md:text-base">
            Documentez le client, le site, la borne, les accessoires, les photos et la signature — conforme au design system KYNETIK.
          </p>
        </div>

        {successId && (
          <div className="rounded-2xl border border-kyn-green/40 bg-kyn-green/10 px-5 py-4 flex items-start gap-3">
            <CheckCircle2 className="text-kyn-green shrink-0 mt-0.5" size={20} />
            <div>
              <p className="font-semibold text-kyn-green">Installation complétée</p>
              <p className="text-sm text-kyn-silver mt-1">
                Fiche enregistrée · ID #{successId}. Les données sont synchronisées avec la base KYNETIK.
              </p>
            </div>
          </div>
        )}

        {error && (
          <div className="rounded-2xl border border-red-500/30 bg-red-500/10 px-5 py-4 flex items-start gap-3">
            <AlertCircle className="text-red-400 shrink-0 mt-0.5" size={18} />
            <div className="flex-1">
              <p className="font-semibold text-red-300">Action requise</p>
              <p className="text-sm text-red-200/80 mt-1">{error}</p>
            </div>
            <button type="button" onClick={() => setError('')} className="text-red-300/70 hover:text-red-200">
              <X size={16} />
            </button>
          </div>
        )}

        {/* 1. Customer */}
        <SectionCard step="01" title="Customer Information" subtitle="Coordonnées du titulaire de l’installation" icon={User}>
          <div className="grid sm:grid-cols-2 gap-4">
            <Field label="Nom complet *">
              <div className="relative">
                <User size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-kyn-metal" />
                <input className={cn(inputClass, 'pl-9')} value={customerName} onChange={(e) => setCustomerName(e.target.value)} placeholder="Nom du client" />
              </div>
            </Field>
            <Field label="Société">
              <div className="relative">
                <Building2 size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-kyn-metal" />
                <input className={cn(inputClass, 'pl-9')} value={customerCompany} onChange={(e) => setCustomerCompany(e.target.value)} placeholder="Entreprise (optionnel)" />
              </div>
            </Field>
            <Field label="Email">
              <div className="relative">
                <Mail size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-kyn-metal" />
                <input type="email" className={cn(inputClass, 'pl-9')} value={customerEmail} onChange={(e) => setCustomerEmail(e.target.value)} placeholder="email@domaine.tn" />
              </div>
            </Field>
            <Field label="Téléphone">
              <div className="relative">
                <Phone size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-kyn-metal" />
                <input className={cn(inputClass, 'pl-9')} value={customerPhone} onChange={(e) => setCustomerPhone(e.target.value)} placeholder="+216 …" />
              </div>
            </Field>
          </div>
        </SectionCard>

        {/* 2. Address */}
        <SectionCard step="02" title="Installation Address" subtitle="Adresse physique du point de charge" icon={Home}>
          <div className="grid sm:grid-cols-2 gap-4">
            <Field label="Adresse *" className="sm:col-span-2">
              <input className={inputClass} value={addressLine} onChange={(e) => setAddressLine(e.target.value)} placeholder="N° et rue" />
            </Field>
            <Field label="Ville *">
              <input className={inputClass} value={city} onChange={(e) => setCity(e.target.value)} placeholder="Ville" />
            </Field>
            <Field label="Code postal">
              <input className={inputClass} value={postalCode} onChange={(e) => setPostalCode(e.target.value)} placeholder="Code postal" />
            </Field>
            <Field label="Pays" className="sm:col-span-2">
              <input className={inputClass} value={country} onChange={(e) => setCountry(e.target.value)} placeholder="Pays" />
            </Field>
          </div>
        </SectionCard>

        {/* 3. GPS */}
        <SectionCard step="03" title="GPS Location" subtitle="Coordonnées pour cartographie & SAV" icon={MapPin}>
          <div className="grid sm:grid-cols-[1fr_1fr_auto] gap-4 items-end">
            <Field label="Latitude">
              <input className={inputClass} value={gpsLat} onChange={(e) => setGpsLat(e.target.value)} placeholder="36.800000" />
            </Field>
            <Field label="Longitude">
              <input className={inputClass} value={gpsLng} onChange={(e) => setGpsLng(e.target.value)} placeholder="10.180000" />
            </Field>
            <button
              type="button"
              onClick={captureGps}
              disabled={gpsLoading}
              className="inline-flex items-center justify-center gap-2 rounded-xl border border-kyn-green/30 bg-kyn-green/10 text-kyn-green px-4 py-2.5 text-xs font-semibold hover:bg-kyn-green/15 disabled:opacity-60"
            >
              {gpsLoading ? <Loader2 size={14} className="animate-spin" /> : <Navigation size={14} />}
              Capturer GPS
            </button>
          </div>
          {gpsError && <p className="mt-3 text-xs text-amber-300">{gpsError}</p>}
          {gpsLat && gpsLng && (
            <div className="mt-4 rounded-xl border border-white/8 bg-black/30 p-4 flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2 text-sm text-kyn-silver">
                <MapPin size={14} className="text-kyn-green" />
                {gpsLat}, {gpsLng}
              </div>
              <a
                href={`https://www.google.com/maps?q=${gpsLat},${gpsLng}`}
                target="_blank"
                rel="noreferrer"
                className="text-xs text-kyn-green font-semibold inline-flex items-center gap-1"
              >
                Ouvrir la carte <ArrowRight size={12} />
              </a>
            </div>
          )}
        </SectionCard>

        {/* 4. Selected charger */}
        <SectionCard step="04" title="Selected Charger" subtitle="Modèle installé sur site" icon={Zap}>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {products.map((p) => {
              const active = p.id === chargerId;
              return (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => setChargerId(p.id)}
                  className={cn(
                    'text-left rounded-2xl border p-3 transition-all',
                    active ? 'border-kyn-green/50 bg-kyn-green/10' : 'border-white/8 bg-black/30 hover:border-white/20'
                  )}
                >
                  <div className="h-24 flex items-center justify-center mb-2 rounded-xl bg-[radial-gradient(circle,rgba(0,230,118,0.1),transparent_70%)]">
                    <img src={p.image_url} alt={p.name} className="max-h-full w-auto object-contain p-2" />
                  </div>
                  <p className="font-display font-semibold text-sm">{p.name}</p>
                  <p className="text-[11px] text-kyn-green mt-0.5">{p.power}</p>
                  {active && (
                    <span className="mt-2 inline-flex items-center gap-1 text-[10px] text-kyn-green font-semibold">
                      <Check size={12} /> Sélectionné
                    </span>
                  )}
                </button>
              );
            })}
          </div>
          {selectedCharger && (
            <div className="mt-4 rounded-xl border border-white/8 bg-black/25 px-4 py-3 flex items-center gap-3">
              <Package size={16} className="text-kyn-green" />
              <p className="text-sm text-kyn-silver">
                Borne retenue : <span className="text-white font-semibold">{selectedCharger.name}</span> · {selectedCharger.power}
              </p>
            </div>
          )}
        </SectionCard>

        {/* 5. Accessories */}
        <SectionCard step="05" title="Required Accessories" subtitle="Matériel fourni / installé avec la borne" icon={Package}>
          <div className="space-y-2">
            {accessories.map((a) => (
              <div
                key={a.id}
                className={cn(
                  'flex flex-wrap items-center gap-3 rounded-xl border px-3 py-3',
                  a.selected ? 'border-kyn-green/25 bg-kyn-green/5' : 'border-white/8 bg-black/25'
                )}
              >
                <button
                  type="button"
                  onClick={() => toggleAccessory(a.id)}
                  className={cn(
                    'w-5 h-5 rounded-md border flex items-center justify-center shrink-0',
                    a.selected ? 'bg-kyn-green border-kyn-green text-kyn-black' : 'border-white/20'
                  )}
                >
                  {a.selected && <Check size={12} strokeWidth={3} />}
                </button>
                <span className={cn('flex-1 text-sm', a.selected ? 'text-white' : 'text-kyn-metal')}>{a.label}</span>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] uppercase text-kyn-metal">Qté</span>
                  <input
                    type="number"
                    min={1}
                    value={a.qty}
                    disabled={!a.selected}
                    onChange={(e) => setAccessoryQty(a.id, Number(e.target.value) || 1)}
                    className="w-16 rounded-lg bg-black/40 border border-white/10 px-2 py-1 text-sm text-center disabled:opacity-40"
                  />
                </div>
              </div>
            ))}
          </div>
        </SectionCard>

        {/* 6. Checklist */}
        <SectionCard
          step="06"
          title="Installation Checklist"
          subtitle={`${checklist.filter((c) => c.done).length}/${checklist.length} étapes validées`}
          icon={ClipboardList}
          accent
        >
          <div className="mb-4 h-2 rounded-full bg-white/10 overflow-hidden">
            <div className="h-full bg-kyn-green transition-all duration-500" style={{ width: `${checklistProgress}%` }} />
          </div>
          <div className="space-y-2">
            {checklist.map((item, idx) => (
              <button
                key={item.id}
                type="button"
                onClick={() => toggleCheck(item.id)}
                className={cn(
                  'w-full flex items-center gap-3 rounded-xl border px-3 py-3 text-left transition-colors',
                  item.done ? 'border-kyn-green/30 bg-kyn-green/10' : 'border-white/8 bg-black/30 hover:border-white/15'
                )}
              >
                <span
                  className={cn(
                    'w-6 h-6 rounded-full border flex items-center justify-center text-[11px] font-bold shrink-0',
                    item.done ? 'bg-kyn-green border-kyn-green text-kyn-black' : 'border-white/20 text-kyn-metal'
                  )}
                >
                  {item.done ? <Check size={13} strokeWidth={3} /> : idx + 1}
                </span>
                <span className={cn('text-sm', item.done ? 'text-white' : 'text-kyn-silver')}>{item.label}</span>
              </button>
            ))}
          </div>
        </SectionCard>

        {/* 7 & 8 Photos */}
        <div className="grid lg:grid-cols-2 gap-5">
          <SectionCard step="07" title="Photos Before Installation" subtitle="État du site avant travaux" icon={Camera}>
            <PhotoUpload
              photos={photosBefore}
              onAdd={(files) => addPhotos(files, 'before')}
              onRemove={(id) => removePhoto('before', id)}
            />
          </SectionCard>
          <SectionCard step="08" title="Photos After Installation" subtitle="Résultat final livré" icon={ImagePlus}>
            <PhotoUpload
              photos={photosAfter}
              onAdd={(files) => addPhotos(files, 'after')}
              onRemove={(id) => removePhoto('after', id)}
            />
          </SectionCard>
        </div>

        {/* 9. Signature */}
        <SectionCard step="09" title="Customer Signature" subtitle="Validation client de la mise en service" icon={PenLine}>
          <div className="rounded-2xl border border-white/10 overflow-hidden bg-black/40">
            <canvas
              ref={canvasRef}
              className="w-full h-44 md:h-52 touch-none cursor-crosshair"
              onPointerDown={onPointerDown}
              onPointerMove={onPointerMove}
              onPointerUp={onPointerUp}
              onPointerLeave={onPointerUp}
            />
          </div>
          <div className="mt-3 flex flex-wrap items-center justify-between gap-3">
            <p className="text-xs text-kyn-metal">
              {hasSignature ? 'Signature capturée' : 'Signez dans la zone ci-dessus'}
            </p>
            <button
              type="button"
              onClick={clearSignature}
              className="inline-flex items-center gap-1.5 text-xs text-kyn-silver border border-white/10 rounded-full px-3 py-1.5 hover:border-white/25"
            >
              <Trash2 size={12} /> Effacer
            </button>
          </div>
          <Field label="Notes installateur" className="mt-4">
            <textarea
              className={cn(inputClass, 'min-h-[88px] resize-y')}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Observations, réserves, recommandations…"
            />
          </Field>
        </SectionCard>

        {/* 10. Completion */}
        <SectionCard step="10" title="Completion" subtitle="Finaliser et synchroniser la fiche" icon={CheckCircle2} accent>
          <div className="grid sm:grid-cols-3 gap-3 mb-5">
            {[
              { l: 'Client', ok: !!customerName.trim() },
              { l: 'Adresse + GPS', ok: !!addressLine.trim() && !!city.trim() && !!gpsLat && !!gpsLng },
              { l: 'Borne', ok: !!selectedCharger },
              { l: 'Checklist 100%', ok: checklistProgress === 100 },
              { l: 'Photos', ok: photosBefore.length + photosAfter.length > 0 },
              { l: 'Signature', ok: hasSignature },
            ].map((item) => (
              <div
                key={item.l}
                className={cn(
                  'rounded-xl border px-3 py-2.5 text-xs flex items-center gap-2',
                  item.ok ? 'border-kyn-green/30 text-kyn-green bg-kyn-green/5' : 'border-white/10 text-kyn-metal'
                )}
              >
                {item.ok ? <CheckCircle2 size={14} /> : <AlertCircle size={14} />}
                {item.l}
              </div>
            ))}
          </div>

          <button
            type="button"
            onClick={completeInstallation}
            disabled={saving}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-8 py-3.5 rounded-full bg-kyn-green text-kyn-black text-sm font-bold glow-green disabled:opacity-60"
          >
            {saving ? (
              <>
                <Loader2 size={16} className="animate-spin" /> Enregistrement…
              </>
            ) : (
              <>
                <CheckCircle2 size={16} /> Completion — Clôturer l’installation
              </>
            )}
          </button>
          <p className="mt-3 text-[11px] text-kyn-metal max-w-lg">
            En validant, la fiche est poussée vers Supabase (`installations`) via l’API installer KYNETIK.
          </p>
        </SectionCard>

        <div className="flex flex-wrap gap-3 pt-2 pb-10">
          <Link to="/installer" className="text-sm text-kyn-metal hover:text-white inline-flex items-center gap-1">
            <ArrowLeft size={14} /> Installer Dashboard
          </Link>
          <Link to="/design-system" className="text-sm text-kyn-metal hover:text-white">
            Design System
          </Link>
        </div>
      </main>
    </div>
  );
}

function PhotoUpload({
  photos,
  onAdd,
  onRemove,
}: {
  photos: PhotoItem[];
  onAdd: (files: FileList | null) => void;
  onRemove: (id: string) => void;
}) {
  const inputRef = useRef<HTMLInputElement | null>(null);

  const onChange = (e: ChangeEvent<HTMLInputElement>) => {
    onAdd(e.target.files);
    e.target.value = '';
  };

  return (
    <div>
      <input ref={inputRef} type="file" accept="image/*" multiple className="hidden" onChange={onChange} />
      <button
        type="button"
        onClick={() => inputRef.current?.click()}
        className="w-full rounded-xl border border-dashed border-white/15 bg-black/25 hover:border-kyn-green/40 hover:bg-kyn-green/5 transition-colors px-4 py-8 flex flex-col items-center gap-2"
      >
        <Camera className="text-kyn-green" size={22} />
        <span className="text-sm font-medium">Ajouter des photos</span>
        <span className="text-[11px] text-kyn-metal">JPG, PNG · max 8</span>
      </button>

      {photos.length > 0 && (
        <div className="mt-4 grid grid-cols-3 gap-2">
          {photos.map((p) => (
            <div key={p.id} className="relative group aspect-square rounded-xl overflow-hidden border border-white/10">
              <img src={p.dataUrl} alt={p.name} className="w-full h-full object-cover" />
              <button
                type="button"
                onClick={() => onRemove(p.id)}
                className="absolute top-1.5 right-1.5 p-1 rounded-md bg-black/70 text-white opacity-0 group-hover:opacity-100 transition-opacity"
                aria-label="Supprimer"
              >
                <Trash2 size={12} />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

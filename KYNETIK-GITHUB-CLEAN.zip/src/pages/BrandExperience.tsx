import { useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { motion, AnimatePresence, useScroll, useSpring, useTransform } from 'framer-motion';
import {
  ArrowRight, ArrowDown, Cloud, Smartphone, GraduationCap, Wrench,
  Headphones, Globe2, Building2, Hotel, Car, Factory,
  MapPin, TrendingUp, Shield, Zap, Play, Pause, ChevronLeft, ChevronRight,
  Package
} from 'lucide-react';
import BrandLogo from '../components/BrandLogo';
import PhoneFrame from '../components/PhoneFrame';
import LiveDashboard from '../components/cloud/LiveDashboard';
import {
  SplashScreen, DashboardScreen, ChargingScreen, MapScreen, PaymentsScreen
} from '../components/mobile/screens';
import { apiGet, cn } from '../lib/utils';

interface Product {
  id: number;
  name: string;
  tagline: string;
  power: string;
  image_url: string;
  accent: string;
  category: string;
  sort_order: number;
}

interface Metric {
  label: string;
  value: string;
  delta: string;
}

const SECTIONS = [
  { id: 'hero', n: '01', label: 'Opening' },
  { id: 'ecosystem', n: '02', label: 'Ecosystem' },
  { id: 'products', n: '03', label: 'Products' },
  { id: 'website', n: '04', label: 'Website' },
  { id: 'app', n: '05', label: 'Mobile' },
  { id: 'cloud', n: '06', label: 'Cloud' },
  { id: 'home', n: '07', label: 'Home' },
  { id: 'commercial', n: '08', label: 'Commercial' },
  { id: 'public', n: '09', label: 'Public' },
  { id: 'academy', n: '10', label: 'Academy' },
  { id: 'production', n: '11', label: 'Production' },
  { id: 'global', n: '12', label: 'Global' },
  { id: 'investor', n: '13', label: 'Investor' },
  { id: 'close', n: '14', label: 'Close' },
] as const;

const ECOSYSTEM = [
  { name: 'GO', kind: 'Hardware', img: '/images/products/go-cee.png' },
  { name: 'FLEX', kind: 'Hardware', img: '/images/products/flex-socket.png' },
  { name: 'PRIME', kind: 'Hardware', img: '/images/products/prime-hero.png' },
  { name: 'NOVA', kind: 'Hardware', img: '/images/products/nova-tethered.png' },
  { name: 'EDGE', kind: 'Hardware', img: '/images/products/edge-wall.png' },
  { name: 'PRO', kind: 'Hardware', img: '/images/products/pro-tethered.png' },
  { name: 'Cloud', kind: 'Platform', img: null as string | null, icon: Cloud },
  { name: 'App', kind: 'Platform', img: null as string | null, icon: Smartphone },
  { name: 'Academy', kind: 'Services', img: null as string | null, icon: GraduationCap },
  { name: 'Installer', kind: 'Services', img: null as string | null, icon: Wrench },
  { name: 'Support', kind: 'Services', img: null as string | null, icon: Headphones },
];

const PARTICLES = Array.from({ length: 48 }, (_, i) => ({
  id: i,
  x: (i * 41 + 7) % 100,
  y: (i * 59 + 13) % 100,
  s: 1 + (i % 5) * 0.6,
  d: 5 + (i % 8),
  delay: (i % 12) * 0.28,
}));

function Fade({
  children,
  className,
  delay = 0,
}: {
  children: ReactNode;
  className?: string;
  delay?: number;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 40 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-10%' }}
      transition={{ duration: 0.95, delay, ease: [0.16, 1, 0.3, 1] }}
      className={className}
    >
      {children}
    </motion.div>
  );
}

function SectionLabel({ n, label }: { n: string; label: string }) {
  return (
    <div className="inline-flex items-center gap-3 mb-6">
      <span className="font-mono text-[11px] text-kyn-green tracking-[0.4em]">{n}</span>
      <span className="h-px w-10 bg-gradient-to-r from-kyn-green to-transparent" />
      <span className="text-[11px] uppercase tracking-[0.32em] text-kyn-metal">{label}</span>
    </div>
  );
}

function DeviceLaptop({ children }: { children: ReactNode }) {
  return (
    <div className="w-full max-w-5xl mx-auto perspective-[1200px]">
      <motion.div
        initial={{ rotateX: 12, y: 30, opacity: 0 }}
        whileInView={{ rotateX: 6, y: 0, opacity: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 1.1, ease: [0.16, 1, 0.3, 1] }}
        style={{ transformStyle: 'preserve-3d' }}
        className="relative"
      >
        <div className="rounded-t-[1.25rem] border border-white/12 bg-gradient-to-b from-[#2a2a32] via-[#141418] to-[#0a0a0c] p-3 shadow-[0_50px_120px_rgba(0,0,0,0.75),0_0_0_1px_rgba(0,230,118,0.06)]">
          <div className="flex justify-center mb-2.5">
            <div className="w-2.5 h-2.5 rounded-full bg-white/10 shadow-inner" />
          </div>
          <div className="rounded-lg overflow-hidden border border-white/8 bg-kyn-black aspect-[16/10] relative ring-1 ring-white/5">
            {children}
            <div className="pointer-events-none absolute inset-0 bg-gradient-to-tr from-white/0 via-white/[0.04] to-transparent" />
          </div>
        </div>
        <div className="h-3.5 bg-gradient-to-b from-[#33333a] to-[#121214] rounded-b-2xl mx-auto w-[103%] -ml-[1.5%] border-x border-b border-white/8" />
        <div className="h-2 w-[28%] mx-auto bg-gradient-to-b from-[#1a1a1e] to-[#080808] rounded-b-lg" />
      </motion.div>
    </div>
  );
}

function EnergyVeins() {
  return (
    <svg className="absolute inset-0 w-full h-full pointer-events-none opacity-40" preserveAspectRatio="none">
      <defs>
        <linearGradient id="vein" x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" stopColor="#00e676" stopOpacity="0" />
          <stop offset="50%" stopColor="#00e676" stopOpacity="0.85" />
          <stop offset="100%" stopColor="#00e676" stopOpacity="0" />
        </linearGradient>
      </defs>
      {[18, 42, 68, 85].map((y, i) => (
        <motion.path
          key={y}
          d={`M0,${y} Q25,${y - 12} 50,${y} T100,${y}`}
          fill="none"
          stroke="url(#vein)"
          strokeWidth="0.35"
          vectorEffect="non-scaling-stroke"
          initial={{ pathLength: 0, opacity: 0 }}
          animate={{ pathLength: [0, 1, 0], opacity: [0, 0.7, 0] }}
          transition={{ duration: 5 + i, repeat: Infinity, delay: i * 0.8, ease: 'easeInOut' }}
          style={{ transform: 'scaleY(4)', transformOrigin: 'center' }}
        />
      ))}
    </svg>
  );
}

export default function BrandExperience() {
  const containerRef = useRef<HTMLDivElement>(null);
  const [products, setProducts] = useState<Product[]>([]);
  const [metrics, setMetrics] = useState<Metric[]>([]);
  const [activeProduct, setActiveProduct] = useState(0);
  const [phoneIdx, setPhoneIdx] = useState(0);
  const [playing, setPlaying] = useState(true);
  const [activeSection, setActiveSection] = useState('hero');
  const [navOpen, setNavOpen] = useState(false);
  const [cloudTab, setCloudTab] = useState(0);

  const { scrollYProgress } = useScroll({ container: containerRef });
  const progress = useSpring(scrollYProgress, { stiffness: 80, damping: 28, mass: 0.4 });
  const heroY = useTransform(scrollYProgress, [0, 0.1], [0, 140]);
  const heroOpacity = useTransform(scrollYProgress, [0, 0.08], [1, 0]);
  const heroScale = useTransform(scrollYProgress, [0, 0.1], [1, 1.08]);

  useEffect(() => {
    Promise.all([
      apiGet<Product[]>('/api/products').catch(() => []),
      apiGet<Metric[]>('/api/cloud-metrics').catch(() => []),
    ]).then(([p, m]) => {
      const clean = (p || [])
        .filter((x) => x.name && !String(x.name).includes('Archive'))
        .sort((a, b) => (a.sort_order ?? 0) - (b.sort_order ?? 0));
      setProducts(clean);
      setMetrics(
        (m || []).slice(0, 4).map((x: Metric) => ({
          label: x.label,
          value: x.value,
          delta: x.delta,
        }))
      );
    });
  }, []);

  useEffect(() => {
    if (!playing) return;
    const t = setInterval(() => {
      setActiveProduct((i) => (products.length ? (i + 1) % products.length : 0));
      setPhoneIdx((i) => (i + 1) % 5);
      setCloudTab((i) => (i + 1) % 4);
    }, 3400);
    return () => clearInterval(t);
  }, [playing, products.length]);

  useEffect(() => {
    const root = containerRef.current;
    if (!root) return;
    const els = SECTIONS.map((s) => document.getElementById(`exp-${s.id}`)).filter(Boolean) as HTMLElement[];
    const io = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((e) => e.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
        if (visible?.target?.id) setActiveSection(visible.target.id.replace('exp-', ''));
      },
      { root, threshold: [0.3, 0.5, 0.65] }
    );
    els.forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'ArrowDown' || e.key === 'PageDown' || e.key === ' ') {
        e.preventDefault();
        const idx = SECTIONS.findIndex((s) => s.id === activeSection);
        const next = SECTIONS[Math.min(idx + 1, SECTIONS.length - 1)];
        document.getElementById(`exp-${next.id}`)?.scrollIntoView({ behavior: 'smooth' });
      }
      if (e.key === 'ArrowUp' || e.key === 'PageUp') {
        e.preventDefault();
        const idx = SECTIONS.findIndex((s) => s.id === activeSection);
        const prev = SECTIONS[Math.max(idx - 1, 0)];
        document.getElementById(`exp-${prev.id}`)?.scrollIntoView({ behavior: 'smooth' });
      }
      if (e.key === 'Escape') setNavOpen(false);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [activeSection]);

  const phones = useMemo(
    () => [
      { label: 'Splash', ui: <SplashScreen /> },
      { label: 'Dashboard', ui: <DashboardScreen /> },
      { label: 'Charging', ui: <ChargingScreen /> },
      { label: 'Map / QR', ui: <MapScreen /> },
      { label: 'Wallet', ui: <PaymentsScreen /> },
    ],
    []
  );

  const current = products[activeProduct] || null;

  const scrollTo = (id: string) => {
    document.getElementById(`exp-${id}`)?.scrollIntoView({ behavior: 'smooth' });
    setNavOpen(false);
  };

  const investorSlides = [
    { k: 'Market', v: '€4.2B', d: 'MENA EV infrastructure by 2030' },
    { k: 'Model', v: 'HaaS + SaaS', d: 'Hardware, Cloud subscriptions, Academy' },
    { k: 'Growth', v: '35% CAGR', d: 'Charging assets target corridor' },
    { k: 'Moat', v: 'Full stack', d: 'Product · Cloud · App · Installers' },
  ];

  const roadmap = ['Tunisia core', 'North Africa', 'Gulf corridors', 'EU partners'];
  const cloudLabels = ['Analytics', 'Fleet Management', 'Energy Monitoring', 'Live Charging'];

  return (
    <div className="h-screen bg-kyn-black text-white overflow-hidden relative selection:bg-kyn-green/30">
      {/* Cinematic letterbox */}
      <div className="pointer-events-none fixed inset-x-0 top-0 h-8 z-[55] bg-gradient-to-b from-black to-transparent" />
      <div className="pointer-events-none fixed inset-x-0 bottom-0 h-8 z-[55] bg-gradient-to-t from-black to-transparent" />

      {/* Progress */}
      <motion.div
        className="fixed top-0 left-0 right-0 h-[2px] z-[60] origin-left bg-gradient-to-r from-kyn-green via-emerald-300 to-cyan-300"
        style={{ scaleX: progress }}
      />

      <header className="fixed top-0 inset-x-0 z-50 pointer-events-none">
        <div className="max-w-[1600px] mx-auto px-5 md:px-8 h-16 md:h-20 flex items-center justify-between pointer-events-auto">
          <Link to="/" className="flex items-center gap-3 group">
            <BrandLogo height={28} />
            <span className="hidden sm:inline text-[10px] tracking-[0.35em] uppercase text-kyn-metal group-hover:text-kyn-silver transition-colors">
              Brand Experience
            </span>
          </Link>
          <div className="flex items-center gap-2 md:gap-3">
            <span className="hidden lg:inline text-[10px] font-mono text-kyn-metal tracking-widest">
              {SECTIONS.find((s) => s.id === activeSection)?.n}/{String(SECTIONS.length).padStart(2, '0')}
            </span>
            <button
              type="button"
              onClick={() => setPlaying((p) => !p)}
              className="w-9 h-9 rounded-full border border-white/10 bg-white/[0.04] backdrop-blur flex items-center justify-center text-kyn-silver hover:text-white hover:border-kyn-green/40 transition-colors"
              aria-label={playing ? 'Pause autoplay' : 'Play autoplay'}
            >
              {playing ? <Pause size={14} /> : <Play size={14} />}
            </button>
            <button
              type="button"
              onClick={() => setNavOpen((v) => !v)}
              className="px-3.5 py-2 rounded-full border border-white/10 bg-white/[0.04] backdrop-blur text-[10px] tracking-[0.22em] uppercase text-kyn-silver hover:text-white transition-colors"
            >
              Index
            </button>
            <Link
              to="/showcase"
              className="hidden md:inline-flex items-center gap-2 px-4 py-2 rounded-full bg-kyn-green text-kyn-black text-xs font-bold hover:bg-kyn-green-glow transition-colors"
            >
              Showcase <ArrowRight size={13} />
            </Link>
          </div>
        </div>
      </header>

      <AnimatePresence>
        {navOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[70] bg-black/85 backdrop-blur-2xl"
            onClick={() => setNavOpen(false)}
          >
            <motion.div
              initial={{ y: 30, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 16, opacity: 0 }}
              transition={{ ease: [0.16, 1, 0.3, 1] }}
              className="max-w-5xl mx-auto px-6 pt-28 pb-16"
              onClick={(e) => e.stopPropagation()}
            >
              <p className="text-kyn-green text-xs tracking-[0.4em] uppercase mb-3">Experience index</p>
              <h3 className="font-display text-3xl font-bold mb-10">14 chapters. One brand.</h3>
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-2">
                {SECTIONS.map((s, i) => (
                  <motion.button
                    key={s.id}
                    type="button"
                    initial={{ opacity: 0, y: 12 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.03 }}
                    onClick={() => scrollTo(s.id)}
                    className={cn(
                      'text-left rounded-2xl border px-4 py-4 transition-all',
                      activeSection === s.id
                        ? 'border-kyn-green/50 bg-kyn-green/10 shadow-[0_0_40px_rgba(0,230,118,0.08)]'
                        : 'border-white/8 bg-white/[0.02] hover:border-white/20'
                    )}
                  >
                    <span className="font-mono text-[10px] text-kyn-green">{s.n}</span>
                    <p className="font-display font-semibold mt-1">{s.label}</p>
                  </motion.button>
                ))}
              </div>
              <p className="mt-10 text-[11px] text-kyn-metal">Keyboard · ↑ ↓ · Space · Esc</p>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <nav className="fixed right-4 md:right-7 top-1/2 -translate-y-1/2 z-50 hidden md:flex flex-col gap-2.5">
        {SECTIONS.map((s) => (
          <button
            key={s.id}
            type="button"
            title={s.label}
            onClick={() => scrollTo(s.id)}
            className={cn(
              'rounded-full transition-all duration-500',
              activeSection === s.id
                ? 'w-1.5 h-7 bg-kyn-green shadow-[0_0_12px_rgba(0,230,118,0.7)]'
                : 'w-1.5 h-1.5 bg-white/20 hover:bg-white/45'
            )}
          />
        ))}
      </nav>

      <div
        ref={containerRef}
        className="h-full overflow-y-auto overflow-x-hidden scroll-smooth snap-y snap-mandatory"
      >
        {/* 01 HERO */}
        <section id="exp-hero" className="relative min-h-screen snap-start flex items-center justify-center overflow-hidden">
          <motion.div className="absolute inset-0" style={{ scale: heroScale }}>
            <img src="/images/hero-city.jpg" alt="" className="w-full h-full object-cover opacity-[0.42]" />
            <div className="absolute inset-0 bg-gradient-to-b from-black via-black/70 to-kyn-black" />
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_50%_40%,rgba(0,230,118,0.18),transparent_55%)]" />
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_80%_70%,rgba(0,230,118,0.08),transparent_40%)]" />
          </motion.div>
          <EnergyVeins />
          {PARTICLES.map((p) => (
            <motion.span
              key={p.id}
              className="absolute rounded-full bg-kyn-green pointer-events-none"
              style={{ left: `${p.x}%`, top: `${p.y}%`, width: p.s, height: p.s }}
              animate={{ y: [0, -36, 0], opacity: [0.1, 0.9, 0.1], scale: [1, 1.4, 1] }}
              transition={{ duration: p.d, repeat: Infinity, delay: p.delay, ease: 'easeInOut' }}
            />
          ))}

          {/* Floating charger silhouettes */}
          <motion.img
            src="/images/products/nova-tethered.png"
            alt=""
            className="absolute right-[6%] bottom-[8%] h-[42vh] max-h-[420px] object-contain opacity-30 hidden lg:block pointer-events-none"
            animate={{ y: [0, -14, 0], rotate: [-2, 2, -2] }}
            transition={{ duration: 8, repeat: Infinity, ease: 'easeInOut' }}
          />
          <motion.img
            src="/images/products/prime-hero.png"
            alt=""
            className="absolute left-[5%] bottom-[12%] h-[34vh] max-h-[340px] object-contain opacity-20 hidden lg:block pointer-events-none"
            animate={{ y: [0, 12, 0] }}
            transition={{ duration: 9, repeat: Infinity, ease: 'easeInOut' }}
          />

          <motion.div style={{ y: heroY, opacity: heroOpacity }} className="relative z-10 text-center px-6 max-w-5xl">
            <motion.div initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1] }}>
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 1.4 }}
                className="inline-flex"
              >
                <BrandLogo height={44} className="mx-auto justify-center mb-10 drop-shadow-[0_0_40px_rgba(0,230,118,0.35)]" />
              </motion.div>
              <p className="text-kyn-green text-[11px] tracking-[0.5em] uppercase mb-7 font-medium">
                KYNETIK · Premium Brand Experience
              </p>
              <h1 className="font-display text-5xl sm:text-6xl md:text-8xl lg:text-[7.5rem] font-bold tracking-[-0.03em] leading-[0.92]">
                Powering
                <br />
                <span className="text-kyn-green text-glow">Tomorrow.</span>
              </h1>
              <p className="mt-8 md:mt-10 text-lg md:text-2xl text-kyn-silver font-light tracking-[0.04em]">
                The Complete Electric Mobility Ecosystem.
              </p>
              <div className="mt-16 flex flex-col items-center gap-3 text-kyn-metal">
                <span className="text-[10px] tracking-[0.45em] uppercase">Enter the experience</span>
                <motion.div animate={{ y: [0, 10, 0] }} transition={{ duration: 1.8, repeat: Infinity }}>
                  <ArrowDown size={18} className="text-kyn-green" />
                </motion.div>
              </div>
            </motion.div>
          </motion.div>
          <div className="absolute bottom-0 inset-x-0 h-40 bg-gradient-to-t from-kyn-black via-kyn-black/80 to-transparent" />
        </section>

        {/* 02 ECOSYSTEM */}
        <section id="exp-ecosystem" className="relative min-h-screen snap-start flex items-center py-24 border-t border-white/5">
          <div className="absolute inset-0 grid-bg opacity-35" />
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(0,230,118,0.06),transparent_60%)]" />
          <div className="relative z-10 max-w-7xl mx-auto px-5 md:px-8 w-full">
            <Fade>
              <SectionLabel n="02" label="Ecosystem" />
              <h2 className="font-display text-4xl md:text-6xl font-bold max-w-3xl leading-[1.05] tracking-tight">
                Everything connected.
                <span className="text-kyn-silver font-medium"> One intelligence.</span>
              </h2>
            </Fade>

            {/* Connection canvas */}
            <div className="relative mt-14">
              <svg className="absolute inset-0 w-full h-full pointer-events-none hidden md:block" style={{ zIndex: 0 }}>
                <motion.line
                  x1="10%" y1="50%" x2="90%" y2="50%"
                  stroke="rgba(0,230,118,0.25)"
                  strokeWidth="1"
                  strokeDasharray="4 8"
                  initial={{ pathLength: 0 }}
                  whileInView={{ pathLength: 1 }}
                  transition={{ duration: 1.8 }}
                />
              </svg>
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-3 relative z-10">
                {ECOSYSTEM.map((item, i) => {
                  const Icon = item.icon;
                  return (
                    <Fade key={item.name} delay={i * 0.045}>
                      <motion.div
                        whileHover={{ y: -4, scale: 1.02 }}
                        className="group relative rounded-2xl border border-white/8 bg-white/[0.025] backdrop-blur-sm p-4 min-h-[148px] flex flex-col items-center justify-center text-center hover:border-kyn-green/35 transition-colors overflow-hidden"
                      >
                        <div className="absolute inset-x-8 top-0 h-px bg-gradient-to-r from-transparent via-kyn-green/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                        <div className="absolute -inset-px rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity bg-[radial-gradient(circle_at_50%_0%,rgba(0,230,118,0.12),transparent_60%)]" />
                        {item.img ? (
                          <motion.img
                            src={item.img}
                            alt={item.name}
                            className="h-16 w-auto object-contain mb-3 relative drop-shadow-[0_12px_28px_rgba(0,230,118,0.18)]"
                            animate={playing ? { y: [0, -4, 0] } : {}}
                            transition={{ duration: 3.5 + (i % 3), repeat: Infinity, ease: 'easeInOut' }}
                          />
                        ) : Icon ? (
                          <div className="w-12 h-12 rounded-xl bg-kyn-green/10 border border-kyn-green/25 flex items-center justify-center text-kyn-green mb-3 relative">
                            <Icon size={20} />
                          </div>
                        ) : null}
                        <p className="font-display font-semibold text-sm relative">{item.name}</p>
                        <p className="text-[10px] text-kyn-metal mt-1 uppercase tracking-wider relative">{item.kind}</p>
                      </motion.div>
                    </Fade>
                  );
                })}
              </div>
            </div>
            <Fade delay={0.25} className="mt-12">
              <div className="h-px w-full bg-gradient-to-r from-transparent via-kyn-green/45 to-transparent" />
              <p className="text-center text-sm text-kyn-metal mt-7 tracking-wide">
                Hardware · Cloud · App · Academy · Installer Portal · Support — one brand system.
              </p>
            </Fade>
          </div>
        </section>

        {/* 03 PRODUCTS */}
        <section id="exp-products" className="relative min-h-screen snap-start flex items-center py-24 bg-kyn-void border-y border-white/5 overflow-hidden">
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_70%_50%,rgba(0,230,118,0.08),transparent_50%)]" />
          <div className="max-w-7xl mx-auto px-5 md:px-8 w-full relative">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div>
                <Fade>
                  <SectionLabel n="03" label="Product Showcase" />
                  <h2 className="font-display text-4xl md:text-5xl font-bold leading-tight tracking-tight">
                    Studio-grade hardware cinema.
                  </h2>
                  <p className="mt-4 text-kyn-silver max-w-md leading-relaxed">
                    Floating presentation, luxury lighting, material presence — Tesla launch energy with KYNETIK identity.
                  </p>
                </Fade>
                <div className="mt-8 flex flex-wrap gap-2">
                  {products.map((p, i) => (
                    <button
                      key={p.id}
                      type="button"
                      onClick={() => setActiveProduct(i)}
                      className={cn(
                        'px-3 py-1.5 rounded-full text-[11px] font-semibold border transition-all duration-300',
                        i === activeProduct
                          ? 'bg-kyn-green text-kyn-black border-kyn-green shadow-[0_0_20px_rgba(0,230,118,0.35)]'
                          : 'border-white/10 text-kyn-metal hover:text-white'
                      )}
                    >
                      {p.name}
                    </button>
                  ))}
                </div>
                {current && (
                  <AnimatePresence mode="wait">
                    <motion.div
                      key={current.id}
                      initial={{ opacity: 0, y: 12 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -8 }}
                      className="mt-8"
                    >
                      <p className="font-display text-2xl md:text-3xl font-bold" style={{ color: current.accent || '#00e676' }}>
                        {current.name}
                      </p>
                      <p className="text-kyn-silver mt-2 leading-relaxed">{current.tagline}</p>
                      <p className="text-sm text-kyn-metal mt-3 font-mono tracking-wide">
                        {current.power} · {current.category}
                      </p>
                    </motion.div>
                  </AnimatePresence>
                )}
                <div className="mt-8 flex gap-2">
                  <button
                    type="button"
                    onClick={() => setActiveProduct((i) => (products.length ? (i - 1 + products.length) % products.length : 0))}
                    className="w-11 h-11 rounded-full border border-white/10 flex items-center justify-center hover:border-kyn-green/40 hover:bg-white/5 transition-colors"
                  >
                    <ChevronLeft size={16} />
                  </button>
                  <button
                    type="button"
                    onClick={() => setActiveProduct((i) => (products.length ? (i + 1) % products.length : 0))}
                    className="w-11 h-11 rounded-full border border-white/10 flex items-center justify-center hover:border-kyn-green/40 hover:bg-white/5 transition-colors"
                  >
                    <ChevronRight size={16} />
                  </button>
                </div>
              </div>
              <div className="relative min-h-[440px] md:min-h-[560px] flex items-center justify-center">
                <motion.div
                  className="absolute w-[75%] h-[75%] rounded-full blur-[110px]"
                  animate={{ opacity: [0.25, 0.5, 0.25], scale: [0.95, 1.05, 0.95] }}
                  transition={{ duration: 5, repeat: Infinity }}
                  style={{ background: current?.accent || '#00e676', opacity: 0.2 }}
                />
                <div className="absolute bottom-[16%] w-[50%] h-10 rounded-[100%] bg-black/80 blur-3xl" />
                {/* Glass floor reflection hint */}
                <div className="absolute bottom-[12%] w-[60%] h-24 bg-gradient-to-t from-kyn-green/5 to-transparent rounded-[100%] blur-xl" />
                <AnimatePresence mode="wait">
                  {current && (
                    <motion.img
                      key={current.id}
                      src={current.image_url}
                      alt={current.name}
                      initial={{ opacity: 0, rotateY: -24, scale: 0.88, filter: 'blur(8px)' }}
                      animate={{
                        opacity: 1,
                        rotateY: 0,
                        scale: 1,
                        filter: 'blur(0px)',
                        y: playing ? [0, -12, 0] : 0,
                      }}
                      exit={{ opacity: 0, rotateY: 20, scale: 0.92, filter: 'blur(6px)' }}
                      transition={{
                        opacity: { duration: 0.55 },
                        rotateY: { duration: 0.75, ease: [0.16, 1, 0.3, 1] },
                        scale: { duration: 0.75 },
                        y: { duration: 4.5, repeat: Infinity, ease: 'easeInOut' },
                      }}
                      className="relative z-10 max-h-[480px] w-auto object-contain"
                      style={{ filter: `drop-shadow(0 40px 90px ${current.accent || '#00e676'}55)` }}
                    />
                  )}
                </AnimatePresence>
              </div>
            </div>
          </div>
        </section>

        {/* 04 WEBSITE */}
        <section id="exp-website" className="relative min-h-screen snap-start flex items-center py-24">
          <div className="max-w-7xl mx-auto px-5 md:px-8 w-full">
            <Fade className="text-center mb-14">
              <SectionLabel n="04" label="Website" />
              <h2 className="font-display text-4xl md:text-5xl font-bold tracking-tight">Digital flagship. Device-perfect.</h2>
            </Fade>
            <DeviceLaptop>
              <div className="absolute inset-0">
                <img src="/images/hero-city.jpg" alt="" className="w-full h-full object-cover opacity-55" />
                <div className="absolute inset-0 bg-gradient-to-r from-black via-black/85 to-black/20" />
                <motion.div
                  className="absolute inset-0 p-6 md:p-10 flex flex-col justify-between"
                  initial={{ y: 20, opacity: 0 }}
                  whileInView={{ y: 0, opacity: 1 }}
                  transition={{ duration: 1 }}
                >
                  <div className="flex items-center justify-between">
                    <BrandLogo height={22} />
                    <div className="hidden md:flex gap-5 text-[10px] text-kyn-silver tracking-wide">
                      {['Products', 'Cloud', 'App', 'Academy'].map((l) => (
                        <span key={l}>{l}</span>
                      ))}
                    </div>
                  </div>
                  <div>
                    <p className="font-display text-2xl md:text-4xl font-bold tracking-tight">L'énergie en mouvement</p>
                    <p className="text-xs md:text-sm text-kyn-silver mt-2 max-w-sm">
                      Intelligent charging infrastructure for the mobility of tomorrow.
                    </p>
                    <div className="mt-5 inline-flex px-4 py-2 rounded-full bg-kyn-green text-kyn-black text-[10px] font-bold">
                      Découvrir KYNETIK
                    </div>
                  </div>
                </motion.div>
              </div>
            </DeviceLaptop>
            <div className="mt-12 flex flex-wrap justify-center gap-8 items-end">
              <Fade delay={0.1} className="w-[210px] hidden sm:block">
                <div className="rounded-[1.6rem] border border-white/12 bg-[#1a1a1e] p-2.5 shadow-2xl shadow-black/50">
                  <div className="rounded-[1.2rem] overflow-hidden aspect-[3/4] relative">
                    <img src="/images/products/family-lineup-premium.jpg" alt="" className="w-full h-full object-cover opacity-85" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent" />
                    <p className="absolute bottom-3 left-3 text-[10px] font-semibold tracking-wide">Tablet</p>
                  </div>
                </div>
              </Fade>
              <Fade delay={0.15}>
                <PhoneFrame width={158} label="Mobile web">
                  <div className="h-full bg-kyn-black p-4 pt-10">
                    <BrandLogo height={18} />
                    <p className="font-display text-lg font-bold mt-6 leading-tight">Powering Tomorrow.</p>
                    <div className="mt-4 h-24 rounded-xl overflow-hidden border border-white/5">
                      <img src="/images/ev-network.jpg" alt="" className="w-full h-full object-cover opacity-75" />
                    </div>
                    <div className="mt-4 space-y-2">
                      {['NOVA', 'PRIME', 'GO', 'Cloud'].map((x) => (
                        <div key={x} className="rounded-lg bg-white/5 border border-white/8 px-3 py-2 text-[10px]">
                          {x}
                        </div>
                      ))}
                    </div>
                  </div>
                </PhoneFrame>
              </Fade>
            </div>
            <div className="mt-10 text-center">
              <Link to="/" className="inline-flex items-center gap-2 text-sm text-kyn-green font-semibold hover:gap-3 transition-all">
                Open live website <ArrowRight size={14} />
              </Link>
            </div>
          </div>
        </section>

        {/* 05 APP */}
        <section id="exp-app" className="relative min-h-screen snap-start flex items-center py-24 bg-kyn-void border-y border-white/5">
          <div className="max-w-7xl mx-auto px-5 md:px-8 w-full">
            <div className="grid lg:grid-cols-2 gap-14 items-center">
              <Fade>
                <SectionLabel n="05" label="Mobile App" />
                <h2 className="font-display text-4xl md:text-5xl font-bold tracking-tight">
                  Driver experience. Cinematic dark mode.
                </h2>
                <p className="mt-4 text-kyn-silver max-w-md leading-relaxed">
                  Charging animation, dashboard, map, wallet and Cloud sync — in realistic device chrome.
                </p>
                <div className="mt-8 flex flex-wrap gap-2">
                  {phones.map((p, i) => (
                    <button
                      key={p.label}
                      type="button"
                      onClick={() => setPhoneIdx(i)}
                      className={cn(
                        'px-3 py-1.5 rounded-full text-[11px] font-semibold border transition-all',
                        phoneIdx === i
                          ? 'bg-kyn-green text-kyn-black border-kyn-green'
                          : 'border-white/10 text-kyn-metal hover:text-white'
                      )}
                    >
                      {p.label}
                    </button>
                  ))}
                </div>
                <Link to="/app-landing" className="mt-8 inline-flex items-center gap-2 text-sm text-kyn-green font-semibold hover:gap-3 transition-all">
                  App marketing page <ArrowRight size={14} />
                </Link>
              </Fade>
              <div className="flex justify-center gap-5 md:gap-8">
                <Fade>
                  <div className="relative">
                    <div className="absolute -inset-8 bg-kyn-green/10 blur-3xl rounded-full" />
                    <PhoneFrame width={240} label={phones[phoneIdx].label}>
                      <AnimatePresence mode="wait">
                        <motion.div
                          key={phoneIdx}
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: -10 }}
                          transition={{ duration: 0.35 }}
                          className="h-full"
                        >
                          {phones[phoneIdx].ui}
                        </motion.div>
                      </AnimatePresence>
                    </PhoneFrame>
                  </div>
                </Fade>
                <Fade delay={0.12} className="hidden sm:block mt-14">
                  <PhoneFrame width={188} label="Charging">
                    <ChargingScreen />
                  </PhoneFrame>
                </Fade>
              </div>
            </div>
          </div>
        </section>

        {/* 06 CLOUD */}
        <section id="exp-cloud" className="relative min-h-screen snap-start flex items-center py-24">
          <div className="max-w-7xl mx-auto px-5 md:px-8 w-full">
            <Fade className="mb-10">
              <SectionLabel n="06" label="Cloud Dashboard" />
              <h2 className="font-display text-4xl md:text-5xl font-bold tracking-tight">Operations at enterprise scale.</h2>
              <p className="mt-3 text-kyn-silver max-w-xl">
                Analytics, fleet, energy, live sessions and remote control — one glass console.
              </p>
            </Fade>
            <div className="flex flex-wrap gap-2 mb-6">
              {cloudLabels.map((t, i) => (
                <button
                  key={t}
                  type="button"
                  onClick={() => setCloudTab(i)}
                  className={cn(
                    'px-3 py-1.5 rounded-full text-[11px] font-semibold border transition-all',
                    cloudTab === i ? 'bg-kyn-green text-kyn-black border-kyn-green' : 'border-white/10 text-kyn-metal'
                  )}
                >
                  {t}
                </button>
              ))}
            </div>
            <Fade>
              <div className="relative">
                <div className="absolute -inset-4 bg-kyn-green/5 blur-3xl rounded-3xl" />
                <LiveDashboard metrics={metrics} />
              </div>
            </Fade>
            <div className="mt-6 grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
              {cloudLabels.map((t, i) => (
                <Fade key={t} delay={i * 0.05}>
                  <div
                    className={cn(
                      'rounded-xl border px-4 py-3 text-sm font-medium flex items-center gap-2 transition-colors',
                      cloudTab === i ? 'border-kyn-green/40 bg-kyn-green/5' : 'border-white/8 bg-white/[0.02]'
                    )}
                  >
                    <span className="w-1.5 h-1.5 rounded-full bg-kyn-green animate-pulse" /> {t}
                  </div>
                </Fade>
              ))}
            </div>
            <div className="mt-8">
              <Link to="/console" className="inline-flex items-center gap-2 text-sm text-kyn-green font-semibold hover:gap-3 transition-all">
                Open live console <ArrowRight size={14} />
              </Link>
            </div>
          </div>
        </section>

        {/* 07 SMART HOME */}
        <section id="exp-home" className="relative min-h-screen snap-start flex items-end py-0">
          <div className="absolute inset-0">
            <img src="/images/experience-villa.jpg" alt="" className="w-full h-full object-cover scale-105" />
            <div className="absolute inset-0 bg-gradient-to-t from-black via-black/55 to-black/35" />
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_75%_65%,rgba(0,230,118,0.14),transparent_45%)]" />
          </div>
          <div className="relative z-10 max-w-7xl mx-auto px-5 md:px-8 pb-28 w-full">
            <Fade>
              <SectionLabel n="07" label="Smart Home" />
              <h2 className="font-display text-4xl md:text-6xl font-bold max-w-2xl tracking-tight">
                Luxury villa. Silent power.
              </h2>
              <p className="mt-4 text-kyn-silver max-w-lg leading-relaxed">
                NOVA / PRIME on the wall. Electric SUV docked under warm night light. Home energy, elevated.
              </p>
              <div className="mt-10 flex items-end gap-8">
                <motion.img
                  src="/images/products/nova-tethered.png"
                  alt="NOVA"
                  className="h-32 md:h-40 object-contain drop-shadow-2xl"
                  animate={{ y: [0, -8, 0] }}
                  transition={{ duration: 5, repeat: Infinity, ease: 'easeInOut' }}
                />
                <div className="pb-2">
                  <p className="text-xs text-kyn-green uppercase tracking-[0.25em]">Residential scene</p>
                  <p className="font-display font-semibold text-xl mt-1">NOVA at home</p>
                </div>
              </div>
            </Fade>
          </div>
        </section>

        {/* 08 COMMERCIAL */}
        <section id="exp-commercial" className="relative min-h-screen snap-start flex items-center py-24 bg-kyn-void border-y border-white/5">
          <div className="max-w-7xl mx-auto px-5 md:px-8 w-full">
            <Fade className="mb-12">
              <SectionLabel n="08" label="Commercial" />
              <h2 className="font-display text-4xl md:text-5xl font-bold tracking-tight">Hospitality to fleet depots.</h2>
            </Fade>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {[
                { t: 'Hotel', d: 'Guest charging with PRIME pearl finish', img: '/images/experience-hotel.jpg', icon: Hotel },
                { t: 'Office', d: 'Workplace bays supervised in Cloud', img: '/images/tunisia-architecture.jpg', icon: Building2 },
                { t: 'Retail & Mall', d: 'Destination charging, dwell-time value', img: '/images/ev-network.jpg', icon: MapPin },
                { t: 'Business parking', d: 'EDGE / PRO multi-bay layouts', img: '/images/charger-wall.jpg', icon: Car },
                { t: 'Fleet depot', d: 'Overnight smart load balancing', img: '/images/cloud-datacenter.jpg', icon: Zap },
                { t: 'Mixed campus', d: 'One operator, many tariffs', img: '/images/presentation.jpg', icon: Globe2 },
              ].map((c, i) => {
                const Icon = c.icon;
                return (
                  <Fade key={c.t} delay={i * 0.05}>
                    <motion.div
                      whileHover={{ y: -4 }}
                      className="group relative rounded-2xl overflow-hidden border border-white/8 min-h-[210px]"
                    >
                      <img
                        src={c.img}
                        alt=""
                        className="absolute inset-0 w-full h-full object-cover opacity-50 group-hover:scale-105 group-hover:opacity-60 transition-all duration-700"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black via-black/65 to-transparent" />
                      <div className="relative p-6 h-full flex flex-col justify-end min-h-[210px]">
                        <Icon size={18} className="text-kyn-green mb-3" />
                        <p className="font-display font-bold text-lg">{c.t}</p>
                        <p className="text-sm text-kyn-silver mt-1">{c.d}</p>
                      </div>
                    </motion.div>
                  </Fade>
                );
              })}
            </div>
          </div>
        </section>

        {/* 09 PUBLIC */}
        <section id="exp-public" className="relative min-h-screen snap-start flex items-center py-24">
          <div className="absolute inset-0">
            <img src="/images/hero-city.jpg" alt="" className="w-full h-full object-cover opacity-35" />
            <div className="absolute inset-0 bg-kyn-black/82" />
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_30%_50%,rgba(0,230,118,0.1),transparent_50%)]" />
          </div>
          <div className="relative z-10 max-w-7xl mx-auto px-5 md:px-8 w-full">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <Fade>
                <SectionLabel n="09" label="Public Infrastructure" />
                <h2 className="font-display text-4xl md:text-5xl font-bold tracking-tight">Urban corridors. Premium presence.</h2>
                <p className="mt-4 text-kyn-silver leading-relaxed">
                  Multi-charger hubs with digital screens, PRO / EDGE lineups and Cloud uptime for city-grade reliability.
                </p>
                <ul className="mt-8 space-y-3 text-sm text-kyn-silver">
                  {['Multi-bay PRO pedestals', 'Live availability on App map', 'OCPP roaming-ready', '24/7 remote supervision'].map((x) => (
                    <li key={x} className="flex items-center gap-2.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-kyn-green shadow-[0_0_8px_#00e676]" /> {x}
                    </li>
                  ))}
                </ul>
              </Fade>
              <Fade delay={0.1} className="flex justify-center gap-6">
                <motion.img
                  src="/images/products/pro-tethered.png"
                  alt="PRO"
                  className="h-72 md:h-96 object-contain"
                  animate={{ y: [0, -10, 0] }}
                  transition={{ duration: 5, repeat: Infinity, ease: 'easeInOut' }}
                />
                <motion.img
                  src="/images/products/edge-pedestal.png"
                  alt="EDGE"
                  className="h-72 md:h-96 object-contain mt-12"
                  animate={{ y: [0, 10, 0] }}
                  transition={{ duration: 5.5, repeat: Infinity, ease: 'easeInOut' }}
                />
              </Fade>
            </div>
          </div>
        </section>

        {/* 10 ACADEMY */}
        <section id="exp-academy" className="relative min-h-screen snap-start flex items-center py-24 bg-kyn-void border-y border-white/5">
          <div className="max-w-7xl mx-auto px-5 md:px-8 w-full">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <Fade>
                <div className="relative rounded-3xl overflow-hidden border border-white/10 min-h-[380px] shadow-2xl shadow-black/40">
                  <img src="/images/academy.jpg" alt="" className="absolute inset-0 w-full h-full object-cover" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black via-black/45 to-transparent" />
                  <div className="absolute bottom-7 left-7 right-7">
                    <p className="font-display text-2xl md:text-3xl font-bold">KYNETIK Academy</p>
                    <p className="text-sm text-kyn-silver mt-1">Certification for installers & engineers</p>
                  </div>
                </div>
              </Fade>
              <Fade delay={0.1}>
                <SectionLabel n="10" label="Academy" />
                <h2 className="font-display text-4xl md:text-5xl font-bold tracking-tight">
                  Train the network that installs the network.
                </h2>
                <div className="mt-8 grid grid-cols-2 gap-3">
                  {['Professional training', 'Certification paths', 'Installer guild', 'Online modules'].map((t) => (
                    <div key={t} className="rounded-xl border border-white/8 bg-black/35 px-4 py-3.5 text-sm backdrop-blur">
                      {t}
                    </div>
                  ))}
                </div>
                <Link to="/academy" className="mt-8 inline-flex items-center gap-2 text-sm text-kyn-green font-semibold hover:gap-3 transition-all">
                  Open Academy UI <ArrowRight size={14} />
                </Link>
              </Fade>
            </div>
          </div>
        </section>

        {/* 11 PRODUCTION */}
        <section id="exp-production" className="relative min-h-screen snap-start flex items-center py-24 overflow-hidden">
          <div className="absolute inset-0 opacity-25">
            <img src="/images/experience-factory.jpg" alt="" className="w-full h-full object-cover" />
            <div className="absolute inset-0 bg-kyn-black/85" />
          </div>
          <div className="max-w-7xl mx-auto px-5 md:px-8 w-full relative z-10">
            <Fade className="mb-12">
              <SectionLabel n="11" label="Production" />
              <h2 className="font-display text-4xl md:text-5xl font-bold tracking-tight">Engineering. Quality. Delivery.</h2>
            </Fade>
            <div className="grid md:grid-cols-5 gap-3">
              {[
                { t: 'Factory', i: Factory },
                { t: 'Quality control', i: Shield },
                { t: 'Engineering', i: Wrench },
                { t: 'Testing', i: Zap },
                { t: 'Packaging', i: Package },
              ].map((s, idx) => {
                const Icon = s.i;
                return (
                  <Fade key={s.t} delay={idx * 0.06}>
                    <motion.div
                      whileHover={{ y: -6 }}
                      className="rounded-2xl border border-white/10 bg-gradient-to-b from-white/[0.06] to-black/40 backdrop-blur p-6 min-h-[190px] flex flex-col justify-between"
                    >
                      <Icon size={22} className="text-kyn-green" />
                      <div>
                        <p className="font-mono text-[10px] text-kyn-metal tracking-widest">0{idx + 1}</p>
                        <p className="font-display font-semibold mt-1 text-lg">{s.t}</p>
                      </div>
                    </motion.div>
                  </Fade>
                );
              })}
            </div>
            <Fade className="mt-8">
              <Link to="/production" className="inline-flex items-center gap-2 text-sm text-kyn-green font-semibold hover:gap-3 transition-all">
                Production asset library <ArrowRight size={14} />
              </Link>
            </Fade>
          </div>
        </section>

        {/* 12 GLOBAL */}
        <section id="exp-global" className="relative min-h-screen snap-start flex items-center py-24 bg-kyn-void border-y border-white/5 overflow-hidden">
          <div className="absolute inset-0 opacity-40">
            <div className="absolute inset-0 grid-bg" />
            <motion.div
              className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-[75vmax] h-[75vmax] rounded-full border border-kyn-green/10"
              animate={{ rotate: 360 }}
              transition={{ duration: 90, repeat: Infinity, ease: 'linear' }}
            />
            <motion.div
              className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-[52vmax] h-[52vmax] rounded-full border border-kyn-green/15"
              animate={{ rotate: -360 }}
              transition={{ duration: 65, repeat: Infinity, ease: 'linear' }}
            />
            <motion.div
              className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-[32vmax] h-[32vmax] rounded-full border border-kyn-green/20"
              animate={{ rotate: 360 }}
              transition={{ duration: 40, repeat: Infinity, ease: 'linear' }}
            />
          </div>
          <div className="relative z-10 max-w-7xl mx-auto px-5 md:px-8 w-full">
            <Fade className="text-center mb-14">
              <SectionLabel n="12" label="Global Vision" />
              <h2 className="font-display text-4xl md:text-6xl font-bold tracking-tight">From Tunisia to the world.</h2>
            </Fade>
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {[
                { r: 'Tunisia', s: 'Home market · HQ', p: 'Now' },
                { r: 'North Africa', s: 'Corridors & fleets', p: 'Phase 2' },
                { r: 'Middle East', s: 'Hospitality & smart cities', p: 'Phase 3' },
                { r: 'Europe', s: 'Partners & roaming', p: 'Horizon' },
              ].map((x, i) => (
                <Fade key={x.r} delay={i * 0.08}>
                  <div className="rounded-2xl border border-kyn-green/25 bg-black/45 backdrop-blur p-7 text-center relative overflow-hidden min-h-[200px] flex flex-col justify-center">
                    <motion.div
                      className="absolute inset-0 bg-kyn-green/[0.07]"
                      animate={{ opacity: [0.15, 0.55, 0.15] }}
                      transition={{ duration: 3.2 + i, repeat: Infinity }}
                    />
                    <MapPin className="mx-auto text-kyn-green mb-3 relative drop-shadow-[0_0_12px_rgba(0,230,118,0.6)]" size={22} />
                    <p className="font-display text-xl font-bold relative">{x.r}</p>
                    <p className="text-sm text-kyn-silver mt-2 relative">{x.s}</p>
                    <p className="text-[10px] uppercase tracking-[0.25em] text-kyn-green mt-5 relative font-semibold">{x.p}</p>
                  </div>
                </Fade>
              ))}
            </div>
          </div>
        </section>

        {/* 13 INVESTOR */}
        <section id="exp-investor" className="relative min-h-screen snap-start flex items-center py-24">
          <div className="max-w-7xl mx-auto px-5 md:px-8 w-full">
            <Fade className="mb-12">
              <SectionLabel n="13" label="Investor" />
              <h2 className="font-display text-4xl md:text-5xl font-bold tracking-tight">Boardroom clarity.</h2>
            </Fade>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
              {investorSlides.map((s, i) => (
                <Fade key={s.k} delay={i * 0.07}>
                  <div className="rounded-2xl border border-white/10 bg-gradient-to-b from-kyn-steel/60 to-transparent p-6 min-h-[190px] relative overflow-hidden">
                    <div className="absolute top-0 inset-x-0 h-px bg-gradient-to-r from-transparent via-kyn-green/50 to-transparent" />
                    <p className="text-[10px] uppercase tracking-[0.3em] text-kyn-metal">{s.k}</p>
                    <p className="font-display text-3xl md:text-4xl font-bold text-kyn-green text-glow mt-5">{s.v}</p>
                    <p className="text-sm text-kyn-silver mt-3 leading-relaxed">{s.d}</p>
                  </div>
                </Fade>
              ))}
            </div>
            <Fade>
              <div className="rounded-2xl border border-white/10 bg-kyn-void/90 p-6 md:p-9 backdrop-blur">
                <div className="flex items-center gap-2 mb-7">
                  <TrendingUp size={16} className="text-kyn-green" />
                  <p className="text-sm font-semibold tracking-wide">Roadmap</p>
                </div>
                <div className="grid sm:grid-cols-4 gap-3">
                  {roadmap.map((r, i) => (
                    <div key={r} className="relative rounded-xl border border-white/8 bg-black/40 px-4 py-5">
                      <p className="font-mono text-[10px] text-kyn-green tracking-widest">0{i + 1}</p>
                      <p className="font-medium text-sm mt-2">{r}</p>
                      {i < roadmap.length - 1 && (
                        <div className="hidden sm:block absolute top-1/2 -right-1.5 w-3 h-px bg-kyn-green/50" />
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </Fade>
            <div className="mt-8">
              <Link to="/investor" className="inline-flex items-center gap-2 text-sm text-kyn-green font-semibold hover:gap-3 transition-all">
                Investor deck module <ArrowRight size={14} />
              </Link>
            </div>
          </div>
        </section>

        {/* 14 CLOSE */}
        <section id="exp-close" className="relative min-h-screen snap-start flex items-center justify-center py-24 overflow-hidden">
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(0,230,118,0.14),transparent_55%)]" />
          {PARTICLES.slice(0, 22).map((p) => (
            <motion.span
              key={`c-${p.id}`}
              className="absolute rounded-full bg-kyn-green/55"
              style={{ left: `${p.x}%`, top: `${p.y}%`, width: p.s, height: p.s }}
              animate={{ opacity: [0.08, 0.75, 0.08], scale: [1, 1.5, 1] }}
              transition={{ duration: p.d, repeat: Infinity, delay: p.delay }}
            />
          ))}
          <div className="relative z-10 text-center px-6 max-w-3xl">
            <Fade>
              <motion.div
                animate={{ scale: [1, 1.04, 1], filter: ['drop-shadow(0 0 20px rgba(0,230,118,0.3))', 'drop-shadow(0 0 48px rgba(0,230,118,0.55))', 'drop-shadow(0 0 20px rgba(0,230,118,0.3))'] }}
                transition={{ duration: 4.5, repeat: Infinity, ease: 'easeInOut' }}
              >
                <BrandLogo height={60} className="mx-auto justify-center" />
              </motion.div>
              <h2 className="mt-12 font-display text-4xl md:text-6xl lg:text-7xl font-bold tracking-tight">
                Powering the <span className="text-kyn-green text-glow">Future.</span>
              </h2>
              <p className="mt-7 text-kyn-silver tracking-wide">www.kynetik.tn · cloud@kynetik.tn · Tunis</p>
              <div className="mt-12 flex flex-wrap justify-center gap-3">
                <Link
                  to="/"
                  className="inline-flex items-center gap-2 px-8 py-4 rounded-full bg-kyn-green text-kyn-black text-sm font-bold glow-green hover:bg-kyn-green-glow transition-colors"
                >
                  Enter website <ArrowRight size={16} />
                </Link>
                <Link
                  to="/showcase"
                  className="inline-flex items-center gap-2 px-8 py-4 rounded-full border border-white/15 text-sm font-medium hover:bg-white/5 transition-colors"
                >
                  Portfolio showcase
                </Link>
                <Link
                  to="/product-system"
                  className="inline-flex items-center gap-2 px-8 py-4 rounded-full border border-white/15 text-sm font-medium hover:bg-white/5 transition-colors"
                >
                  Product system
                </Link>
              </div>
              <motion.p
                className="mt-20 text-[10px] tracking-[0.4em] uppercase text-kyn-metal"
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                transition={{ delay: 0.6 }}
              >
                End of experience · KYNETIK Premium Brand
              </motion.p>
            </Fade>
          </div>
        </section>
      </div>
    </div>
  );
}

import { useEffect, useState, type ComponentType, type ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  ArrowRight, CheckCircle2, Palette, Smartphone, Cloud, Package, Code2,
  Layout, Type, MousePointer2, FormInput, Shapes, Layers, Monitor,
  Tablet, MapPin, Zap, History, Leaf, Bell, Play, Square, Gauge,
  User, Car, CreditCard, Building2, Users, BarChart3, Radio, Server,
  FileText, Database, Workflow, BookOpen, Rocket, Menu, X, Shield,
  Terminal, GitBranch, Boxes
} from 'lucide-react';
import BrandLogo from '../components/BrandLogo';
import { cn } from '../lib/utils';

function Fade({ children, className, delay = 0 }: { children: ReactNode; className?: string; delay?: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-40px' }}
      transition={{ duration: 0.5, delay }}
      className={className}
    >
      {children}
    </motion.div>
  );
}

const phases = [
  {
    id: '18',
    phase: 'Phase 18',
    title: 'Design System',
    status: 'Complete',
    icon: Palette,
    color: '#00e676',
    summary: 'Logo DNA, colors, type, primitives, components library, responsive rules — locked for delivery.',
    links: [
      { to: '/design-system/hub', label: 'System Hub' },
      { to: '/components', label: 'Component Library' },
      { to: '/design-system/tokens', label: 'Tokens' },
      { to: '/brand', label: 'Brand DNA' },
      { to: '/ui', label: 'UI Tokens' },
    ],
    checklist: [
      'Logo system (bolt mark + lockups + favicon)',
      'Color palette (black / green / metal / status)',
      'Typography (Inter + Space Grotesk)',
      'Buttons · Cards · Forms · Inputs',
      'Icons (Lucide) + status patterns',
      'Responsive: Mobile · Tablet · Desktop',
    ],
  },
  {
    id: '19',
    phase: 'Phase 19',
    title: 'Customer App',
    status: 'Complete',
    icon: Smartphone,
    color: '#3b82f6',
    summary: 'Real customer account: chargers, history, energy, CO₂, map, control, vehicles, payments.',
    links: [
      { to: '/kynetik-app', label: 'Mobile App UX' },
      { to: '/portal', label: 'Customer Portal' },
      { to: '/portal/chargers', label: 'Charger Control' },
      { to: '/portal/map', label: 'Station Map' },
      { to: '/portal/energy', label: 'Energy & CO₂' },
      { to: '/app', label: 'Mobile UX library' },
      { to: '/app-landing', label: 'App Landing' },
    ],
    checklist: [
      'Dashboard · My chargers · History',
      'Energy consumption · Cost · CO₂ saved',
      'Start / Stop · Schedule · Power limit',
      'Map · Availability · Navigation',
      'Profile · Vehicles · Payments · Subscriptions',
    ],
  },
  {
    id: '20',
    phase: 'Phase 20',
    title: 'Cloud Platform',
    status: 'Complete',
    icon: Cloud,
    color: '#22d3ee',
    summary: 'Operator command center: stations, fleets, users, billing, analytics, OCPP, remote diagnostics.',
    links: [
      { to: '/architecture', label: 'Cloud Dashboard' },
      { to: '/cloud', label: 'Cloud Marketing' },
      { to: '/admin', label: 'Enterprise Admin' },
      { to: '/developers', label: 'API Platform' },
      { to: '/ai-platform', label: 'AI Layer' },
    ],
    checklist: [
      'Stations management + live telemetry',
      'Fleet · Users · Payments · Reports',
      'Analytics · Remote diagnostics',
      'OCPP 1.6J · IoT monitoring',
      'Developer API · Webhooks · Keys',
    ],
  },
  {
    id: '21',
    phase: 'Phase 21',
    title: 'Product Pages',
    status: 'Complete',
    icon: Package,
    color: '#a78bfa',
    summary: 'Full family: GO · FLEX · NOVA · PRIME · EDGE · PRO — hero, specs, install, compatibility, CTA.',
    links: [
      { to: '/products', label: 'Product Catalog' },
      { to: '/products/go', label: 'GO' },
      { to: '/products/flex', label: 'FLEX' },
      { to: '/products/nova', label: 'NOVA' },
      { to: '/products/prime', label: 'PRIME' },
      { to: '/products/edge', label: 'EDGE' },
      { to: '/products/pro', label: 'PRO' },
      { to: '/products/compare', label: 'Compare' },
      { to: '/configurator', label: 'Configurator' },
    ],
    checklist: [
      'GO 3.7 / 7 kW · FLEX 7 kW',
      'NOVA / PRIME / EDGE 7·11·22 kW',
      'PRO 22 / 44 kW dual charging',
      'Hero · Specs · Advantages · Install',
      'Compatibility · Downloads · CTA quote',
    ],
  },
  {
    id: '22',
    phase: 'Phase 22',
    title: 'Developer Handoff',
    status: 'Complete',
    icon: Code2,
    color: '#f59e0b',
    summary: 'Everything a pro eng team needs: tokens, components, flows, API, DB, roadmap.',
    links: [
      { to: '/dev-handoff', label: 'Handoff Package' },
      { to: '/handoff', label: 'Classic Handoff' },
      { to: '/database', label: 'Database Architecture' },
      { to: '/docs-suite', label: 'Docs Suite' },
      { to: '/ux-journeys', label: 'User Flows' },
      { to: '/prototype', label: 'Interactive Prototype' },
    ],
    checklist: [
      'Design tokens + component docs',
      'User flows + interactive prototype',
      'API requirements + OCPP notes',
      'Database structure',
      'Development roadmap (MVP → scale)',
    ],
  },
];

const stack = [
  { icon: Monitor, t: 'Web', d: 'Marketing + product + portal' },
  { icon: Smartphone, t: 'Customer App', d: 'Account · control · map' },
  { icon: Cloud, t: 'Cloud', d: 'B2B ops · OCPP · fleets' },
  { icon: Terminal, t: 'Developers', d: 'API · SDKs · webhooks' },
  { icon: Database, t: 'Data', d: 'Supabase Postgres' },
  { icon: Boxes, t: 'Design System', d: 'Tokens · UI kit · brand' },
];

export default function DeliveryArchitecture() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 16);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <div className="min-h-screen bg-kyn-black text-white">
      <header
        className={cn(
          'fixed top-0 inset-x-0 z-50 transition-all',
          scrolled ? 'bg-kyn-black/90 backdrop-blur-xl border-b border-white/5' : 'bg-transparent'
        )}
      >
        <div className="max-w-7xl mx-auto px-5 md:px-8 h-16 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-3">
            <BrandLogo height={28} />
            <span className="hidden sm:inline text-[10px] font-semibold tracking-[0.2em] uppercase text-kyn-green border border-kyn-green/30 rounded-full px-2 py-0.5">
              Delivery
            </span>
          </Link>
          <nav className="hidden lg:flex items-center gap-6 text-xs text-kyn-silver">
            {phases.map((p) => (
              <a key={p.id} href={`#p${p.id}`} className="hover:text-white transition-colors">
                {p.phase}
              </a>
            ))}
          </nav>
          <div className="flex items-center gap-2">
            <Link
              to="/dev-handoff"
              className="hidden sm:inline-flex items-center gap-2 px-4 py-2 rounded-full bg-kyn-green text-kyn-black text-xs font-bold"
            >
              Open handoff <ArrowRight size={14} />
            </Link>
            <button type="button" className="lg:hidden p-2" onClick={() => setMenuOpen(!menuOpen)} aria-label="Menu">
              {menuOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </div>
      </header>

      <section className="relative pt-28 md:pt-36 pb-16 overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(0,230,118,0.14),transparent_55%)]" />
        <div className="absolute inset-0 grid-bg opacity-30" />
        <div className="relative z-10 max-w-7xl mx-auto px-5 md:px-8">
          <Fade>
            <p className="text-kyn-green text-xs font-semibold tracking-[0.3em] uppercase mb-4">
              Phases 18 → 22
            </p>
            <h1 className="font-display text-4xl md:text-6xl font-bold tracking-tight max-w-4xl leading-[1.05]">
              KYNETIK Digital Product Architecture
            </h1>
            <p className="mt-5 text-lg text-kyn-silver max-w-2xl leading-relaxed">
              Design system locked. Customer app, Cloud platform, product pages and developer handoff —
              ready for a professional engineering team to build and ship.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link to="/portal" className="inline-flex items-center gap-2 px-5 py-3 rounded-full bg-kyn-green text-kyn-black text-sm font-bold">
                Customer App <ArrowRight size={16} />
              </Link>
              <Link to="/console" className="inline-flex items-center gap-2 px-5 py-3 rounded-full border border-white/15 text-sm font-semibold hover:border-kyn-green/40">
                Cloud Dashboard
              </Link>
              <Link to="/products" className="inline-flex items-center gap-2 px-5 py-3 rounded-full border border-white/15 text-sm font-semibold hover:border-kyn-green/40">
                Product Pages
              </Link>
              <Link to="/dev-handoff" className="inline-flex items-center gap-2 px-5 py-3 rounded-full border border-white/15 text-sm font-semibold hover:border-kyn-green/40">
                Dev Package
              </Link>
            </div>
          </Fade>

          <div className="mt-14 grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
            {stack.map(({ icon: Icon, t, d }, i) => (
              <Fade key={t} delay={i * 0.04}>
                <div className="rounded-2xl border border-white/8 bg-white/[0.03] p-4 h-full">
                  <Icon size={18} className="text-kyn-green mb-3" />
                  <p className="font-semibold text-sm">{t}</p>
                  <p className="text-[11px] text-kyn-metal mt-1">{d}</p>
                </div>
              </Fade>
            ))}
          </div>
        </div>
      </section>

      <section className="pb-24">
        <div className="max-w-7xl mx-auto px-5 md:px-8 space-y-8">
          {phases.map((p, idx) => {
            const Icon = p.icon;
            return (
              <Fade key={p.id} delay={0.05}>
                <article
                  id={`p${p.id}`}
                  className="scroll-mt-24 rounded-3xl border border-white/8 bg-gradient-to-b from-white/[0.04] to-transparent overflow-hidden"
                >
                  <div className="grid lg:grid-cols-[1.1fr_1fr] gap-0">
                    <div className="p-6 md:p-10 border-b lg:border-b-0 lg:border-r border-white/8">
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex items-center gap-3">
                          <div
                            className="w-11 h-11 rounded-2xl border flex items-center justify-center"
                            style={{ borderColor: `${p.color}44`, background: `${p.color}14`, color: p.color }}
                          >
                            <Icon size={20} />
                          </div>
                          <div>
                            <p className="text-[11px] uppercase tracking-[0.22em] font-semibold" style={{ color: p.color }}>
                              {p.phase}
                            </p>
                            <h2 className="font-display text-2xl md:text-3xl font-bold">{p.title}</h2>
                          </div>
                        </div>
                        <span className="text-[10px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-full border border-kyn-green/30 text-kyn-green bg-kyn-green/10 shrink-0">
                          {p.status}
                        </span>
                      </div>
                      <p className="mt-5 text-kyn-silver leading-relaxed">{p.summary}</p>
                      <ul className="mt-6 space-y-2.5">
                        {p.checklist.map((c) => (
                          <li key={c} className="flex items-start gap-2.5 text-sm text-kyn-silver">
                            <CheckCircle2 size={15} className="text-kyn-green shrink-0 mt-0.5" />
                            {c}
                          </li>
                        ))}
                      </ul>
                    </div>
                    <div className="p-6 md:p-10 bg-black/20">
                      <p className="text-[11px] uppercase tracking-wider text-kyn-metal font-semibold mb-4">
                        Open live surfaces
                      </p>
                      <div className="flex flex-wrap gap-2">
                        {p.links.map((l) => (
                          <Link
                            key={l.to}
                            to={l.to}
                            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-full border border-white/10 bg-white/[0.03] text-xs font-semibold hover:border-kyn-green/40 hover:text-kyn-green transition-colors"
                          >
                            {l.label} <ArrowRight size={12} />
                          </Link>
                        ))}
                      </div>
                      <div className="mt-8 rounded-2xl border border-white/8 p-5 bg-kyn-void/60">
                        <p className="text-xs text-kyn-metal uppercase tracking-wider mb-2">Delivery order</p>
                        <p className="text-sm text-kyn-silver">
                          {idx === 0 && 'Foundation for all surfaces — do not restyle without design review.'}
                          {idx === 1 && 'Ship customer value first: control, history, billing, map.'}
                          {idx === 2 && 'B2B ops layer on the same OCPP + data plane as the app.'}
                          {idx === 3 && 'Catalog drives quote → install → portal attach rate.'}
                          {idx === 4 && 'Hand this package to engineering — tokens, APIs, schema, roadmap.'}
                        </p>
                      </div>
                    </div>
                  </div>
                </article>
              </Fade>
            );
          })}
        </div>
      </section>

      <section className="py-16 border-t border-white/5">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <Fade>
            <div className="rounded-3xl border border-kyn-green/25 bg-kyn-green/5 p-8 md:p-12 flex flex-col md:flex-row md:items-center justify-between gap-6">
              <div>
                <p className="text-kyn-green text-xs font-semibold tracking-[0.25em] uppercase mb-2">Ready for engineering</p>
                <h3 className="font-display text-2xl md:text-3xl font-bold">Start from the handoff package</h3>
                <p className="mt-2 text-kyn-silver max-w-xl text-sm">
                  Tokens, routes, user flows, API contracts, database map and MVP roadmap — one place.
                </p>
              </div>
              <div className="flex flex-wrap gap-3">
                <Link to="/dev-handoff" className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-kyn-green text-kyn-black text-sm font-bold">
                  Developer Handoff <Rocket size={16} />
                </Link>
                <Link to="/showcase" className="inline-flex items-center gap-2 px-6 py-3 rounded-full border border-white/15 text-sm font-semibold">
                  Final Showcase
                </Link>
              </div>
            </div>
          </Fade>
        </div>
      </section>

      <footer className="border-t border-white/5 py-8">
        <div className="max-w-7xl mx-auto px-5 md:px-8 flex flex-wrap justify-between gap-3 items-center">
          <BrandLogo height={24} />
          <p className="text-[11px] text-kyn-metal">Phases 18–22 · Design → App → Cloud → Products → Handoff</p>
        </div>
      </footer>
    </div>
  );
}

import { useEffect, useState, type ComponentType, type ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  ArrowRight, Zap, MapPin, Bell, CreditCard, BarChart3, QrCode, Car,
  Shield, Sparkles, Cloud, Smartphone, Battery, Navigation, Check,
  Menu, X, Star, Lock, Wallet, Cpu, Radio, ChevronRight, Play,
  Calendar, Share2, Truck, GraduationCap, Store, Gift, BookOpen, Layers
} from 'lucide-react';
import BrandLogo from '../components/BrandLogo';
import LoadingState from '../components/LoadingState';
import AppDownloadCTA from '../components/AppDownloadCTA';
import {
  SplashScreen, DashboardScreen, ChargingScreen, MapScreen,
  AnalyticsScreen, PaymentsScreen, ProfileScreen
} from '../components/mobile/screens';
import { apiGet, cn } from '../lib/utils';

interface Item {
  id: number;
  type: string;
  title: string;
  subtitle: string;
  body: string;
  meta: string | null;
  icon: string | null;
  sort_order: number;
}

const iconMap: Record<string, ComponentType<{ size?: number; className?: string }>> = {
  zap: Zap, map: MapPin, bell: Bell, card: CreditCard, chart: BarChart3,
  qr: QrCode, car: Car, shield: Shield, spark: Sparkles, cloud: Cloud,
  phone: Smartphone, battery: Battery, nav: Navigation, lock: Lock,
  wallet: Wallet, cpu: Cpu, radio: Radio,
};

function Fade({ children, className, delay = 0 }: { children: ReactNode; className?: string; delay?: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 28 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-50px' }}
      transition={{ duration: 0.55, delay, ease: [0.22, 1, 0.36, 1] }}
      className={className}
    >
      {children}
    </motion.div>
  );
}

function PhoneShell({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <div className={cn('relative', className)}>
      <div className="absolute -inset-8 rounded-full bg-kyn-blue/20 blur-3xl" />
      <div className="relative w-[260px] sm:w-[280px] h-[540px] sm:h-[580px] rounded-[2.8rem] p-[3px] bg-gradient-to-b from-kyn-blue-bright/80 via-white/20 to-kyn-blue/40 shadow-2xl shadow-kyn-blue/30">
        <div className="w-full h-full rounded-[2.65rem] bg-black p-2 overflow-hidden">
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-28 h-6 bg-black rounded-b-2xl z-30" />
          <div className="w-full h-full rounded-[2.2rem] overflow-hidden bg-kyn-black relative">
            {children}
          </div>
        </div>
      </div>
    </div>
  );
}

function FloatIcon({
  icon: Icon, label, className, delay = 0,
}: {
  icon: ComponentType<{ size?: number; className?: string }>;
  label: string;
  className?: string;
  delay?: number;
}) {
  return (
    <motion.div
      className={cn('absolute z-20', className)}
      animate={{ y: [0, -10, 0] }}
      transition={{ duration: 4 + delay, repeat: Infinity, ease: 'easeInOut', delay }}
    >
      <div className="rounded-2xl border border-white/15 bg-white/10 backdrop-blur-xl px-3 py-2.5 shadow-xl shadow-kyn-blue/10 flex items-center gap-2">
        <div className="w-8 h-8 rounded-xl bg-kyn-blue/20 border border-kyn-blue/40 flex items-center justify-center text-kyn-blue-bright">
          <Icon size={15} />
        </div>
        <span className="text-[11px] font-semibold text-white pr-1">{label}</span>
      </div>
    </motion.div>
  );
}

export default function AppLanding() {
  const [items, setItems] = useState<Item[]>([]);
  const [loading, setLoading] = useState(true);
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [screen, setScreen] = useState(0);

  useEffect(() => {
    apiGet<Item[]>('/api/app-landing')
      .then(setItems)
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 30);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    const t = setInterval(() => setScreen((s) => (s + 1) % 5), 4200);
    return () => clearInterval(t);
  }, []);

  const by = (t: string) => items.filter((i) => i.type === t).sort((a, b) => a.sort_order - b.sort_order);
  const features = by('feature');
  const journey = by('journey');
  const plans = by('plan');
  const security = by('security');

  const screens = [
    { name: 'Home', node: <DashboardScreen /> },
    { name: 'Charging', node: <ChargingScreen /> },
    { name: 'Map', node: <MapScreen /> },
    { name: 'Energy', node: <AnalyticsScreen /> },
    { name: 'Wallet', node: <PaymentsScreen /> },
  ];

  if (loading) {
    return (
      <div className="min-h-screen bg-[#030712] flex items-center justify-center">
        <LoadingState label="Loading KYNETIK App…" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#030712] text-white overflow-x-hidden">
      {/* NAV */}
      <header className={cn(
        'fixed top-0 inset-x-0 z-50 transition-all duration-300',
        scrolled ? 'bg-[#030712]/85 backdrop-blur-xl border-b border-white/5' : 'bg-transparent'
      )}>
        <div className="max-w-7xl mx-auto px-5 md:px-8 h-16 md:h-20 flex items-center justify-between">
          <a href="#top" className="flex items-center gap-3">
            <BrandLogo height={30} />
            <span className="hidden sm:inline text-[10px] font-bold tracking-[0.22em] uppercase text-kyn-blue-bright border border-kyn-blue/40 rounded-full px-2.5 py-0.5">
              App
            </span>
          </a>
          <nav className="hidden lg:flex items-center gap-7 text-xs font-medium text-white/60">
            {[
              ['#journey', 'Journey'],
              ['#features', 'Features'],
              ['#screens', 'Screens'],
              ['#ecosystem', 'Ecosystem'],
              ['#platform', 'Platform'],
              ['#plans', 'Plans'],
            ].map(([h, l]) => (
              <a key={h} href={h} className="hover:text-white transition-colors">{l}</a>
            ))}
          </nav>
          <div className="flex items-center gap-3">
            <Link to="/product-system" className="hidden md:inline text-xs text-white/40 hover:text-white">Products</Link>
            <a href="#download" className="hidden sm:inline-flex items-center gap-2 px-4 py-2 rounded-full bg-kyn-blue text-white text-xs font-bold hover:bg-kyn-blue-bright transition-colors shadow-lg shadow-kyn-blue/30">
              Get the App <ArrowRight size={13} />
            </a>
            <button type="button" className="lg:hidden p-2 text-white/70" onClick={() => setMenuOpen(!menuOpen)}>
              {menuOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </div>
        {menuOpen && (
          <div className="lg:hidden border-t border-white/5 bg-[#030712]/95 px-5 py-4 space-y-2">
            {['#journey', '#features', '#screens', '#ecosystem', '#plans', '#download'].map((h) => (
              <a key={h} href={h} onClick={() => setMenuOpen(false)} className="block py-2 text-sm text-white/70 capitalize">{h.slice(1)}</a>
            ))}
          </div>
        )}
      </header>

      {/* HERO */}
      <section id="top" className="relative min-h-screen flex items-center pt-24 pb-16 overflow-hidden">
        <div className="absolute inset-0">
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_50%_0%,rgba(59,130,246,0.28),transparent_55%)]" />
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_80%_60%,rgba(34,211,238,0.1),transparent_40%)]" />
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_20%_80%,rgba(0,230,118,0.08),transparent_35%)]" />
          <div className="absolute inset-0 opacity-50" style={{
            backgroundImage: 'linear-gradient(rgba(59,130,246,0.06) 1px, transparent 1px), linear-gradient(90deg, rgba(59,130,246,0.06) 1px, transparent 1px)',
            backgroundSize: '56px 56px',
          }} />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-5 md:px-8 w-full">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-8 items-center">
            <motion.div initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7 }}>
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-kyn-blue/40 bg-kyn-blue/10 text-kyn-blue-bright text-[11px] font-semibold mb-6">
                <Sparkles size={13} /> Foundation of Tunisia’s electric mobility platform
              </div>
              <h1 className="font-display text-4xl sm:text-5xl md:text-6xl lg:text-[3.6rem] font-bold leading-[1.06] tracking-tight">
                Your Charger.
                <br />
                Your Energy.
                <br />
                <span className="bg-gradient-to-r from-kyn-blue-bright via-kyn-cyan to-kyn-green bg-clip-text text-transparent">
                  Your Control.
                </span>
              </h1>
              <p className="mt-6 text-base md:text-lg text-white/60 max-w-lg leading-relaxed">
                KYNETIK App is not a simple charger companion — it is the daily control center between
                user, charger, cloud, vehicle, payments and analytics. Tesla-simple. Enterprise-ready.
              </p>
              <div className="mt-9 flex flex-wrap gap-3">
                <a href="#download" className="inline-flex items-center gap-2 px-6 py-3.5 rounded-full bg-kyn-blue text-white text-sm font-bold shadow-xl shadow-kyn-blue/35 hover:bg-kyn-blue-bright transition-colors">
                  Download free <ArrowRight size={16} />
                </a>
                <a href="#screens" className="inline-flex items-center gap-2 px-6 py-3.5 rounded-full border border-white/15 text-sm font-medium hover:bg-white/5 transition-colors">
                  <Play size={14} /> See the experience
                </a>
              </div>
              <div className="mt-10 flex flex-wrap gap-6 text-sm">
                {[
                  { v: '4.9', l: 'User rating' },
                  { v: '50k+', l: 'Sessions' },
                  { v: '99.9%', l: 'Uptime' },
                ].map((s) => (
                  <div key={s.l}>
                    <p className="font-display text-2xl font-bold text-white">{s.v}</p>
                    <p className="text-[11px] text-white/40 uppercase tracking-wider mt-0.5">{s.l}</p>
                  </div>
                ))}
              </div>
            </motion.div>

            {/* Cinematic phone */}
            <div className="relative flex justify-center min-h-[560px] items-center">
              <FloatIcon icon={Zap} label="Charging 75%" className="top-8 left-0 sm:left-4" delay={0} />
              <FloatIcon icon={MapPin} label="Stations nearby" className="top-28 right-0 sm:right-2" delay={0.4} />
              <FloatIcon icon={Bell} label="Smart alerts" className="bottom-36 left-0 sm:left-2" delay={0.8} />
              <FloatIcon icon={CreditCard} label="Instant pay" className="bottom-16 right-2 sm:right-6" delay={1.1} />
              <FloatIcon icon={BarChart3} label="Analytics" className="top-1/2 -right-2 hidden sm:flex" delay={0.6} />

              <motion.div
                initial={{ opacity: 0, y: 40, scale: 0.94 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                transition={{ duration: 0.85, delay: 0.15 }}
              >
                <PhoneShell>
                  <motion.div
                    key={screen}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ duration: 0.35 }}
                    className="h-full"
                  >
                    {screens[screen].node}
                  </motion.div>
                </PhoneShell>
              </motion.div>
            </div>
          </div>
        </div>
      </section>

      {/* JOURNEY — light high-tech panel */}
      <section id="journey" className="py-24 md:py-28 relative bg-[#f4f6fa] text-kyn-charcoal">
        <div className="absolute inset-0 opacity-60" style={{
          backgroundImage: 'linear-gradient(rgba(15,23,42,0.04) 1px, transparent 1px), linear-gradient(90deg, rgba(15,23,42,0.04) 1px, transparent 1px)',
          backgroundSize: '48px 48px',
        }} />
        <div className="relative max-w-7xl mx-auto px-5 md:px-8">
          <Fade className="max-w-2xl mb-14">
            <p className="text-kyn-blue text-xs font-semibold tracking-[0.3em] uppercase mb-3">User journey</p>
            <h2 className="font-display text-3xl md:text-5xl font-bold text-slate-900">From arrival to departure</h2>
            <p className="mt-4 text-slate-500 leading-relaxed">
              A Tesla-simple flow designed for real Tunisian roads — discover, plug, pay, drive.
            </p>
          </Fade>

          <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-3">
            {(journey.length ? journey : [
              { id: 1, title: 'Arrive', body: 'Open map & locate available power', meta: '01', icon: 'nav' },
              { id: 2, title: 'Authenticate', body: 'QR, RFID or app one-tap start', meta: '02', icon: 'qr' },
              { id: 3, title: 'Charge', body: 'Live ring, power & time remaining', meta: '03', icon: 'zap' },
              { id: 4, title: 'Pay', body: 'Wallet, card or subscription', meta: '04', icon: 'wallet' },
              { id: 5, title: 'Depart', body: 'Receipt, CO₂ saved, next tip', meta: '05', icon: 'car' },
            ] as Item[]).map((step, i) => {
              const Icon = iconMap[step.icon || 'zap'] || Zap;
              return (
                <Fade key={step.id || step.title} delay={i * 0.06}>
                  <div className="h-full rounded-2xl border border-slate-200/80 bg-white shadow-sm shadow-slate-200/60 p-5 hover:border-kyn-blue/40 hover:shadow-md transition-all relative overflow-hidden">
                    <div className="absolute top-0 right-0 text-6xl font-display font-bold text-slate-900/[0.04] leading-none p-2">
                      {step.meta || `0${i + 1}`}
                    </div>
                    <div className="w-10 h-10 rounded-xl bg-blue-50 border border-blue-100 flex items-center justify-center text-kyn-blue mb-4">
                      <Icon size={18} />
                    </div>
                    <p className="text-[10px] text-kyn-blue font-semibold tracking-wider uppercase mb-1">
                      Step {step.meta || `0${i + 1}`}
                    </p>
                    <h3 className="font-display font-semibold text-lg text-slate-900">{step.title}</h3>
                    <p className="text-sm text-slate-500 mt-2 leading-relaxed">{step.body}</p>
                  </div>
                </Fade>
              );
            })}
          </div>
        </div>
      </section>

      {/* FEATURES */}
      <section id="features" className="py-24 md:py-28 bg-[#060b16] border-y border-white/5">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <Fade className="mb-14">
            <p className="text-kyn-blue-bright text-xs font-semibold tracking-[0.3em] uppercase mb-3">Advanced features</p>
            <h2 className="font-display text-3xl md:text-4xl font-bold max-w-xl">Everything drivers expect. More operators need.</h2>
          </Fade>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {(features.length ? features : []).map((f, i) => {
              const Icon = iconMap[f.icon || 'zap'] || Zap;
              return (
                <Fade key={f.id} delay={i * 0.05}>
                  <div className="group h-full rounded-2xl border border-white/10 bg-gradient-to-b from-white/[0.05] to-transparent p-6 hover:border-kyn-blue/40 transition-all">
                    <div className="w-11 h-11 rounded-2xl bg-kyn-blue/15 border border-kyn-blue/30 flex items-center justify-center text-kyn-blue-bright mb-4 group-hover:shadow-lg group-hover:shadow-kyn-blue/20 transition-shadow">
                      <Icon size={18} />
                    </div>
                    <h3 className="font-display font-semibold text-lg">{f.title}</h3>
                    {f.subtitle && <p className="text-xs text-kyn-blue-bright mt-1">{f.subtitle}</p>}
                    <p className="text-sm text-white/50 mt-3 leading-relaxed">{f.body}</p>
                  </div>
                </Fade>
              );
            })}
          </div>
        </div>
      </section>

      {/* SCREENS GALLERY */}
      <section id="screens" className="py-24 md:py-32">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <Fade className="text-center max-w-2xl mx-auto mb-14">
            <p className="text-kyn-blue-bright text-xs font-semibold tracking-[0.3em] uppercase mb-3">Real app screens</p>
            <h2 className="font-display text-3xl md:text-4xl font-bold">A dark, cinematic interface</h2>
            <p className="mt-4 text-white/50">Dashboard, live charging, Tesla-style map, analytics and wallet — one coherent system.</p>
          </Fade>

          <div className="flex gap-6 overflow-x-auto pb-6 snap-x justify-start lg:justify-center px-1">
            {[
              { n: 'Splash', el: <SplashScreen /> },
              { n: 'Dashboard', el: <DashboardScreen /> },
              { n: 'Charging', el: <ChargingScreen /> },
              { n: 'Map', el: <MapScreen /> },
              { n: 'Analytics', el: <AnalyticsScreen /> },
              { n: 'Payments', el: <PaymentsScreen /> },
              { n: 'Profile', el: <ProfileScreen /> },
            ].map((s, i) => (
              <Fade key={s.n} delay={i * 0.04} className="snap-center shrink-0">
                <div className="w-[200px]">
                  <div className="rounded-[2rem] p-[2px] bg-gradient-to-b from-kyn-blue/50 to-white/10">
                    <div className="rounded-[1.9rem] overflow-hidden bg-black h-[410px] relative">
                      <div className="origin-top-left scale-[0.715] w-[280px] h-[580px]">
                        {s.el}
                      </div>
                    </div>
                  </div>
                  <p className="text-center text-xs text-white/50 mt-3 font-medium">{s.n}</p>
                </div>
              </Fade>
            ))}
          </div>
        </div>
      </section>

      {/* QR + MULTI VEHICLE + AI */}
      <section className="py-24 md:py-28 bg-[#060b16] border-y border-white/5">
        <div className="max-w-7xl mx-auto px-5 md:px-8 grid lg:grid-cols-3 gap-5">
          {[
            {
              icon: QrCode,
              title: 'QR charging flow',
              body: 'Scan any KYNETIK station, confirm connector, start in under 3 seconds — no cable confusion.',
              points: ['Station identity verified', 'Connector picker', 'Remote start via Cloud'],
            },
            {
              icon: Car,
              title: 'Multi-vehicle management',
              body: 'Households and fleets manage several EVs with preferred chargers, plugs and billing profiles.',
              points: ['Vehicle garage', 'Default charge limits', 'Per-car history'],
            },
            {
              icon: Sparkles,
              title: 'AI recommendations',
              body: 'Personalized tips on when to charge, which station is free, and how to cut cost & CO₂.',
              points: ['Off-peak suggestions', 'Route-aware stops', 'Tariff intelligence'],
            },
          ].map((card, i) => (
            <Fade key={card.title} delay={i * 0.08}>
              <div className="h-full rounded-3xl border border-white/10 bg-white/[0.03] p-7 hover:border-kyn-blue/35 transition-colors">
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-kyn-blue/30 to-kyn-cyan/10 border border-kyn-blue/30 flex items-center justify-center text-kyn-blue-bright mb-5">
                  <card.icon size={22} />
                </div>
                <h3 className="font-display text-xl font-bold">{card.title}</h3>
                <p className="mt-3 text-sm text-white/50 leading-relaxed">{card.body}</p>
                <ul className="mt-6 space-y-2">
                  {card.points.map((p) => (
                    <li key={p} className="flex items-center gap-2 text-sm text-white/70">
                      <Check size={14} className="text-kyn-blue-bright shrink-0" /> {p}
                    </li>
                  ))}
                </ul>
              </div>
            </Fade>
          ))}
        </div>
      </section>

      {/* DATA VIZ STRIP */}
      <section className="py-16 border-y border-white/5 bg-[#050a12]">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <div className="grid md:grid-cols-4 gap-4">
            {[
              { l: 'Avg. session', v: '28 min', d: 'home NOVA' },
              { l: 'Cost clarity', v: '−18%', d: 'with off-peak AI' },
              { l: 'Start success', v: '99.2%', d: 'QR + Cloud' },
              { l: 'CO₂ tracked', v: '1.1 t', d: 'per active user / yr' },
            ].map((k, i) => (
              <Fade key={k.l} delay={i * 0.05}>
                <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-5 relative overflow-hidden">
                  <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-kyn-blue via-kyn-cyan to-kyn-green opacity-70" />
                  <p className="text-[10px] uppercase tracking-wider text-white/40">{k.l}</p>
                  <p className="font-display text-3xl font-bold mt-2 text-white">{k.v}</p>
                  <p className="text-xs text-kyn-blue-bright mt-1">{k.d}</p>
                </div>
              </Fade>
            ))}
          </div>
          <div className="mt-6 rounded-2xl border border-white/10 bg-black/40 p-5 md:p-6">
            <div className="flex items-center justify-between mb-4">
              <p className="text-xs font-semibold text-white/70">Weekly energy · elegant data viz</p>
              <BarChart3 size={14} className="text-kyn-blue-bright" />
            </div>
            <div className="h-28 flex items-end gap-1.5 md:gap-2">
              {[40, 55, 48, 70, 62, 85, 78, 90, 72, 88, 95, 80, 68, 74].map((h, i) => (
                <div
                  key={i}
                  className="flex-1 rounded-t-md bg-gradient-to-t from-kyn-blue/40 via-kyn-blue-bright/80 to-kyn-cyan"
                  style={{ height: `${h}%`, opacity: 0.55 + (i / 20) }}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* NOTIFICATIONS */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <div className="grid lg:grid-cols-2 gap-10 items-center">
            <Fade>
              <p className="text-kyn-blue-bright text-xs font-semibold tracking-[0.3em] uppercase mb-3">Smart notifications</p>
              <h2 className="font-display text-3xl md:text-4xl font-bold">Always one step ahead</h2>
              <p className="mt-4 text-white/50 leading-relaxed">
                Session complete, price drop nearby, fault on your home NOVA, subscription renewal —
                precise alerts without noise.
              </p>
              <div className="mt-8 space-y-3">
                {[
                  { t: 'Charge complete · 100%', s: 'NOVA Home · Garage', c: 'text-emerald-400' },
                  { t: 'Hub Lac 2 has 3 free DC', s: '1.2 km · 0.45 DT/kWh', c: 'text-kyn-blue-bright' },
                  { t: 'Off-peak window starts 22:00', s: 'Save ~18% tonight', c: 'text-kyn-cyan' },
                ].map((n) => (
                  <div key={n.t} className="flex items-start gap-3 rounded-2xl border border-white/10 bg-white/[0.03] p-4">
                    <div className="w-9 h-9 rounded-xl bg-kyn-blue/15 flex items-center justify-center shrink-0">
                      <Bell size={15} className="text-kyn-blue-bright" />
                    </div>
                    <div>
                      <p className={cn('text-sm font-semibold', n.c)}>{n.t}</p>
                      <p className="text-xs text-white/40 mt-0.5">{n.s}</p>
                    </div>
                  </div>
                ))}
              </div>
            </Fade>
            <Fade delay={0.1} className="flex justify-center">
              <PhoneShell>
                <div className="h-full bg-[#0a0e17] p-5 pt-12">
                  <p className="text-xs text-white/40 uppercase tracking-wider">Notifications</p>
                  <h3 className="font-display font-bold text-lg mt-1">Inbox</h3>
                  <div className="mt-5 space-y-2">
                    {['Session ended', 'Payment receipt', 'New station nearby', 'Firmware ready'].map((t, i) => (
                      <div key={t} className="rounded-xl border border-white/8 bg-white/[0.04] p-3 flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className={cn('w-2 h-2 rounded-full', i < 2 ? 'bg-kyn-blue-bright' : 'bg-white/20')} />
                          <span className="text-[11px]">{t}</span>
                        </div>
                        <ChevronRight size={12} className="text-white/30" />
                      </div>
                    ))}
                  </div>
                </div>
              </PhoneShell>
            </Fade>
          </div>
        </div>
      </section>

      {/* ECOSYSTEM */}
      <section id="ecosystem" className="py-24 md:py-32 relative overflow-hidden border-y border-white/5">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(59,130,246,0.12),transparent_55%)]" />
        <div className="relative z-10 max-w-7xl mx-auto px-5 md:px-8">
          <Fade className="text-center max-w-2xl mx-auto mb-14">
            <p className="text-kyn-blue-bright text-xs font-semibold tracking-[0.3em] uppercase mb-3">Ecosystem</p>
            <h2 className="font-display text-3xl md:text-4xl font-bold">App at the center of everything</h2>
            <p className="mt-4 text-white/50">Visually connected to cloud, charger, vehicle, payments and analytics.</p>
          </Fade>

          <Fade>
            <div className="relative rounded-3xl border border-kyn-blue/25 bg-[#060b16]/80 backdrop-blur-xl p-8 md:p-14">
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
                {[
                  { l: 'Vehicle', i: Car },
                  { l: 'Charger', i: Zap },
                  { l: 'KYNETIK App', i: Smartphone, hi: true },
                  { l: 'Cloud', i: Cloud },
                  { l: 'Payments', i: CreditCard },
                  { l: 'Analytics', i: BarChart3 },
                ].map(({ l, i: Icon, hi }) => (
                  <div key={l} className="flex flex-col items-center text-center">
                    <div className={cn(
                      'w-16 h-16 md:w-20 md:h-20 rounded-2xl border flex items-center justify-center mb-3',
                      hi
                        ? 'bg-kyn-blue/20 border-kyn-blue/60 text-kyn-blue-bright shadow-lg shadow-kyn-blue/30'
                        : 'bg-white/[0.03] border-white/10 text-white/70'
                    )}>
                      <Icon size={hi ? 28 : 22} />
                    </div>
                    <p className={cn('text-xs font-semibold', hi && 'text-kyn-blue-bright')}>{l}</p>
                  </div>
                ))}
              </div>
              <p className="mt-10 text-center text-sm text-white/40 max-w-xl mx-auto">
                Bidirectional session data · secure OCPP commands · wallet settlement · live energy graphs
              </p>
              <div className="mt-8 flex flex-wrap justify-center gap-3">
                <Link to="/cloud" className="text-xs font-semibold text-kyn-blue-bright inline-flex items-center gap-1 hover:gap-2 transition-all">
                  Explore Cloud platform <ArrowRight size={12} />
                </Link>
                <Link to="/product-system" className="text-xs font-semibold text-white/50 inline-flex items-center gap-1 hover:text-white transition-colors">
                  See chargers <ArrowRight size={12} />
                </Link>
              </div>
            </div>
          </Fade>
        </div>
      </section>

      {/* PLANS — light conversion surface */}
      <section id="plans" className="py-24 md:py-28 bg-[#f4f6fa] text-slate-900">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <Fade className="text-center mb-14">
            <p className="text-kyn-blue text-xs font-semibold tracking-[0.3em] uppercase mb-3">Subscriptions</p>
            <h2 className="font-display text-3xl md:text-4xl font-bold text-slate-900">Plans that scale with you</h2>
            <p className="mt-3 text-slate-500 max-w-lg mx-auto text-sm">Transparent pricing for drivers, power users and fleets — upgrade anytime from the app wallet.</p>
          </Fade>
          <div className="grid md:grid-cols-3 gap-5 max-w-5xl mx-auto">
            {(plans.length ? plans : [
              { id: 1, title: 'Free', subtitle: 'Drivers', body: 'Map, QR charge, basic history', meta: '0 DT', icon: null, type: 'plan', sort_order: 1 },
              { id: 2, title: 'Plus', subtitle: 'Power users', body: 'AI tips, multi-vehicle, priority support', meta: '19 DT/mo', icon: null, type: 'plan', sort_order: 2 },
              { id: 3, title: 'Fleet', subtitle: 'Business', body: 'Team wallets, reports, admin roles', meta: 'Custom', icon: null, type: 'plan', sort_order: 3 },
            ] as Item[]).map((p, i) => (
              <Fade key={p.id} delay={i * 0.07}>
                <div className={cn(
                  'h-full rounded-3xl border p-7 flex flex-col bg-white shadow-sm',
                  i === 1
                    ? 'border-kyn-blue/40 shadow-xl shadow-blue-500/10 ring-2 ring-kyn-blue/20'
                    : 'border-slate-200'
                )}>
                  {i === 1 && (
                    <span className="self-start text-[10px] font-bold uppercase tracking-wider text-kyn-blue bg-blue-50 px-2 py-1 rounded-full mb-3">
                      Popular
                    </span>
                  )}
                  <p className="text-xs text-slate-400 uppercase tracking-wider">{p.subtitle}</p>
                  <h3 className="font-display text-2xl font-bold mt-1 text-slate-900">{p.title}</h3>
                  <p className="font-display text-3xl font-bold text-kyn-blue mt-4">{p.meta}</p>
                  <p className="text-sm text-slate-500 mt-3 flex-1">{p.body}</p>
                  <a href="#download" className={cn(
                    'mt-6 text-center rounded-full py-3 text-xs font-bold transition-colors',
                    i === 1 ? 'bg-kyn-blue text-white hover:bg-blue-600' : 'border border-slate-200 text-slate-800 hover:bg-slate-50'
                  )}>
                    Choose {p.title}
                  </a>
                </div>
              </Fade>
            ))}
          </div>
        </div>
      </section>

      {/* SECURITY */}
      <section className="py-20 bg-[#060b16] border-y border-white/5">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <div className="grid lg:grid-cols-2 gap-10 items-start">
            <Fade>
              <p className="text-kyn-blue-bright text-xs font-semibold tracking-[0.3em] uppercase mb-3">Security</p>
              <h2 className="font-display text-3xl md:text-4xl font-bold">Bank-grade trust for energy sessions</h2>
              <p className="mt-4 text-white/50 leading-relaxed">
                Payments, identity and remote commands protected with enterprise patterns from the KYNETIK Cloud stack.
              </p>
            </Fade>
            <div className="grid sm:grid-cols-2 gap-3">
              {(security.length ? security : [
                { id: 1, title: 'Encrypted sessions', body: 'TLS everywhere, signed commands', icon: 'lock' },
                { id: 2, title: 'Secure wallet', body: 'Tokenized payments & receipts', icon: 'wallet' },
                { id: 3, title: 'Privacy controls', body: 'Granular notification & data choices', icon: 'shield' },
                { id: 4, title: 'Device trust', body: 'Station authenticity via Cloud', icon: 'radio' },
              ] as Item[]).map((s, i) => {
                const Icon = iconMap[s.icon || 'shield'] || Shield;
                return (
                  <Fade key={s.id || s.title} delay={i * 0.05}>
                    <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-5 h-full">
                      <Icon size={18} className="text-kyn-blue-bright mb-3" />
                      <p className="font-semibold">{s.title}</p>
                      <p className="text-sm text-white/45 mt-1">{s.body}</p>
                    </div>
                  </Fade>
                );
              })}
            </div>
          </div>
        </div>
      </section>

      {/* FUTURE PLATFORM */}
      <section id="platform" className="py-24 md:py-28 bg-[#060b16] border-y border-white/5">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <Fade className="max-w-3xl mb-14">
            <p className="text-kyn-green text-xs font-semibold tracking-[0.3em] uppercase mb-3">Strategic roadmap</p>
            <h2 className="font-display text-3xl md:text-4xl font-bold leading-tight">
              Built as a mobility platform — not a one-feature app
            </h2>
            <p className="mt-4 text-white/50 leading-relaxed">
              Today: home & public charging control. Tomorrow: the operating system of electric mobility in Tunisia —
              with modules ready for staged launch without redesigning the product DNA.
            </p>
          </Fade>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { icon: MapPin, t: 'Public station network', d: 'National discovery, roaming & live occupancy' },
              { icon: Calendar, t: 'Reservations', d: 'Book DC slots before you arrive' },
              { icon: Share2, t: 'Home charger sharing', d: 'Monetize NOVA / PRIME when idle' },
              { icon: Truck, t: 'Fleet management', d: 'Drivers, cost centers, depot smart charge' },
              { icon: GraduationCap, t: 'Academy integration', d: 'Certified installers & learning paths' },
              { icon: Store, t: 'Marketplace', d: 'Cables, wallboxes, accessories, services' },
              { icon: Gift, t: 'Rewards', d: 'kWh points, partner perks, loyalty tiers' },
              { icon: Layers, t: 'Open APIs', d: 'Partners plug into the same Cloud fabric' },
            ].map((m, i) => (
              <Fade key={m.t} delay={i * 0.04}>
                <div className="h-full rounded-2xl border border-white/10 bg-white/[0.03] p-5 hover:border-kyn-green/30 transition-colors">
                  <m.icon size={18} className="text-kyn-green mb-3" />
                  <p className="font-display font-semibold text-sm">{m.t}</p>
                  <p className="text-xs text-white/45 mt-2 leading-relaxed">{m.d}</p>
                </div>
              </Fade>
            ))}
          </div>
        </div>
      </section>

      {/* DESIGN BIBLE */}
      <section id="design-bible" className="py-24 md:py-28">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <div className="rounded-3xl border border-white/10 overflow-hidden bg-gradient-to-br from-[#0a1222] via-[#060b16] to-black">
            <div className="grid lg:grid-cols-2 gap-0">
              <Fade className="p-8 md:p-12 lg:p-14">
                <div className="inline-flex items-center gap-2 text-kyn-blue-bright text-xs font-semibold tracking-[0.25em] uppercase mb-4">
                  <BookOpen size={14} /> Recommended next step
                </div>
                <h2 className="font-display text-3xl md:text-4xl font-bold leading-tight">
                  Establish the KYNETIK Design Bible
                </h2>
                <p className="mt-5 text-white/55 leading-relaxed">
                  Before expanding Academy, Services and Company pages, lock an 80–120 page system that
                  guarantees speed, consistency and scalability across the full ecosystem — App, Cloud,
                  Product, Marketing and Investor surfaces.
                </p>
                <ul className="mt-8 space-y-3">
                  {[
                    'Brand voice, messaging pillars & tone by audience',
                    'Grids, spacing scale, type hierarchy & responsive rules',
                    'Component library, iconography & motion principles',
                    'Imagery direction, 3D product staging & UI states',
                  ].map((item) => (
                    <li key={item} className="flex items-start gap-3 text-sm text-white/70">
                      <Check size={16} className="text-kyn-blue-bright mt-0.5 shrink-0" />
                      {item}
                    </li>
                  ))}
                </ul>
                <div className="mt-10 flex flex-wrap gap-3">
                  <Link
                    to="/design-system"
                    className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-white text-kyn-black text-xs font-bold"
                  >
                    Open design system hub <ArrowRight size={14} />
                  </Link>
                  <Link
                    to="/tokens"
                    className="inline-flex items-center gap-2 px-6 py-3 rounded-full border border-white/15 text-xs font-medium hover:bg-white/5"
                  >
                    UI tokens
                  </Link>
                </div>
              </Fade>
              <Fade delay={0.1} className="relative p-8 md:p-12 border-t lg:border-t-0 lg:border-l border-white/10 bg-black/30">
                <p className="text-[10px] uppercase tracking-[0.3em] text-white/35 mb-6">Bible outline · 10 chapters</p>
                <div className="space-y-2">
                  {[
                    ['01', 'Brand foundation & voice'],
                    ['02', 'Color · light / dark dual system'],
                    ['03', 'Typography & editorial rules'],
                    ['04', 'Layout grids & spacing'],
                    ['05', 'Components & patterns'],
                    ['06', 'Iconography & motion'],
                    ['07', 'Product photography & 3D'],
                    ['08', 'App & Cloud UI standards'],
                    ['09', 'Marketing & social templates'],
                    ['10', 'Accessibility & responsive QA'],
                  ].map(([n, t]) => (
                    <div key={n} className="flex items-center gap-4 rounded-xl border border-white/8 bg-white/[0.03] px-4 py-3">
                      <span className="font-display text-sm font-bold text-kyn-blue-bright w-8">{n}</span>
                      <span className="text-sm text-white/75">{t}</span>
                    </div>
                  ))}
                </div>
              </Fade>
            </div>
          </div>
        </div>
      </section>

      {/* SOCIAL PROOF */}
      <section className="py-20">
        <div className="max-w-4xl mx-auto px-5 text-center">
          <Fade>
            <div className="flex justify-center gap-1 mb-6">
              {Array.from({ length: 5 }).map((_, i) => (
                <Star key={i} size={18} className="text-kyn-blue-bright fill-kyn-blue-bright" />
              ))}
            </div>
            <blockquote className="font-display text-2xl md:text-3xl font-medium leading-snug text-white/90">
              “Finally an EV app that feels as premium as the car — map, charge, pay, done.”
            </blockquote>
            <p className="mt-6 text-sm text-white/40">Amine K. · Tesla Model 3 owner · Tunis</p>
          </Fade>
        </div>
      </section>

      {/* CTA DOWNLOAD — Ready to Take Control */}
      <AppDownloadCTA id="download" accent="#3b82f6" />

      <footer className="border-t border-white/5 py-10">
        <div className="max-w-7xl mx-auto px-5 md:px-8 flex flex-wrap items-center justify-between gap-4">
          <BrandLogo height={26} />
          <p className="text-[11px] text-white/35">© KYNETIK App — L'énergie en mouvement</p>
          <div className="flex gap-4 text-[11px] text-white/40">
            <Link to="/" className="hover:text-white">Home</Link>
            <Link to="/cloud" className="hover:text-white">Cloud</Link>
            <Link to="/product-system" className="hover:text-white">Products</Link>
          </div>
        </div>
      </footer>
    </div>
  );
}

import { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  ArrowDown, ArrowRight, BookOpen, CheckCircle2, ChevronRight, CircleAlert,
  Compass, Gauge, Layers, Map as MapIcon, Menu, MousePointerClick, Route,
  Sparkles, Target, X, Zap
} from 'lucide-react';
import BrandLogo from '../components/BrandLogo';
import LoadingState from '../components/LoadingState';
import ErrorState from '../components/ErrorState';
import { apiGet, cn } from '../lib/utils';

interface Journey {
  id: number;
  slug: string;
  chapter: string;
  chapter_num: number;
  title: string;
  persona: string;
  surface: string;
  goal: string;
  entry_point: string;
  steps: string;
  decision_points: string;
  click_limit: string;
  sticky_cta: string;
  success_state: string;
  failure_states: string;
  notes: string;
  sort_order: number;
}

interface Kpi {
  id: number;
  journey_slug: string;
  metric: string;
  target: string;
  definition: string;
  sort_order: number;
}

interface Notif {
  id: number;
  event_name: string;
  channel: string;
  audience: string;
  trigger_when: string;
  copy_example: string;
  sort_order: number;
}

function parseList(raw: string | null | undefined): string[] {
  if (!raw) return [];
  try {
    const v = JSON.parse(raw);
    return Array.isArray(v) ? v.map(String) : [];
  } catch {
    return String(raw)
      .split('|')
      .map((s) => s.trim())
      .filter(Boolean);
  }
}

const ecosystems = [
  { name: 'Website', desc: 'Acquisition, trust, product story' },
  { name: 'Cloud Platform', desc: 'Operator & fleet control plane' },
  { name: 'Mobile App', desc: 'Driver & owner daily control' },
  { name: 'Customer Portal', desc: 'Account, billing, assets' },
  { name: 'Installer Portal', desc: 'Jobs, commissioning, QA' },
  { name: 'Academy', desc: 'Training & certification' },
  { name: 'Admin Portal', desc: 'Governance & platform ops' },
];

export default function UxJourneys() {
  const [journeys, setJourneys] = useState<Journey[]>([]);
  const [kpis, setKpis] = useState<Kpi[]>([]);
  const [notifs, setNotifs] = useState<Notif[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [activeSlug, setActiveSlug] = useState('homepage');
  const [chapterFilter, setChapterFilter] = useState('All');
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    Promise.all([
      apiGet<Journey[]>('/api/ux-journeys'),
      apiGet<Kpi[]>('/api/ux-kpis'),
      apiGet<Notif[]>('/api/ux-notifications'),
    ])
      .then(([j, k, n]) => {
        setJourneys(j);
        setKpis(k);
        setNotifs(n);
        if (j[0]) setActiveSlug(j[0].slug);
      })
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const chapters = useMemo(() => {
    const map = new Map<string, number>();
    journeys.forEach((j) => {
      if (!map.has(j.chapter)) map.set(j.chapter, j.chapter_num);
    });
    return Array.from(map.entries())
      .sort((a, b) => a[1] - b[1])
      .map(([name, num]) => ({ name, num }));
  }, [journeys]);

  const filtered = useMemo(
    () =>
      journeys.filter((j) => chapterFilter === 'All' || j.chapter === chapterFilter),
    [journeys, chapterFilter]
  );

  const active = journeys.find((j) => j.slug === activeSlug) || filtered[0] || null;
  const activeKpis = kpis.filter((k) => k.journey_slug === active?.slug);

  if (loading) {
    return (
      <div className="min-h-screen bg-kyn-black flex items-center justify-center">
        <LoadingState label="Loading UX Flows & Journeys…" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-kyn-black flex items-center justify-center p-8">
        <ErrorState message={error} />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-kyn-black text-white">
      {/* Top nav */}
      <header
        className={cn(
          'fixed top-0 inset-x-0 z-50 transition-all',
          scrolled ? 'bg-kyn-black/90 backdrop-blur-xl border-b border-white/5' : 'bg-transparent'
        )}
      >
        <div className="max-w-7xl mx-auto px-5 md:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <BrandLogo height={28} />
            <span className="hidden sm:inline text-[10px] tracking-[0.22em] uppercase text-kyn-green border border-kyn-green/30 rounded-full px-2 py-0.5">
              UX Architecture
            </span>
          </div>
          <nav className="hidden lg:flex items-center gap-6 text-xs text-kyn-silver">
            {[
              ['#manifesto', 'Manifesto'],
              ['#ecosystem', 'Ecosystem'],
              ['#chapters', 'Chapters'],
              ['#journeys', 'Journeys'],
              ['#notifications', 'Notifications'],
              ['#kpis', 'KPI Map'],
              ['#next', 'Next Phase'],
            ].map(([href, label]) => (
              <a key={href} href={href} className="hover:text-white">
                {label}
              </a>
            ))}
          </nav>
          <div className="flex items-center gap-2">
            <Link to="/design-system" className="hidden md:inline text-xs text-kyn-metal hover:text-white">
              Design System
            </Link>
            <a
              href="#journeys"
              className="hidden sm:inline-flex items-center gap-1.5 px-3 py-2 rounded-full bg-kyn-green text-kyn-black text-xs font-bold"
            >
              Open journeys <ArrowRight size={12} />
            </a>
            <button type="button" className="lg:hidden p-2 text-kyn-silver" onClick={() => setMenuOpen(!menuOpen)}>
              {menuOpen ? <X size={18} /> : <Menu size={18} />}
            </button>
          </div>
        </div>
        {menuOpen && (
          <div className="lg:hidden border-t border-white/5 bg-kyn-void px-5 py-3 space-y-2">
            {['#manifesto', '#ecosystem', '#chapters', '#journeys', '#kpis', '#next'].map((href) => (
              <a key={href} href={href} onClick={() => setMenuOpen(false)} className="block py-2 text-sm text-kyn-silver capitalize">
                {href.replace('#', '')}
              </a>
            ))}
          </div>
        )}
      </header>

      {/* Cover */}
      <section className="relative pt-28 pb-20 md:pt-36 md:pb-28 overflow-hidden">
        <div className="absolute inset-0 grid-bg opacity-40" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(0,230,118,0.14),transparent_55%)]" />
        <div className="relative z-10 max-w-7xl mx-auto px-5 md:px-8">
          <motion.div initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }}>
            <div className="inline-flex items-center gap-2 text-kyn-green text-[11px] font-semibold tracking-[0.28em] uppercase mb-6">
              <BookOpen size={14} /> Document · UX Flows & User Journeys
            </div>
            <h1 className="font-display text-4xl md:text-6xl lg:text-7xl font-bold tracking-tight leading-[1.05] max-w-4xl">
              KYNETIK Ecosystem
              <br />
              <span className="text-kyn-green text-glow">Journey Architecture</span>
            </h1>
            <p className="mt-6 text-lg md:text-xl text-kyn-silver max-w-3xl leading-relaxed">
              A product-strategy grade map of how people move through the KYNETIK digital system —
              Website, Cloud, App, Academy, Installer, Customer and Admin portals — designed with the
              clarity of Stripe, the calm of Apple, and the operational rigor of Tesla Energy.
            </p>
            <div className="mt-10 flex flex-wrap gap-3">
              <a href="#journeys" className="inline-flex items-center gap-2 px-5 py-3 rounded-full bg-kyn-green text-kyn-black text-sm font-bold glow-green">
                Explore journeys <Compass size={16} />
              </a>
              <a href="#next" className="inline-flex items-center gap-2 px-5 py-3 rounded-full border border-white/15 text-sm font-medium">
                Next: Information Architecture
              </a>
            </div>
            <div className="mt-12 grid grid-cols-2 md:grid-cols-4 gap-3 max-w-3xl">
              {[
                { l: 'Journeys', v: String(journeys.length) },
                { l: 'Chapters', v: String(chapters.length) },
                { l: 'KPI bindings', v: String(kpis.length) },
                { l: 'Surfaces', v: '7' },
              ].map((s) => (
                <div key={s.l} className="glass-card rounded-xl p-4">
                  <p className="text-[10px] uppercase tracking-widest text-kyn-metal">{s.l}</p>
                  <p className="font-display text-2xl font-bold mt-1">{s.v}</p>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* Manifesto */}
      <section id="manifesto" className="py-20 border-t border-white/5 bg-kyn-void">
        <div className="max-w-7xl mx-auto px-5 md:px-8 grid lg:grid-cols-12 gap-10">
          <div className="lg:col-span-4">
            <p className="text-kyn-green text-xs font-semibold tracking-[0.25em] uppercase mb-3">01 · Manifesto</p>
            <h2 className="font-display text-3xl font-bold">Not a website. An operating system for energy mobility.</h2>
          </div>
          <div className="lg:col-span-8 space-y-5 text-kyn-silver leading-relaxed">
            <p>
              KYNETIK is a unified ecosystem. Hardware without software is silent. Software without journeys is
              inventory. This document defines the human paths that connect acquisition, activation, charging,
              operations, learning and governance into one coherent product story.
            </p>
            <div className="grid sm:grid-cols-3 gap-3">
              {[
                { t: 'Decision clarity', d: 'Every screen answers what now and why.' },
                { t: 'Click discipline', d: 'Critical outcomes stay inside strict click budgets.' },
                { t: 'Recoverable failure', d: 'No dead ends — only guided next actions.' },
              ].map((c) => (
                <div key={c.t} className="rounded-2xl border border-white/8 bg-black/30 p-4">
                  <p className="font-semibold text-white">{c.t}</p>
                  <p className="text-sm text-kyn-metal mt-2">{c.d}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Ecosystem */}
      <section id="ecosystem" className="py-20 border-t border-white/5">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <p className="text-kyn-green text-xs font-semibold tracking-[0.25em] uppercase mb-3">02 · Ecosystem surfaces</p>
          <h2 className="font-display text-3xl md:text-4xl font-bold mb-8">Seven surfaces. One brand nervous system.</h2>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {ecosystems.map((e, i) => (
              <motion.div
                key={e.name}
                initial={{ opacity: 0, y: 10 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.04 }}
                className="rounded-2xl border border-white/8 bg-gradient-to-b from-white/[0.04] to-transparent p-5"
              >
                <div className="w-9 h-9 rounded-xl bg-kyn-green/10 border border-kyn-green/25 flex items-center justify-center text-kyn-green mb-3">
                  <Layers size={16} />
                </div>
                <p className="font-display font-semibold">{e.name}</p>
                <p className="text-sm text-kyn-metal mt-1">{e.desc}</p>
              </motion.div>
            ))}
          </div>
          <div className="mt-10 rounded-2xl border border-kyn-green/20 bg-kyn-green/5 p-6 md:p-8">
            <p className="text-xs text-kyn-green font-semibold tracking-widest uppercase mb-3">North-star flow</p>
            <div className="flex flex-wrap items-center gap-2 text-sm">
              {['Discover', 'Configure', 'Quote', 'Install', 'Pair', 'Charge', 'Operate', 'Learn', 'Govern'].map((s, i, arr) => (
                <div key={s} className="flex items-center gap-2">
                  <span className="px-3 py-1.5 rounded-full bg-black/40 border border-white/10 font-medium">{s}</span>
                  {i < arr.length - 1 && <ChevronRight size={14} className="text-kyn-green" />}
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Chapters index */}
      <section id="chapters" className="py-20 border-t border-white/5 bg-kyn-void">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <p className="text-kyn-green text-xs font-semibold tracking-[0.25em] uppercase mb-3">03 · Document chapters</p>
          <h2 className="font-display text-3xl font-bold mb-8">Structured for delivery to UX, UI and engineering</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {chapters.map((c) => {
              const count = journeys.filter((j) => j.chapter === c.name).length;
              return (
                <button
                  key={c.name}
                  type="button"
                  onClick={() => {
                    setChapterFilter(c.name);
                    document.getElementById('journeys')?.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className="text-left rounded-2xl border border-white/8 bg-black/30 p-5 hover:border-kyn-green/30 transition-colors"
                >
                  <p className="text-kyn-green font-display text-sm font-bold">Chapter {String(c.num).padStart(2, '0')}</p>
                  <p className="font-display text-xl font-semibold mt-1">{c.name}</p>
                  <p className="text-xs text-kyn-metal mt-2">{count} journey{count > 1 ? 's' : ''}</p>
                </button>
              );
            })}
          </div>
        </div>
      </section>

      {/* Journeys interactive */}
      <section id="journeys" className="py-20 border-t border-white/5">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <div className="flex flex-wrap items-end justify-between gap-4 mb-8">
            <div>
              <p className="text-kyn-green text-xs font-semibold tracking-[0.25em] uppercase mb-3">04 · Journey library</p>
              <h2 className="font-display text-3xl md:text-4xl font-bold">Flows, decisions, states, constraints</h2>
            </div>
            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                onClick={() => setChapterFilter('All')}
                className={cn(
                  'px-3 py-1.5 rounded-full text-xs font-semibold',
                  chapterFilter === 'All' ? 'bg-kyn-green text-kyn-black' : 'bg-kyn-steel text-kyn-silver'
                )}
              >
                All
              </button>
              {chapters.map((c) => (
                <button
                  key={c.name}
                  type="button"
                  onClick={() => setChapterFilter(c.name)}
                  className={cn(
                    'px-3 py-1.5 rounded-full text-xs font-semibold',
                    chapterFilter === c.name ? 'bg-kyn-green text-kyn-black' : 'bg-kyn-steel text-kyn-silver'
                  )}
                >
                  {c.name}
                </button>
              ))}
            </div>
          </div>

          <div className="grid lg:grid-cols-[320px_1fr] gap-6">
            <div className="space-y-2 max-h-[70vh] overflow-y-auto pr-1 lg:sticky lg:top-24">
              {filtered.map((j) => (
                <button
                  key={j.id}
                  type="button"
                  onClick={() => setActiveSlug(j.slug)}
                  className={cn(
                    'w-full text-left rounded-xl border px-4 py-3 transition-all',
                    activeSlug === j.slug
                      ? 'border-kyn-green/40 bg-kyn-green/10'
                      : 'border-white/8 bg-white/[0.02] hover:border-white/15'
                  )}
                >
                  <p className="text-[10px] uppercase tracking-wider text-kyn-metal">
                    Ch.{j.chapter_num} · {j.chapter}
                  </p>
                  <p className="font-semibold text-sm mt-0.5">{j.title}</p>
                  <p className="text-[11px] text-kyn-metal mt-1 line-clamp-1">{j.surface}</p>
                </button>
              ))}
            </div>

            {active && (
              <motion.article
                key={active.slug}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                className="rounded-3xl border border-white/10 bg-gradient-to-b from-kyn-charcoal to-kyn-black overflow-hidden"
              >
                <div className="p-6 md:p-8 border-b border-white/5">
                  <div className="flex flex-wrap items-center gap-2 mb-3">
                    <span className="text-[10px] px-2 py-1 rounded-full bg-kyn-green/10 text-kyn-green border border-kyn-green/25 font-semibold uppercase tracking-wider">
                      {active.chapter}
                    </span>
                    <span className="text-[10px] px-2 py-1 rounded-full bg-white/5 text-kyn-metal border border-white/10">
                      {active.surface}
                    </span>
                  </div>
                  <h3 className="font-display text-2xl md:text-3xl font-bold">{active.title}</h3>
                  <p className="mt-3 text-kyn-silver leading-relaxed">{active.goal}</p>
                  <div className="mt-5 grid sm:grid-cols-2 gap-3 text-sm">
                    <div className="rounded-xl bg-black/30 border border-white/5 p-3">
                      <p className="text-[10px] uppercase tracking-wider text-kyn-metal">Persona</p>
                      <p className="mt-1 text-kyn-silver">{active.persona}</p>
                    </div>
                    <div className="rounded-xl bg-black/30 border border-white/5 p-3">
                      <p className="text-[10px] uppercase tracking-wider text-kyn-metal">Entry points</p>
                      <p className="mt-1 text-kyn-silver">{active.entry_point}</p>
                    </div>
                  </div>
                </div>

                <div className="p-6 md:p-8 grid lg:grid-cols-2 gap-8">
                  {/* Vertical flow */}
                  <div>
                    <div className="flex items-center gap-2 mb-4">
                      <Route size={16} className="text-kyn-green" />
                      <h4 className="font-display font-semibold">Flow diagram</h4>
                    </div>
                    <div className="space-y-0">
                      {parseList(active.steps).map((step, i, arr) => (
                        <div key={step} className="flex gap-3">
                          <div className="flex flex-col items-center">
                            <div className="w-8 h-8 rounded-full border border-kyn-green/40 bg-kyn-green/10 text-kyn-green text-xs font-bold flex items-center justify-center shrink-0">
                              {i + 1}
                            </div>
                            {i < arr.length - 1 && (
                              <div className="w-px flex-1 min-h-[28px] bg-gradient-to-b from-kyn-green/50 to-kyn-green/10 my-1" />
                            )}
                          </div>
                          <div className="pb-5">
                            <p className="text-sm text-kyn-silver pt-1.5 leading-relaxed">{step}</p>
                            {i < arr.length - 1 && (
                              <div className="mt-2 text-kyn-green/70">
                                <ArrowDown size={12} />
                              </div>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-5">
                    <div>
                      <div className="flex items-center gap-2 mb-3">
                        <Target size={16} className="text-kyn-green" />
                        <h4 className="font-display font-semibold">Decision points</h4>
                      </div>
                      <ul className="space-y-2">
                        {parseList(active.decision_points).map((d) => (
                          <li key={d} className="flex gap-2 text-sm text-kyn-silver">
                            <ChevronRight size={14} className="text-kyn-green shrink-0 mt-0.5" /> {d}
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="grid sm:grid-cols-2 gap-3">
                      <div className="rounded-xl border border-white/8 bg-white/[0.03] p-4">
                        <div className="flex items-center gap-2 text-kyn-green text-xs font-semibold uppercase tracking-wider">
                          <MousePointerClick size={13} /> Click limit
                        </div>
                        <p className="text-sm mt-2 text-kyn-silver">{active.click_limit}</p>
                      </div>
                      <div className="rounded-xl border border-white/8 bg-white/[0.03] p-4">
                        <div className="flex items-center gap-2 text-kyn-green text-xs font-semibold uppercase tracking-wider">
                          <Zap size={13} /> Sticky CTA
                        </div>
                        <p className="text-sm mt-2 text-kyn-silver">{active.sticky_cta}</p>
                      </div>
                    </div>

                    <div className="rounded-xl border border-kyn-green/25 bg-kyn-green/5 p-4">
                      <div className="flex items-center gap-2 text-kyn-green text-xs font-semibold uppercase tracking-wider">
                        <CheckCircle2 size={13} /> Success state
                      </div>
                      <p className="text-sm mt-2 text-kyn-silver">{active.success_state}</p>
                    </div>

                    <div className="rounded-xl border border-amber-500/20 bg-amber-500/5 p-4">
                      <div className="flex items-center gap-2 text-amber-300 text-xs font-semibold uppercase tracking-wider">
                        <CircleAlert size={13} /> Failure states
                      </div>
                      <ul className="mt-2 space-y-1.5">
                        {parseList(active.failure_states).map((f) => (
                          <li key={f} className="text-sm text-kyn-silver">• {f}</li>
                        ))}
                      </ul>
                    </div>

                    {active.notes && (
                      <div className="rounded-xl border border-white/8 p-4">
                        <p className="text-[10px] uppercase tracking-wider text-kyn-metal mb-1">Design note</p>
                        <p className="text-sm text-kyn-silver">{active.notes}</p>
                      </div>
                    )}

                    {activeKpis.length > 0 && (
                      <div>
                        <div className="flex items-center gap-2 mb-3">
                          <Gauge size={16} className="text-kyn-green" />
                          <h4 className="font-display font-semibold">Journey KPIs</h4>
                        </div>
                        <div className="overflow-hidden rounded-xl border border-white/8">
                          <table className="w-full text-left text-xs">
                            <thead className="bg-white/[0.03] text-kyn-metal">
                              <tr>
                                <th className="px-3 py-2 font-medium">Metric</th>
                                <th className="px-3 py-2 font-medium">Target</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-white/5">
                              {activeKpis.map((k) => (
                                <tr key={k.id}>
                                  <td className="px-3 py-2 text-kyn-silver">
                                    <p className="font-medium text-white">{k.metric}</p>
                                    <p className="text-kyn-metal mt-0.5">{k.definition}</p>
                                  </td>
                                  <td className="px-3 py-2 text-kyn-green font-semibold whitespace-nowrap">{k.target}</td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </motion.article>
            )}
          </div>
        </div>
      </section>

      {/* Notifications matrix */}
      <section id="notifications" className="py-20 border-t border-white/5 bg-kyn-void">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <p className="text-kyn-green text-xs font-semibold tracking-[0.25em] uppercase mb-3">05 · Notifications matrix</p>
          <h2 className="font-display text-3xl font-bold mb-3">Signal taxonomy across the ecosystem</h2>
          <p className="text-kyn-metal max-w-2xl mb-8">
            Critical and transactional messages earn interruption rights. Marketing never hijacks safety or charging flows.
          </p>
          <div className="overflow-x-auto rounded-2xl border border-white/10">
            <table className="w-full text-left text-sm min-w-[900px]">
              <thead className="bg-white/[0.03] text-[11px] uppercase tracking-wider text-kyn-metal">
                <tr>
                  <th className="px-4 py-3 font-medium">Event</th>
                  <th className="px-4 py-3 font-medium">Channel</th>
                  <th className="px-4 py-3 font-medium">Audience</th>
                  <th className="px-4 py-3 font-medium">Trigger</th>
                  <th className="px-4 py-3 font-medium">Copy example</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {notifs.map((n) => (
                  <tr key={n.id} className="text-kyn-silver">
                    <td className="px-4 py-3 font-medium text-white">{n.event_name}</td>
                    <td className="px-4 py-3">{n.channel}</td>
                    <td className="px-4 py-3">{n.audience}</td>
                    <td className="px-4 py-3">{n.trigger_when}</td>
                    <td className="px-4 py-3 text-kyn-metal italic">{n.copy_example}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </section>

      {/* Full KPI board */}
      <section id="kpis" className="py-20 border-t border-white/5">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <p className="text-kyn-green text-xs font-semibold tracking-[0.25em] uppercase mb-3">06 · KPI mapping</p>
          <h2 className="font-display text-3xl font-bold mb-3">If it ships, it reports</h2>
          <p className="text-kyn-metal max-w-2xl mb-8">
            Every journey binds to outcomes. Product, growth and ops review the same board — different lenses, shared truth.
          </p>
          <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-3">
            {kpis.map((k) => {
              const j = journeys.find((x) => x.slug === k.journey_slug);
              return (
                <button
                  key={k.id}
                  type="button"
                  onClick={() => {
                    setActiveSlug(k.journey_slug);
                    setChapterFilter('All');
                    document.getElementById('journeys')?.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className="text-left rounded-2xl border border-white/8 bg-white/[0.02] p-4 hover:border-kyn-green/30 transition-colors"
                >
                  <p className="text-[10px] uppercase tracking-wider text-kyn-metal">{j?.title || k.journey_slug}</p>
                  <p className="font-semibold mt-1">{k.metric}</p>
                  <p className="text-kyn-green font-display text-lg font-bold mt-2">{k.target}</p>
                  <p className="text-xs text-kyn-metal mt-2">{k.definition}</p>
                </button>
              );
            })}
          </div>
        </div>
      </section>

      {/* Principles strip */}
      <section className="py-16 border-t border-white/5 bg-kyn-void">
        <div className="max-w-7xl mx-auto px-5 md:px-8 grid md:grid-cols-4 gap-4">
          {[
            { icon: MousePointerClick, t: 'Click budgets', d: 'Primary jobs stay inside declared limits.' },
            { icon: Zap, t: 'Sticky CTAs', d: 'Conversion and safety actions remain reachable.' },
            { icon: CheckCircle2, t: 'Success contracts', d: 'Each flow defines done in observable terms.' },
            { icon: CircleAlert, t: 'Failure playbooks', d: 'Errors always offer recovery or escalation.' },
          ].map(({ icon: Icon, t, d }) => (
            <div key={t} className="rounded-2xl border border-white/8 p-5">
              <Icon size={18} className="text-kyn-green mb-3" />
              <p className="font-display font-semibold">{t}</p>
              <p className="text-sm text-kyn-metal mt-2">{d}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Next phase */}
      <section id="next" className="py-24 border-t border-white/5 relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(0,230,118,0.1),transparent_55%)]" />
        <div className="relative z-10 max-w-4xl mx-auto px-5 md:px-8 text-center">
          <div className="inline-flex items-center gap-2 text-kyn-green text-xs font-semibold tracking-[0.25em] uppercase mb-4">
            <Sparkles size={14} /> Phase gate
          </div>
          <h2 className="font-display text-3xl md:text-5xl font-bold">
            Next: Information Architecture
            <br />
            <span className="text-kyn-green text-glow">& Master Navigation Map</span>
          </h2>
          <p className="mt-5 text-kyn-silver max-w-2xl mx-auto leading-relaxed">
            With journeys defined, the next artifact structures navigation trees, object models, URL strategy,
            cross-surface handoffs, and the global IA that keeps seven products feeling like one KYNETIK.
          </p>
          <div className="mt-8 flex flex-wrap justify-center gap-3 text-left">
            {[
              'Global nav & role-based shells',
              'Object model: Site, Charger, Session, Ticket',
              'URL & deep-link contracts',
              'Cross-surface handoff matrix',
            ].map((item) => (
              <span key={item} className="px-3 py-2 rounded-full border border-white/10 bg-white/[0.03] text-xs text-kyn-silver">
                {item}
              </span>
            ))}
          </div>
          <div className="mt-10 flex flex-wrap justify-center gap-3">
            <Link to="/design-system" className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-kyn-green text-kyn-black text-sm font-bold">
              Back to Design System <ArrowRight size={15} />
            </Link>
            <Link to="/product-spec" className="inline-flex items-center gap-2 px-6 py-3 rounded-full border border-white/15 text-sm font-medium">
              Product Specification
            </Link>
            <Link to="/handoff" className="inline-flex items-center gap-2 px-6 py-3 rounded-full border border-white/15 text-sm font-medium">
              Dev Handoff
            </Link>
          </div>
        </div>
      </section>

      <footer className="border-t border-white/5 py-8">
        <div className="max-w-7xl mx-auto px-5 md:px-8 flex flex-wrap items-center justify-between gap-4">
          <BrandLogo height={26} />
          <p className="text-[11px] text-kyn-metal flex items-center gap-2">
            <MapIcon size={12} /> KYNETIK UX Flows & User Journeys · Ready for IA phase
          </p>
        </div>
      </footer>
    </div>
  );
}

import { useState } from 'react';
import { Link, NavLink, Outlet, useLocation } from 'react-router-dom';
import {
  BookOpen, Code2, Webhook, Terminal, LayoutDashboard, KeyRound,
  Activity, Search, Users, Menu, X, ChevronRight, ExternalLink, Home
} from 'lucide-react';
import BrandLogo from '../../components/BrandLogo';
import { cn } from '../../lib/utils';

const nav = [
  { to: '/developers', label: 'Home', icon: Home, end: true },
  { to: '/developers/docs', label: 'API Documentation', icon: BookOpen },
  { to: '/developers/sdks', label: 'SDK Center', icon: Code2 },
  { to: '/developers/webhooks', label: 'Webhooks', icon: Webhook },
  { to: '/developers/playground', label: 'API Playground', icon: Terminal },
  { to: '/developers/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { to: '/developers/keys', label: 'API Keys', icon: KeyRound },
  { to: '/developers/status', label: 'Status', icon: Activity },
  { to: '/developers/search', label: 'Search Docs', icon: Search },
  { to: '/developers/community', label: 'Community', icon: Users },
];

export default function DevShell() {
  const [open, setOpen] = useState(false);
  const location = useLocation();
  const current = nav.find((n) =>
    n.end ? location.pathname === n.to : location.pathname.startsWith(n.to)
  );

  return (
    <div className="min-h-screen bg-kyn-black text-white flex">
      <aside className="hidden lg:flex w-64 xl:w-72 flex-col border-r border-white/5 bg-[#07080a] sticky top-0 h-screen">
        <div className="p-5 border-b border-white/5">
          <Link to="/developers" className="flex items-center gap-2.5">
            <BrandLogo height={28} />
            <span className="text-[10px] font-bold tracking-[0.18em] uppercase text-kyn-green border border-kyn-green/30 rounded-md px-1.5 py-0.5">
              Dev
            </span>
          </Link>
          <p className="mt-3 text-[11px] text-kyn-metal">Developer Platform · API v1</p>
        </div>
        <nav className="flex-1 overflow-y-auto p-3 space-y-0.5">
          {nav.map(({ to, label, icon: Icon, end }) => (
            <NavLink
              key={to}
              to={to}
              end={end}
              className={({ isActive }) =>
                cn(
                  'flex items-center gap-2.5 px-3 py-2 rounded-lg text-[13px] transition-colors',
                  isActive
                    ? 'bg-kyn-green/10 text-kyn-green border border-kyn-green/20'
                    : 'text-kyn-silver hover:bg-white/5 hover:text-white border border-transparent'
                )
              }
            >
              <Icon size={15} />
              {label}
            </NavLink>
          ))}
        </nav>
        <div className="p-4 border-t border-white/5 space-y-2">
          <Link to="/console" className="flex items-center justify-between text-xs text-kyn-metal hover:text-kyn-green px-2 py-1.5">
            Cloud Console <ExternalLink size={12} />
          </Link>
          <Link to="/" className="flex items-center justify-between text-xs text-kyn-metal hover:text-white px-2 py-1.5">
            KYNETIK Home <ChevronRight size={12} />
          </Link>
        </div>
      </aside>

      <div className="flex-1 min-w-0 flex flex-col">
        <header className="sticky top-0 z-40 border-b border-white/5 bg-kyn-black/90 backdrop-blur-xl">
          <div className="h-14 px-4 md:px-6 flex items-center justify-between gap-3">
            <div className="flex items-center gap-3 min-w-0">
              <button type="button" className="lg:hidden p-2 text-kyn-silver" onClick={() => setOpen(!open)}>
                {open ? <X size={18} /> : <Menu size={18} />}
              </button>
              <div className="lg:hidden">
                <BrandLogo height={24} />
              </div>
              <div className="hidden sm:flex items-center gap-1.5 text-xs text-kyn-metal truncate">
                <span>Developers</span>
                <ChevronRight size={12} />
                <span className="text-kyn-silver">{current?.label || 'Platform'}</span>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Link
                to="/developers/search"
                className="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-lg border border-white/10 bg-white/[0.03] text-xs text-kyn-metal hover:text-white min-w-[180px]"
              >
                <Search size={13} /> Search docs…
              </Link>
              <Link
                to="/developers/keys"
                className="px-3 py-1.5 rounded-lg border border-white/10 text-xs text-kyn-silver hover:text-white"
              >
                API Keys
              </Link>
              <Link
                to="/developers/playground"
                className="px-3 py-1.5 rounded-lg bg-kyn-green text-kyn-black text-xs font-bold"
              >
                Playground
              </Link>
            </div>
          </div>
          {open && (
            <nav className="lg:hidden border-t border-white/5 px-3 py-3 space-y-1 max-h-[70vh] overflow-y-auto">
              {nav.map(({ to, label, icon: Icon, end }) => (
                <NavLink
                  key={to}
                  to={to}
                  end={end}
                  onClick={() => setOpen(false)}
                  className={({ isActive }) =>
                    cn(
                      'flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-sm',
                      isActive ? 'bg-kyn-green/10 text-kyn-green' : 'text-kyn-silver'
                    )
                  }
                >
                  <Icon size={15} />
                  {label}
                </NavLink>
              ))}
            </nav>
          )}
        </header>

        <main className="flex-1">
          <Outlet />
        </main>
      </div>
    </div>
  );
}

import { useEffect, useState } from 'react';
import { BookOpen, Newspaper, Map, LifeBuoy, Sparkles } from 'lucide-react';
import { apiGet } from '../../lib/utils';
import { Badge, Card, DevSection, LoadingInline } from './components';

interface Item {
  id: number;
  type: string;
  title: string;
  body: string;
  category: string;
  meta: string | null;
}

export default function DevCommunity() {
  const [items, setItems] = useState<Item[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    apiGet<Item[]>('/api/dev-content')
      .then((all) =>
        setItems(all.filter((i) => ['tutorial', 'release', 'roadmap', 'faq', 'news', 'support'].includes(i.type)))
      )
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <LoadingInline />;

  const group = (t: string) => items.filter((i) => i.type === t);

  const blocks = [
    {
      type: 'tutorial',
      title: 'Tutorials',
      icon: BookOpen,
      fallback: [
        { id: 1, title: 'Start a session in 5 minutes', body: 'Create a key, list stations, remote-start.', meta: '5 min' },
        { id: 2, title: 'Verify webhooks securely', body: 'Signature validation pattern for Node & Python.', meta: '8 min' },
      ],
    },
    {
      type: 'release',
      title: 'Release notes',
      icon: Newspaper,
      fallback: [
        { id: 1, title: 'API v1.14', body: 'Idempotency keys on remote-stop · improved pagination cursors.', meta: 'Mar 2026' },
      ],
    },
    {
      type: 'roadmap',
      title: 'Roadmap',
      icon: Map,
      fallback: [
        { id: 1, title: 'GraphQL explorer (beta)', body: 'Optional query layer for analytics workloads.', meta: 'Q3' },
        { id: 2, title: 'OCPI roaming pack', body: 'Partner roaming objects in REST.', meta: 'Q4' },
      ],
    },
    {
      type: 'support',
      title: 'Support',
      icon: LifeBuoy,
      fallback: [
        { id: 1, title: 'developers@kynetik.tn', body: 'Priority support for live integrations.', meta: 'Email' },
      ],
    },
    {
      type: 'news',
      title: 'Developer news',
      icon: Sparkles,
      fallback: [
        { id: 1, title: 'Playground is live', body: 'Simulate remote-start responses without a physical charger.', meta: 'New' },
      ],
    },
    {
      type: 'faq',
      title: 'FAQ',
      icon: BookOpen,
      fallback: [
        { id: 1, title: 'Can I use test keys in production?', body: 'No. Test keys only hit the sandbox cluster.', meta: 'FAQ' },
      ],
    },
  ];

  return (
    <DevSection
      eyebrow="10 · Community"
      title="Learn, ship, stay updated"
      description="Tutorials, release notes, roadmap and support channels for KYNETIK builders."
    >
      <div className="grid lg:grid-cols-2 gap-4">
        {blocks.map(({ type, title, icon: Icon, fallback }) => {
          const rows = group(type);
          const data = rows.length ? rows : fallback;
          return (
            <Card key={type}>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 rounded-lg bg-kyn-green/10 border border-kyn-green/20 flex items-center justify-center text-kyn-green">
                  <Icon size={15} />
                </div>
                <p className="font-display font-semibold">{title}</p>
              </div>
              <div className="space-y-3">
                {data.map((item) => (
                  <div key={item.id} className="border-t border-white/5 pt-3 first:border-0 first:pt-0">
                    <div className="flex items-center gap-2">
                      <p className="text-sm font-medium">{item.title}</p>
                      {item.meta && <Badge tone="zinc">{item.meta}</Badge>}
                    </div>
                    <p className="text-xs text-kyn-metal mt-1 leading-relaxed">{item.body}</p>
                  </div>
                ))}
              </div>
            </Card>
          );
        })}
      </div>
    </DevSection>
  );
}

import { useEffect, useState } from 'react';
import { Download, ExternalLink } from 'lucide-react';
import { apiGet } from '../../lib/utils';
import { Badge, Card, CodeBlock, DevSection, LoadingInline } from './components';

interface Item {
  id: number;
  title: string;
  body: string;
  category: string;
  meta: string | null;
  code: string | null;
}

const fallback = [
  { id: 1, title: 'Python', category: 'python', body: 'Official sync/async client for backend services.', meta: 'pip install kynetik', code: 'from kynetik import Kynetik\nkyn = Kynetik("kyn_live_…")\nprint(kyn.stations.list())' },
  { id: 2, title: 'JavaScript', category: 'javascript', body: 'Node & modern bundlers. TypeScript types included.', meta: 'npm i @kynetik/sdk', code: 'import Kynetik from "@kynetik/sdk"\nconst kyn = new Kynetik(process.env.KYN_KEY)' },
  { id: 3, title: 'Flutter', category: 'flutter', body: 'Mobile driver & partner apps on Flutter.', meta: 'kynetik: ^1.2.0', code: 'final kyn = Kynetik(apiKey: "kyn_live_…");' },
  { id: 4, title: 'Android', category: 'android', body: 'Kotlin-first SDK for OEM and utility apps.', meta: 'implementation("tn.kynetik:sdk:1.2.0")', code: 'val kyn = Kynetik.create("kyn_live_…")' },
  { id: 5, title: 'iOS', category: 'ios', body: 'Swift package for iOS 15+.', meta: 'https://github.com/kynetik/kynetik-ios', code: 'let kyn = Kynetik(apiKey: "kyn_live_…")' },
  { id: 6, title: 'Java', category: 'java', body: 'Enterprise JVM integrations.', meta: 'com.kynetik:sdk:1.2.0', code: 'var kyn = Kynetik.builder().apiKey("kyn_live_…").build();' },
  { id: 7, title: 'C#', category: 'csharp', body: '.NET 8 client for fleet backends.', meta: 'dotnet add package Kynetik', code: 'var kyn = new KynetikClient("kyn_live_…");' },
];

export default function DevSdks() {
  const [items, setItems] = useState<Item[]>([]);
  const [active, setActive] = useState<Item | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    apiGet<Item[]>('/api/dev-content?type=sdk')
      .then((data) => {
        const rows = data.length ? data : fallback;
        setItems(rows);
        setActive(rows[0]);
      })
      .catch(() => {
        setItems(fallback);
        setActive(fallback[0]);
      })
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <LoadingInline />;

  return (
    <DevSection
      eyebrow="03 · SDK Center"
      title="Official SDKs"
      description="Install a first-party library and start charging sessions in minutes. Examples are copy-ready."
    >
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3 mb-8">
        {items.map((sdk) => (
          <Card
            key={sdk.id}
            onClick={() => setActive(sdk)}
            className={active?.id === sdk.id ? '!border-kyn-green/40 !bg-kyn-green/5' : ''}
          >
            <div className="flex items-start justify-between gap-2">
              <p className="font-display font-bold text-lg">{sdk.title}</p>
              <Badge>Official</Badge>
            </div>
            <p className="text-sm text-kyn-metal mt-2 line-clamp-2">{sdk.body}</p>
            {sdk.meta && <p className="mt-3 font-mono text-[11px] text-kyn-green">{sdk.meta}</p>}
          </Card>
        ))}
      </div>

      {active && (
        <div className="grid lg:grid-cols-2 gap-4">
          <div className="rounded-2xl border border-white/10 p-6 bg-white/[0.02]">
            <p className="text-kyn-green text-xs font-semibold tracking-wider uppercase">{active.title} SDK</p>
            <h2 className="font-display text-2xl font-bold mt-2">{active.title}</h2>
            <p className="text-sm text-kyn-metal mt-3">{active.body}</p>
            <div className="mt-6 flex flex-wrap gap-2">
              <a href="#example" className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-kyn-green text-kyn-black text-xs font-bold">
                <Download size={13} /> Install snippet
              </a>
              <button type="button" className="inline-flex items-center gap-2 px-4 py-2 rounded-lg border border-white/10 text-xs text-kyn-silver">
                <ExternalLink size={13} /> GitHub
              </button>
            </div>
            {active.meta && (
              <div className="mt-6">
                <p className="text-[11px] text-kyn-metal mb-2 uppercase tracking-wider">Install</p>
                <CodeBlock code={active.meta} language="bash" />
              </div>
            )}
          </div>
          <div id="example">
            <CodeBlock code={active.code || '// example'} language={active.category || 'text'} title="Example" />
          </div>
        </div>
      )}
    </DevSection>
  );
}

import { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { Search } from 'lucide-react';
import { apiGet } from '../../lib/utils';
import { Badge, Card, DevSection, LoadingInline } from './components';

interface Item {
  id: number;
  type: string;
  title: string;
  body: string;
  category: string;
  meta: string | null;
}

const typeRoute: Record<string, string> = {
  doc: '/developers/docs',
  endpoint: '/developers/docs',
  sdk: '/developers/sdks',
  webhook: '/developers/webhooks',
  tutorial: '/developers/community',
  faq: '/developers/community',
  overview: '/developers',
};

export default function DevSearch() {
  const [q, setQ] = useState('');
  const [items, setItems] = useState<Item[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    apiGet<Item[]>('/api/dev-content')
      .then(setItems)
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  const results = useMemo(() => {
    const s = q.trim().toLowerCase();
    if (!s) return items.slice(0, 12);
    return items.filter(
      (i) =>
        i.title?.toLowerCase().includes(s) ||
        i.body?.toLowerCase().includes(s) ||
        i.category?.toLowerCase().includes(s) ||
        i.type?.toLowerCase().includes(s)
    );
  }, [q, items]);

  const categories = useMemo(() => {
    const set = new Set(items.map((i) => i.category || i.type).filter(Boolean));
    return Array.from(set);
  }, [items]);

  if (loading) return <LoadingInline />;

  return (
    <DevSection
      eyebrow="09 · Documentation Search"
      title="Search the developer docs"
      description="Find endpoints, SDKs, webhooks, tutorials and FAQs across the KYNETIK platform."
    >
      <div className="relative mb-6">
        <Search size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-kyn-metal" />
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search authentication, webhooks, remote-start…"
          className="w-full rounded-2xl bg-white/[0.03] border border-white/10 pl-11 pr-4 py-3.5 text-sm outline-none focus:border-kyn-green/40"
          autoFocus
        />
      </div>

      <div className="flex flex-wrap gap-2 mb-6">
        {categories.slice(0, 12).map((c) => (
          <button
            key={c}
            type="button"
            onClick={() => setQ(c)}
            className="px-3 py-1 rounded-full border border-white/10 text-[11px] text-kyn-metal hover:text-kyn-green hover:border-kyn-green/30"
          >
            {c}
          </button>
        ))}
      </div>

      <p className="text-xs text-kyn-metal mb-3">{results.length} results</p>
      <div className="space-y-2">
        {results.map((r) => (
          <Link key={`${r.type}-${r.id}`} to={typeRoute[r.type] || '/developers/docs'}>
            <Card className="hover:border-kyn-green/30 transition-colors mb-2">
              <div className="flex items-center gap-2 mb-1">
                <Badge tone="zinc">{r.type}</Badge>
                {r.category && <span className="text-[11px] text-kyn-metal">{r.category}</span>}
              </div>
              <p className="font-semibold">{r.title}</p>
              <p className="text-sm text-kyn-metal mt-1 line-clamp-2">{r.body}</p>
            </Card>
          </Link>
        ))}
        {results.length === 0 && (
          <Card>
            <p className="text-sm text-kyn-metal">No matches. Try “OAuth”, “webhook” or “Python”.</p>
          </Card>
        )}
      </div>
    </DevSection>
  );
}

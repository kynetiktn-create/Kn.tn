import { useEffect, useState } from 'react';
import { KeyRound, RefreshCw, Ban, Plus, Copy, Check, Trash2 } from 'lucide-react';
import { apiGet, apiPost, cn } from '../../lib/utils';
import { Badge, Card, DevSection, LoadingInline } from './components';

interface ApiKey {
  id: number;
  name: string;
  key_value: string;
  permissions: string;
  environment: string;
  status: string;
  last_used: string | null;
  created_at?: string;
}

async function apiMutate(method: string, body: unknown) {
  const res = await fetch('/api/dev-keys', {
    method,
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
}

function mask(key: string) {
  if (!key || key.length < 12) return key;
  return `${key.slice(0, 12)}…${key.slice(-4)}`;
}

export default function DevKeys() {
  const [keys, setKeys] = useState<ApiKey[]>([]);
  const [loading, setLoading] = useState(true);
  const [name, setName] = useState('');
  const [env, setEnv] = useState<'live' | 'test'>('live');
  const [perms, setPerms] = useState('read,write');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [copied, setCopied] = useState<number | null>(null);
  const [revealed, setRevealed] = useState<Record<number, boolean>>({});

  const load = () =>
    apiGet<ApiKey[]>('/api/dev-keys')
      .then(setKeys)
      .catch((e) => setError(e.message));

  useEffect(() => {
    load().finally(() => setLoading(false));
  }, []);

  const create = async () => {
    if (!name.trim()) return;
    setBusy(true);
    setError('');
    try {
      await apiPost('/api/dev-keys', { name: name.trim(), environment: env, permissions: perms });
      setName('');
      await load();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed');
    } finally {
      setBusy(false);
    }
  };

  const act = async (id: number, action: string) => {
    setBusy(true);
    setError('');
    try {
      await apiMutate('PUT', { id, action });
      await load();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed');
    } finally {
      setBusy(false);
    }
  };

  const remove = async (id: number) => {
    setBusy(true);
    try {
      await apiMutate('DELETE', { id });
      await load();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed');
    } finally {
      setBusy(false);
    }
  };

  const copy = async (k: ApiKey) => {
    try {
      await navigator.clipboard.writeText(k.key_value);
      setCopied(k.id);
      setTimeout(() => setCopied(null), 1200);
    } catch {
      /* ignore */
    }
  };

  if (loading) return <LoadingInline />;

  return (
    <DevSection
      eyebrow="07 · API Keys"
      title="Manage secret keys"
      description="Create, rotate and disable workspace keys. Never embed live secrets in client-side apps."
    >
      <Card className="mb-6">
        <p className="font-semibold mb-4 flex items-center gap-2">
          <Plus size={16} className="text-kyn-green" /> Create key
        </p>
        <div className="grid md:grid-cols-4 gap-3">
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Name (e.g. Backend prod)"
            className="rounded-lg bg-black/40 border border-white/10 px-3 py-2 text-sm outline-none focus:border-kyn-green/40"
          />
          <select
            value={env}
            onChange={(e) => setEnv(e.target.value as 'live' | 'test')}
            className="rounded-lg bg-black/40 border border-white/10 px-3 py-2 text-sm outline-none"
          >
            <option value="live">Live</option>
            <option value="test">Test</option>
          </select>
          <select
            value={perms}
            onChange={(e) => setPerms(e.target.value)}
            className="rounded-lg bg-black/40 border border-white/10 px-3 py-2 text-sm outline-none"
          >
            <option value="read">read</option>
            <option value="read,write">read,write</option>
            <option value="read,write,admin">read,write,admin</option>
          </select>
          <button
            type="button"
            disabled={busy || !name.trim()}
            onClick={create}
            className="rounded-lg bg-kyn-green text-kyn-black text-sm font-bold disabled:opacity-50"
          >
            Create
          </button>
        </div>
        {error && <p className="text-xs text-red-300 mt-3">{error}</p>}
      </Card>

      <div className="space-y-3">
        {keys.length === 0 && (
          <Card>
            <p className="text-sm text-kyn-metal">No keys yet. Create your first secret key to call the API.</p>
          </Card>
        )}
        {keys.map((k) => (
          <Card key={k.id} className="!p-4">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div className="min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <KeyRound size={14} className="text-kyn-green" />
                  <p className="font-semibold">{k.name}</p>
                  <Badge tone={k.status === 'active' ? 'green' : 'zinc'}>{k.status}</Badge>
                  <Badge tone="zinc">{k.environment}</Badge>
                </div>
                <button
                  type="button"
                  onClick={() => setRevealed((r) => ({ ...r, [k.id]: !r[k.id] }))}
                  className="mt-2 font-mono text-xs text-kyn-silver hover:text-white"
                >
                  {revealed[k.id] ? k.key_value : mask(k.key_value)}
                </button>
                <p className="text-[11px] text-kyn-metal mt-2">
                  Permissions: {k.permissions}
                  {k.last_used ? ` · Last used ${k.last_used}` : ' · Never used'}
                </p>
              </div>
              <div className="flex flex-wrap gap-2">
                <button type="button" onClick={() => copy(k)} className="px-2.5 py-1.5 rounded-lg border border-white/10 text-xs inline-flex items-center gap-1 hover:border-kyn-green/30">
                  {copied === k.id ? <Check size={12} className="text-kyn-green" /> : <Copy size={12} />}
                  Copy
                </button>
                <button type="button" disabled={busy} onClick={() => act(k.id, 'rotate')} className="px-2.5 py-1.5 rounded-lg border border-white/10 text-xs inline-flex items-center gap-1 hover:border-kyn-green/30">
                  <RefreshCw size={12} /> Rotate
                </button>
                <button
                  type="button"
                  disabled={busy}
                  onClick={() => act(k.id, k.status === 'active' ? 'disable' : 'enable')}
                  className="px-2.5 py-1.5 rounded-lg border border-white/10 text-xs inline-flex items-center gap-1"
                >
                  <Ban size={12} /> {k.status === 'active' ? 'Disable' : 'Enable'}
                </button>
                <button type="button" disabled={busy} onClick={() => remove(k.id)} className={cn('px-2.5 py-1.5 rounded-lg border border-red-500/30 text-xs text-red-300 inline-flex items-center gap-1')}>
                  <Trash2 size={12} /> Delete
                </button>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </DevSection>
  );
}

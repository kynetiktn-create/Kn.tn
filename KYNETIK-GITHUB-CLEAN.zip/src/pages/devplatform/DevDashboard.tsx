import { useEffect, useState } from 'react';
import { apiGet } from '../../lib/utils';
import { Badge, Card, DevSection, LoadingInline } from './components';

interface Metric {
  id: number;
  type: string;
  label: string;
  value: string;
  meta: string | null;
  sort_order: number;
}

export default function DevDashboard() {
  const [rows, setRows] = useState<Metric[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    apiGet<Metric[]>('/api/dev-usage')
      .then(setRows)
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <LoadingInline />;

  const kpis = rows.filter((r) => r.type === 'kpi');
  const series = rows.filter((r) => r.type === 'series');
  const logs = rows.filter((r) => r.type === 'log').slice(0, 12);

  const bars = series.length
    ? series.map((s) => Number(s.value) || 0)
    : [42, 55, 48, 70, 63, 80, 74, 90, 85, 78, 92, 88, 70, 66, 72, 81, 95, 84, 76, 69, 60, 58, 64, 71];

  const displayKpis = kpis.length
    ? kpis
    : [
        { id: 1, label: 'Requests (24h)', value: '128.4k', meta: '+9%', type: 'kpi', sort_order: 1 },
        { id: 2, label: 'Error rate', value: '0.18%', meta: '-0.04%', type: 'kpi', sort_order: 2 },
        { id: 3, label: 'p95 latency', value: '612 ms', meta: 'stable', type: 'kpi', sort_order: 3 },
        { id: 4, label: 'Quota used', value: '54%', meta: 'of 500k', type: 'kpi', sort_order: 4 },
      ];

  return (
    <DevSection
      eyebrow="06 · Developer Dashboard"
      title="API usage & health"
      description="Monitor request volume, errors, latency and remaining quota for your workspace."
    >
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3 mb-6">
        {displayKpis.map((k) => (
          <Card key={k.id} className="!p-4">
            <p className="text-[11px] uppercase tracking-wider text-kyn-metal">{k.label}</p>
            <p className="font-display text-2xl font-bold mt-1">{k.value}</p>
            {k.meta && <p className="text-xs text-kyn-green mt-1">{k.meta}</p>}
          </Card>
        ))}
      </div>

      <div className="grid lg:grid-cols-3 gap-4">
        <Card className="lg:col-span-2">
          <div className="flex items-center justify-between mb-4">
            <p className="font-semibold text-sm">Requests · 24h</p>
            <Badge>Live</Badge>
          </div>
          <div className="h-40 flex items-end gap-1">
            {bars.map((h, i) => (
              <div
                key={i}
                className="flex-1 rounded-t-sm bg-gradient-to-t from-kyn-green/25 to-kyn-green"
                style={{ height: `${Math.min(100, Math.max(8, h))}%` }}
              />
            ))}
          </div>
        </Card>

        <Card>
          <p className="font-semibold text-sm mb-4">Quota</p>
          <div className="space-y-4">
            {[
              { l: 'REST calls', v: 54 },
              { l: 'Webhook deliveries', v: 31 },
              { l: 'Playground', v: 12 },
            ].map((q) => (
              <div key={q.l}>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-kyn-metal">{q.l}</span>
                  <span className="text-kyn-green">{q.v}%</span>
                </div>
                <div className="h-1.5 rounded-full bg-white/10 overflow-hidden">
                  <div className="h-full bg-kyn-green rounded-full" style={{ width: `${q.v}%` }} />
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <Card className="mt-4 !p-0 overflow-hidden">
        <div className="px-5 py-3 border-b border-white/5 flex items-center justify-between">
          <p className="font-semibold text-sm">Recent logs</p>
          <span className="text-[11px] text-kyn-metal">{logs.length || 8} events</span>
        </div>
        <div className="divide-y divide-white/5">
          {(logs.length
            ? logs
            : [
                { id: 1, label: 'GET /v1/stations', value: '200', meta: '42ms' },
                { id: 2, label: 'POST /v1/sessions/remote-start', value: '200', meta: '610ms' },
                { id: 3, label: 'GET /v1/sessions', value: '200', meta: '55ms' },
                { id: 4, label: 'POST /v1/webhooks/test', value: '201', meta: '88ms' },
                { id: 5, label: 'GET /v1/stations/stn_x', value: '404', meta: '21ms' },
              ]
          ).map((log) => (
            <div key={log.id} className="px-5 py-2.5 flex items-center justify-between gap-3 text-xs">
              <span className="font-mono text-kyn-silver truncate">{log.label}</span>
              <div className="flex items-center gap-3 shrink-0">
                <span className={String(log.value).startsWith('2') ? 'text-kyn-green' : 'text-amber-300'}>
                  {log.value}
                </span>
                <span className="text-kyn-metal w-14 text-right">{log.meta || '—'}</span>
              </div>
            </div>
          ))}
        </div>
      </Card>
    </DevSection>
  );
}

import { useState, type ReactNode } from 'react';
import { Check, Copy } from 'lucide-react';
import { cn } from '../../lib/utils';

export function DevSection({
  eyebrow,
  title,
  description,
  children,
  className,
}: {
  eyebrow?: string;
  title: string;
  description?: string;
  children?: ReactNode;
  className?: string;
}) {
  return (
    <div className={cn('max-w-6xl mx-auto px-4 md:px-8 py-10 md:py-14', className)}>
      {eyebrow && (
        <p className="text-kyn-green text-[11px] font-semibold tracking-[0.22em] uppercase mb-3">{eyebrow}</p>
      )}
      <h1 className="font-display text-3xl md:text-4xl font-bold tracking-tight">{title}</h1>
      {description && <p className="mt-3 text-kyn-metal max-w-2xl leading-relaxed">{description}</p>}
      <div className="mt-8">{children}</div>
    </div>
  );
}

export function CodeBlock({
  code,
  language = 'bash',
  title,
}: {
  code: string;
  language?: string;
  title?: string;
}) {
  const [copied, setCopied] = useState(false);
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(code);
      setCopied(true);
      setTimeout(() => setCopied(false), 1400);
    } catch {
      /* ignore */
    }
  };
  return (
    <div className="rounded-xl border border-white/10 overflow-hidden bg-[#0b0d11]">
      <div className="flex items-center justify-between px-3 py-2 border-b border-white/5 bg-white/[0.02]">
        <div className="flex items-center gap-2">
          <span className="text-[10px] uppercase tracking-wider text-kyn-metal">{language}</span>
          {title && <span className="text-[11px] text-kyn-silver">{title}</span>}
        </div>
        <button
          type="button"
          onClick={copy}
          className="inline-flex items-center gap-1.5 text-[11px] text-kyn-metal hover:text-kyn-green"
        >
          {copied ? <Check size={12} className="text-kyn-green" /> : <Copy size={12} />}
          {copied ? 'Copied' : 'Copy'}
        </button>
      </div>
      <pre className="p-4 overflow-x-auto text-[12px] leading-relaxed text-kyn-silver font-mono whitespace-pre">
        {code}
      </pre>
    </div>
  );
}

export function Card({
  children,
  className,
  onClick,
}: {
  children: ReactNode;
  className?: string;
  onClick?: () => void;
}) {
  const Comp = onClick ? 'button' : 'div';
  return (
    <Comp
      type={onClick ? 'button' : undefined}
      onClick={onClick}
      className={cn(
        'rounded-2xl border border-white/8 bg-white/[0.02] p-5 text-left',
        onClick && 'hover:border-kyn-green/30 transition-colors w-full',
        className
      )}
    >
      {children}
    </Comp>
  );
}

export function Badge({ children, tone = 'green' }: { children: ReactNode; tone?: 'green' | 'amber' | 'red' | 'zinc' }) {
  const tones = {
    green: 'bg-kyn-green/10 text-kyn-green border-kyn-green/20',
    amber: 'bg-amber-400/10 text-amber-300 border-amber-400/20',
    red: 'bg-red-400/10 text-red-300 border-red-400/20',
    zinc: 'bg-white/5 text-kyn-metal border-white/10',
  };
  return (
    <span className={cn('inline-flex items-center px-2 py-0.5 rounded-md text-[10px] font-semibold border', tones[tone])}>
      {children}
    </span>
  );
}

export function MethodBadge({ method }: { method: string }) {
  const m = method.toUpperCase();
  const color =
    m === 'GET' ? 'text-sky-300 border-sky-400/30 bg-sky-400/10' :
    m === 'POST' ? 'text-kyn-green border-kyn-green/30 bg-kyn-green/10' :
    m === 'PUT' || m === 'PATCH' ? 'text-amber-300 border-amber-400/30 bg-amber-400/10' :
    'text-red-300 border-red-400/30 bg-red-400/10';
  return <span className={cn('px-2 py-0.5 rounded text-[10px] font-bold border font-mono', color)}>{m}</span>;
}

export function LoadingInline({ label = 'Loading…' }: { label?: string }) {
  return (
    <div className="flex items-center justify-center py-20 text-sm text-kyn-metal">
      <div className="w-4 h-4 rounded-full border-2 border-kyn-green/30 border-t-kyn-green animate-spin mr-3" />
      {label}
    </div>
  );
}

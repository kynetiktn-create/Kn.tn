import { useEffect, useState } from 'react';
import { Play, Loader2 } from 'lucide-react';
import { apiGet, apiPost, cn } from '../../lib/utils';
import { Badge, CodeBlock, DevSection, LoadingInline, MethodBadge } from './components';

interface Endpoint {
  id: number;
  title: string;
  meta: string | null;
  body: string;
}

const defaults = [
  { id: 1, title: 'List stations', meta: 'GET /v1/stations', body: 'Return stations for the workspace.' },
  { id: 2, title: 'Remote start', meta: 'POST /v1/sessions/remote-start', body: 'Start a charging session on a connector.' },
  { id: 3, title: 'List sessions', meta: 'GET /v1/sessions', body: 'Paginated session history.' },
  { id: 4, title: 'List webhooks', meta: 'GET /v1/webhooks', body: 'Configured webhook endpoints.' },
];

export default function DevPlayground() {
  const [endpoints, setEndpoints] = useState<Endpoint[]>([]);
  const [method, setMethod] = useState('GET');
  const [path, setPath] = useState('/v1/stations');
  const [apiKey, setApiKey] = useState('kyn_live_demo');
  const [body, setBody] = useState(`{
  "station_id": "stn_tn_lac2_01",
  "connector_id": 2
}`);
  const [result, setResult] = useState('');
  const [latency, setLatency] = useState<number | null>(null);
  const [running, setRunning] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    apiGet<Endpoint[]>('/api/dev-playground')
      .then((data) => setEndpoints(data.length ? data : defaults))
      .catch(() => setEndpoints(defaults))
      .finally(() => setLoading(false));
  }, []);

  const run = async () => {
    setRunning(true);
    setResult('');
    try {
      const res = await apiPost<{ status: number; body: unknown; latency_ms: number }>('/api/dev-playground', {
        method,
        path,
        apiKey,
        body: method === 'GET' ? undefined : body,
      });
      setLatency(res.latency_ms);
      setResult(JSON.stringify({ status: res.status, ...((res.body as object) || {}) }, null, 2));
    } catch (e) {
      setResult(JSON.stringify({ error: e instanceof Error ? e.message : 'Request failed' }, null, 2));
      setLatency(null);
    } finally {
      setRunning(false);
    }
  };

  if (loading) return <LoadingInline />;

  return (
    <DevSection
      eyebrow="05 · API Playground"
      title="Live request builder"
      description="Craft requests against the simulated KYNETIK API. Copy responses into your integration tests."
    >
      <div className="grid lg:grid-cols-[280px_1fr] gap-4">
        <div className="space-y-2">
          <p className="text-[11px] uppercase tracking-wider text-kyn-metal mb-2">Presets</p>
          {endpoints.map((ep) => {
            const [m, ...rest] = (ep.meta || 'GET /v1/stations').split(' ');
            const p = rest.join(' ');
            return (
              <button
                key={ep.id}
                type="button"
                onClick={() => {
                  setMethod(m);
                  setPath(p.startsWith('/') ? p : `/${p}`);
                }}
                className="w-full text-left rounded-xl border border-white/8 bg-white/[0.02] px-3 py-3 hover:border-kyn-green/30"
              >
                <div className="flex items-center gap-2">
                  <MethodBadge method={m} />
                  <span className="font-mono text-[11px] text-kyn-silver truncate">{p}</span>
                </div>
                <p className="text-xs text-kyn-metal mt-1">{ep.title}</p>
              </button>
            );
          })}
        </div>

        <div className="space-y-4">
          <div className="rounded-2xl border border-white/10 bg-[#0b0d11] p-4 space-y-3">
            <div className="flex flex-wrap gap-2">
              {['GET', 'POST', 'PUT', 'DELETE'].map((m) => (
                <button
                  key={m}
                  type="button"
                  onClick={() => setMethod(m)}
                  className={cn(
                    'px-3 py-1.5 rounded-lg text-xs font-bold border',
                    method === m ? 'bg-kyn-green text-kyn-black border-kyn-green' : 'border-white/10 text-kyn-silver'
                  )}
                >
                  {m}
                </button>
              ))}
            </div>
            <div>
              <label className="text-[11px] text-kyn-metal">Path</label>
              <input
                value={path}
                onChange={(e) => setPath(e.target.value)}
                className="mt-1 w-full rounded-lg bg-black/40 border border-white/10 px-3 py-2 font-mono text-sm text-white outline-none focus:border-kyn-green/40"
              />
            </div>
            <div>
              <label className="text-[11px] text-kyn-metal">API Key</label>
              <input
                value={apiKey}
                onChange={(e) => setApiKey(e.target.value)}
                className="mt-1 w-full rounded-lg bg-black/40 border border-white/10 px-3 py-2 font-mono text-sm text-white outline-none focus:border-kyn-green/40"
              />
            </div>
            {method !== 'GET' && (
              <div>
                <label className="text-[11px] text-kyn-metal">JSON body</label>
                <textarea
                  value={body}
                  onChange={(e) => setBody(e.target.value)}
                  rows={6}
                  className="mt-1 w-full rounded-lg bg-black/40 border border-white/10 px-3 py-2 font-mono text-xs text-kyn-silver outline-none focus:border-kyn-green/40"
                />
              </div>
            )}
            <button
              type="button"
              onClick={run}
              disabled={running}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-kyn-green text-kyn-black text-sm font-bold disabled:opacity-60"
            >
              {running ? <Loader2 size={15} className="animate-spin" /> : <Play size={15} />}
              Send request
            </button>
          </div>

          <div>
            <div className="flex items-center gap-2 mb-2">
              <p className="text-sm font-semibold">Response</p>
              {latency != null && <Badge>{latency} ms</Badge>}
            </div>
            <CodeBlock code={result || `{
  "message": "Run a request to see output"
}`} language="json" />
          </div>

          <CodeBlock
            language="bash"
            title="cURL"
            code={`curl -X ${method} https://api.kynetik.tn${path} \\\n  -H "Authorization: Bearer ${apiKey}" \\\n  -H "Content-Type: application/json"${
              method === 'GET' ? '' : ` \\\n  -d '${body.replace(/\n/g, '')}'`
            }`}
          />
        </div>
      </div>
    </DevSection>
  );
}

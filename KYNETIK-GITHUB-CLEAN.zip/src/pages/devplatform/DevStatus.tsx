import { useEffect, useState } from 'react';
import { apiGet } from '../../lib/utils';
import { Badge, Card, DevSection, LoadingInline } from './components';

interface Item {
  id: number;
  title: string;
  body: string;
  category: string;
  meta: string | null;
}

export default function DevStatus() {
  const [items, setItems] = useState<Item[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    apiGet<Item[]>('/api/dev-content?type=status')
      .then(setItems)
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <LoadingInline />;

  const services = items.filter((i) => i.category === 'service');
  const incidents = items.filter((i) => i.category === 'incident');
  const maintenance = items.filter((i) => i.category === 'maintenance');

  const defaultServices = [
    { id: 1, title: 'API', body: 'Operational', meta: '99.98%' },
    { id: 2, title: 'Cloud Platform', body: 'Operational', meta: '99.95%' },
    { id: 3, title: 'OCPP Gateway', body: 'Operational', meta: '99.94%' },
    { id: 4, title: 'Webhooks', body: 'Operational', meta: '99.97%' },
    { id: 5, title: 'Dashboard', body: 'Operational', meta: '100%' },
  ];

  const list = services.length ? services : defaultServices;

  return (
    <DevSection
      eyebrow="08 · Status Page"
      title="System status"
      description="Realtime health for API, Cloud, OCPP gateway and developer services."
    >
      <Card className="mb-6 flex flex-wrap items-center justify-between gap-3">
        <div>
          <p className="font-display text-xl font-bold text-kyn-green">All systems operational</p>
          <p className="text-sm text-kyn-metal mt-1">Last checked just now · Tunisia region</p>
        </div>
        <Badge>Live</Badge>
      </Card>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3 mb-10">
        {list.map((s) => (
          <Card key={s.id}>
            <div className="flex items-center justify-between gap-2">
              <p className="font-semibold">{s.title}</p>
              <span className="w-2 h-2 rounded-full bg-kyn-green animate-pulse" />
            </div>
            <p className="text-sm text-kyn-green mt-2">{s.body}</p>
            {s.meta && <p className="text-[11px] text-kyn-metal mt-1">Uptime {s.meta}</p>}
          </Card>
        ))}
      </div>

      <div className="grid lg:grid-cols-2 gap-4">
        <Card>
          <p className="font-semibold mb-4">Maintenance</p>
          {(maintenance.length ? maintenance : [
            { id: 1, title: 'No scheduled maintenance', body: 'Next window TBD', meta: null },
          ]).map((m) => (
            <div key={m.id} className="py-2 border-t border-white/5 first:border-0">
              <p className="text-sm font-medium">{m.title}</p>
              <p className="text-xs text-kyn-metal mt-1">{m.body}</p>
            </div>
          ))}
        </Card>
        <Card>
          <p className="font-semibold mb-4">Incident history</p>
          {(incidents.length ? incidents : [
            { id: 1, title: 'Resolved · Elevated latency on OCPP broker', body: 'Mar 12, 2026 · 14 min · Monitoring complete', meta: 'resolved' },
            { id: 2, title: 'Resolved · Webhook retries delayed', body: 'Feb 28, 2026 · 22 min · Root cause: queue backlog', meta: 'resolved' },
          ]).map((m) => (
            <div key={m.id} className="py-2 border-t border-white/5 first:border-0">
              <div className="flex items-center gap-2">
                <Badge tone="zinc">{m.meta || 'resolved'}</Badge>
                <p className="text-sm font-medium">{m.title}</p>
              </div>
              <p className="text-xs text-kyn-metal mt-1">{m.body}</p>
            </div>
          ))}
        </Card>
      </div>
    </DevSection>
  );
}

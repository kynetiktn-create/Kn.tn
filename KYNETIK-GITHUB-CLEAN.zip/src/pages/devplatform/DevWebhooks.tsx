import { useEffect, useState } from 'react';
import { apiGet } from '../../lib/utils';
import { cn } from '../../lib/utils';
import { Badge, Card, CodeBlock, DevSection, LoadingInline } from './components';

interface Item {
  id: number;
  title: string;
  body: string;
  category: string;
  meta: string | null;
  code: string | null;
}

const fallback: Item[] = [
  { id: 1, title: 'charging.started', body: 'Emitted when a session is accepted and power delivery begins.', category: 'session', meta: 'Charging Started', code: null },
  { id: 2, title: 'charging.finished', body: 'Session completed or stopped. Includes energy_kwh and cost.', category: 'session', meta: 'Charging Finished', code: null },
  { id: 3, title: 'station.offline', body: 'Station missed heartbeat window or reported Unavailable.', category: 'station', meta: 'Offline', code: null },
  { id: 4, title: 'station.online', body: 'Station recovered and is ready for new sessions.', category: 'station', meta: 'Online', code: null },
  { id: 5, title: 'firmware.updated', body: 'OTA firmware job finished successfully on a charge point.', category: 'device', meta: 'Firmware Updated', code: null },
  { id: 6, title: 'payment.received', body: 'Wallet top-up or session payment captured.', category: 'billing', meta: 'Payment Received', code: null },
];

function payloadFor(event: string) {
  return JSON.stringify(
    {
      id: 'evt_01HXYZ',
      type: event,
      created: Math.floor(Date.now() / 1000),
      data: {
        object: {
          station_id: 'stn_tn_lac2_01',
          session_id: event.includes('charging') ? 'ses_k88421' : undefined,
          status: event.includes('offline') ? 'offline' : 'ok',
          energy_kwh: event.includes('finished') ? 18.4 : undefined,
          amount_dt: event.includes('payment') ? 12.5 : undefined,
        },
      },
    },
    null,
    2
  );
}

export default function DevWebhooks() {
  const [items, setItems] = useState<Item[]>([]);
  const [active, setActive] = useState<Item | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    apiGet<Item[]>('/api/dev-content?type=webhook')
      .then((data) => {
        const rows = data.length ? data : fallback;
        setItems(rows);
        setActive(rows[0]);
      })
      .catch(() => {
        setItems(fallback);
        setActive(fallback[0]);
      })
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <LoadingInline />;

  return (
    <DevSection
      eyebrow="04 · Webhooks"
      title="Realtime charging events"
      description="Subscribe to lifecycle events and receive signed JSON payloads. Verify the Kynetik-Signature header on every request."
    >
      <div className="grid lg:grid-cols-2 gap-4">
        <div className="space-y-2">
          {items.map((w) => (
            <Card
              key={w.id}
              onClick={() => setActive(w)}
              className={cn(active?.id === w.id && '!border-kyn-green/40 !bg-kyn-green/5')}
            >
              <div className="flex items-center justify-between gap-2">
                <p className="font-mono text-sm text-kyn-green">{w.title}</p>
                <Badge tone="zinc">{w.meta || w.category}</Badge>
              </div>
              <p className="text-sm text-kyn-metal mt-2">{w.body}</p>
            </Card>
          ))}
        </div>
        <div className="space-y-4">
          <CodeBlock
            language="json"
            title={active ? `Payload · ${active.title}` : 'Payload'}
            code={active?.code || payloadFor(active?.title || 'charging.started')}
          />
          <CodeBlock
            language="javascript"
            title="Verify signature"
            code={`import { validateWebhook } from '@kynetik/sdk/webhooks';\n\nexport function POST(req) {\n  const event = validateWebhook(req.body, req.headers, process.env.KYN_WHSEC);\n  if (event.type === 'charging.finished') {\n    // settle invoice…\n  }\n  return new Response('ok');\n}`}
          />
        </div>
      </div>
    </DevSection>
  );
}

import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  ArrowRight, BookOpen, Code2, Webhook, Terminal, KeyRound,
  Activity, Shield, Zap, Layers, CheckCircle2
} from 'lucide-react';
import { apiGet } from '../../lib/utils';
import { Badge, Card, CodeBlock, LoadingInline } from './components';

interface Item {
  id: number;
  type: string;
  title: string;
  body: string;
  category: string;
  meta: string | null;
}

const quickLinks = [
  { to: '/developers/docs', icon: BookOpen, t: 'API Overview', d: 'REST reference, auth, errors' },
  { to: '/developers/sdks', icon: Code2, t: 'SDKs', d: 'Python, JS, Flutter, mobile…' },
  { to: '/developers/docs', icon: Zap, t: 'Quick Start', d: 'Ship your first session call' },
  { to: '/developers/docs', icon: Shield, t: 'Authentication', d: 'API keys & OAuth 2.0' },
  { to: '/developers/webhooks', icon: Webhook, t: 'Webhooks', d: 'Realtime charging events' },
  { to: '/developers/status', icon: Activity, t: 'API Status', d: 'Live platform health' },
];

export default function DevHome() {
  const [items, setItems] = useState<Item[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    apiGet<Item[]>('/api/dev-content?type=overview')
      .then(setItems)
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <LoadingInline label="Loading developer platform…" />;

  return (
    <div>
      <section className="relative overflow-hidden border-b border-white/5">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(0,230,118,0.12),transparent_55%)]" />
        <div className="absolute inset-0 grid-bg opacity-30" />
        <div className="relative max-w-6xl mx-auto px-4 md:px-8 py-16 md:py-24">
          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}>
            <Badge>KYNETIK API · v1</Badge>
            <h1 className="mt-5 font-display text-4xl md:text-6xl font-bold tracking-tight leading-[1.05] max-w-3xl">
              Build the Future of EV Charging with{' '}
              <span className="text-kyn-green text-glow">KYNETIK APIs</span>
            </h1>
            <p className="mt-5 text-kyn-silver text-lg max-w-2xl leading-relaxed">
              Premium developer infrastructure for stations, sessions, smart charging, billing and OCPP —
              designed like Stripe, Vercel and Twilio.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link to="/developers/docs" className="inline-flex items-center gap-2 px-5 py-3 rounded-full bg-kyn-green text-kyn-black text-sm font-bold">
                Read the docs <ArrowRight size={15} />
              </Link>
              <Link to="/developers/playground" className="inline-flex items-center gap-2 px-5 py-3 rounded-full border border-white/15 text-sm font-medium hover:border-kyn-green/40">
                <Terminal size={15} /> Open playground
              </Link>
              <Link to="/developers/keys" className="inline-flex items-center gap-2 px-5 py-3 rounded-full border border-white/10 text-sm text-kyn-silver hover:text-white">
                <KeyRound size={15} /> Get API keys
              </Link>
            </div>
          </motion.div>

          <div className="mt-12 grid lg:grid-cols-2 gap-6 items-start">
            <CodeBlock
              language="bash"
              title="Quick start"
              code={`curl https://api.kynetik.tn/v1/stations \\\n  -H "Authorization: Bearer kyn_live_…" \\\n  -H "Content-Type: application/json"`}
            />
            <div className="grid sm:grid-cols-2 gap-3">
              {[
                { t: '99.95%', l: 'API uptime SLA' },
                { t: '<800ms', l: 'Command p95' },
                { t: 'OCPP', l: '1.6J / 2.0.1' },
                { t: 'REST', l: '+ Webhooks' },
              ].map((s) => (
                <Card key={s.l} className="!p-4">
                  <p className="font-display text-2xl font-bold text-kyn-green">{s.t}</p>
                  <p className="text-xs text-kyn-metal mt-1">{s.l}</p>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="max-w-6xl mx-auto px-4 md:px-8 py-14">
        <div className="flex items-end justify-between gap-4 mb-6">
          <div>
            <p className="text-kyn-green text-[11px] font-semibold tracking-[0.2em] uppercase">Platform</p>
            <h2 className="font-display text-2xl md:text-3xl font-bold mt-2">Everything you need to integrate</h2>
          </div>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {quickLinks.map(({ to, icon: Icon, t, d }) => (
            <Link key={t} to={to}>
              <Card className="h-full hover:border-kyn-green/30 transition-colors">
                <div className="w-9 h-9 rounded-lg bg-kyn-green/10 border border-kyn-green/20 flex items-center justify-center text-kyn-green mb-3">
                  <Icon size={16} />
                </div>
                <p className="font-semibold">{t}</p>
                <p className="text-sm text-kyn-metal mt-1">{d}</p>
              </Card>
            </Link>
          ))}
        </div>
      </section>

      <section className="border-t border-white/5 bg-[#07080a]">
        <div className="max-w-6xl mx-auto px-4 md:px-8 py-14">
          <div className="grid lg:grid-cols-2 gap-10">
            <div>
              <p className="text-kyn-green text-[11px] font-semibold tracking-[0.2em] uppercase">API surface</p>
              <h2 className="font-display text-2xl md:text-3xl font-bold mt-2">Charge points to payments</h2>
              <ul className="mt-6 space-y-3">
                {(items.length
                  ? items
                  : [
                      { id: 1, title: 'Stations & connectors', body: 'Inventory, status, power limits' },
                      { id: 2, title: 'Sessions', body: 'Remote start/stop, energy, tariffs' },
                      { id: 3, title: 'Smart charging', body: 'Load profiles and schedules' },
                      { id: 4, title: 'Billing hooks', body: 'Usage events for invoicing' },
                    ]
                ).map((it) => (
                  <li key={it.id} className="flex gap-3 text-sm text-kyn-silver">
                    <CheckCircle2 size={16} className="text-kyn-green shrink-0 mt-0.5" />
                    <div>
                      <p className="font-medium text-white">{it.title}</p>
                      <p className="text-kyn-metal">{it.body}</p>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
            <CodeBlock
              language="javascript"
              title="Node.js"
              code={`import Kynetik from '@kynetik/sdk';\n\nconst kyn = new Kynetik('kyn_live_…');\n\nconst session = await kyn.sessions.remoteStart({\n  station_id: 'stn_tn_lac2_01',\n  connector_id: 2,\n  id_tag: 'USR_42',\n});\n\nconsole.log(session.id);`}
            />
          </div>

          <div className="mt-12 grid md:grid-cols-3 gap-3">
            {[
              { icon: Layers, t: 'Versioned REST', d: 'Stable /v1 with predictable pagination & errors' },
              { icon: Webhook, t: 'Event-driven', d: 'Signed webhooks for charging lifecycle' },
              { icon: Activity, t: 'Observable', d: 'Usage, latency and error dashboards built-in' },
            ].map(({ icon: Icon, t, d }) => (
              <Card key={t}>
                <Icon size={18} className="text-kyn-green mb-3" />
                <p className="font-semibold">{t}</p>
                <p className="text-sm text-kyn-metal mt-1">{d}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}

import { useEffect, useMemo, useState } from 'react';
import { apiGet, cn } from '../../lib/utils';
import { Badge, Card, CodeBlock, DevSection, LoadingInline, MethodBadge } from './components';

interface Item {
  id: number;
  type: string;
  title: string;
  body: string;
  category: string;
  meta: string | null;
  code: string | null;
  sort_order: number;
}

const toc = [
  { id: 'overview', label: 'Overview' },
  { id: 'auth', label: 'Authentication' },
  { id: 'oauth', label: 'OAuth' },
  { id: 'keys', label: 'API Keys' },
  { id: 'limits', label: 'Rate Limits' },
  { id: 'pagination', label: 'Pagination' },
  { id: 'errors', label: 'Error Codes' },
  { id: 'explorer', label: 'Endpoint Explorer' },
];

const sections: Array<[string, string]> = [
  ['auth', 'Authentication'],
  ['oauth', 'OAuth'],
  ['keys', 'API Keys'],
  ['limits', 'Rate Limits'],
  ['pagination', 'Pagination'],
  ['errors', 'Error Codes'],
];

function defaultDoc(id: string) {
  const map: Record<string, string> = {
    auth: 'Authenticate every request with an Authorization: Bearer header. Prefer restricted keys in production.',
    oauth: 'OAuth 2.0 authorization code flow for partner apps acting on behalf of operators.',
    keys: 'Create publishable/test/live secret keys from the dashboard. Rotate immediately if exposed.',
    limits: 'Default 600 requests/minute per workspace. Burst headers: X-RateLimit-Remaining.',
    pagination: 'List endpoints return { data, has_more }. Pass starting_after cursor for the next page.',
    errors: 'Errors use a consistent JSON shape with type, code and message fields.',
  };
  return map[id] || '';
}

function defaultCode(id: string) {
  if (id === 'auth' || id === 'keys') {
    return 'curl https://api.kynetik.tn/v1/stations \\\n  -H "Authorization: Bearer kyn_live_xxx"';
  }
  if (id === 'errors') {
    return '{\n  "error": {\n    "type": "invalid_request",\n    "code": "parameter_missing",\n    "message": "station_id is required"\n  }\n}';
  }
  if (id === 'pagination') {
    return 'GET /v1/sessions?limit=20&starting_after=ses_k88402';
  }
  return '';
}

export default function DevDocs() {
  const [items, setItems] = useState<Item[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeEp, setActiveEp] = useState<Item | null>(null);

  useEffect(() => {
    Promise.all([
      apiGet<Item[]>('/api/dev-content?type=doc'),
      apiGet<Item[]>('/api/dev-content?type=endpoint'),
    ])
      .then(([docs, endpoints]) => {
        setItems([...docs, ...endpoints]);
        setActiveEp(endpoints[0] || null);
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  const docs = useMemo(() => items.filter((i) => i.type === 'doc'), [items]);
  const endpoints = useMemo(() => items.filter((i) => i.type === 'endpoint'), [items]);
  const byCat = (c: string) => docs.filter((d) => d.category === c);

  if (loading) return <LoadingInline />;

  return (
    <DevSection
      eyebrow="02 · API Documentation"
      title="REST API reference"
      description="Clean, predictable HTTP APIs for the KYNETIK Cloud charging stack. All requests use HTTPS and JSON."
    >
      <div className="grid lg:grid-cols-[200px_1fr] gap-8">
        <aside className="hidden lg:block sticky top-24 self-start space-y-1">
          {toc.map((t) => (
            <a key={t.id} href={`#${t.id}`} className="block text-xs text-kyn-metal hover:text-kyn-green py-1.5">
              {t.label}
            </a>
          ))}
        </aside>

        <div className="space-y-12 min-w-0">
          <section id="overview" className="scroll-mt-24">
            <h2 className="font-display text-xl font-bold mb-3">Base URL</h2>
            <CodeBlock language="text" code="https://api.kynetik.tn/v1" />
            <div className="mt-4 grid sm:grid-cols-3 gap-3">
              {[
                { t: 'Format', d: 'JSON request & response' },
                { t: 'Auth', d: 'Bearer API key or OAuth token' },
                { t: 'Idempotency', d: 'Idempotency-Key on writes' },
              ].map((x) => (
                <Card key={x.t} className="!p-4">
                  <p className="text-sm font-semibold">{x.t}</p>
                  <p className="text-xs text-kyn-metal mt-1">{x.d}</p>
                </Card>
              ))}
            </div>
          </section>

          {sections.map(([id, label]) => (
            <section key={id} id={id} className="scroll-mt-24">
              <h2 className="font-display text-xl font-bold mb-4">{label}</h2>
              <div className="space-y-3">
                {(byCat(id).length
                  ? byCat(id)
                  : [
                      {
                        id: 0,
                        title: label,
                        body: defaultDoc(id),
                        code: defaultCode(id),
                        meta: null,
                        type: 'doc',
                        category: id,
                        sort_order: 0,
                      },
                    ]
                ).map((d) => (
                  <div key={d.id || label} className="space-y-3">
                    {d.title !== label && <h3 className="font-semibold text-kyn-silver">{d.title}</h3>}
                    <p className="text-sm text-kyn-metal leading-relaxed">{d.body}</p>
                    {d.code && <CodeBlock code={d.code} language={id === 'errors' ? 'json' : 'bash'} />}
                  </div>
                ))}
              </div>
            </section>
          ))}

          <section id="explorer" className="scroll-mt-24">
            <div className="flex items-center justify-between gap-3 mb-4">
              <h2 className="font-display text-xl font-bold">Interactive endpoint explorer</h2>
              <Badge>{endpoints.length} endpoints</Badge>
            </div>
            <div className="grid lg:grid-cols-2 gap-4">
              <div className="space-y-2 max-h-[480px] overflow-y-auto pr-1">
                {endpoints.map((ep) => {
                  const [method, ...rest] = (ep.meta || 'GET /v1').split(' ');
                  const path = rest.join(' ') || ep.title;
                  return (
                    <button
                      key={ep.id}
                      type="button"
                      onClick={() => setActiveEp(ep)}
                      className={cn(
                        'w-full text-left rounded-xl border px-3 py-3 transition-colors',
                        activeEp?.id === ep.id
                          ? 'border-kyn-green/40 bg-kyn-green/5'
                          : 'border-white/8 bg-white/[0.02] hover:border-white/15'
                      )}
                    >
                      <div className="flex items-center gap-2">
                        <MethodBadge method={method} />
                        <span className="font-mono text-xs text-kyn-silver truncate">{path}</span>
                      </div>
                      <p className="text-xs text-kyn-metal mt-1.5">{ep.title}</p>
                    </button>
                  );
                })}
              </div>
              <div className="rounded-2xl border border-white/10 bg-[#0b0d11] p-4 min-h-[320px]">
                {activeEp ? (
                  <>
                    <div className="flex items-center gap-2 mb-3">
                      <MethodBadge method={(activeEp.meta || 'GET').split(' ')[0]} />
                      <span className="font-mono text-sm text-white">
                        {(activeEp.meta || '').split(' ').slice(1).join(' ') || activeEp.title}
                      </span>
                    </div>
                    <p className="text-sm text-kyn-metal mb-4">{activeEp.body}</p>
                    <CodeBlock
                      language="json"
                      title="Example response"
                      code={activeEp.code || '{\n  "ok": true\n}'}
                    />
                  </>
                ) : (
                  <p className="text-sm text-kyn-metal">Select an endpoint</p>
                )}
              </div>
            </div>
          </section>
        </div>
      </div>
    </DevSection>
  );
}

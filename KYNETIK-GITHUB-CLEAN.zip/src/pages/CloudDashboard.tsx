import { useCallback, useEffect, useMemo, useState, type ComponentType, type ReactNode } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  LayoutDashboard, PlugZap, Activity, Map as MapIcon, BarChart3, Users, Building2,
  CreditCard, Bell, Settings, Search, Filter, RefreshCw, Play, Square, RotateCcw,
  Lock, Unlock, Download, CheckCircle2, AlertTriangle, XCircle, Info, Zap, Leaf,
  Radio, Server, ChevronRight, Menu, X, ExternalLink, Wrench, Sparkles, FileText,
  Shield, KeyRound, Globe, Cpu, Thermometer, Wifi, Clock, Car, UserCircle2,
  Stethoscope, HardDrive, Palette, Moon, Sun, TrendingUp, Target
} from 'lucide-react';
import BrandLogo from '../components/BrandLogo';
import LoadingState from '../components/LoadingState';
import { apiGet, apiSend, cn, statusColor } from '../lib/dashboardApi';

type ViewId =
  | 'dashboard' | 'chargers' | 'sessions' | 'map' | 'analytics'
  | 'fleet' | 'users' | 'notifications' | 'billing' | 'installer' | 'ai' | 'settings';

interface ChargePoint {
  id: number;
  station_id: string;
  name: string;
  model: string;
  city: string;
  address: string;
  status: string;
  connector_status: string;
  power_kw: number;
  current_a: number;
  voltage_v: number;
  temperature_c: number;
  firmware: string;
  last_seen: string;
  lat: number;
  lng: number;
  locked: boolean;
  ocpp_version: string;
  org_name: string;
}

interface Session {
  id: number;
  session_code: string;
  station_id: string;
  station_name: string;
  user_name: string;
  rfid: string;
  status: string;
  energy_kwh: number;
  cost_dt: number;
  duration_min: number;
  started_at: string;
  ended_at: string | null;
  max_power_kw: number;
}

interface CloudUser {
  id: number;
  name: string;
  email: string;
  user_type: string;
  org_name: string;
  role: string;
  status: string;
  sessions_count: number;
  spend_dt: number;
}

interface Notif {
  id: number;
  title: string;
  body: string;
  category: string;
  severity: string;
  read: boolean;
  created_at: string;
}

interface Fleet {
  id: number;
  name: string;
  company: string;
  vehicles: number;
  drivers: number;
  chargers: number;
  energy_kwh: number;
  cost_dt: number;
  city: string;
  status: string;
}

interface InstallerJob {
  id: number;
  title: string;
  customer: string;
  city: string;
  model: string;
  status: string;
  assignee: string;
  priority: string;
  scheduled_at: string;
  notes: string;
}

interface AiInsight {
  id: number;
  title: string;
  category: string;
  severity: string;
  body: string;
  impact: string;
  action_label: string;
}

interface BillingRecord {
  id: number;
  kind: string;
  title: string;
  customer: string;
  amount_dt: number;
  vat_dt: number;
  status: string;
  plan: string;
  period: string;
}

const NAV: { id: ViewId; label: string; icon: ComponentType<{ size?: number; className?: string }>; group: string }[] = [
  { id: 'dashboard', label: 'Executive', icon: LayoutDashboard, group: 'Command' },
  { id: 'chargers', label: 'Chargers', icon: PlugZap, group: 'Command' },
  { id: 'sessions', label: 'Live Sessions', icon: Activity, group: 'Command' },
  { id: 'map', label: 'Map', icon: MapIcon, group: 'Command' },
  { id: 'analytics', label: 'Energy Analytics', icon: BarChart3, group: 'Intelligence' },
  { id: 'ai', label: 'AI Insights', icon: Sparkles, group: 'Intelligence' },
  { id: 'fleet', label: 'Fleet', icon: Car, group: 'Customers' },
  { id: 'users', label: 'Users & Roles', icon: Users, group: 'Customers' },
  { id: 'billing', label: 'Billing', icon: CreditCard, group: 'Customers' },
  { id: 'installer', label: 'Installer Portal', icon: Wrench, group: 'Field' },
  { id: 'notifications', label: 'Notifications', icon: Bell, group: 'Field' },
  { id: 'settings', label: 'Settings', icon: Settings, group: 'Platform' },
];

const ROLES = ['Super Admin', 'Company Admin', 'Installer', 'Technician', 'Customer'] as const;
const PERMS = ['View dashboard', 'Control chargers', 'Manage users', 'Billing', 'Firmware OTA', 'API keys', 'Installer jobs', 'Export data'];
const PERM_MATRIX: Record<string, boolean[]> = {
  'Super Admin': [true, true, true, true, true, true, true, true],
  'Company Admin': [true, true, true, true, false, false, true, true],
  Installer: [true, true, false, false, true, false, true, false],
  Technician: [true, true, false, false, true, false, true, false],
  Customer: [true, false, false, true, false, false, false, true],
};

function Badge({ status }: { status: string }) {
  return (
    <span className={cn('inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold border capitalize', statusColor(status))}>
      {String(status).replace('_', ' ')}
    </span>
  );
}

function Kpi({
  label, value, delta, icon: Icon, accent = false,
}: {
  label: string;
  value: string;
  delta?: string;
  icon: ComponentType<{ size?: number; className?: string }>;
  accent?: boolean;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className={cn(
        'rounded-2xl border p-4 md:p-5 backdrop-blur-sm transition-all hover:border-kyn-green/25',
        accent
          ? 'border-kyn-green/25 bg-gradient-to-br from-kyn-green/10 to-transparent'
          : 'border-white/8 bg-gradient-to-b from-white/[0.045] to-transparent'
      )}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="text-[10px] uppercase tracking-wider text-kyn-metal">{label}</p>
          <p className="font-display text-2xl md:text-3xl font-bold mt-1 text-white tracking-tight truncate">{value}</p>
          {delta && <p className="text-[11px] text-kyn-green mt-1 flex items-center gap-1"><TrendingUp size={11} />{delta}</p>}
        </div>
        <div className="w-10 h-10 rounded-xl bg-kyn-green/10 border border-kyn-green/20 flex items-center justify-center text-kyn-green shrink-0">
          <Icon size={18} />
        </div>
      </div>
    </motion.div>
  );
}

function Panel({ title, action, children, className }: { title: string; action?: ReactNode; children: ReactNode; className?: string }) {
  return (
    <div className={cn('rounded-2xl border border-white/8 bg-[#0b0d11]/90 overflow-hidden shadow-[0_0_0_1px_rgba(255,255,255,0.02)]', className)}>
      <div className="flex items-center justify-between gap-3 px-4 md:px-5 py-3.5 border-b border-white/5 bg-white/[0.015]">
        <h3 className="text-sm font-semibold text-white">{title}</h3>
        {action}
      </div>
      <div className="p-4 md:p-5">{children}</div>
    </div>
  );
}

function MiniBars({ values, color = '#00e676' }: { values: number[]; color?: string }) {
  const max = Math.max(...values, 1);
  return (
    <div className="h-32 flex items-end gap-1">
      {values.map((v, i) => (
        <motion.div
          key={i}
          initial={{ height: 0 }}
          animate={{ height: `${(v / max) * 100}%` }}
          transition={{ delay: i * 0.02, type: 'spring', stiffness: 120, damping: 18 }}
          className="flex-1 rounded-t-sm min-h-[4px]"
          style={{ background: `linear-gradient(to top, ${color}40, ${color})` }}
        />
      ))}
    </div>
  );
}

function SkeletonGrid() {
  return (
    <div className="grid grid-cols-2 xl:grid-cols-4 gap-3">
      {Array.from({ length: 8 }).map((_, i) => (
        <div key={i} className="h-28 rounded-2xl border border-white/5 bg-white/[0.03] animate-pulse" />
      ))}
    </div>
  );
}

function batteryFromSession(s: Session) {
  const base = Math.min(96, Math.round(28 + Number(s.energy_kwh) * 2.1 + (s.duration_min % 17)));
  return base;
}

function etaMinutes(s: Session) {
  const pct = batteryFromSession(s);
  return Math.max(8, Math.round((100 - pct) * 0.9));
}

export type CloudRole = 'admin' | 'business' | 'installer';

const ROLE_VIEWS: Record<CloudRole, ViewId[]> = {
  admin: ['dashboard', 'chargers', 'sessions', 'map', 'analytics', 'ai', 'fleet', 'users', 'billing', 'installer', 'notifications', 'settings'],
  business: ['dashboard', 'chargers', 'sessions', 'map', 'analytics', 'fleet', 'users', 'billing', 'notifications', 'settings'],
  installer: ['dashboard', 'chargers', 'map', 'installer', 'notifications', 'settings'],
};

const ROLE_LABEL: Record<CloudRole, string> = {
  admin: 'Admin KYNETIK',
  business: 'Business Owner',
  installer: 'Installer Partner',
};

export default function CloudDashboard() {
  const [searchParams] = useSearchParams();
  const [role, setRole] = useState<CloudRole>(() => {
    const q = (typeof window !== 'undefined' && new URLSearchParams(window.location.search).get('role')) || '';
    if (q === 'admin' || q === 'business' || q === 'installer') return q;
    try {
      const s = localStorage.getItem('kyn_cloud_role');
      if (s === 'admin' || s === 'business' || s === 'installer') return s;
    } catch { /* */ }
    return 'admin';
  });
  const [view, setView] = useState<ViewId>('dashboard');
  const [chargers, setChargers] = useState<ChargePoint[]>([]);
  const [sessions, setSessions] = useState<Session[]>([]);
  const [users, setUsers] = useState<CloudUser[]>([]);
  const [notifs, setNotifs] = useState<Notif[]>([]);
  const [fleets, setFleets] = useState<Fleet[]>([]);
  const [jobs, setJobs] = useState<InstallerJob[]>([]);
  const [insights, setInsights] = useState<AiInsight[]>([]);
  const [billing, setBilling] = useState<BillingRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [mapFilter, setMapFilter] = useState('all');
  const [analyticsRange, setAnalyticsRange] = useState<'daily' | 'weekly' | 'monthly' | 'yearly'>('weekly');
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [busyId, setBusyId] = useState<number | null>(null);
  const [toast, setToast] = useState('');
  const [themeDark, setThemeDark] = useState(true);
  const [tick, setTick] = useState(0);

  const load = useCallback(async () => {
    try {
      const [c, s, u, n, f, j, a, b] = await Promise.all([
        apiGet<ChargePoint[]>('/api/charge-points'),
        apiGet<Session[]>('/api/charging-sessions'),
        apiGet<CloudUser[]>('/api/cloud-users'),
        apiGet<Notif[]>('/api/cloud-notifications'),
        apiGet<Fleet[]>('/api/fleets'),
        apiGet<InstallerJob[]>('/api/installer-jobs'),
        apiGet<AiInsight[]>('/api/ai-insights'),
        apiGet<BillingRecord[]>('/api/billing'),
      ]);
      setChargers(c);
      setSessions(s);
      setUsers(u);
      setNotifs(n);
      setFleets(f);
      setJobs(j);
      setInsights(a);
      setBilling(b);
      if (!selectedId && c[0]) setSelectedId(c[0].id);
      setError('');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load console');
    } finally {
      setLoading(false);
    }
  }, [selectedId]);

  useEffect(() => { load(); }, [load]);
  useEffect(() => {
    const t = setInterval(() => setTick((x) => x + 1), 4000);
    return () => clearInterval(t);
  }, []);

  useEffect(() => {
    const q = searchParams.get('role');
    if (q === 'admin' || q === 'business' || q === 'installer') {
      setRole(q);
      try { localStorage.setItem('kyn_cloud_role', q); } catch { /* */ }
    }
  }, [searchParams]);

  useEffect(() => {
    const allowed = ROLE_VIEWS[role];
    if (!allowed.includes(view)) setView(allowed[0] || 'dashboard');
  }, [role, view]);

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(''), 2600);
  };

  const runAction = async (id: number, action: string) => {
    setBusyId(id);
    try {
      await apiSend('/api/charge-points', 'PUT', { id, action });
      await load();
      showToast(`Command “${action.replaceAll('_', ' ')}” executed`);
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'Action failed');
    } finally {
      setBusyId(null);
    }
  };

  const markRead = async (id: number) => {
    await apiSend('/api/cloud-notifications', 'PUT', { id, read: true });
    setNotifs((prev) => prev.map((n) => (n.id === id ? { ...n, read: true } : n)));
  };

  const updateJob = async (id: number, status: string) => {
    await apiSend('/api/installer-jobs', 'PUT', { id, status });
    setJobs((prev) => prev.map((j) => (j.id === id ? { ...j, status } : j)));
    showToast(`Job marked ${status.replace('_', ' ')}`);
  };

  const filteredChargers = useMemo(() => {
    return chargers.filter((c) => {
      const q = search.toLowerCase();
      const matchQ =
        !q ||
        c.name.toLowerCase().includes(q) ||
        c.station_id.toLowerCase().includes(q) ||
        c.city.toLowerCase().includes(q) ||
        c.model.toLowerCase().includes(q) ||
        c.org_name?.toLowerCase().includes(q);
      const matchS = statusFilter === 'all' || c.status === statusFilter;
      return matchQ && matchS;
    });
  }, [chargers, search, statusFilter]);

  const mapChargers = useMemo(() => {
    const q = search.toLowerCase();
    return chargers.filter((c) => {
      const matchQ =
        !q ||
        c.name.toLowerCase().includes(q) ||
        c.city.toLowerCase().includes(q) ||
        c.org_name?.toLowerCase().includes(q) ||
        c.station_id.toLowerCase().includes(q);
      if (!matchQ) return false;
      if (mapFilter === 'all') return true;
      if (mapFilter === 'available') return c.status === 'available';
      if (mapFilter === 'busy') return c.status === 'charging';
      if (mapFilter === 'offline') return c.status === 'offline';
      if (mapFilter === 'maintenance') return c.status === 'maintenance' || c.status === 'fault';
      return true;
    });
  }, [chargers, mapFilter, search]);

  const selected = chargers.find((c) => c.id === selectedId) || chargers[0] || null;
  const unread = notifs.filter((n) => !n.read).length;
  const activeSessions = sessions.filter((s) => s.status === 'active');
  const onlineCount = chargers.filter((c) => ['available', 'charging'].includes(c.status)).length;
  const offlineCount = chargers.filter((c) => c.status === 'offline' || c.status === 'fault').length;
  const energyToday = sessions.reduce((a, s) => a + Number(s.energy_kwh || 0), 0);
  const revenueToday = sessions.reduce((a, s) => a + Number(s.cost_dt || 0), 0);
  const co2 = (energyToday * 0.42).toFixed(1);

  const energySeries = useMemo(() => {
    const base = {
      daily: [12, 18, 15, 22, 28, 31, 26, 34, 40, 38, 44, 48, 42, 39, 45, 50, 47, 43, 41, 36, 30, 24, 19, 14],
      weekly: [120, 145, 132, 168, 190, 210, 186],
      monthly: [820, 910, 880, 1020, 1140, 1090, 1210, 1180, 1300, 1260, 1400, energyToday + 980],
      yearly: [9.2, 10.1, 11.4, 12.8, 13.1, 14.6, 15.2, 16.0, 15.4, 16.8, 17.5, 18.2],
    }[analyticsRange];
    return base.map((v, i) => Math.round(v + ((tick + i) % 3)));
  }, [analyticsRange, energyToday, tick]);

  const allowedViews = ROLE_VIEWS[role];
  const groups = useMemo(() => {
    const map = new Map<string, typeof NAV>();
    NAV.filter((item) => allowedViews.includes(item.id)).forEach((item) => {
      const arr = map.get(item.group) || [];
      arr.push(item);
      map.set(item.group, arr);
    });
    return Array.from(map.entries());
  }, [allowedViews]);

  const go = (id: ViewId) => {
    setView(id);
    setSidebarOpen(false);
  };

  const exportReport = (label: string) => {
    showToast(`${label} export queued (PDF / Excel)`);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#07080a] flex items-center justify-center">
        <div className="w-full max-w-5xl px-6 space-y-6">
          <LoadingState label={`Booting KYNETIK Cloud · ${ROLE_LABEL[role]}…`} />
          <SkeletonGrid />
        </div>
      </div>
    );
  }

  return (
    <div className={cn('min-h-screen text-white flex', themeDark ? 'bg-[#07080a]' : 'bg-zinc-100 text-zinc-900')}>
      {/* Sidebar */}
      <aside
        className={cn(
          'fixed lg:sticky top-0 z-40 h-screen w-[270px] border-r flex flex-col transition-transform duration-300',
          themeDark ? 'bg-[#0a0b0f]/95 border-white/5 backdrop-blur-xl' : 'bg-white border-zinc-200',
          sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        )}
      >
        <div className="p-4 border-b border-white/5 flex items-center justify-between">
          <div>
            <BrandLogo height={28} />
            <p className="mt-2 text-[10px] uppercase tracking-[0.22em] text-kyn-green font-semibold">Cloud Platform</p>
            <p className="text-[10px] text-kyn-metal mt-1">{ROLE_LABEL[role]}</p>
          </div>
          <button type="button" className="lg:hidden p-1 text-kyn-metal" onClick={() => setSidebarOpen(false)}>
            <X size={18} />
          </button>
        </div>

        
        <div className="px-3 pt-3 pb-1 flex flex-wrap gap-1.5">
          {(['admin', 'business', 'installer'] as CloudRole[]).map((r) => (
            <button
              key={r}
              type="button"
              onClick={() => {
                setRole(r);
                try { localStorage.setItem('kyn_cloud_role', r); } catch { /* */ }
              }}
              className={cn(
                'px-2 py-1 rounded-lg text-[9px] font-bold uppercase tracking-wide border transition-colors',
                role === r ? 'bg-kyn-green/15 text-kyn-green border-kyn-green/30' : 'border-white/10 text-kyn-metal hover:text-white'
              )}
            >
              {r}
            </button>
          ))}
          <Link to="/cloud-platform" className="px-2 py-1 rounded-lg text-[9px] font-bold uppercase tracking-wide border border-white/10 text-kyn-metal hover:text-white">
            Exit
          </Link>
        </div>

        <nav className="flex-1 overflow-y-auto p-3 space-y-4">
          {groups.map(([group, items]) => (
            <div key={group}>
              <p className="px-2 mb-1.5 text-[10px] uppercase tracking-wider text-kyn-metal">{group}</p>
              <div className="space-y-0.5">
                {items.map(({ id, label, icon: Icon }) => (
                  <button
                    key={id}
                    type="button"
                    onClick={() => go(id)}
                    className={cn(
                      'w-full flex items-center gap-2.5 px-2.5 py-2 rounded-xl text-xs font-medium transition-all',
                      view === id
                        ? 'bg-kyn-green/15 text-kyn-green border border-kyn-green/25 shadow-[0_0_20px_rgba(0,230,118,0.08)]'
                        : 'text-kyn-silver hover:bg-white/5 hover:text-white border border-transparent'
                    )}
                  >
                    <Icon size={15} />
                    <span className="flex-1 text-left">{label}</span>
                    {id === 'notifications' && unread > 0 && (
                      <span className="min-w-[18px] h-[18px] rounded-full bg-kyn-green text-kyn-black text-[10px] font-bold flex items-center justify-center">
                        {unread}
                      </span>
                    )}
                  </button>
                ))}
              </div>
            </div>
          ))}
        </nav>

        <div className="p-3 border-t border-white/5 space-y-1">
          <div className="rounded-xl border border-white/8 bg-white/[0.02] p-3 mb-2">
            <p className="text-[10px] text-kyn-metal uppercase tracking-wider">Network health</p>
            <p className="text-sm font-semibold mt-1 text-kyn-green">{onlineCount}/{chargers.length} online</p>
          </div>
          <Link to="/cloud-platform" className="flex items-center gap-2 px-2.5 py-2 rounded-lg text-xs text-kyn-metal hover:text-white">
            <ExternalLink size={14} /> Marketing site
          </Link>
          <Link to="/design-system" className="flex items-center gap-2 px-2.5 py-2 rounded-lg text-xs text-kyn-metal hover:text-white">
            <Palette size={14} /> Design system
          </Link>
        </div>
      </aside>

      {sidebarOpen && <div className="fixed inset-0 z-30 bg-black/60 lg:hidden" onClick={() => setSidebarOpen(false)} />}

      <div className="flex-1 min-w-0 flex flex-col">
        <header className={cn('sticky top-0 z-20 border-b backdrop-blur-xl', themeDark ? 'bg-[#07080a]/90 border-white/5' : 'bg-white/90 border-zinc-200')}>
          <div className="h-14 md:h-16 px-4 md:px-6 flex items-center gap-3">
            <button type="button" className="lg:hidden p-2 text-kyn-silver" onClick={() => setSidebarOpen(true)}>
              <Menu size={18} />
            </button>
            <div className="min-w-0 flex-1">
              <p className="text-[10px] uppercase tracking-[0.2em] text-kyn-metal">KYNETIK Cloud · Welcome back</p>
              <h1 className="font-display text-sm md:text-base font-semibold truncate">
                {NAV.find((n) => n.id === view)?.label || 'Console'} · {ROLE_LABEL[role]}
              </h1>
            </div>
            <div className="hidden md:flex items-center gap-2 rounded-xl bg-white/5 border border-white/8 px-3 py-2 w-64">
              <Search size={14} className="text-kyn-metal" />
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search city, customer, charger…"
                className="bg-transparent outline-none text-xs w-full placeholder:text-kyn-metal"
              />
            </div>
            <button type="button" onClick={() => load()} className="p-2 rounded-xl border border-white/8 hover:border-kyn-green/30 text-kyn-silver" title="Refresh">
              <RefreshCw size={15} className={loading ? 'animate-spin' : ''} />
            </button>
            <button type="button" onClick={() => go('notifications')} className="relative p-2 rounded-xl border border-white/8 text-kyn-silver">
              <Bell size={15} />
              {unread > 0 && <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-kyn-green text-kyn-black text-[9px] font-bold flex items-center justify-center">{unread}</span>}
            </button>
            <div className="hidden sm:flex items-center gap-2 pl-2 border-l border-white/10">
              <div className="w-8 h-8 rounded-full bg-kyn-green/15 border border-kyn-green/30 flex items-center justify-center text-[11px] font-bold text-kyn-green">
                {role === 'admin' ? 'AD' : role === 'business' ? 'BO' : 'IN'}
              </div>
              <div className="leading-tight">
                <p className="text-xs font-semibold">Welcome back</p>
                <p className="text-[10px] text-kyn-metal">{ROLE_LABEL[role]}</p>
              </div>
            </div>
          </div>
        </header>

        <main className="flex-1 p-4 md:p-6 overflow-x-hidden">
          {error && (
            <div className="mb-4 rounded-xl border border-red-500/30 bg-red-500/10 px-4 py-3 text-sm text-red-300 flex items-center gap-2">
              <XCircle size={16} /> {error}
            </div>
          )}

          <AnimatePresence mode="wait">
            <motion.div
              key={view}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -6 }}
              transition={{ duration: 0.25 }}
            >
              {/* 01 EXECUTIVE */}
              {view === 'dashboard' && (
                <div className="space-y-5">
                  <div className="grid grid-cols-2 xl:grid-cols-4 gap-3">
                    <Kpi label="Total Stations" value={String(Math.max(chargers.length, 1) * 21)} delta={`${chargers.length} live in demo DB`} icon={PlugZap} />
                    <Kpi label="Active Chargers" value={String(onlineCount)} delta={`${Math.round((onlineCount / Math.max(chargers.length, 1)) * 100)}% Online`} icon={Wifi} accent />
                    <Kpi label="Energy Delivered" value={`${(energyToday / 1000 + 154.8).toFixed(1)} MWh`} delta="This month" icon={Zap} />
                    <Kpi label="Revenue" value="48,500 TND" delta="Monthly · demo target" icon={CreditCard} accent />
                    <Kpi label="Active sessions" value={String(activeSessions.length)} delta="live now" icon={Activity} />
                    <Kpi label="Offline / fault" value={String(offlineCount)} delta="needs attention" icon={AlertTriangle} />
                    <Kpi label="CO₂ saved" value={`${co2} kg`} delta="this period" icon={Leaf} />
                    <Kpi label="Monthly growth" value="+12.4%" delta="sessions MoM" icon={TrendingUp} accent />
                  </div>

                  <div className="grid xl:grid-cols-3 gap-4">
                    <Panel title="Energy & demand" className="xl:col-span-2" action={<button type="button" onClick={() => go('analytics')} className="text-[11px] text-kyn-green">Open analytics</button>}>
                      <MiniBars values={energySeries} />
                      <div className="mt-3 flex flex-wrap gap-3 text-[10px] text-kyn-metal">
                        <span>Peak hour 18:00–20:00</span>
                        <span>·</span>
                        <span>Load balance healthy</span>
                        <span>·</span>
                        <span className="text-kyn-green">Live counters · tick {tick}</span>
                      </div>
                    </Panel>
                    <Panel title="Smart alerts" action={<button type="button" onClick={() => go('notifications')} className="text-[11px] text-kyn-green">All</button>}>
                      <div className="space-y-2 max-h-64 overflow-y-auto pr-1">
                        {notifs.slice(0, 5).map((n) => (
                          <button key={n.id} type="button" onClick={() => markRead(n.id)} className="w-full text-left rounded-xl border border-white/6 bg-white/[0.02] p-3 hover:border-kyn-green/20">
                            <div className="flex items-center justify-between gap-2">
                              <p className="text-xs font-semibold">{n.title}</p>
                              <Badge status={n.severity} />
                            </div>
                            <p className="text-[11px] text-kyn-metal mt-1 line-clamp-2">{n.body}</p>
                          </button>
                        ))}
                      </div>
                    </Panel>
                  </div>

                  <div className="grid lg:grid-cols-3 gap-4">
                    <Panel title="Live sessions" className="lg:col-span-2" action={<button type="button" onClick={() => go('sessions')} className="text-[11px] text-kyn-green">Manage</button>}>
                      <div className="overflow-x-auto">
                        <table className="w-full text-left text-xs min-w-[640px]">
                          <thead className="text-kyn-metal">
                            <tr>
                              <th className="pb-2 font-medium">Vehicle / user</th>
                              <th className="pb-2 font-medium">Station</th>
                              <th className="pb-2 font-medium">Energy</th>
                              <th className="pb-2 font-medium">Speed</th>
                              <th className="pb-2 font-medium">Battery</th>
                              <th className="pb-2 font-medium">ETA</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-white/5">
                            {activeSessions.map((s) => (
                              <tr key={s.id} className="text-kyn-silver">
                                <td className="py-2.5 text-white font-medium">{s.user_name}</td>
                                <td className="py-2.5">{s.station_name}</td>
                                <td className="py-2.5 text-kyn-green">{s.energy_kwh} kWh</td>
                                <td className="py-2.5">{s.max_power_kw} kW</td>
                                <td className="py-2.5">{batteryFromSession(s)}%</td>
                                <td className="py-2.5">{etaMinutes(s)} min</td>
                              </tr>
                            ))}
                            {!activeSessions.length && (
                              <tr><td colSpan={6} className="py-8 text-center text-kyn-metal">No active sessions</td></tr>
                            )}
                          </tbody>
                        </table>
                      </div>
                    </Panel>
                    <Panel title="AI pulse" action={<button type="button" onClick={() => go('ai')} className="text-[11px] text-kyn-green">Insights</button>}>
                      <div className="space-y-2">
                        {insights.slice(0, 3).map((ins) => (
                          <div key={ins.id} className="rounded-xl border border-white/6 p-3 bg-white/[0.02]">
                            <div className="flex items-center gap-2 mb-1">
                              <Sparkles size={12} className="text-kyn-green" />
                              <Badge status={ins.severity} />
                            </div>
                            <p className="text-xs font-semibold">{ins.title}</p>
                            <p className="text-[11px] text-kyn-metal mt-1 line-clamp-2">{ins.body}</p>
                          </div>
                        ))}
                      </div>
                    </Panel>
                  </div>
                </div>
              )}

              {/* 02 CHARGERS */}
              {view === 'chargers' && (
                <div className="space-y-4">
                  <div className="flex flex-wrap gap-2 items-center">
                    <div className="flex items-center gap-2 rounded-xl bg-white/5 border border-white/8 px-3 py-2 flex-1 min-w-[200px] max-w-md">
                      <Search size={14} className="text-kyn-metal" />
                      <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Model, serial, city, customer…" className="bg-transparent outline-none text-xs w-full" />
                    </div>
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <Filter size={14} className="text-kyn-metal" />
                      {['all', 'available', 'charging', 'offline', 'fault', 'maintenance'].map((s) => (
                        <button key={s} type="button" onClick={() => setStatusFilter(s)} className={cn('px-2.5 py-1.5 rounded-full text-[10px] font-semibold capitalize border', statusFilter === s ? 'bg-kyn-green text-kyn-black border-kyn-green' : 'border-white/10 text-kyn-silver')}>
                          {s}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="grid lg:grid-cols-5 gap-4">
                    <Panel title={`${filteredChargers.length} chargers`} className="lg:col-span-3">
                      <div className="space-y-2 max-h-[680px] overflow-y-auto pr-1">
                        {filteredChargers.map((c) => (
                          <button
                            key={c.id}
                            type="button"
                            onClick={() => setSelectedId(c.id)}
                            className={cn('w-full text-left rounded-xl border p-3 transition-all', selectedId === c.id ? 'border-kyn-green/40 bg-kyn-green/5' : 'border-white/6 bg-white/[0.02] hover:border-white/15')}
                          >
                            <div className="flex items-start justify-between gap-3">
                              <div>
                                <p className="text-sm font-semibold text-white">{c.name}</p>
                                <p className="text-[11px] text-kyn-metal mt-0.5">SN {c.station_id} · {c.model}</p>
                                <p className="text-[11px] text-kyn-silver mt-1">{c.city} · {c.address}</p>
                              </div>
                              <Badge status={c.status} />
                            </div>
                            <div className="mt-2 grid grid-cols-2 sm:grid-cols-4 gap-2 text-[10px] text-kyn-metal">
                              <span className="flex items-center gap-1"><HardDrive size={11} /> FW {c.firmware}</span>
                              <span className="flex items-center gap-1"><Zap size={11} /> {c.power_kw} kW</span>
                              <span className="flex items-center gap-1"><Thermometer size={11} /> {c.temperature_c}°C</span>
                              <span className="flex items-center gap-1"><Wifi size={11} /> {c.ocpp_version}</span>
                            </div>
                          </button>
                        ))}
                      </div>
                    </Panel>

                    <Panel title="Charger control" className="lg:col-span-2">
                      {selected ? (
                        <div className="space-y-4">
                          <div>
                            <p className="font-display font-bold text-lg">{selected.name}</p>
                            <p className="text-xs text-kyn-metal mt-1">Serial {selected.station_id}</p>
                            <div className="mt-2 flex flex-wrap gap-2">
                              <Badge status={selected.status} />
                              <Badge status={selected.connector_status} />
                              <Badge status={selected.locked ? 'locked' : 'unlocked'} />
                            </div>
                          </div>
                          <div className="grid grid-cols-2 gap-2 text-xs">
                            {[
                              ['Model', selected.model],
                              ['Location', selected.city],
                              ['Power', `${selected.power_kw} kW`],
                              ['Temp', `${selected.temperature_c} °C`],
                              ['Connectivity', selected.status === 'offline' ? 'Offline' : 'Online'],
                              ['Last activity', new Date(selected.last_seen).toLocaleString()],
                              ['Firmware', selected.firmware],
                              ['Org', selected.org_name],
                            ].map(([l, v]) => (
                              <div key={l} className="rounded-xl bg-white/[0.03] border border-white/6 p-3">
                                <p className="text-kyn-metal">{l}</p>
                                <p className="font-semibold mt-1 truncate">{v}</p>
                              </div>
                            ))}
                          </div>
                          <div className="grid grid-cols-2 gap-2">
                            {[
                              { a: 'restart', l: 'Restart', icon: RotateCcw },
                              { a: selected.locked ? 'unlock' : 'lock', l: selected.locked ? 'Unlock' : 'Lock', icon: selected.locked ? Unlock : Lock },
                              { a: 'remote_start', l: 'Start', icon: Play },
                              { a: 'remote_stop', l: 'Stop', icon: Square },
                            ].map(({ a, l, icon: Icon }) => (
                              <button
                                key={a}
                                type="button"
                                disabled={busyId === selected.id}
                                onClick={() => runAction(selected.id, a)}
                                className="rounded-xl border border-white/10 bg-white/[0.03] hover:border-kyn-green/40 px-3 py-2.5 text-xs font-semibold flex items-center justify-center gap-1.5 disabled:opacity-50"
                              >
                                <Icon size={13} className="text-kyn-green" /> {busyId === selected.id ? '…' : l}
                              </button>
                            ))}
                          </div>
                          <div className="grid grid-cols-1 gap-2">
                            <button type="button" onClick={() => showToast('Diagnostics pack generated')} className="rounded-xl border border-white/10 px-3 py-2.5 text-xs font-semibold flex items-center justify-center gap-1.5 hover:border-kyn-green/30">
                              <Stethoscope size={13} className="text-kyn-green" /> Diagnostics
                            </button>
                            <button type="button" onClick={() => showToast('Firmware update queued')} className="rounded-xl border border-white/10 px-3 py-2.5 text-xs font-semibold flex items-center justify-center gap-1.5 hover:border-kyn-green/30">
                              <Cpu size={13} className="text-kyn-green" /> Update firmware
                            </button>
                            <button type="button" onClick={() => go('settings')} className="rounded-xl bg-kyn-green text-kyn-black px-3 py-2.5 text-xs font-bold flex items-center justify-center gap-1.5">
                              <Settings size={13} /> Configuration
                            </button>
                          </div>
                        </div>
                      ) : (
                        <p className="text-sm text-kyn-metal">Select a charger</p>
                      )}
                    </Panel>
                  </div>
                </div>
              )}

              {/* 03 LIVE SESSIONS */}
              {view === 'sessions' && (
                <div className="space-y-4">
                  <div className="grid md:grid-cols-4 gap-3">
                    <Kpi label="Live sessions" value={String(activeSessions.length)} icon={Activity} accent />
                    <Kpi label="Energy in flight" value={`${activeSessions.reduce((a, s) => a + Number(s.energy_kwh), 0).toFixed(1)} kWh`} icon={Zap} />
                    <Kpi label="Avg speed" value={`${(activeSessions.reduce((a, s) => a + Number(s.max_power_kw), 0) / Math.max(activeSessions.length, 1)).toFixed(1)} kW`} icon={Radio} />
                    <Kpi label="Session revenue" value={`${activeSessions.reduce((a, s) => a + Number(s.cost_dt), 0).toFixed(1)} DT`} icon={CreditCard} />
                  </div>
                  <div className="grid lg:grid-cols-2 gap-4">
                    {activeSessions.map((s) => {
                      const batt = batteryFromSession(s);
                      const cp = chargers.find((c) => c.station_id === s.station_id);
                      return (
                        <Panel key={s.id} title={s.session_code} action={<Badge status={s.status} />}>
                          <div className="flex items-start justify-between gap-4">
                            <div>
                              <p className="font-display text-lg font-bold">{s.user_name}</p>
                              <p className="text-xs text-kyn-metal mt-1">{s.station_name} · {s.rfid}</p>
                            </div>
                            <div className="relative w-16 h-16">
                              <div className="absolute inset-0 rounded-full" style={{ background: `conic-gradient(#00e676 ${batt}%, #1a1a1e 0)` }} />
                              <div className="absolute inset-1.5 rounded-full bg-[#0b0d11] flex items-center justify-center text-xs font-bold">{batt}%</div>
                            </div>
                          </div>
                          <div className="mt-4 grid grid-cols-3 gap-2 text-xs">
                            {[
                              ['Energy', `${s.energy_kwh} kWh`],
                              ['Speed', `${s.max_power_kw} kW`],
                              ['Duration', `${s.duration_min} min`],
                              ['Cost', `${s.cost_dt} DT`],
                              ['ETA', `${etaMinutes(s)} min`],
                              ['Finish', new Date(Date.now() + etaMinutes(s) * 60000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })],
                            ].map(([l, v]) => (
                              <div key={l} className="rounded-xl border border-white/6 bg-white/[0.02] p-2.5">
                                <p className="text-[10px] text-kyn-metal">{l}</p>
                                <p className="font-semibold mt-0.5">{v}</p>
                              </div>
                            ))}
                          </div>
                          <button
                            type="button"
                            disabled={!cp}
                            onClick={() => cp && runAction(cp.id, 'remote_stop')}
                            className="mt-4 w-full rounded-xl border border-red-500/30 text-red-300 text-xs font-semibold py-2.5 hover:bg-red-500/10 disabled:opacity-40"
                          >
                            Remote stop
                          </button>
                        </Panel>
                      );
                    })}
                    {!activeSessions.length && (
                      <Panel title="No live sessions" className="lg:col-span-2">
                        <p className="text-sm text-kyn-metal">Active charging sessions will appear here in real time.</p>
                      </Panel>
                    )}
                  </div>
                  <Panel title="Session history">
                    <div className="overflow-x-auto">
                      <table className="w-full text-left text-xs min-w-[700px]">
                        <thead className="text-kyn-metal">
                          <tr>
                            <th className="pb-2">Code</th>
                            <th className="pb-2">User</th>
                            <th className="pb-2">Station</th>
                            <th className="pb-2">Energy</th>
                            <th className="pb-2">Cost</th>
                            <th className="pb-2">Status</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-white/5">
                          {sessions.map((s) => (
                            <tr key={s.id} className="text-kyn-silver">
                              <td className="py-2.5 text-white font-medium">{s.session_code}</td>
                              <td className="py-2.5">{s.user_name}</td>
                              <td className="py-2.5">{s.station_name}</td>
                              <td className="py-2.5">{s.energy_kwh} kWh</td>
                              <td className="py-2.5">{s.cost_dt} DT</td>
                              <td className="py-2.5"><Badge status={s.status} /></td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </Panel>
                </div>
              )}

              {/* 04 MAP */}
              {view === 'map' && (
                <div className="space-y-4">
                  <div className="flex flex-wrap gap-2 items-center">
                    {['all', 'available', 'busy', 'offline', 'maintenance'].map((f) => (
                      <button key={f} type="button" onClick={() => setMapFilter(f)} className={cn('px-3 py-1.5 rounded-full text-[11px] font-semibold capitalize border', mapFilter === f ? 'bg-kyn-green text-kyn-black border-kyn-green' : 'border-white/10 text-kyn-silver')}>
                        {f}
                      </button>
                    ))}
                    <span className="text-[11px] text-kyn-metal ml-auto">{mapChargers.length} locations</span>
                  </div>
                  <Panel title="Interactive network map" action={<span className="text-[10px] text-kyn-green flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full bg-kyn-green animate-pulse" /> Live</span>}>
                    <div className="relative h-[480px] rounded-2xl bg-[#0c1210] border border-white/5 overflow-hidden">
                      <div className="absolute inset-0 opacity-40" style={{ backgroundImage: 'radial-gradient(circle at 20% 30%, rgba(0,230,118,0.12), transparent 35%), radial-gradient(circle at 70% 60%, rgba(56,189,248,0.08), transparent 30%), linear-gradient(rgba(0,230,118,0.06) 1px, transparent 1px), linear-gradient(90deg, rgba(0,230,118,0.06) 1px, transparent 1px)', backgroundSize: 'auto, auto, 32px 32px, 32px 32px' }} />
                      <div className="absolute left-1/2 top-[42%] -translate-x-1/2 -translate-y-1/2 w-[58%] h-[46%] rounded-[40%] border border-kyn-green/10 bg-kyn-green/[0.03]" />
                      {mapChargers.map((c, i) => {
                        const top = 12 + ((Math.abs(Number(c.lat) * 10 + i * 7) % 70));
                        const left = 8 + ((Math.abs(Number(c.lng) * 12 + i * 11) % 80));
                        return (
                          <button
                            key={c.id}
                            type="button"
                            onClick={() => { setSelectedId(c.id); go('chargers'); }}
                            className="absolute group"
                            style={{ top: `${top}%`, left: `${left}%` }}
                            title={`${c.name} · ${c.status}`}
                          >
                            <span className={cn(
                              'w-3.5 h-3.5 rounded-full border-2 block transition-transform group-hover:scale-125',
                              c.status === 'charging' && 'bg-kyn-green border-kyn-green shadow-[0_0_14px_#00e676]',
                              c.status === 'available' && 'bg-emerald-400 border-emerald-300',
                              c.status === 'offline' && 'bg-zinc-600 border-zinc-500',
                              (c.status === 'fault' || c.status === 'maintenance') && 'bg-amber-400 border-amber-300 animate-pulse'
                            )} />
                            <span className="opacity-0 group-hover:opacity-100 absolute left-4 top-1/2 -translate-y-1/2 whitespace-nowrap rounded-lg bg-black/80 border border-white/10 px-2 py-1 text-[10px] transition-opacity">
                              {c.name} · {c.city}
                            </span>
                          </button>
                        );
                      })}
                      <div className="absolute bottom-3 left-3 flex flex-wrap gap-2 text-[10px]">
                        {['available', 'busy', 'offline', 'maintenance'].map((s) => (
                          <span key={s} className="px-2 py-1 rounded-md bg-black/50 border border-white/10 capitalize text-kyn-silver">{s}</span>
                        ))}
                      </div>
                    </div>
                  </Panel>
                </div>
              )}

              {/* 05 ANALYTICS */}
              {view === 'analytics' && (
                <div className="space-y-4">
                  <div className="flex flex-wrap gap-2 items-center justify-between">
                    <div className="flex gap-1.5 p-1 rounded-full bg-white/5 border border-white/8">
                      {(['daily', 'weekly', 'monthly', 'yearly'] as const).map((r) => (
                        <button key={r} type="button" onClick={() => setAnalyticsRange(r)} className={cn('px-3 py-1.5 rounded-full text-[11px] font-semibold capitalize', analyticsRange === r ? 'bg-kyn-green text-kyn-black' : 'text-kyn-silver')}>
                          {r}
                        </button>
                      ))}
                    </div>
                    <div className="flex gap-2">
                      <button type="button" onClick={() => exportReport('PDF')} className="px-3 py-1.5 rounded-xl border border-white/10 text-xs font-semibold flex items-center gap-1.5"><Download size={13} className="text-kyn-green" /> PDF</button>
                      <button type="button" onClick={() => exportReport('Excel')} className="px-3 py-1.5 rounded-xl border border-white/10 text-xs font-semibold flex items-center gap-1.5"><FileText size={13} className="text-kyn-green" /> Excel</button>
                    </div>
                  </div>
                  <div className="grid md:grid-cols-4 gap-3">
                    <Kpi label="Consumption" value={`${energyToday.toFixed(0)} kWh`} delta="+4.1%" icon={Zap} accent />
                    <Kpi label="Peak hours" value="18–20h" delta="grid stress med" icon={Clock} />
                    <Kpi label="Load balance" value="Healthy" delta="under 80% feeder" icon={Target} />
                    <Kpi label="CO₂ reduction" value={`${co2} kg`} delta="vs ICE baseline" icon={Leaf} />
                  </div>
                  <div className="grid xl:grid-cols-3 gap-4">
                    <Panel title={`${analyticsRange} consumption`} className="xl:col-span-2">
                      <MiniBars values={energySeries} />
                    </Panel>
                    <Panel title="Peak & load">
                      <div className="space-y-3 text-xs">
                        {[
                          ['00–06', 28],
                          ['06–12', 62],
                          ['12–18', 74],
                          ['18–24', 91],
                        ].map(([label, pct]) => (
                          <div key={label as string}>
                            <div className="flex justify-between text-kyn-metal mb-1"><span>{label}</span><span className="text-kyn-green">{pct}%</span></div>
                            <div className="h-2 rounded-full bg-white/5 overflow-hidden">
                              <div className="h-full rounded-full bg-gradient-to-r from-kyn-green/50 to-kyn-green" style={{ width: `${pct}%` }} />
                            </div>
                          </div>
                        ))}
                      </div>
                    </Panel>
                  </div>
                </div>
              )}

              {/* 06 FLEET */}
              {view === 'fleet' && (
                <div className="space-y-4">
                  <div className="grid md:grid-cols-4 gap-3">
                    <Kpi label="Fleets" value={String(fleets.length)} icon={Building2} />
                    <Kpi label="Vehicles" value={String(fleets.reduce((a, f) => a + Number(f.vehicles), 0))} icon={Car} accent />
                    <Kpi label="Drivers" value={String(fleets.reduce((a, f) => a + Number(f.drivers), 0))} icon={UserCircle2} />
                    <Kpi label="Fleet energy cost" value={`${fleets.reduce((a, f) => a + Number(f.cost_dt), 0).toLocaleString()} DT`} icon={CreditCard} />
                  </div>
                  <div className="grid lg:grid-cols-2 gap-4">
                    {fleets.map((f) => (
                      <Panel key={f.id} title={f.name} action={<Badge status={f.status} />}>
                        <p className="text-xs text-kyn-metal">{f.company} · {f.city}</p>
                        <div className="mt-4 grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs">
                          {[
                            ['Vehicles', f.vehicles],
                            ['Drivers', f.drivers],
                            ['Chargers', f.chargers],
                            ['Energy', `${Number(f.energy_kwh).toLocaleString()} kWh`],
                            ['Cost', `${Number(f.cost_dt).toLocaleString()} DT`],
                            ['Avg / veh', `${(Number(f.energy_kwh) / Math.max(Number(f.vehicles), 1)).toFixed(0)} kWh`],
                          ].map(([l, v]) => (
                            <div key={l as string} className="rounded-xl border border-white/6 bg-white/[0.02] p-3">
                              <p className="text-[10px] text-kyn-metal">{l}</p>
                              <p className="font-semibold mt-1">{v}</p>
                            </div>
                          ))}
                        </div>
                      </Panel>
                    ))}
                  </div>
                </div>
              )}

              {/* 07 USERS */}
              {view === 'users' && (
                <div className="space-y-4">
                  <Panel title="Directory">
                    <div className="overflow-x-auto">
                      <table className="w-full text-left text-xs min-w-[720px]">
                        <thead className="text-kyn-metal">
                          <tr>
                            <th className="pb-2">Name</th>
                            <th className="pb-2">Email</th>
                            <th className="pb-2">Org</th>
                            <th className="pb-2">Role</th>
                            <th className="pb-2">Type</th>
                            <th className="pb-2">Status</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-white/5">
                          {users.map((u) => (
                            <tr key={u.id} className="text-kyn-silver">
                              <td className="py-2.5 text-white font-medium">{u.name}</td>
                              <td className="py-2.5">{u.email}</td>
                              <td className="py-2.5">{u.org_name}</td>
                              <td className="py-2.5">{u.role}</td>
                              <td className="py-2.5 capitalize">{u.user_type}</td>
                              <td className="py-2.5"><Badge status={u.status} /></td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </Panel>
                  <Panel title="Permissions matrix">
                    <div className="overflow-x-auto">
                      <table className="w-full text-left text-[11px] min-w-[800px]">
                        <thead className="text-kyn-metal">
                          <tr>
                            <th className="pb-3 pr-4">Role</th>
                            {PERMS.map((p) => <th key={p} className="pb-3 px-2 font-medium">{p}</th>)}
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-white/5">
                          {ROLES.map((role) => (
                            <tr key={role}>
                              <td className="py-3 pr-4 text-white font-semibold whitespace-nowrap">{role}</td>
                              {PERM_MATRIX[role].map((ok, i) => (
                                <td key={i} className="py-3 px-2 text-center">
                                  {ok ? <CheckCircle2 size={14} className="inline text-kyn-green" /> : <XCircle size={14} className="inline text-kyn-metal/50" />}
                                </td>
                              ))}
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </Panel>
                </div>
              )}

              {/* 08 NOTIFICATIONS */}
              {view === 'notifications' && (
                <div className="space-y-3">
                  {notifs.map((n) => (
                    <button
                      key={n.id}
                      type="button"
                      onClick={() => markRead(n.id)}
                      className={cn('w-full text-left rounded-2xl border p-4 transition-all hover:border-kyn-green/25', n.read ? 'border-white/6 bg-white/[0.015]' : 'border-kyn-green/20 bg-kyn-green/[0.04]')}
                    >
                      <div className="flex items-start gap-3">
                        <div className="mt-0.5">
                          {n.severity === 'critical' ? <XCircle className="text-red-400" size={18} /> :
                           n.severity === 'warning' ? <AlertTriangle className="text-amber-300" size={18} /> :
                           n.severity === 'success' ? <CheckCircle2 className="text-kyn-green" size={18} /> :
                           <Info className="text-sky-300" size={18} />}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex flex-wrap items-center gap-2">
                            <p className="text-sm font-semibold">{n.title}</p>
                            <Badge status={n.severity} />
                            <span className="text-[10px] text-kyn-metal capitalize">{n.category}</span>
                            {!n.read && <span className="text-[10px] text-kyn-green font-semibold">NEW</span>}
                          </div>
                          <p className="text-xs text-kyn-silver mt-1">{n.body}</p>
                          <p className="text-[10px] text-kyn-metal mt-2">{new Date(n.created_at).toLocaleString()}</p>
                        </div>
                      </div>
                    </button>
                  ))}
                </div>
              )}

              {/* 09 BILLING */}
              {view === 'billing' && (
                <div className="space-y-4">
                  <div className="grid md:grid-cols-3 gap-3">
                    <Kpi label="Open invoices" value={String(billing.filter((b) => b.kind === 'invoice' && b.status !== 'paid').length)} icon={FileText} />
                    <Kpi label="MRR plans" value={`${billing.filter((b) => b.kind === 'plan').reduce((a, b) => a + Number(b.amount_dt), 0).toLocaleString()} DT`} icon={CreditCard} accent />
                    <Kpi label="Licenses active" value={String(billing.filter((b) => b.kind === 'license').length)} icon={Shield} />
                  </div>
                  <div className="grid xl:grid-cols-3 gap-4">
                    <Panel title="Invoices" className="xl:col-span-2" action={<button type="button" onClick={() => exportReport('Invoices')} className="text-[11px] text-kyn-green">Download</button>}>
                      <div className="space-y-2">
                        {billing.filter((b) => b.kind === 'invoice').map((b) => (
                          <div key={b.id} className="flex flex-wrap items-center gap-3 rounded-xl border border-white/6 bg-white/[0.02] p-3 text-xs">
                            <div className="flex-1 min-w-[140px]">
                              <p className="font-semibold text-white">{b.title}</p>
                              <p className="text-kyn-metal mt-0.5">{b.customer} · {b.period}</p>
                            </div>
                            <div className="text-right">
                              <p className="font-semibold">{Number(b.amount_dt).toLocaleString()} DT</p>
                              <p className="text-kyn-metal">VAT {Number(b.vat_dt).toLocaleString()} DT</p>
                            </div>
                            <Badge status={b.status} />
                            <button type="button" onClick={() => showToast(`Invoice ${b.title} downloaded`)} className="p-2 rounded-lg border border-white/10 hover:border-kyn-green/30"><Download size={13} className="text-kyn-green" /></button>
                          </div>
                        ))}
                      </div>
                    </Panel>
                    <Panel title="Plans & subscriptions">
                      <div className="space-y-2">
                        {billing.filter((b) => b.kind === 'plan' || b.kind === 'license').map((b) => (
                          <div key={b.id} className="rounded-xl border border-white/6 p-3">
                            <div className="flex items-center justify-between gap-2">
                              <p className="text-sm font-semibold">{b.title}</p>
                              <Badge status={b.status} />
                            </div>
                            <p className="text-xs text-kyn-metal mt-1">{b.plan} · {b.period}</p>
                            {Number(b.amount_dt) > 0 && <p className="text-kyn-green text-sm font-semibold mt-2">{Number(b.amount_dt)} DT</p>}
                          </div>
                        ))}
                      </div>
                    </Panel>
                  </div>
                  <Panel title="Payments">
                    <div className="overflow-x-auto">
                      <table className="w-full text-left text-xs min-w-[560px]">
                        <thead className="text-kyn-metal">
                          <tr>
                            <th className="pb-2">Payment</th>
                            <th className="pb-2">Customer</th>
                            <th className="pb-2">Amount</th>
                            <th className="pb-2">Plan</th>
                            <th className="pb-2">Status</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-white/5">
                          {billing.filter((b) => b.kind === 'payment').map((b) => (
                            <tr key={b.id} className="text-kyn-silver">
                              <td className="py-2.5 text-white font-medium">{b.title}</td>
                              <td className="py-2.5">{b.customer}</td>
                              <td className="py-2.5">{Number(b.amount_dt).toLocaleString()} DT</td>
                              <td className="py-2.5">{b.plan}</td>
                              <td className="py-2.5"><Badge status={b.status} /></td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </Panel>
                </div>
              )}

              {/* 10 INSTALLER */}
              {view === 'installer' && (
                <div className="space-y-4">
                  <div className="grid md:grid-cols-4 gap-3">
                    <Kpi label="Assigned" value={String(jobs.length)} icon={Wrench} />
                    <Kpi label="Pending" value={String(jobs.filter((j) => ['pending', 'open'].includes(j.status)).length)} icon={Clock} accent />
                    <Kpi label="In progress" value={String(jobs.filter((j) => j.status === 'in_progress').length)} icon={Activity} />
                    <Kpi label="Completed" value={String(jobs.filter((j) => j.status === 'completed').length)} icon={CheckCircle2} />
                  </div>
                  <div className="grid lg:grid-cols-2 gap-4">
                    {jobs.map((job) => (
                      <Panel key={job.id} title={job.title} action={<Badge status={job.priority} />}>
                        <div className="flex flex-wrap gap-2 mb-3">
                          <Badge status={job.status} />
                          <span className="text-[10px] text-kyn-metal px-2 py-0.5 rounded-full border border-white/10">{job.model}</span>
                        </div>
                        <div className="grid grid-cols-2 gap-2 text-xs">
                          <div className="rounded-xl border border-white/6 p-2.5"><p className="text-kyn-metal">Customer</p><p className="font-semibold mt-0.5">{job.customer}</p></div>
                          <div className="rounded-xl border border-white/6 p-2.5"><p className="text-kyn-metal">City</p><p className="font-semibold mt-0.5">{job.city}</p></div>
                          <div className="rounded-xl border border-white/6 p-2.5"><p className="text-kyn-metal">Assignee</p><p className="font-semibold mt-0.5">{job.assignee}</p></div>
                          <div className="rounded-xl border border-white/6 p-2.5"><p className="text-kyn-metal">Schedule</p><p className="font-semibold mt-0.5">{job.scheduled_at}</p></div>
                        </div>
                        <p className="text-xs text-kyn-silver mt-3">{job.notes}</p>
                        <div className="mt-4 flex flex-wrap gap-2">
                          {job.status !== 'completed' && (
                            <button type="button" onClick={() => updateJob(job.id, 'in_progress')} className="px-3 py-1.5 rounded-lg border border-white/10 text-[11px] font-semibold hover:border-kyn-green/30">Start</button>
                          )}
                          {job.status !== 'completed' && (
                            <button type="button" onClick={() => updateJob(job.id, 'completed')} className="px-3 py-1.5 rounded-lg bg-kyn-green text-kyn-black text-[11px] font-bold">Complete + report</button>
                          )}
                          <button type="button" onClick={() => showToast('Support ticket opened')} className="px-3 py-1.5 rounded-lg border border-white/10 text-[11px] font-semibold">Support ticket</button>
                        </div>
                      </Panel>
                    ))}
                  </div>
                </div>
              )}

              {/* 11 AI */}
              {view === 'ai' && (
                <div className="space-y-4">
                  <div className="rounded-2xl border border-kyn-green/20 bg-gradient-to-r from-kyn-green/10 via-transparent to-sky-500/5 p-5 md:p-6">
                    <div className="flex items-start gap-3">
                      <div className="w-11 h-11 rounded-2xl bg-kyn-green/15 border border-kyn-green/30 flex items-center justify-center text-kyn-green">
                        <Sparkles size={20} />
                      </div>
                      <div>
                        <p className="text-[10px] uppercase tracking-[0.2em] text-kyn-green font-semibold">KYNETIK Intelligence</p>
                        <h2 className="font-display text-xl md:text-2xl font-bold mt-1">Predictive ops for global EV networks</h2>
                        <p className="text-sm text-kyn-silver mt-2 max-w-2xl">Anomaly detection, maintenance forecasts and charging optimisation — designed for operators and investors.</p>
                      </div>
                    </div>
                  </div>
                  <div className="grid lg:grid-cols-2 gap-4">
                    {insights.map((ins) => (
                      <Panel key={ins.id} title={ins.title} action={<Badge status={ins.severity} />}>
                        <p className="text-[10px] uppercase tracking-wider text-kyn-metal mb-2">{ins.category}</p>
                        <p className="text-sm text-kyn-silver leading-relaxed">{ins.body}</p>
                        <div className="mt-4 flex items-center justify-between gap-3">
                          <span className="text-xs text-kyn-green font-semibold">{ins.impact}</span>
                          <button type="button" onClick={() => showToast(`${ins.action_label} queued`)} className="px-3 py-1.5 rounded-lg bg-kyn-green text-kyn-black text-[11px] font-bold">
                            {ins.action_label}
                          </button>
                        </div>
                      </Panel>
                    ))}
                  </div>
                </div>
              )}

              {/* 12 SETTINGS */}
              {view === 'settings' && (
                <div className="grid lg:grid-cols-2 gap-4">
                  <Panel title="Platform">
                    <div className="space-y-2">
                      {[
                        { icon: Palette, l: 'Branding', v: 'KYNETIK green · dark premium' },
                        { icon: Shield, l: 'Security', v: 'SSO ready · 2FA enforced' },
                        { icon: KeyRound, l: 'API keys', v: '3 active production keys' },
                        { icon: Globe, l: 'Integrations', v: 'OCPP · webhooks · ERP' },
                        { icon: Server, l: 'OCPP settings', v: '1.6J / 2.0.1 dual stack' },
                        { icon: Globe, l: 'Languages', v: 'FR · EN · AR' },
                        { icon: Clock, l: 'Time zone', v: 'Africa/Tunis (GMT+1)' },
                        { icon: HardDrive, l: 'Backup', v: 'Daily encrypted snapshots' },
                        { icon: FileText, l: 'Audit logs', v: '90-day retention' },
                      ].map(({ icon: Icon, l, v }) => (
                        <div key={l} className="flex items-center gap-3 rounded-xl border border-white/6 px-3 py-3 hover:border-kyn-green/20 transition-colors">
                          <Icon size={16} className="text-kyn-green" />
                          <div className="flex-1">
                            <p className="font-semibold text-sm">{l}</p>
                            <p className="text-xs text-kyn-metal">{v}</p>
                          </div>
                          <ChevronRight size={14} className="text-kyn-metal" />
                        </div>
                      ))}
                      <button
                        type="button"
                        onClick={() => setThemeDark((v) => !v)}
                        className="w-full flex items-center justify-between rounded-xl border border-white/6 px-3 py-3"
                      >
                        <span className="flex items-center gap-3 text-sm font-semibold">
                          {themeDark ? <Moon size={16} className="text-kyn-green" /> : <Sun size={16} className="text-amber-300" />}
                          Theme
                        </span>
                        <span className="text-xs text-kyn-metal">{themeDark ? 'Dark' : 'Light'}</span>
                      </button>
                    </div>
                  </Panel>
                  <Panel title="Roles snapshot">
                    <div className="space-y-2 text-xs">
                      {ROLES.map((r) => (
                        <div key={r} className="flex items-center justify-between rounded-xl border border-white/6 px-3 py-2.5">
                          <span>{r}</span>
                          <span className="text-kyn-green">Configured</span>
                        </div>
                      ))}
                      <div className="pt-3 border-t border-white/5 space-y-2">
                        {['Stripe / local PSP', 'Roaming hub', 'ERP webhook', 'Slack / Teams alerts'].map((i) => (
                          <div key={i} className="flex items-center justify-between rounded-xl border border-white/6 px-3 py-2.5">
                            <span>{i}</span>
                            <Badge status="success" />
                          </div>
                        ))}
                      </div>
                    </div>
                  </Panel>
                </div>
              )}
            </motion.div>
          </AnimatePresence>
        </main>
      </div>

      <AnimatePresence>
        {toast && (
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 8 }}
            className="fixed bottom-6 right-6 z-50 rounded-xl border border-kyn-green/30 bg-kyn-void/95 backdrop-blur px-4 py-3 text-sm shadow-2xl"
          >
            {toast}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

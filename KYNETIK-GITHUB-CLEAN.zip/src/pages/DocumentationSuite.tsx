import { useEffect, useMemo, useState, type ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  ArrowRight, BookMarked, CheckCircle2, ChevronRight, CircleDashed,
  FileText, Layers, Menu, Search, Sparkles, Target, X, Zap,
  AlertTriangle, Rocket, Shield, Compass
} from 'lucide-react';
import BrandLogo from '../components/BrandLogo';
import LoadingState from '../components/LoadingState';
import { apiGet, cn } from '../lib/utils';
import { VOLUMES, GAP_DOCS, type VolumeDef } from '../lib/docsSuiteData';

interface DocItem {
  id: number;
  volume: string;
  type: string;
  title: string;
  subtitle: string | null;
  body: string;
  meta: string | null;
  sort_order: number;
}

function statusStyle(s: VolumeDef['status']) {
  if (s === 'canonical') return 'text-emerald-300 bg-emerald-400/10 border-emerald-400/25';
  if (s === 'living') return 'text-sky-300 bg-sky-400/10 border-sky-400/25';
  return 'text-amber-300 bg-amber-400/10 border-amber-400/25';
}

function statusLabel(s: VolumeDef['status']) {
  if (s === 'canonical') return 'Canonical';
  if (s === 'living') return 'Living doc';
  return 'Gap / draft';
}

function Fade({ children, className, delay = 0 }: { children: ReactNode; className?: string; delay?: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-40px' }}
      transition={{ duration: 0.45, delay }}
      className={className}
    >
      {children}
    </motion.div>
  );
}

export default function DocumentationSuite() {
  const [items, setItems] = useState<DocItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeVol, setActiveVol] = useState(VOLUMES[0].id);
  const [query, setQuery] = useState('');
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    apiGet<DocItem[]>('/api/docs-suite')
      .then(setItems)
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const volume = VOLUMES.find((v) => v.id === activeVol) || VOLUMES[0];

  const volumeItems = useMemo(
    () => items.filter((i) => i.volume === activeVol).sort((a, b) => a.sort_order - b.sort_order),
    [items, activeVol]
  );

  const filteredVolumes = useMemo(() => {
    if (!query.trim()) return VOLUMES;
    const q = query.toLowerCase();
    return VOLUMES.filter(
      (v) =>
        v.title.toLowerCase().includes(q) ||
        v.summary.toLowerCase().includes(q) ||
        v.audience.toLowerCase().includes(q) ||
        v.pillars.some((p) => p.toLowerCase().includes(q))
    );
  }, [query]);

  const principles = items.filter((i) => i.type === 'principle');
  const stats = items.filter((i) => i.type === 'stat');

  if (loading) {
    return (
      <div className="min-h-screen bg-[#05070c] flex items-center justify-center">
        <LoadingState label="Loading documentation suite…" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#05070c] text-slate-100">
      {/* Top bar */}
      <header
        className={cn(
          'fixed top-0 inset-x-0 z-50 transition-all duration-300',
          scrolled ? 'bg-[#05070c]/90 backdrop-blur-xl border-b border-white/[0.06]' : 'bg-transparent'
        )}
      >
        <div className="max-w-[1400px] mx-auto px-4 md:px-6 h-14 md:h-16 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 min-w-0">
            <BrandLogo height={28} />
            <div className="hidden sm:block h-5 w-px bg-white/10" />
            <div className="hidden sm:flex items-center gap-2 min-w-0">
              <BookMarked size={14} className="text-sky-400 shrink-0" />
              <span className="text-xs font-medium text-slate-300 truncate">Product Documentation Suite</span>
              <span className="text-[10px] px-1.5 py-0.5 rounded border border-white/10 text-slate-500 font-mono">v3.0</span>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Link to="/master-docs" className="hidden md:inline text-[11px] text-slate-500 hover:text-white">
              Master Docs v2
            </Link>
            <a
              href="#gaps"
              className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-amber-400/10 border border-amber-400/25 text-amber-200 text-[11px] font-semibold"
            >
              <AlertTriangle size={12} /> 5 strategic gaps
            </a>
            <a
              href="#next"
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-kyn-green text-kyn-black text-[11px] font-bold"
            >
              Next: PRD <ArrowRight size={12} />
            </a>
            <button type="button" className="lg:hidden p-2 text-slate-400" onClick={() => setMenuOpen(!menuOpen)}>
              {menuOpen ? <X size={18} /> : <Menu size={18} />}
            </button>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="relative pt-24 md:pt-28 pb-12 md:pb-16 border-b border-white/[0.06]">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(56,189,248,0.08),transparent_55%)]" />
        <div className="absolute inset-0 opacity-[0.35]" style={{
          backgroundImage: 'linear-gradient(rgba(148,163,184,0.06) 1px, transparent 1px), linear-gradient(90deg, rgba(148,163,184,0.06) 1px, transparent 1px)',
          backgroundSize: '48px 48px',
        }} />
        <div className="relative max-w-[1400px] mx-auto px-4 md:px-6">
          <Fade>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-sky-400/20 bg-sky-400/5 text-sky-300 text-[11px] font-semibold mb-6">
              <Sparkles size={12} />
              Apple clarity · Tesla ambition · Stripe rigor · AWS structure
            </div>
            <h1 className="font-display text-3xl sm:text-4xl md:text-5xl lg:text-[3.25rem] font-bold tracking-tight text-white max-w-4xl leading-[1.08]">
              KYNETIK Product
              <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-sky-300 via-emerald-300 to-teal-200">
                Documentation Suite
              </span>
            </h1>
            <p className="mt-5 text-base md:text-lg text-slate-400 max-w-2xl leading-relaxed">
              Institutional knowledge system for a Tunisian EV charging technology company building toward global
              standards — twenty governed volumes spanning vision, product, design, platforms, security, operations,
              and investment cadence.
            </p>
          </Fade>

          <div className="mt-10 grid grid-cols-2 md:grid-cols-4 gap-3 max-w-3xl">
            {(stats.length
              ? stats.slice(0, 4).map((s) => ({ title: s.title, label: s.subtitle || s.body }))
              : [
                  { title: '20', label: 'Governed volumes' },
                  { title: '5', label: 'Strategic gap docs' },
                  { title: '1', label: 'Source of truth' },
                  { title: 'PRD', label: 'Recommended next' },
                ]
            ).map((s, i) => (
              <Fade key={s.title} delay={i * 0.05}>
                <div className="rounded-xl border border-white/[0.07] bg-white/[0.02] px-4 py-3">
                  <p className="font-display text-2xl font-bold text-white">{s.title}</p>
                  <p className="text-[11px] text-slate-500 mt-0.5">{s.label}</p>
                </div>
              </Fade>
            ))}
          </div>

          {/* Principles strip */}
          {principles.length > 0 && (
            <div className="mt-10 grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
              {principles.slice(0, 4).map((p, i) => (
                <Fade key={p.id} delay={0.05 + i * 0.04}>
                  <div className="rounded-xl border border-white/[0.06] bg-gradient-to-b from-white/[0.03] to-transparent p-4 h-full">
                    <p className="text-[10px] uppercase tracking-[0.2em] text-sky-400/80 mb-2">Doctrine</p>
                    <p className="font-semibold text-sm text-white">{p.title}</p>
                    <p className="text-xs text-slate-500 mt-2 leading-relaxed">{p.body}</p>
                  </div>
                </Fade>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Main workspace */}
      <div className="max-w-[1400px] mx-auto px-4 md:px-6 py-8 md:py-10">
        <div className="flex flex-col lg:flex-row gap-6 lg:gap-8">
          {/* Sidebar volumes */}
          <aside
            className={cn(
              'lg:w-80 shrink-0',
              menuOpen ? 'block' : 'hidden lg:block'
            )}
          >
            <div className="lg:sticky lg:top-20 space-y-3">
              <div className="relative">
                <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                <input
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="Search volumes…"
                  className="w-full rounded-xl bg-white/[0.03] border border-white/10 pl-9 pr-3 py-2.5 text-sm text-white placeholder:text-slate-600 focus:outline-none focus:border-sky-400/40"
                />
              </div>
              <p className="text-[10px] uppercase tracking-[0.22em] text-slate-500 px-1 pt-2">
                20 institutional folders
              </p>
              <nav className="max-h-[65vh] overflow-y-auto pr-1 space-y-0.5 rounded-2xl border border-white/[0.06] bg-[#080b12]/80 p-2">
                {filteredVolumes.map((v) => {
                  const active = v.id === activeVol;
                  return (
                    <button
                      key={v.id}
                      type="button"
                      onClick={() => {
                        setActiveVol(v.id);
                        setMenuOpen(false);
                        document.getElementById('volume-panel')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
                      }}
                      className={cn(
                        'w-full text-left rounded-xl px-3 py-2.5 transition-colors flex gap-3',
                        active ? 'bg-sky-400/10 border border-sky-400/25' : 'border border-transparent hover:bg-white/[0.03]'
                      )}
                    >
                      <span className={cn('font-mono text-[11px] pt-0.5', active ? 'text-sky-300' : 'text-slate-600')}>
                        {v.code}
                      </span>
                      <span className="min-w-0">
                        <span className={cn('block text-[13px] font-medium leading-snug', active ? 'text-white' : 'text-slate-300')}>
                          {v.title}
                        </span>
                        <span className="block text-[10px] text-slate-600 mt-0.5 truncate">{v.audience}</span>
                      </span>
                    </button>
                  );
                })}
              </nav>
              <a
                href="#gaps"
                className="flex items-center justify-between rounded-xl border border-amber-400/20 bg-amber-400/5 px-3 py-3 text-xs text-amber-100 hover:bg-amber-400/10 transition-colors"
              >
                <span className="flex items-center gap-2">
                  <Target size={14} /> Gap analysis
                </span>
                <ChevronRight size={14} />
              </a>
            </div>
          </aside>

          {/* Volume content */}
          <main id="volume-panel" className="flex-1 min-w-0 scroll-mt-24">
            <AnimatePresence mode="wait">
              <motion.div
                key={volume.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -6 }}
                transition={{ duration: 0.3 }}
                className="rounded-2xl border border-white/[0.07] bg-gradient-to-b from-[#0c1018] to-[#080b12] overflow-hidden"
              >
                <div className="px-6 md:px-8 py-7 border-b border-white/[0.06] relative">
                  <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,rgba(56,189,248,0.07),transparent_50%)]" />
                  <div className="relative">
                    <div className="flex flex-wrap items-center gap-2 mb-4">
                      <span className="font-mono text-xs text-sky-400">VOL {volume.code}</span>
                      <span className={cn('text-[10px] px-2 py-0.5 rounded-full border font-semibold', statusStyle(volume.status))}>
                        {statusLabel(volume.status)}
                      </span>
                    </div>
                    <h2 className="font-display text-2xl md:text-3xl font-bold text-white tracking-tight">
                      {volume.title}
                    </h2>
                    <p className="mt-3 text-slate-400 leading-relaxed max-w-3xl">{volume.summary}</p>
                    <div className="mt-5 flex flex-wrap gap-2">
                      <span className="text-[11px] text-slate-500 self-center mr-1">Audience</span>
                      {volume.audience.split('·').map((a) => (
                        <span key={a} className="text-[11px] px-2.5 py-1 rounded-md bg-white/[0.04] border border-white/10 text-slate-300">
                          {a.trim()}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="px-6 md:px-8 py-6 border-b border-white/[0.06]">
                  <p className="text-[10px] uppercase tracking-[0.22em] text-slate-500 mb-3">Pillars in this volume</p>
                  <div className="grid sm:grid-cols-2 gap-2">
                    {volume.pillars.map((p) => (
                      <div key={p} className="flex items-center gap-2 rounded-lg border border-white/[0.06] bg-white/[0.02] px-3 py-2.5">
                        <CheckCircle2 size={14} className="text-emerald-400 shrink-0" />
                        <span className="text-sm text-slate-200">{p}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="px-6 md:px-8 py-7 space-y-4">
                  <p className="text-[10px] uppercase tracking-[0.22em] text-slate-500">Volume contents</p>
                  {volumeItems.length === 0 ? (
                    <div className="rounded-xl border border-dashed border-white/10 p-6 text-sm text-slate-500">
                      Structural scaffold ready — populate section articles as the living knowledge base grows.
                    </div>
                  ) : (
                    volumeItems.map((item) => (
                      <article
                        key={item.id}
                        className="rounded-xl border border-white/[0.06] bg-black/20 p-5 hover:border-sky-400/20 transition-colors"
                      >
                        <div className="flex flex-wrap items-start justify-between gap-2">
                          <div>
                            {item.subtitle && (
                              <p className="text-[10px] uppercase tracking-[0.18em] text-sky-400/80 mb-1">{item.subtitle}</p>
                            )}
                            <h3 className="font-display font-semibold text-lg text-white">{item.title}</h3>
                          </div>
                          {item.meta && (
                            <span className="text-[10px] font-mono text-slate-500 border border-white/10 rounded px-2 py-1">
                              {item.meta}
                            </span>
                          )}
                        </div>
                        <p className="mt-3 text-sm text-slate-400 leading-relaxed whitespace-pre-line">{item.body}</p>
                      </article>
                    ))
                  )}
                </div>

                {/* Cross-links */}
                <div className="px-6 md:px-8 py-5 border-t border-white/[0.06] bg-black/20 flex flex-wrap gap-2">
                  <span className="text-[11px] text-slate-500 self-center mr-1">Related surfaces</span>
                  {[
                    ['/product-system', 'Hardware'],
                    ['/cloud-platform', 'Cloud'],
                    ['/app', 'Mobile UX'],
                    ['/brand', 'Brand'],
                  ].map(([to, label]) => (
                    <Link
                      key={to}
                      to={to}
                      className="text-[11px] px-2.5 py-1 rounded-full border border-white/10 text-slate-300 hover:border-sky-400/30 hover:text-white"
                    >
                      {label}
                    </Link>
                  ))}
                </div>
              </motion.div>
            </AnimatePresence>

            {/* Library map */}
            <section className="mt-10">
              <div className="flex items-center gap-2 mb-4">
                <Layers size={16} className="text-sky-400" />
                <h3 className="font-display font-semibold text-lg">Library map — 20 volumes</h3>
              </div>
              <div className="grid sm:grid-cols-2 xl:grid-cols-4 gap-2.5">
                {VOLUMES.map((v) => (
                  <button
                    key={v.id}
                    type="button"
                    onClick={() => {
                      setActiveVol(v.id);
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                    className={cn(
                      'text-left rounded-xl border p-3.5 transition-all hover:-translate-y-0.5',
                      v.id === activeVol
                        ? 'border-sky-400/35 bg-sky-400/10'
                        : 'border-white/[0.06] bg-white/[0.02] hover:border-white/15'
                    )}
                  >
                    <div className="flex items-center justify-between gap-2 mb-1.5">
                      <span className="font-mono text-[10px] text-slate-500">{v.code}</span>
                      {v.status === 'draft-gap' ? (
                        <CircleDashed size={12} className="text-amber-400" />
                      ) : (
                        <CheckCircle2 size={12} className="text-emerald-400/80" />
                      )}
                    </div>
                    <p className="text-[13px] font-medium text-white leading-snug">{v.title}</p>
                  </button>
                ))}
              </div>
            </section>
          </main>
        </div>
      </div>

      {/* Gaps */}
      <section id="gaps" className="border-t border-white/[0.06] bg-[#070a10] scroll-mt-20">
        <div className="max-w-[1400px] mx-auto px-4 md:px-6 py-16 md:py-20">
          <Fade>
            <div className="flex items-start gap-3 mb-3">
              <Shield className="text-amber-300 mt-1" size={20} />
              <div>
                <p className="text-[11px] uppercase tracking-[0.28em] text-amber-300/90 font-semibold">Path to world-class</p>
                <h2 className="font-display text-2xl md:text-4xl font-bold text-white mt-2 tracking-tight">
                  Five strategic documents still required
                </h2>
                <p className="mt-4 text-slate-400 max-w-3xl leading-relaxed">
                  This suite establishes institutional structure. To operate at the standard of global EV and cloud
                  platforms, KYNETIK must close five documentation gaps — each one a contract between market reality,
                  product ambition, engineering truth, trust, and field execution.
                </p>
              </div>
            </div>
          </Fade>

          <div className="mt-10 grid md:grid-cols-2 xl:grid-cols-3 gap-4">
            {GAP_DOCS.map((g, i) => (
              <Fade key={g.id} delay={i * 0.05}>
                <div
                  className={cn(
                    'h-full rounded-2xl border p-6 bg-gradient-to-b from-white/[0.03] to-transparent',
                    g.id === 'prd' ? 'border-kyn-green/35 shadow-[0_0_40px_rgba(0,230,118,0.08)]' : 'border-white/[0.07]'
                  )}
                >
                  <div className="flex items-center justify-between gap-2 mb-4">
                    <span className="font-mono text-xs text-sky-300">{g.code}</span>
                    <span
                      className={cn(
                        'text-[10px] font-semibold px-2 py-0.5 rounded-full border',
                        g.level === 'Critical'
                          ? 'border-rose-400/30 text-rose-300 bg-rose-400/10'
                          : 'border-amber-400/30 text-amber-200 bg-amber-400/10'
                      )}
                    >
                      {g.level}
                    </span>
                  </div>
                  <h3 className="font-display text-lg font-bold text-white">{g.title}</h3>
                  <p className="mt-3 text-sm text-slate-400 leading-relaxed">{g.why}</p>
                  <div className="mt-5 pt-4 border-t border-white/[0.06] space-y-2 text-xs">
                    <p>
                      <span className="text-slate-500">Owners · </span>
                      <span className="text-slate-300">{g.owners}</span>
                    </p>
                    <p>
                      <span className="text-slate-500">Unlocks · </span>
                      <span className="text-slate-300">{g.unlocks}</span>
                    </p>
                  </div>
                  {g.id === 'prd' && (
                    <div className="mt-4 inline-flex items-center gap-1.5 text-[11px] font-bold text-kyn-green">
                      <Rocket size={12} /> Recommended next step
                    </div>
                  )}
                </div>
              </Fade>
            ))}
          </div>
        </div>
      </section>

      {/* Next step PRD */}
      <section id="next" className="border-t border-white/[0.06] relative overflow-hidden scroll-mt-20">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(0,230,118,0.1),transparent_55%)]" />
        <div className="relative max-w-4xl mx-auto px-4 md:px-6 py-20 md:py-28 text-center">
          <Fade>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-kyn-green/30 bg-kyn-green/10 text-kyn-green text-[11px] font-semibold mb-6">
              <Compass size={12} /> Executive recommendation
            </div>
            <h2 className="font-display text-3xl md:text-5xl font-bold text-white tracking-tight leading-tight">
              Next move: a complete
              <br />
              <span className="text-kyn-green text-glow">Executive PRD</span>
              {' '}for KYNETIK
            </h2>
            <p className="mt-6 text-slate-400 leading-relaxed max-w-2xl mx-auto">
              The PRD is the single document that binds market needs to product objectives, feature scope, usage
              scenarios, and cross-team requirements — Cloud, hardware SKUs, mobile, portals, install network, and
              Academy. It becomes the north document from which FRD, TAD, Security Handbook, and Launch Playbook cascade.
            </p>

            <div className="mt-10 grid sm:grid-cols-3 gap-3 text-left">
              {[
                { t: 'Market → outcomes', d: 'ICP pains mapped to measurable product goals' },
                { t: 'Features → contracts', d: 'Must / should / later with acceptance criteria' },
                { t: 'Teams → ownership', d: 'RACI across eng, design, ops, GTM, security' },
              ].map((x) => (
                <div key={x.t} className="rounded-xl border border-white/10 bg-black/30 p-4">
                  <p className="font-semibold text-sm text-white">{x.t}</p>
                  <p className="text-xs text-slate-500 mt-1.5 leading-relaxed">{x.d}</p>
                </div>
              ))}
            </div>

            <div className="mt-12 flex flex-wrap justify-center gap-3">
              <Link
                to="/"
                className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-kyn-green text-kyn-black text-sm font-bold glow-green"
              >
                <Zap size={16} /> Return to Design System
              </Link>
              <Link
                to="/cloud-platform"
                className="inline-flex items-center gap-2 px-6 py-3 rounded-full border border-white/15 text-sm font-medium hover:bg-white/5"
              >
                Cloud platform narrative
              </Link>
              <Link
                to="/product-system"
                className="inline-flex items-center gap-2 px-6 py-3 rounded-full border border-white/15 text-sm font-medium hover:bg-white/5"
              >
                Hardware portfolio
              </Link>
            </div>

            <p className="mt-10 text-[12px] text-slate-600 max-w-lg mx-auto leading-relaxed">
              Leadership posture: document like the company you are becoming. Ship the PRD before scaling headcount
              or capital deployment against ambiguous scope.
            </p>
          </Fade>
        </div>
      </section>

      <footer className="border-t border-white/[0.06] py-8">
        <div className="max-w-[1400px] mx-auto px-4 md:px-6 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <BrandLogo height={24} />
            <span className="text-[11px] text-slate-600">Product Documentation Suite · Confidential internal reference</span>
          </div>
          <div className="flex items-center gap-2 text-[11px] text-slate-600">
            <FileText size={12} />
            20 volumes · 5 gap documents · PRD next
          </div>
        </div>
      </footer>
    </div>
  );
}

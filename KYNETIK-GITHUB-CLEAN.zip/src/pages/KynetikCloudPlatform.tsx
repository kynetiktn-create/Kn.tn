import { useEffect, useState, type ComponentType, type ReactNode } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  ArrowRight, Building2, CheckCircle2, Cloud, Cpu, CreditCard, Gauge, Layers,
  Menu, Radio, Server, Shield, Smartphone, Sparkles, UserCog, Users, Wrench,
  X, Zap, MapPin, BarChart3, Activity, Network, KeyRound
} from 'lucide-react';
import BrandLogo from '../components/BrandLogo';
import { cn } from '../lib/utils';

export type CloudRole = 'admin' | 'business' | 'installer';

const ROLES: {
  id: CloudRole;
  title: string;
  subtitle: string;
  icon: ComponentType<{ size?: number; className?: string }>;
  color: string;
  perks: string[];
  entry: string;
}[] = [
  {
    id: 'admin',
    title: 'Admin KYNETIK',
    subtitle: 'Réseau national · full control',
    icon: UserCog,
    color: '#00e676',
    perks: ['Toutes les stations', 'OCPP & firmware OTA', 'Billing global', 'API & sécurité'],
    entry: '/console?role=admin',
  },
  {
    id: 'business',
    title: 'Business Owner',
    subtitle: 'Entreprise · Hôtel · Fleet · Parking',
    icon: Building2,
    color: '#3b82f6',
    perks: ['Multi-sites', 'Fleet & drivers', 'Revenue reports', 'Users & rôles'],
    entry: '/console?role=business',
  },
  {
    id: 'installer',
    title: 'Installer Partner',
    subtitle: 'Installation · maintenance · warranty',
    icon: Wrench,
    color: '#f59e0b',
    perks: ['Jobs assignés', 'Tickets maintenance', 'Commissioning', 'Field calendar'],
    entry: '/console?role=installer',
  },
];

const modules = [
  { t: 'Live Monitor', d: 'Map + remote start/stop/restart/diagnose', icon: Activity },
  { t: 'Stations', d: 'CRUD sites · GPS · models GO→PRO', icon: MapPin },
  { t: 'Fleet', d: 'Vehicles · drivers · cost per km', icon: Users },
  { t: 'Revenue', d: 'Daily→yearly · invoices · energy sold', icon: CreditCard },
  { t: 'AI Analytics', d: 'Usage forecast · maintenance alerts', icon: Sparkles },
  { t: 'Installer Portal', d: 'Request → install → test → activate', icon: Wrench },
];

const stack = [
  { t: 'EV Charger', d: 'GO · FLEX · NOVA · PRIME · EDGE · PRO', icon: Zap },
  { t: 'OCPP 1.6J', d: 'Wi‑Fi · 4G · Ethernet heartbeat', icon: Radio },
  { t: 'KYNETIK Backend', d: 'Sessions · billing · RBAC · webhooks', icon: Server },
  { t: 'Cloud Platform', d: 'B2B console · multi-tenant orgs', icon: Cloud },
  { t: 'Mobile App', d: 'Customer control & payments', icon: Smartphone },
];

function Fade({ children, className, delay = 0 }: { children: ReactNode; className?: string; delay?: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 18 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-40px' }}
      transition={{ duration: 0.45, delay }}
      className={className}
    >
      {children}
    </motion.div>
  );
}

export default function KynetikCloudPlatform() {
  const nav = useNavigate();
  const [menuOpen, setMenuOpen] = useState(false);
  const [picked, setPicked] = useState<CloudRole | null>(null);

  useEffect(() => {
    try {
      const r = localStorage.getItem('kyn_cloud_role') as CloudRole | null;
      if (r === 'admin' || r === 'business' || r === 'installer') setPicked(r);
    } catch { /* ignore */ }
  }, []);

  const enter = (role: CloudRole) => {
    try {
      localStorage.setItem('kyn_cloud_role', role);
      localStorage.setItem(
        'kyn_cloud_user',
        JSON.stringify({
          role,
          name: role === 'admin' ? 'Admin KYNETIK' : role === 'business' ? 'Business Owner' : 'Installer Partner',
          org: role === 'admin' ? 'KYNETIK HQ' : role === 'business' ? 'Atlas Mobility' : 'ElectroPlus Install',
        })
      );
    } catch { /* ignore */ }
    nav(`/console?role=${role}`);
  };

  return (
    <div className="min-h-screen bg-[#05070a] text-white overflow-x-hidden">
      <header className="fixed top-0 inset-x-0 z-50 border-b border-white/5 bg-[#05070a]/85 backdrop-blur-xl">
        <div className="max-w-7xl mx-auto px-5 md:px-8 h-16 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-3">
            <BrandLogo height={28} />
            <span className="hidden sm:inline text-[10px] font-bold tracking-[0.22em] uppercase text-sky-300 border border-sky-400/30 rounded-full px-2 py-0.5">
              Cloud
            </span>
          </Link>
          <nav className="hidden lg:flex items-center gap-6 text-xs text-white/55">
            <a href="#login" className="hover:text-white">Login</a>
            <a href="#modules" className="hover:text-white">Modules</a>
            <a href="#stack" className="hover:text-white">Architecture</a>
            <Link to="/kynetik-app" className="hover:text-white">Mobile App</Link>
            <Link to="/delivery" className="hover:text-white">Delivery</Link>
          </nav>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => enter(picked || 'admin')}
              className="hidden sm:inline-flex items-center gap-2 px-4 py-2 rounded-full bg-kyn-green text-kyn-black text-xs font-bold"
            >
              Open Console <ArrowRight size={14} />
            </button>
            <button type="button" className="lg:hidden p-2 text-white/60" onClick={() => setMenuOpen(!menuOpen)}>
              {menuOpen ? <X size={18} /> : <Menu size={18} />}
            </button>
          </div>
        </div>
        {menuOpen && (
          <div className="lg:hidden border-t border-white/5 px-5 py-4 space-y-2 bg-[#05070a]">
            {['#login', '#modules', '#stack'].map((h) => (
              <a key={h} href={h} onClick={() => setMenuOpen(false)} className="block py-2 text-sm text-white/70">
                {h.slice(1)}
              </a>
            ))}
            <button type="button" onClick={() => enter('admin')} className="w-full rounded-full bg-kyn-green text-kyn-black text-xs font-bold py-3">
              Open Console
            </button>
          </div>
        )}
      </header>

      {/* Hero */}
      <section className="relative pt-28 md:pt-36 pb-16 overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(59,130,246,0.18),transparent_50%),radial-gradient(ellipse_at_bottom_right,rgba(0,230,118,0.12),transparent_45%)]" />
        <div className="absolute inset-0 opacity-30" style={{ backgroundImage: 'linear-gradient(rgba(255,255,255,0.04) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.04) 1px, transparent 1px)', backgroundSize: '48px 48px' }} />
        <div className="relative z-10 max-w-7xl mx-auto px-5 md:px-8 grid lg:grid-cols-[1.15fr_0.85fr] gap-12 items-center">
          <Fade>
            <p className="text-sky-300 text-[11px] font-semibold tracking-[0.3em] uppercase mb-4">Phase 20 · B2B SaaS</p>
            <h1 className="font-display text-4xl sm:text-5xl md:text-6xl font-bold leading-[1.05] tracking-tight">
              KYNETIK Cloud
              <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-kyn-green to-sky-400">
                Platform
              </span>
            </h1>
            <p className="mt-5 text-white/60 text-base md:text-lg max-w-xl leading-relaxed">
              SaaS de supervision pour stations, flottes, installateurs et revenus — OCPP 1.6J, contrôle distant, analytics & AI.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <a href="#login" className="inline-flex items-center gap-2 px-6 py-3.5 rounded-full bg-kyn-green text-kyn-black text-sm font-bold">
                Choisir un compte <ArrowRight size={16} />
              </a>
              <Link to="/console?role=admin" className="inline-flex items-center gap-2 px-6 py-3.5 rounded-full border border-white/15 text-sm font-semibold hover:border-kyn-green/40">
                Demo Admin
              </Link>
            </div>
            <div className="mt-10 grid grid-cols-2 sm:grid-cols-4 gap-3">
              {[
                ['248', 'Stations'],
                ['91%', 'Online'],
                ['154.8', 'MWh / mo'],
                ['48.5k', 'TND rev.'],
              ].map(([v, l]) => (
                <div key={l} className="rounded-2xl border border-white/10 bg-white/[0.03] p-3">
                  <p className="font-display text-xl font-bold text-kyn-green">{v}</p>
                  <p className="text-[10px] uppercase tracking-wider text-white/40 mt-0.5">{l}</p>
                </div>
              ))}
            </div>
          </Fade>

          <Fade delay={0.1}>
            <div className="rounded-3xl border border-white/10 bg-gradient-to-b from-white/[0.06] to-transparent p-1 shadow-2xl shadow-sky-500/10">
              <div className="rounded-[1.35rem] bg-[#0a0e14] p-5 md:p-6">
                <div className="flex items-center justify-between mb-5">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-kyn-green animate-pulse" />
                    <span className="text-[11px] text-kyn-green font-semibold uppercase tracking-wider">Live network</span>
                  </div>
                  <Cloud size={16} className="text-sky-400" />
                </div>
                <div className="space-y-2.5">
                  {[
                    { n: 'Tunis Centre', s: 'Online', p: '22 kW', u: 'Active', c: 'text-kyn-green' },
                    { n: 'La Marsa', s: 'Warning', p: '7 kW', u: 'Idle', c: 'text-amber-300' },
                    { n: 'Sousse Port', s: 'Offline', p: '—', u: '—', c: 'text-red-400' },
                    { n: 'Sfax Depot', s: 'Charging', p: '44 kW', u: 'Fleet', c: 'text-sky-300' },
                  ].map((r) => (
                    <div key={r.n} className="flex items-center justify-between gap-2 rounded-xl border border-white/8 bg-black/40 px-3 py-2.5 text-xs">
                      <div>
                        <p className="font-semibold text-white">{r.n}</p>
                        <p className={cn('text-[10px] mt-0.5', r.c)}>{r.s}</p>
                      </div>
                      <div className="text-right text-white/50">
                        <p className="text-white/80 font-medium">{r.p}</p>
                        <p className="text-[10px]">{r.u}</p>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="mt-4 grid grid-cols-3 gap-2 text-center">
                  {['Start', 'Stop', 'Diagnose'].map((a) => (
                    <div key={a} className="rounded-lg border border-white/10 py-2 text-[10px] font-semibold text-white/70">
                      {a}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </Fade>
        </div>
      </section>

      {/* Login roles */}
      <section id="login" className="py-16 md:py-24 border-t border-white/5">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <Fade>
            <p className="text-kyn-green text-[11px] font-semibold tracking-[0.28em] uppercase mb-3">1 · Login Cloud Platform</p>
            <h2 className="font-display text-3xl md:text-4xl font-bold">Choisir le type de compte</h2>
            <p className="mt-3 text-white/50 max-w-2xl">RBAC multi-tenant — chaque rôle ouvre la console avec la navigation adaptée.</p>
          </Fade>
          <div className="mt-10 grid md:grid-cols-3 gap-4">
            {ROLES.map((r, i) => {
              const Icon = r.icon;
              const on = picked === r.id;
              return (
                <Fade key={r.id} delay={i * 0.06}>
                  <button
                    type="button"
                    onClick={() => {
                      setPicked(r.id);
                      enter(r.id);
                    }}
                    className={cn(
                      'w-full text-left rounded-3xl border p-6 transition-all h-full',
                      on ? 'border-kyn-green/50 bg-kyn-green/5 shadow-[0_0_40px_rgba(0,230,118,0.08)]' : 'border-white/10 bg-white/[0.02] hover:border-white/25'
                    )}
                  >
                    <div
                      className="w-12 h-12 rounded-2xl flex items-center justify-center mb-4 border"
                      style={{ background: `${r.color}18`, borderColor: `${r.color}40`, color: r.color }}
                    >
                      <Icon size={22} />
                    </div>
                    <h3 className="font-display text-xl font-bold">{r.title}</h3>
                    <p className="text-sm text-white/45 mt-1">{r.subtitle}</p>
                    <ul className="mt-5 space-y-2">
                      {r.perks.map((p) => (
                        <li key={p} className="flex items-center gap-2 text-xs text-white/65">
                          <CheckCircle2 size={13} className="text-kyn-green shrink-0" /> {p}
                        </li>
                      ))}
                    </ul>
                    <span className="mt-6 inline-flex items-center gap-2 text-sm font-bold" style={{ color: r.color }}>
                      Enter console <ArrowRight size={14} />
                    </span>
                  </button>
                </Fade>
              );
            })}
          </div>
        </div>
      </section>

      {/* Modules */}
      <section id="modules" className="py-16 md:py-20 bg-[#080b10] border-y border-white/5">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <Fade>
            <p className="text-sky-300 text-[11px] font-semibold tracking-[0.28em] uppercase mb-3">Modules opérationnels</p>
            <h2 className="font-display text-3xl font-bold mb-8">Ce que la console livre aujourd’hui</h2>
          </Fade>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {modules.map((m, i) => {
              const Icon = m.icon;
              return (
                <Fade key={m.t} delay={i * 0.04}>
                  <div className="rounded-2xl border border-white/10 bg-black/30 p-5 h-full hover:border-sky-400/30 transition-colors">
                    <Icon className="text-sky-300 mb-3" size={18} />
                    <p className="font-semibold">{m.t}</p>
                    <p className="text-sm text-white/45 mt-1.5 leading-relaxed">{m.d}</p>
                  </div>
                </Fade>
              );
            })}
          </div>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link to="/console?role=admin" className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-white text-black text-xs font-bold">
              Executive KPIs
            </Link>
            <Link to="/console?role=admin" className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full border border-white/15 text-xs font-semibold">
              Live monitor
            </Link>
            <Link to="/installer" className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full border border-amber-400/30 text-amber-200 text-xs font-semibold">
              Installer field app
            </Link>
            <Link to="/ai-platform" className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full border border-kyn-green/30 text-kyn-green text-xs font-semibold">
              AI layer
            </Link>
          </div>
        </div>
      </section>

      {/* Stack */}
      <section id="stack" className="py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <Fade>
            <p className="text-kyn-green text-[11px] font-semibold tracking-[0.28em] uppercase mb-3">11 · API & technical layer</p>
            <h2 className="font-display text-3xl font-bold">Architecture de bout en bout</h2>
          </Fade>
          <div className="mt-10 flex flex-col lg:flex-row items-stretch gap-3">
            {stack.map((s, i) => {
              const Icon = s.icon;
              return (
                <Fade key={s.t} delay={i * 0.05} className="flex-1 flex items-center gap-3">
                  <div className="flex-1 rounded-2xl border border-white/10 bg-gradient-to-b from-white/[0.05] to-transparent p-5 text-center h-full">
                    <div className="w-11 h-11 mx-auto rounded-xl bg-kyn-green/10 border border-kyn-green/25 text-kyn-green flex items-center justify-center mb-3">
                      <Icon size={18} />
                    </div>
                    <p className="font-semibold text-sm">{s.t}</p>
                    <p className="text-[11px] text-white/40 mt-1.5 leading-relaxed">{s.d}</p>
                  </div>
                  {i < stack.length - 1 && (
                    <div className="hidden lg:block text-kyn-green/50 shrink-0">→</div>
                  )}
                </Fade>
              );
            })}
          </div>
          <div className="mt-8 grid sm:grid-cols-2 lg:grid-cols-5 gap-2">
            {['Wi‑Fi', '4G', 'Bluetooth', 'OCPP 1.6J', 'Payment API'].map((x) => (
              <div key={x} className="rounded-xl border border-white/8 px-3 py-2.5 text-center text-xs font-semibold text-white/60 flex items-center justify-center gap-2">
                <Network size={12} className="text-kyn-green" /> {x}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 border-t border-white/5">
        <div className="max-w-3xl mx-auto px-5 text-center">
          <Layers className="mx-auto text-sky-300 mb-4" size={28} />
          <h2 className="font-display text-3xl font-bold">Console opérationnelle prête pour démo investisseur</h2>
          <p className="mt-3 text-white/50">Stations · clients · fleets · installateurs · revenus — une seule plateforme.</p>
          <div className="mt-8 flex flex-wrap justify-center gap-3">
            <button type="button" onClick={() => enter('admin')} className="inline-flex items-center gap-2 px-7 py-3.5 rounded-full bg-kyn-green text-kyn-black text-sm font-bold">
              Launch Admin Console <ArrowRight size={16} />
            </button>
            <Link to="/kynetik-app" className="inline-flex items-center gap-2 px-7 py-3.5 rounded-full border border-white/15 text-sm font-semibold">
              Mobile App
            </Link>
            <Link to="/website" className="inline-flex items-center gap-2 px-7 py-3.5 rounded-full border border-white/15 text-sm font-semibold">
              Phase 21 Website →
            </Link>
          </div>
        </div>
      </section>

      <footer className="border-t border-white/5 py-8">
        <div className="max-w-7xl mx-auto px-5 md:px-8 flex flex-wrap justify-between gap-3 items-center">
          <BrandLogo height={24} />
          <p className="text-[11px] text-white/35">Phase 20 · KYNETIK Cloud Platform · OCPP · SaaS</p>
        </div>
      </footer>
    </div>
  );
}

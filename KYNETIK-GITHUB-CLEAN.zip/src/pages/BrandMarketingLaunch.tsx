import { useEffect, useMemo, useState, type ComponentType, type ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  ArrowRight, Target, Sparkles, Eye, Heart, Rocket, Leaf, Handshake, Link2,
  Gauge, Calendar, Megaphone, Car, Building2, Briefcase, Globe2, Linkedin,
  Instagram, FileText, Presentation, BookOpen, Download, CheckCircle2,
  Menu, X, Zap, Cloud, Package, Users, TrendingUp, Share2, Mail
} from 'lucide-react';
import BrandLogo from '../components/BrandLogo';
import LoadingState from '../components/LoadingState';
import { apiGet, cn } from '../lib/utils';

interface Item {
  id: number;
  type: string;
  category: string;
  title: string;
  subtitle: string;
  body: string;
  meta: string | null;
  sort_order: number;
}

function Fade({ children, className, delay = 0 }: { children: ReactNode; className?: string; delay?: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-60px' }}
      transition={{ duration: 0.55, delay, ease: [0.22, 1, 0.36, 1] }}
      className={className}
    >
      {children}
    </motion.div>
  );
}

const FALLBACK: Item[] = [
  { id: 1, type: 'brand_launch', category: 'positioning', title: 'Écosystème intelligent', subtitle: 'Positionnement', body: "KYNETIK n'est pas seulement un vendeur de bornes. C'est un écosystème intelligent de recharge électrique qui combine hardware, software et expertise locale pour accompagner la transition énergétique.", meta: 'HW+SW+Local', sort_order: 1 },
  { id: 2, type: 'brand_launch', category: 'mission', title: 'Mission', subtitle: 'Pourquoi nous existons', body: "Permettre à chaque entreprise, foyer et collectivité d'adopter une mobilité électrique simple, intelligente et durable.", meta: 'Mission', sort_order: 2 },
  { id: 3, type: 'brand_launch', category: 'vision', title: 'Vision 2036', subtitle: 'Ambition', body: 'Devenir le leader tunisien des solutions de recharge électrique et un acteur majeur en Afrique du Nord.', meta: '2036', sort_order: 3 },
];

const VALUE_ICONS: Record<string, ComponentType<{ size?: number; className?: string }>> = {
  Innovation: Sparkles,
  Durabilité: Leaf,
  Confiance: Handshake,
  Connectivité: Link2,
  Performance: Rocket,
};

const PRODUCT_HREF: Record<string, string> = {
  GO: '/products/go',
  FLEX: '/products/flex',
  NOVA: '/products/nova',
  PRIME: '/products/prime',
  EDGE: '/products/edge',
  PRO: '/products/pro',
};

const KIT_ICONS: Record<string, ComponentType<{ size?: number; className?: string }>> = {
  'Corporate Presentation': Presentation,
  'Product Catalog': Package,
  'Technical Datasheets': FileText,
  'Price List': BookOpen,
  'Installation Guide': BookOpen,
  'Partner Program': Users,
  'Investor Deck': TrendingUp,
};

const nav = [
  { href: '#positioning', label: 'Position' },
  { href: '#identity', label: 'Identité' },
  { href: '#gtm', label: 'GTM 24 mois' },
  { href: '#products', label: 'Lancement' },
  { href: '#channels', label: 'Acquisition' },
  { href: '#calendar', label: 'Calendrier' },
  { href: '#content', label: 'Contenu' },
  { href: '#kit', label: 'Sales Kit' },
];

export default function BrandMarketingLaunch() {
  const [items, setItems] = useState<Item[]>([]);
  const [loading, setLoading] = useState(true);
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    apiGet<Item[]>('/api/marketing-content?type=brand_launch')
      .then((data) => setItems(data?.length ? data : FALLBACK))
      .catch(() => setItems(FALLBACK))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const by = (cat: string) =>
    items.filter((i) => i.category === cat).sort((a, b) => a.sort_order - b.sort_order);

  const positioning = by('positioning')[0] || FALLBACK[0];
  const mission = by('mission')[0] || FALLBACK[1];
  const vision = by('vision')[0] || FALLBACK[2];
  const values = by('value');
  const gtm = by('gtm');
  const productOrder = by('product_order');
  const channels = by('channel');
  const calendar = by('calendar');
  const content = by('content');
  const kit = by('sales_kit');

  if (loading) {
    return (
      <div className="min-h-screen bg-kyn-black flex items-center justify-center">
        <LoadingState label="Loading Brand & Launch System…" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-kyn-black text-white overflow-x-hidden">
      <header
        className={cn(
          'fixed top-0 inset-x-0 z-50 transition-all duration-300',
          scrolled ? 'bg-kyn-black/90 backdrop-blur-xl border-b border-white/5' : 'bg-transparent'
        )}
      >
        <div className="max-w-7xl mx-auto px-5 md:px-8 h-16 md:h-[72px] flex items-center justify-between gap-4">
          <Link to="/" className="shrink-0 flex items-center gap-3">
            <BrandLogo height={30} />
            <span className="hidden sm:inline text-[10px] font-semibold tracking-[0.2em] uppercase text-violet-300 border border-violet-400/30 rounded-full px-2 py-0.5">
              Phase 22
            </span>
          </Link>
          <nav className="hidden xl:flex items-center gap-5">
            {nav.map((n) => (
              <a key={n.href} href={n.href} className="text-[11px] font-medium text-kyn-silver hover:text-white transition-colors">
                {n.label}
              </a>
            ))}
          </nav>
          <div className="flex items-center gap-2">
            <Link
              to="/sales"
              className="hidden sm:inline-flex items-center gap-2 px-4 py-2 rounded-full border border-white/12 text-xs font-semibold hover:border-kyn-green/40"
            >
              Sales hub
            </Link>
            <Link
              to="/quote"
              className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-kyn-green text-kyn-black text-xs font-bold"
            >
              Devis <ArrowRight size={13} />
            </Link>
            <button type="button" className="xl:hidden p-2 text-kyn-silver" onClick={() => setMenuOpen(!menuOpen)} aria-label="Menu">
              {menuOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </div>
        {menuOpen && (
          <div className="xl:hidden border-t border-white/5 bg-kyn-black/95 px-5 py-4 space-y-2">
            {nav.map((n) => (
              <a key={n.href} href={n.href} onClick={() => setMenuOpen(false)} className="block py-2 text-sm text-kyn-silver">
                {n.label}
              </a>
            ))}
          </div>
        )}
      </header>

      {/* HERO */}
      <section className="relative pt-28 md:pt-36 pb-20 md:pb-28 overflow-hidden">
        <div className="absolute inset-0">
          <img src="/images/presentation.jpg" alt="" className="w-full h-full object-cover opacity-25" />
          <div className="absolute inset-0 bg-gradient-to-b from-kyn-black via-kyn-black/85 to-kyn-black" />
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,rgba(167,139,250,0.15),transparent_50%)]" />
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom_left,rgba(0,230,118,0.12),transparent_55%)]" />
        </div>
        <div className="relative z-10 max-w-7xl mx-auto px-5 md:px-8">
          <Fade>
            <p className="text-violet-300 text-xs font-semibold tracking-[0.32em] uppercase mb-5">
              Phase 22 · Brand & Marketing Launch
            </p>
            <h1 className="font-display text-4xl sm:text-5xl md:text-7xl font-bold tracking-tight leading-[1.05] max-w-4xl">
              De la tech
              <br />
              <span className="text-kyn-green text-glow">au brand marché.</span>
            </h1>
            <p className="mt-6 text-lg md:text-xl text-kyn-silver max-w-2xl leading-relaxed">
              Positionnement, GTM 24 mois, ordre de lancement produits, canaux d&apos;acquisition,
              calendrier de communication, contenu et sales kit — le système pour faire exister KYNETIK
              auprès clients et investisseurs.
            </p>
            <div className="mt-10 flex flex-wrap gap-3">
              <a href="#gtm" className="inline-flex items-center gap-2 px-7 py-3.5 rounded-full bg-kyn-green text-kyn-black text-sm font-bold glow-green">
                Voir le GTM 24 mois <ArrowRight size={16} />
              </a>
              <a href="#kit" className="inline-flex items-center gap-2 px-7 py-3.5 rounded-full border border-white/15 text-sm font-semibold hover:border-violet-400/40">
                Sales kit
              </a>
              <Link to="/investors" className="inline-flex items-center gap-2 px-7 py-3.5 rounded-full border border-white/15 text-sm font-semibold">
                Investor deck
              </Link>
            </div>
          </Fade>

          <div className="mt-14 grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {[
              { t: 'Positionnement', d: 'Écosystème HW + SW + local', icon: Target },
              { t: 'GTM 24 mois', d: 'Pré-lancement → Leadership', icon: Calendar },
              { t: '6 séries', d: 'GO → PRO en séquence', icon: Package },
              { t: '4 canaux', d: 'Auto · Immo · B2B · Digital', icon: Megaphone },
            ].map(({ t, d, icon: Icon }, i) => (
              <Fade key={t} delay={i * 0.05}>
                <div className="rounded-2xl border border-white/10 bg-white/[0.03] backdrop-blur p-5 h-full">
                  <Icon className="text-kyn-green mb-3" size={18} />
                  <p className="font-display font-semibold">{t}</p>
                  <p className="text-xs text-kyn-metal mt-1">{d}</p>
                </div>
              </Fade>
            ))}
          </div>
        </div>
      </section>

      {/* 1 POSITIONING */}
      <section id="positioning" className="py-20 md:py-28 border-t border-white/5 scroll-mt-24">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <Fade>
            <p className="text-kyn-green text-xs font-semibold tracking-[0.28em] uppercase mb-4">01 · Positionnement</p>
            <h2 className="font-display text-3xl md:text-5xl font-bold max-w-3xl leading-tight">
              KYNETIK n&apos;est pas seulement
              <br />
              <span className="text-white/50">un vendeur de bornes.</span>
            </h2>
          </Fade>
          <div className="mt-12 grid lg:grid-cols-2 gap-8 items-stretch">
            <Fade>
              <div className="rounded-3xl border border-kyn-green/25 bg-gradient-to-br from-kyn-green/10 via-kyn-void to-kyn-void p-8 md:p-10 h-full">
                <Target className="text-kyn-green mb-6" size={28} />
                <p className="text-[11px] uppercase tracking-wider text-kyn-green font-semibold mb-3">
                  {positioning.subtitle}
                </p>
                <h3 className="font-display text-2xl md:text-3xl font-bold mb-4">{positioning.title}</h3>
                <p className="text-kyn-silver leading-relaxed text-lg">{positioning.body}</p>
                {positioning.meta && (
                  <p className="mt-6 inline-flex px-3 py-1.5 rounded-full border border-kyn-green/30 text-xs text-kyn-green font-semibold">
                    {positioning.meta}
                  </p>
                )}
              </div>
            </Fade>
            <Fade delay={0.08}>
              <div className="rounded-3xl border border-white/10 bg-kyn-void p-8 md:p-10 h-full flex flex-col justify-center">
                <p className="text-sm text-kyn-metal uppercase tracking-wider mb-6">Ce que nous vendons vraiment</p>
                <ul className="space-y-4">
                  {[
                    { t: 'Hardware', d: 'GO · FLEX · NOVA · PRIME · EDGE · PRO' },
                    { t: 'Software', d: 'App client + KYNETIK Cloud B2B' },
                    { t: 'Expertise', d: 'Academy, installateurs, maintenance locale' },
                    { t: 'Résultat', d: 'Transition énergétique mesurable' },
                  ].map((row) => (
                    <li key={row.t} className="flex gap-4 items-start border-b border-white/5 pb-4 last:border-0">
                      <CheckCircle2 className="text-kyn-green shrink-0 mt-0.5" size={18} />
                      <div>
                        <p className="font-semibold">{row.t}</p>
                        <p className="text-sm text-kyn-metal mt-0.5">{row.d}</p>
                      </div>
                    </li>
                  ))}
                </ul>
              </div>
            </Fade>
          </div>
        </div>
      </section>

      {/* 2 IDENTITY */}
      <section id="identity" className="py-20 md:py-28 bg-kyn-void border-t border-white/5 scroll-mt-24">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <Fade>
            <p className="text-kyn-green text-xs font-semibold tracking-[0.28em] uppercase mb-4">02 · Brand identity</p>
            <h2 className="font-display text-3xl md:text-5xl font-bold">Mission · Vision · Valeurs</h2>
          </Fade>
          <div className="mt-12 grid md:grid-cols-2 gap-5">
            <Fade>
              <div className="rounded-3xl border border-white/10 bg-black/40 p-8 h-full">
                <div className="w-11 h-11 rounded-2xl bg-kyn-green/10 border border-kyn-green/25 flex items-center justify-center text-kyn-green mb-5">
                  <Heart size={20} />
                </div>
                <p className="text-[11px] uppercase tracking-wider text-kyn-green font-semibold">{mission.subtitle}</p>
                <h3 className="font-display text-2xl font-bold mt-2">{mission.title}</h3>
                <p className="mt-4 text-kyn-silver leading-relaxed">{mission.body}</p>
              </div>
            </Fade>
            <Fade delay={0.06}>
              <div className="rounded-3xl border border-white/10 bg-black/40 p-8 h-full">
                <div className="w-11 h-11 rounded-2xl bg-violet-500/10 border border-violet-400/25 flex items-center justify-center text-violet-300 mb-5">
                  <Eye size={20} />
                </div>
                <p className="text-[11px] uppercase tracking-wider text-violet-300 font-semibold">{vision.subtitle}</p>
                <h3 className="font-display text-2xl font-bold mt-2">{vision.title}</h3>
                <p className="mt-4 text-kyn-silver leading-relaxed">{vision.body}</p>
              </div>
            </Fade>
          </div>

          <div className="mt-6 grid sm:grid-cols-2 lg:grid-cols-5 gap-3">
            {(values.length
              ? values
              : [
                  { title: 'Innovation', body: 'Hardware premium, OCPP, Cloud et IA.', id: 1 },
                  { title: 'Durabilité', body: 'Décarbonation de la mobilité.', id: 2 },
                  { title: 'Confiance', body: 'Support local et garantie.', id: 3 },
                  { title: 'Connectivité', body: 'App + Cloud toujours on.', id: 4 },
                  { title: 'Performance', body: '3,7 kW → 44 kW.', id: 5 },
                ]
            ).map((v, i) => {
              const Icon = VALUE_ICONS[v.title] || Sparkles;
              return (
                <Fade key={v.id || v.title} delay={i * 0.04}>
                  <div className="rounded-2xl border border-white/10 bg-kyn-black/50 p-5 h-full hover:border-kyn-green/30 transition-colors">
                    <Icon className="text-kyn-green mb-3" size={18} />
                    <p className="font-display font-semibold">{v.title}</p>
                    <p className="text-xs text-kyn-metal mt-2 leading-relaxed">{v.body}</p>
                  </div>
                </Fade>
              );
            })}
          </div>
        </div>
      </section>

      {/* 3 GTM */}
      <section id="gtm" className="py-20 md:py-28 border-t border-white/5 scroll-mt-24">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <Fade>
            <p className="text-kyn-green text-xs font-semibold tracking-[0.28em] uppercase mb-4">03 · Go-to-market</p>
            <h2 className="font-display text-3xl md:text-5xl font-bold">Stratégie 24 mois</h2>
            <p className="mt-4 text-kyn-silver max-w-2xl">
              De la présence de marque aux premiers clients, puis au leadership réseau.
            </p>
          </Fade>

          <div className="mt-12 relative">
            <div className="hidden md:block absolute top-10 left-[8%] right-[8%] h-px bg-gradient-to-r from-transparent via-kyn-green/40 to-transparent" />
            <div className="grid md:grid-cols-4 gap-4">
              {(gtm.length
                ? gtm
                : [
                    { title: 'Pré-lancement', subtitle: 'M-3 → M0', body: 'Site, LinkedIn, deck, pilotes.', meta: 'Présence', id: 1 },
                    { title: 'Launch Tunisia', subtitle: '0–6 mois', body: 'Premiers B2C et B2B.', meta: 'Clients', id: 2 },
                    { title: 'Scale & Network', subtitle: '6–18 mois', body: 'Academy + Cloud + flottes.', meta: 'Réseau', id: 3 },
                    { title: 'Leadership', subtitle: '18–24 mois', body: 'PRO public + expansion.', meta: 'Leadership', id: 4 },
                  ]
              ).map((phase, i) => (
                <Fade key={phase.id || phase.title} delay={i * 0.06}>
                  <div className="relative rounded-3xl border border-white/10 bg-kyn-void p-6 h-full pt-8">
                    <div className="absolute -top-3 left-6 w-8 h-8 rounded-full bg-kyn-green text-kyn-black text-xs font-bold flex items-center justify-center shadow-lg shadow-kyn-green/30">
                      {i + 1}
                    </div>
                    <p className="text-[10px] uppercase tracking-wider text-kyn-green font-semibold">{phase.subtitle}</p>
                    <h3 className="font-display text-xl font-bold mt-1">{phase.title}</h3>
                    <p className="mt-3 text-sm text-kyn-silver leading-relaxed">{phase.body}</p>
                    {phase.meta && (
                      <p className="mt-4 text-[11px] font-semibold text-kyn-metal uppercase tracking-wider">{phase.meta}</p>
                    )}
                  </div>
                </Fade>
              ))}
            </div>
          </div>

          <Fade>
            <div className="mt-10 grid md:grid-cols-2 gap-4">
              <div className="rounded-2xl border border-white/10 p-6 bg-white/[0.02]">
                <p className="text-xs font-semibold text-kyn-green uppercase tracking-wider mb-3">Cibles B2C</p>
                <ul className="space-y-2 text-sm text-kyn-silver">
                  {['Propriétaires VE', 'Villas', 'Résidences premium'].map((x) => (
                    <li key={x} className="flex gap-2"><CheckCircle2 size={14} className="text-kyn-green shrink-0 mt-0.5" />{x}</li>
                  ))}
                </ul>
              </div>
              <div className="rounded-2xl border border-white/10 p-6 bg-white/[0.02]">
                <p className="text-xs font-semibold text-kyn-green uppercase tracking-wider mb-3">Cibles B2B</p>
                <ul className="space-y-2 text-sm text-kyn-silver">
                  {['Entreprises & flottes', 'Hôtels', 'Promoteurs immobiliers', 'Parkings'].map((x) => (
                    <li key={x} className="flex gap-2"><CheckCircle2 size={14} className="text-kyn-green shrink-0 mt-0.5" />{x}</li>
                  ))}
                </ul>
              </div>
            </div>
          </Fade>
        </div>
      </section>

      {/* 4 PRODUCT LAUNCH ORDER */}
      <section id="products" className="py-20 md:py-28 bg-kyn-void border-t border-white/5 scroll-mt-24">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <Fade>
            <p className="text-kyn-green text-xs font-semibold tracking-[0.28em] uppercase mb-4">04 · Product launch order</p>
            <h2 className="font-display text-3xl md:text-5xl font-bold">GO → PRO en 6 étapes</h2>
            <p className="mt-4 text-kyn-silver max-w-xl">Séquence marché : entrée rapide, puis premium, puis infrastructure.</p>
          </Fade>
          <div className="mt-12 space-y-3">
            {(productOrder.length
              ? productOrder
              : [
                  { title: 'GO Series', subtitle: 'Étape 1', body: 'Entrée marché. Première recharge à domicile.', meta: '3.7–7 kW', id: 1 },
                  { title: 'FLEX Series', subtitle: 'Étape 2', body: 'Résidentiel premium.', meta: '7 kW', id: 2 },
                  { title: 'NOVA Series', subtitle: 'Étape 3', body: 'La recharge intelligente.', meta: '7–22 kW', id: 3 },
                  { title: 'PRIME Series', subtitle: 'Étape 4', body: 'Entreprises et pros.', meta: '7–22 kW', id: 4 },
                  { title: 'EDGE Series', subtitle: 'Étape 5', body: 'Marché premium design.', meta: '7–22 kW', id: 5 },
                  { title: 'PRO Series', subtitle: 'Étape 6', body: 'Public et flottes.', meta: '22–44 kW', id: 6 },
                ]
            ).map((p, i) => {
              const key = p.title.split(' ')[0]?.toUpperCase() || '';
              const href = PRODUCT_HREF[key] || '/products';
              return (
                <Fade key={p.id || p.title} delay={i * 0.03}>
                  <Link
                    to={href}
                    className="group flex flex-col sm:flex-row sm:items-center gap-4 rounded-2xl border border-white/10 bg-kyn-black/40 p-5 md:p-6 hover:border-kyn-green/35 transition-all"
                  >
                    <div className="w-12 h-12 rounded-2xl bg-kyn-green/10 border border-kyn-green/25 flex items-center justify-center font-display font-bold text-kyn-green shrink-0">
                      {String(i + 1).padStart(2, '0')}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex flex-wrap items-center gap-2">
                        <h3 className="font-display text-lg md:text-xl font-bold group-hover:text-kyn-green transition-colors">{p.title}</h3>
                        <span className="text-[10px] uppercase tracking-wider text-kyn-metal border border-white/10 rounded-full px-2 py-0.5">{p.subtitle}</span>
                      </div>
                      <p className="text-sm text-kyn-silver mt-1">{p.body}</p>
                    </div>
                    <div className="flex items-center gap-3 shrink-0">
                      {p.meta && <span className="text-xs font-semibold text-kyn-green">{p.meta}</span>}
                      <ArrowRight size={16} className="text-kyn-metal group-hover:text-kyn-green group-hover:translate-x-1 transition-all" />
                    </div>
                  </Link>
                </Fade>
              );
            })}
          </div>
        </div>
      </section>

      {/* 5 CHANNELS */}
      <section id="channels" className="py-20 md:py-28 border-t border-white/5 scroll-mt-24">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <Fade>
            <p className="text-kyn-green text-xs font-semibold tracking-[0.28em] uppercase mb-4">05 · Acquisition</p>
            <h2 className="font-display text-3xl md:text-5xl font-bold">Premiers clients — 4 canaux</h2>
          </Fade>
          <div className="mt-12 grid sm:grid-cols-2 gap-4">
            {(channels.length
              ? channels
              : [
                  { title: 'Partenariats automobiles', subtitle: 'Canal 1', body: 'Vehicle + KYNETIK Charger Package.', meta: 'Auto', id: 1 },
                  { title: 'Promoteurs immobiliers', subtitle: 'Canal 2', body: 'Résidence KYNETIK Ready.', meta: 'Immo', id: 2 },
                  { title: 'Entreprises', subtitle: 'Canal 3', body: 'Coûts flotte + image écologique.', meta: 'B2B', id: 3 },
                  { title: 'Digital', subtitle: 'Canal 4', body: 'LinkedIn + Google SEO local.', meta: 'Digital', id: 4 },
                ]
            ).map((c, i) => {
              const icons = [Car, Building2, Briefcase, Globe2];
              const Icon = icons[i % icons.length];
              return (
                <Fade key={c.id || c.title} delay={i * 0.05}>
                  <div className="rounded-3xl border border-white/10 bg-kyn-void p-7 h-full hover:border-kyn-green/30 transition-colors">
                    <div className="flex items-start justify-between gap-3">
                      <div className="w-11 h-11 rounded-2xl bg-kyn-green/10 border border-kyn-green/20 flex items-center justify-center text-kyn-green">
                        <Icon size={20} />
                      </div>
                      <span className="text-[10px] uppercase tracking-wider text-kyn-metal font-semibold">{c.subtitle}</span>
                    </div>
                    <h3 className="font-display text-xl font-bold mt-5">{c.title}</h3>
                    <p className="mt-3 text-sm text-kyn-silver leading-relaxed">{c.body}</p>
                  </div>
                </Fade>
              );
            })}
          </div>

          <Fade>
            <div className="mt-8 rounded-3xl border border-white/10 bg-gradient-to-r from-kyn-green/10 via-transparent to-violet-500/10 p-8 md:p-10">
              <p className="text-xs font-semibold text-kyn-green uppercase tracking-wider mb-3">Offres commerciales lancement</p>
              <div className="grid sm:grid-cols-3 gap-4">
                {[
                  { t: 'Offre lancement', d: 'Pack borne + install pour early adopters' },
                  { t: 'Clé en main', d: 'Audit → pose → mise en service Cloud' },
                  { t: 'Audit gratuit', d: 'Diagnostic électrique pour entreprises pilotes' },
                ].map((o) => (
                  <div key={o.t} className="rounded-2xl border border-white/10 bg-black/30 p-5">
                    <p className="font-semibold">{o.t}</p>
                    <p className="text-sm text-kyn-metal mt-2">{o.d}</p>
                  </div>
                ))}
              </div>
            </div>
          </Fade>
        </div>
      </section>

      {/* 6 CALENDAR */}
      <section id="calendar" className="py-20 md:py-28 bg-kyn-void border-t border-white/5 scroll-mt-24">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <Fade>
            <p className="text-kyn-green text-xs font-semibold tracking-[0.28em] uppercase mb-4">06 · Communication calendar</p>
            <h2 className="font-display text-3xl md:text-5xl font-bold">6 premiers mois</h2>
          </Fade>
          <div className="mt-12 grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {(calendar.length
              ? calendar
              : [
                  { title: 'Mois 1', subtitle: 'Annonce', body: 'Annonce officielle KYNETIK.', id: 1 },
                  { title: 'Mois 2', subtitle: 'Produits', body: 'Présentation famille produits.', id: 2 },
                  { title: 'Mois 3', subtitle: 'Client', body: 'Premier projet client.', id: 3 },
                  { title: 'Mois 4', subtitle: 'Cloud', body: 'Présentation KYNETIK Cloud.', id: 4 },
                  { title: 'Mois 5', subtitle: 'Partenaires', body: 'Partenariats pro.', id: 5 },
                  { title: 'Mois 6', subtitle: 'Bilan', body: 'Premier bilan marché.', id: 6 },
                ]
            ).map((m, i) => (
              <Fade key={m.id || m.title} delay={i * 0.04}>
                <div className="rounded-2xl border border-white/10 bg-kyn-black/50 p-6 h-full">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-9 h-9 rounded-xl bg-violet-500/15 border border-violet-400/25 flex items-center justify-center text-violet-300 text-xs font-bold">
                      M{i + 1}
                    </div>
                    <div>
                      <p className="font-display font-bold">{m.title}</p>
                      <p className="text-[10px] uppercase tracking-wider text-kyn-green">{m.subtitle}</p>
                    </div>
                  </div>
                  <p className="text-sm text-kyn-silver leading-relaxed">{m.body}</p>
                </div>
              </Fade>
            ))}
          </div>
        </div>
      </section>

      {/* 7 CONTENT */}
      <section id="content" className="py-20 md:py-28 border-t border-white/5 scroll-mt-24">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <Fade>
            <p className="text-kyn-green text-xs font-semibold tracking-[0.28em] uppercase mb-4">07 · Content strategy</p>
            <h2 className="font-display text-3xl md:text-5xl font-bold">Rythme hebdomadaire</h2>
          </Fade>
          <div className="mt-12 grid md:grid-cols-3 gap-5">
            {(content.length
              ? content
              : [
                  { title: 'LinkedIn', subtitle: '2 posts / semaine', body: 'Innovation + projet client.', id: 1 },
                  { title: 'Instagram', subtitle: '3 contenus / semaine', body: 'Produits · install · lifestyle.', id: 2 },
                  { title: 'Blog', subtitle: 'Articles guides', body: 'Choisir une borne, guide TN.', id: 3 },
                ]
            ).map((c, i) => {
              const Icon = i === 0 ? Linkedin : i === 1 ? Instagram : BookOpen;
              return (
                <Fade key={c.id || c.title} delay={i * 0.05}>
                  <div className="rounded-3xl border border-white/10 bg-kyn-void p-8 h-full">
                    <Icon className="text-kyn-green mb-5" size={24} />
                    <p className="text-[11px] uppercase tracking-wider text-kyn-green font-semibold">{c.subtitle}</p>
                    <h3 className="font-display text-2xl font-bold mt-2">{c.title}</h3>
                    <p className="mt-4 text-sm text-kyn-silver leading-relaxed">{c.body}</p>
                    <Link to="/social" className="mt-6 inline-flex items-center gap-1.5 text-xs font-semibold text-kyn-green">
                      Templates sociaux <ArrowRight size={12} />
                    </Link>
                  </div>
                </Fade>
              );
            })}
          </div>

          <Fade>
            <div className="mt-8 rounded-2xl border border-white/10 p-6 md:p-8 bg-white/[0.02]">
              <p className="font-semibold mb-4">Sujets blog prioritaires</p>
              <div className="flex flex-wrap gap-2">
                {[
                  'Comment choisir une borne ?',
                  'Pourquoi passer à l’électrique ?',
                  'Guide recharge Tunisie',
                  'OCPP expliqué simplement',
                  'Bornes en copropriété',
                  'Flotte électrique ROI',
                ].map((tag) => (
                  <span key={tag} className="px-3 py-1.5 rounded-full border border-white/10 text-xs text-kyn-silver">
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          </Fade>
        </div>
      </section>

      {/* 8 SALES KIT */}
      <section id="kit" className="py-20 md:py-28 bg-kyn-void border-t border-white/5 scroll-mt-24">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <Fade>
            <p className="text-kyn-green text-xs font-semibold tracking-[0.28em] uppercase mb-4">08 · Sales kit</p>
            <h2 className="font-display text-3xl md:text-5xl font-bold">Assets commerciaux</h2>
            <p className="mt-4 text-kyn-silver max-w-xl">Tout ce dont l&apos;équipe a besoin pour vendre et signer.</p>
          </Fade>
          <div className="mt-12 grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {(kit.length
              ? kit
              : [
                  { title: 'Corporate Presentation', body: 'Deck corporate prospects.', meta: 'PDF', id: 1 },
                  { title: 'Product Catalog', body: 'Catalogue GO → PRO.', meta: 'PDF', id: 2 },
                  { title: 'Technical Datasheets', body: 'Fiches techniques.', meta: 'PDF', id: 3 },
                  { title: 'Price List', body: 'Grille tarifaire.', meta: 'XLS', id: 4 },
                  { title: 'Installation Guide', body: 'Guide pose & OCPP.', meta: 'PDF', id: 5 },
                  { title: 'Partner Program', body: 'Installateurs / distributeurs.', meta: 'PDF', id: 6 },
                  { title: 'Investor Deck', body: 'Vision 2036.', meta: 'PDF', id: 7 },
                ]
            ).map((k, i) => {
              const Icon = KIT_ICONS[k.title] || FileText;
              const link =
                k.title.includes('Investor') ? '/investors'
                  : k.title.includes('Partner') ? '/installers'
                    : k.title.includes('Catalog') || k.title.includes('Datasheet') ? '/products'
                      : k.title.includes('Price') || k.title.includes('Corporate') ? '/quote'
                        : '/resources';
              return (
                <Fade key={k.id || k.title} delay={i * 0.03}>
                  <Link
                    to={link}
                    className="group rounded-2xl border border-white/10 bg-kyn-black/40 p-6 h-full flex flex-col hover:border-kyn-green/35 transition-colors"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="w-10 h-10 rounded-xl bg-kyn-green/10 border border-kyn-green/20 flex items-center justify-center text-kyn-green">
                        <Icon size={18} />
                      </div>
                      <span className="text-[10px] uppercase tracking-wider text-kyn-metal font-semibold flex items-center gap-1">
                        <Download size={12} /> {k.meta || 'PDF'}
                      </span>
                    </div>
                    <h3 className="font-display font-bold mt-4 group-hover:text-kyn-green transition-colors">{k.title}</h3>
                    <p className="text-sm text-kyn-metal mt-2 flex-1">{k.body}</p>
                    <span className="mt-4 inline-flex items-center gap-1 text-xs font-semibold text-kyn-green">
                      Ouvrir <ArrowRight size={12} />
                    </span>
                  </Link>
                </Fade>
              );
            })}
          </div>
        </div>
      </section>

      {/* CTA + Phase 23 */}
      <section className="py-20 md:py-28 border-t border-white/5 relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(0,230,118,0.1),transparent_55%)]" />
        <div className="relative z-10 max-w-4xl mx-auto px-5 text-center">
          <Fade>
            <p className="text-kyn-green text-xs font-semibold tracking-[0.28em] uppercase mb-4">Next</p>
            <h2 className="font-display text-3xl md:text-5xl font-bold">
              Phase 23 — Sales System
              <br />
              <span className="text-white/45">& Commercial Strategy</span>
            </h2>
            <p className="mt-5 text-kyn-silver max-w-xl mx-auto">
              Équipe vente, pricing, offres particuliers / entreprises, contrats, réseau installateurs,
              objectifs 2027–2030 et KPIs.
            </p>
            <div className="mt-10 flex flex-wrap justify-center gap-3">
              <Link to="/quote" className="inline-flex items-center gap-2 px-7 py-3.5 rounded-full bg-kyn-green text-kyn-black text-sm font-bold">
                Activer un devis <ArrowRight size={16} />
              </Link>
              <Link to="/sales" className="inline-flex items-center gap-2 px-7 py-3.5 rounded-full border border-white/15 text-sm font-semibold">
                Marketing hub
              </Link>
              <Link to="/delivery" className="inline-flex items-center gap-2 px-7 py-3.5 rounded-full border border-white/15 text-sm font-semibold">
                Architecture
              </Link>
              <a href="mailto:hello@kynetik.tn" className="inline-flex items-center gap-2 px-7 py-3.5 rounded-full border border-white/15 text-sm font-semibold">
                <Mail size={14} /> hello@kynetik.tn
              </a>
            </div>
          </Fade>
        </div>
      </section>

      <footer className="border-t border-white/5 py-8">
        <div className="max-w-7xl mx-auto px-5 md:px-8 flex flex-wrap justify-between gap-4 items-center">
          <BrandLogo height={26} />
          <div className="flex items-center gap-3 text-kyn-metal">
            <Share2 size={14} />
            <span className="text-[11px]">LinkedIn · Instagram · Facebook</span>
          </div>
          <p className="text-[11px] text-kyn-metal">Phase 22 · Brand & Marketing Launch System</p>
        </div>
      </footer>
    </div>
  );
}

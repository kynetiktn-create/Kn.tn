import { useEffect, useMemo, useState, type ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  ArrowRight, BookOpen, Component, Copy, Check, Menu, X, Search,
  Home, Zap, Cloud, Settings, Bell, Mail, Lock, Plus, Download,
  ChevronRight, Layers, Palette, MousePointer2, LayoutGrid,
  FormInput, Table2, MessageSquare, Loader2, Navigation, Box
} from 'lucide-react';
import BrandLogo from '../components/BrandLogo';
import LoadingState from '../components/LoadingState';
import {
  Button, Badge, Input, Textarea, Select, Checkbox, Toggle, Card, CardHeader,
  Avatar, Tabs, UnderlineTabs, Alert, Spinner, Skeleton, ProgressBar,
  Table, THead, Th, TBody, Td, NavItem, Breadcrumb, Tooltip, EmptyState,
  Toast, FormField, ChargeRing, StatCard, StatusPill, SpecChip, ProductStage,
  SectionLabel, MetricTile, GlassPanel, colors, space, radius, type as typeTokens
} from '../ui';
import { apiGet, cn } from '../lib/utils';

interface BibleItem {
  id: number;
  chapter: string;
  type: string;
  title: string;
  subtitle: string;
  body: string;
  meta: string | null;
  sort_order: number;
}

const TOC = [
  { id: 'cover', label: '00 · Cover', icon: BookOpen },
  { id: 'tokens', label: '01 · Design Tokens', icon: Palette },
  { id: 'buttons', label: '02 · Buttons', icon: MousePointer2 },
  { id: 'navigation', label: '03 · Navigation', icon: Navigation },
  { id: 'cards', label: '04 · Cards & Widgets', icon: LayoutGrid },
  { id: 'forms', label: '05 · Forms', icon: FormInput },
  { id: 'tables', label: '06 · Tables', icon: Table2 },
  { id: 'feedback', label: '07 · Feedback', icon: MessageSquare },
  { id: 'states', label: '08 · System States', icon: Loader2 },
  { id: 'domain', label: '09 · KYNETIK Domain', icon: Zap },
  { id: 'naming', label: '10 · Naming & Handoff', icon: Box },
];

function Section({
  id,
  number,
  title,
  subtitle,
  children,
}: {
  id: string;
  number: string;
  title: string;
  subtitle: string;
  children: ReactNode;
}) {
  return (
    <section id={id} className="scroll-mt-28 border-t border-white/5 py-16 md:py-20">
      <div className="mb-10 max-w-2xl">
        <p className="mb-2 text-[11px] font-semibold uppercase tracking-[0.28em] text-kyn-green">{number}</p>
        <h2 className="font-display text-3xl font-bold tracking-tight text-white md:text-4xl">{title}</h2>
        <p className="mt-3 text-base leading-relaxed text-kyn-metal">{subtitle}</p>
      </div>
      {children}
    </section>
  );
}

function SpecRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between gap-4 border-b border-white/5 py-2 text-xs">
      <span className="text-kyn-metal">{label}</span>
      <code className="font-mono text-[11px] text-kyn-green">{value}</code>
    </div>
  );
}

function Canvas({ title, children, className }: { title?: string; children: ReactNode; className?: string }) {
  return (
    <div className={cn('overflow-hidden rounded-2xl border border-white/8 bg-kyn-void', className)}>
      {title && (
        <div className="flex items-center justify-between border-b border-white/5 px-4 py-2.5">
          <span className="text-[10px] font-semibold uppercase tracking-wider text-kyn-metal">{title}</span>
          <span className="text-[10px] text-kyn-graphite">Live preview</span>
        </div>
      )}
      <div className="p-5 md:p-6">{children}</div>
    </div>
  );
}

function CodeChip({ children }: { children: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <button
      type="button"
      onClick={() => {
        navigator.clipboard?.writeText(children).catch(() => undefined);
        setCopied(true);
        setTimeout(() => setCopied(false), 1200);
      }}
      className="group inline-flex items-center gap-2 rounded-xl border border-white/8 bg-black/40 px-3 py-1.5 font-mono text-[11px] text-kyn-silver transition-colors hover:border-kyn-green/30 hover:text-kyn-green"
    >
      {children}
      {copied ? <Check size={12} className="text-kyn-green" /> : <Copy size={12} className="opacity-50 group-hover:opacity-100" />}
    </button>
  );
}

export default function ComponentLibrary() {
  const [items, setItems] = useState<BibleItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [activeToc, setActiveToc] = useState('cover');
  const [tabDemo, setTabDemo] = useState('overview');
  const [toggleOn, setToggleOn] = useState(true);
  const [checkA, setCheckA] = useState(true);
  const [search, setSearch] = useState('');

  useEffect(() => {
    apiGet<BibleItem[]>('/api/design-bible')
      .then((data) => setItems(data.filter((d) => d.chapter === 'components' || d.chapter === 'library')))
      .catch(() => setItems([]))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    const onScroll = () => {
      setScrolled(window.scrollY > 16);
      const ids = TOC.map((t) => t.id);
      let current = ids[0];
      for (const id of ids) {
        const el = document.getElementById(id);
        if (el && el.getBoundingClientRect().top <= 140) current = id;
      }
      setActiveToc(current);
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const libNotes = useMemo(() => items.filter((i) => i.chapter === 'library' || i.chapter === 'components'), [items]);

  const filteredToc = TOC.filter((t) => t.label.toLowerCase().includes(search.toLowerCase()));

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-kyn-black">
        <LoadingState label="Loading UI Component Library…" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#070708] text-white">
      {/* Top bar */}
      <header
        className={cn(
          'fixed inset-x-0 top-0 z-50 transition-all duration-300',
          scrolled ? 'border-b border-white/5 bg-kyn-black/85 backdrop-blur-xl' : 'bg-transparent'
        )}
      >
        <div className="mx-auto flex h-16 max-w-[1400px] items-center justify-between px-4 md:px-6">
          <div className="flex items-center gap-3">
            <BrandLogo height={28} />
            <div className="hidden h-5 w-px bg-white/10 sm:block" />
            <div className="hidden sm:block">
              <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-kyn-green">Design System</p>
              <p className="text-[11px] text-kyn-metal">Chapter 02 · UI Component Library v1.0</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Link to="/design-system/tokens" className="hidden text-xs text-kyn-metal hover:text-white md:inline">
              Design Bible
            </Link>
            <Link to="/design-system/tokens" className="hidden text-xs text-kyn-metal hover:text-white md:inline">
              Dev Handoff
            </Link>
            <Button size="sm" className="hidden sm:inline-flex">
              Export to Figma <ArrowRight size={12} />
            </Button>
            <button type="button" className="p-2 text-kyn-silver lg:hidden" onClick={() => setMenuOpen(!menuOpen)}>
              {menuOpen ? <X size={18} /> : <Menu size={18} />}
            </button>
          </div>
        </div>
      </header>

      <div className="mx-auto flex max-w-[1400px] gap-0 pt-16">
        {/* Sidebar TOC */}
        <aside
          className={cn(
            'fixed inset-y-16 left-0 z-40 w-72 overflow-y-auto border-r border-white/5 bg-[#0a0a0c]/95 p-4 backdrop-blur-xl transition-transform lg:sticky lg:top-16 lg:h-[calc(100vh-4rem)] lg:translate-x-0 lg:bg-transparent lg:backdrop-blur-0',
            menuOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
          )}
        >
          <div className="mb-4">
            <div className="relative">
              <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-kyn-metal" />
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search sections…"
                className="w-full rounded-xl border border-white/8 bg-white/[0.03] py-2 pl-9 pr-3 text-xs text-white outline-none placeholder:text-kyn-metal focus:border-kyn-green/30"
              />
            </div>
          </div>
          <p className="mb-2 px-2 text-[10px] font-semibold uppercase tracking-wider text-kyn-metal">Contents</p>
          <nav className="space-y-0.5">
            {filteredToc.map((t) => {
              const Icon = t.icon;
              return (
                <a
                  key={t.id}
                  href={`#${t.id}`}
                  onClick={() => setMenuOpen(false)}
                  className={cn(
                    'flex items-center gap-2.5 rounded-xl px-3 py-2 text-xs font-medium transition-all',
                    activeToc === t.id
                      ? 'bg-kyn-green/10 text-kyn-green border border-kyn-green/20'
                      : 'text-kyn-silver hover:bg-white/5 hover:text-white'
                  )}
                >
                  <Icon size={14} />
                  {t.label}
                </a>
              );
            })}
          </nav>
          <div className="mt-6 rounded-2xl border border-white/8 bg-white/[0.02] p-4">
            <p className="text-[10px] font-semibold uppercase tracking-wider text-kyn-green">Status</p>
            <p className="mt-1 font-display text-sm font-semibold">v1.0 · Stable</p>
            <p className="mt-1 text-[11px] leading-relaxed text-kyn-metal">
              Ready for Master Figma File & React/Next component package.
            </p>
          </div>
        </aside>

        {/* Document */}
        <main className="min-w-0 flex-1 px-4 pb-24 md:px-8 lg:px-12">
          {/* COVER */}
          <section id="cover" className="relative scroll-mt-28 py-16 md:py-24">
            <div className="absolute inset-0 -mx-4 bg-[radial-gradient(ellipse_at_top,rgba(0,230,118,0.12),transparent_55%)] md:-mx-8 lg:-mx-12" />
            <div className="relative">
              <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}>
                <Badge tone="green">
                  <Component size={10} /> Chapter 02
                </Badge>
                <h1 className="mt-6 font-display text-4xl font-bold leading-[1.05] tracking-tight md:text-6xl">
                  UI Component
                  <br />
                  <span className="text-kyn-green text-glow">Library</span>
                </h1>
                <p className="mt-5 max-w-2xl text-lg leading-relaxed text-kyn-silver">
                  KYNETIK Design System — the production-ready interface kit for Cloud, Mobile, Portal and
                  Installer surfaces. Apple clarity · Stripe precision · EV energy aesthetics.
                </p>
                <div className="mt-8 flex flex-wrap gap-3">
                  <div className="rounded-2xl border border-white/8 bg-white/[0.03] px-4 py-3">
                    <p className="text-[10px] uppercase tracking-wider text-kyn-metal">Version</p>
                    <p className="font-display font-semibold">1.0.0</p>
                  </div>
                  <div className="rounded-2xl border border-white/8 bg-white/[0.03] px-4 py-3">
                    <p className="text-[10px] uppercase tracking-wider text-kyn-metal">Components</p>
                    <p className="font-display font-semibold">40+</p>
                  </div>
                  <div className="rounded-2xl border border-white/8 bg-white/[0.03] px-4 py-3">
                    <p className="text-[10px] uppercase tracking-wider text-kyn-metal">Platforms</p>
                    <p className="font-display font-semibold">Web · App · Ops</p>
                  </div>
                  <div className="rounded-2xl border border-white/8 bg-white/[0.03] px-4 py-3">
                    <p className="text-[10px] uppercase tracking-wider text-kyn-metal">Stack</p>
                    <p className="font-display font-semibold">React · Tailwind</p>
                  </div>
                </div>
                <div className="mt-8 flex flex-wrap gap-2">
                  <CodeChip>{"import { Button } from '@/ui'"}</CodeChip>
                  <CodeChip>@kynetik/ui</CodeChip>
                </div>
              </motion.div>

              {libNotes.length > 0 && (
                <div className="mt-12 grid gap-3 md:grid-cols-3">
                  {libNotes.slice(0, 3).map((n) => (
                    <Card key={n.id} className="!bg-white/[0.02]">
                      <p className="text-[10px] font-semibold uppercase tracking-wider text-kyn-green">{n.subtitle || n.type}</p>
                      <p className="mt-2 font-display font-semibold">{n.title}</p>
                      <p className="mt-2 text-xs leading-relaxed text-kyn-metal">{n.body}</p>
                    </Card>
                  ))}
                </div>
              )}
            </div>
          </section>

          {/* TOKENS */}
          <Section
            id="tokens"
            number="01 · Foundations"
            title="Design Tokens"
            subtitle="Single source of truth for color, type, space, radius and elevation — mapped 1:1 to CSS variables and Figma styles."
          >
            <div className="grid gap-6 lg:grid-cols-2">
              <Canvas title="Color · Core">
                <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
                  {Object.entries(colors).map(([name, value]) => (
                    <div key={name} className="overflow-hidden rounded-xl border border-white/8">
                      <div className="h-14" style={{ background: value }} />
                      <div className="bg-black/40 px-2.5 py-2">
                        <p className="text-[11px] font-medium capitalize text-white">{name}</p>
                        <p className="font-mono text-[10px] text-kyn-green">{value}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </Canvas>
              <div className="space-y-4">
                <Canvas title="Typography">
                  <p className="font-display text-3xl font-bold" style={{ fontFamily: typeTokens.display }}>
                    Space Grotesk
                  </p>
                  <p className="mt-1 text-sm text-kyn-metal">Display · Headlines · Product names</p>
                  <p className="mt-6 text-base leading-relaxed" style={{ fontFamily: typeTokens.body }}>
                    Inter — body UI, forms, tables, dense operational interfaces.
                  </p>
                  <div className="mt-4 space-y-1">
                    <SpecRow label="Display" value="Space Grotesk Bold 32–64" />
                    <SpecRow label="Title" value="Space Grotesk SemiBold 20–28" />
                    <SpecRow label="Body" value="Inter Regular 14–16 / 1.55" />
                    <SpecRow label="Caption" value="Inter Medium 11–12 tracking-wide" />
                  </div>
                </Canvas>
                <Canvas title="Space · Radius">
                  <div className="flex flex-wrap items-end gap-3">
                    {Object.entries(space).map(([k, v]) => (
                      <div key={k} className="text-center">
                        <div className="mx-auto rounded-sm bg-kyn-green/80" style={{ width: Math.min(v, 64), height: Math.min(v, 48) }} />
                        <p className="mt-1 font-mono text-[9px] text-kyn-metal">{k} {v}</p>
                      </div>
                    ))}
                  </div>
                  <div className="mt-6 flex flex-wrap gap-3">
                    {Object.entries(radius).map(([k, v]) => (
                      <div key={k} className="flex flex-col items-center gap-1">
                        <div className="h-12 w-12 border border-kyn-green/40 bg-kyn-green/10" style={{ borderRadius: v }} />
                        <p className="font-mono text-[9px] text-kyn-metal">{k}</p>
                      </div>
                    ))}
                  </div>
                </Canvas>
              </div>
            </div>
          </Section>

          {/* BUTTONS */}
          <Section
            id="buttons"
            number="02 · Actions"
            title="Buttons"
            subtitle="Primary energy actions, secondary outlines, ghost utilities and destructive stops — all with hover, active, loading and disabled states."
          >
            <div className="grid gap-4 lg:grid-cols-2">
              <Canvas title="Variants">
                <div className="flex flex-wrap gap-3">
                  <Button>Primary</Button>
                  <Button variant="secondary">Secondary</Button>
                  <Button variant="ghost">Ghost</Button>
                  <Button variant="danger">Danger</Button>
                </div>
                <div className="mt-6 flex flex-wrap items-center gap-3">
                  <Button size="sm">Small</Button>
                  <Button size="md">Medium</Button>
                  <Button size="lg">Large</Button>
                </div>
                <div className="mt-6 flex flex-wrap gap-3">
                  <Button><Plus size={14} /> With icon</Button>
                  <Button variant="secondary"><Download size={14} /> Export</Button>
                  <Button disabled>Disabled</Button>
                  <Button className="pointer-events-none opacity-80">
                    <Spinner size="sm" /> Loading
                  </Button>
                </div>
              </Canvas>
              <Canvas title="Specs · KynButton">
                <SpecRow label="Component" value="Button / KynButton" />
                <SpecRow label="Variants" value="primary | secondary | ghost | danger" />
                <SpecRow label="Sizes" value="sm | md | lg" />
                <SpecRow label="Radius" value="12–16px (rounded-xl/2xl)" />
                <SpecRow label="Primary fill" value="#00E676" />
                <SpecRow label="Hover" value="greenGlow + 2% lift" />
                <SpecRow label="Disabled" value="opacity 40% · no pointer" />
                <SpecRow label="Focus ring" value="2px green/30" />
                <div className="mt-4">
                  <CodeChip>{'<Button variant="primary" size="md">Label</Button>'}</CodeChip>
                </div>
              </Canvas>
            </div>
          </Section>

          {/* NAVIGATION */}
          <Section
            id="navigation"
            number="03 · Navigation"
            title="Navigation"
            subtitle="Sidebar items, breadcrumbs, tabs and wayfinding patterns for Cloud Console, Portal and marketing."
          >
            <div className="grid gap-4 lg:grid-cols-2">
              <Canvas title="Sidebar · NavItem">
                <div className="max-w-xs space-y-1 rounded-2xl border border-white/8 bg-kyn-black/50 p-2">
                  <NavItem icon={<Home size={15} />} label="Overview" active />
                  <NavItem icon={<Zap size={15} />} label="Chargers" badge={12} />
                  <NavItem icon={<Cloud size={15} />} label="Sessions" />
                  <NavItem icon={<Bell size={15} />} label="Alerts" badge={3} />
                  <NavItem icon={<Settings size={15} />} label="Settings" />
                </div>
              </Canvas>
              <div className="space-y-4">
                <Canvas title="Breadcrumb">
                  <Breadcrumb items={['Cloud', 'Sites', 'Hub Lac 2', 'Connector 02']} />
                </Canvas>
                <Canvas title="Tabs · Pill">
                  <Tabs
                    value={tabDemo}
                    onChange={setTabDemo}
                    items={[
                      { id: 'overview', label: 'Overview' },
                      { id: 'energy', label: 'Energy' },
                      { id: 'billing', label: 'Billing' },
                      { id: 'logs', label: 'Logs' },
                    ]}
                  />
                  <p className="mt-4 text-xs text-kyn-metal">Active tab: <span className="text-kyn-green">{tabDemo}</span></p>
                </Canvas>
                <Canvas title="Tabs · Underline">
                  <UnderlineTabs
                    value={tabDemo}
                    onChange={setTabDemo}
                    items={[
                      { id: 'overview', label: 'Overview' },
                      { id: 'energy', label: 'Energy' },
                      { id: 'billing', label: 'Billing' },
                    ]}
                  />
                </Canvas>
              </div>
            </div>
          </Section>

          {/* CARDS */}
          <Section
            id="cards"
            number="04 · Surfaces"
            title="Cards & Widgets"
            subtitle="Glass cards, KPI tiles and interactive containers — the backbone of dashboards and product pages."
          >
            <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
              <Card interactive>
                <CardHeader title="NOVA Home" subtitle="La Marsa · Online" action={<Badge>Live</Badge>} />
                <p className="text-sm text-kyn-silver">11.2 kW · Session 42 min</p>
                <ProgressBar value={67} className="mt-4" />
              </Card>
              <StatCard label="Energy today" value="8.2k kWh" delta="+4.1% vs yesterday" icon={<Zap size={14} className="text-kyn-green" />} />
              <StatCard label="Uptime" value="99.4%" delta="SLA OK" icon={<Cloud size={14} className="text-kyn-green" />} />
              <Card className="md:col-span-2 xl:col-span-3">
                <CardHeader title="Widget anatomy" subtitle="Header · body · footer actions" />
                <div className="grid gap-3 sm:grid-cols-3">
                  <div className="rounded-xl border border-white/8 bg-black/30 p-3 text-xs text-kyn-metal">
                    <p className="font-semibold text-white">Padding</p>
                    <p className="mt-1">16–28px · radius 16</p>
                  </div>
                  <div className="rounded-xl border border-white/8 bg-black/30 p-3 text-xs text-kyn-metal">
                    <p className="font-semibold text-white">Border</p>
                    <p className="mt-1">1px white/8 · hover green/30</p>
                  </div>
                  <div className="rounded-xl border border-white/8 bg-black/30 p-3 text-xs text-kyn-metal">
                    <p className="font-semibold text-white">Elevation</p>
                    <p className="mt-1">Hairline + optional green glow</p>
                  </div>
                </div>
              </Card>
            </div>
          </Section>

          {/* FORMS */}
          <Section
            id="forms"
            number="05 · Inputs"
            title="Forms"
            subtitle="Text fields, selects, checkboxes and toggles with validation, icons and helper copy."
          >
            <div className="grid gap-4 lg:grid-cols-2">
              <Canvas title="Controls">
                <div className="space-y-4">
                  <Input label="Email" placeholder="khalifa@kynetik.tn" leftIcon={<Mail size={14} />} />
                  <Input label="Password" type="password" placeholder="••••••••" leftIcon={<Lock size={14} />} />
                  <Input label="Site name" error="Site name is required" defaultValue="" placeholder="Hub name" />
                  <Select
                    label="Connector type"
                    options={[
                      { value: 't2', label: 'Type 2' },
                      { value: 'ccs', label: 'CCS2' },
                      { value: 'chademo', label: 'CHAdeMO' },
                    ]}
                  />
                  <Textarea label="Notes" placeholder="Installation notes…" hint="Visible to field technicians" />
                  <div className="flex flex-wrap items-center gap-6 pt-2">
                    <Checkbox
                      label="Smart charging"
                      description="Allow Cloud load balancing"
                      checked={checkA}
                      onChange={(e) => setCheckA(e.target.checked)}
                    />
                    <Toggle checked={toggleOn} onChange={setToggleOn} label="Notifications" />
                  </div>
                </div>
              </Canvas>
              <Canvas title="Form pattern · Auth">
                <div className="mx-auto max-w-sm space-y-4 rounded-2xl border border-white/8 bg-kyn-black/40 p-5">
                  <div className="text-center">
                    <BrandLogo height={28} className="mx-auto justify-center" />
                    <p className="mt-3 font-display text-lg font-semibold">Bienvenue chez KYNETIK</p>
                    <p className="text-xs text-kyn-metal">Connectez-vous pour piloter votre énergie</p>
                  </div>
                  <FormField label="Email" required>
                    <Input placeholder="email@company.tn" />
                  </FormField>
                  <FormField label="Password" required hint="Min 8 chars">
                    <Input type="password" placeholder="••••••••" />
                  </FormField>
                  <Button className="w-full">Connexion</Button>
                  <Button variant="secondary" className="w-full">Créer un compte</Button>
                </div>
              </Canvas>
            </div>
          </Section>

          {/* TABLES */}
          <Section
            id="tables"
            number="06 · Data"
            title="Tables"
            subtitle="Dense, legible operational tables for sessions, stations and billing — monochrome with green status accents."
          >
            <Canvas title="Sessions table">
              <Table>
                <THead>
                  <tr>
                    <Th>Session</Th>
                    <Th>Station</Th>
                    <Th>Energy</Th>
                    <Th>Duration</Th>
                    <Th>Status</Th>
                  </tr>
                </THead>
                <TBody>
                  {[
                    ['#K-88421', 'Hub Lac 2', '34.2 kWh', '48 min', 'Active'],
                    ['#K-88418', 'NOVA Marsa', '12.8 kWh', '1h 12m', 'Active'],
                    ['#K-88402', 'PRIME Hotel', '8.4 kWh', '38 min', 'Completed'],
                    ['#K-88391', 'GO Fleet 03', '4.1 kWh', '22 min', 'Completed'],
                  ].map((row) => (
                    <tr key={row[0]} className="hover:bg-white/[0.02]">
                      <Td className="font-medium text-white">{row[0]}</Td>
                      <Td>{row[1]}</Td>
                      <Td>{row[2]}</Td>
                      <Td>{row[3]}</Td>
                      <Td>
                        <Badge tone={row[4] === 'Active' ? 'green' : 'metal'}>{row[4]}</Badge>
                      </Td>
                    </tr>
                  ))}
                </TBody>
              </Table>
              <div className="mt-4 flex flex-wrap gap-2">
                <SpecRow label="Row height" value="44–48px" />
              </div>
            </Canvas>
          </Section>

          {/* FEEDBACK */}
          <Section
            id="feedback"
            number="07 · Feedback"
            title="Alerts, Toasts & Badges"
            subtitle="System communication for success, warning, info and error — never silent failures."
          >
            <div className="grid gap-4 lg:grid-cols-2">
              <div className="space-y-3">
                <Alert tone="success" title="Charge complete">
                  Vehicle reached target SoC 80%. Session #K-88421 closed.
                </Alert>
                <Alert tone="info" title="Firmware available">
                  OTA 2.4.1 ready for 12 PRIME stations.
                </Alert>
                <Alert tone="warning" title="Load peak approaching">
                  Site Lac corridor at 86% capacity.
                </Alert>
                <Alert tone="error" title="Station offline">
                  Hotel Palm unreachable for 2h 14m.
                </Alert>
              </div>
              <div className="space-y-4">
                <Canvas title="Toasts">
                  <div className="space-y-3">
                    <Toast title="Session started" body="NOVA Home · 11.2 kW" />
                    <Toast title="Invoice exported" body="March 2026 PDF ready" tone="info" />
                    <Toast title="Payment failed" body="Retry or update card" tone="error" />
                  </div>
                </Canvas>
                <Canvas title="Badges">
                  <div className="flex flex-wrap gap-2">
                    <Badge>Online</Badge>
                    <Badge tone="metal">Draft</Badge>
                    <Badge tone="warning">Degraded</Badge>
                    <Badge tone="danger">Fault</Badge>
                    <Tooltip label="Connector available">
                      <Badge>● Available</Badge>
                    </Tooltip>
                  </div>
                </Canvas>
              </div>
            </div>
          </Section>

          {/* STATES */}
          <Section
            id="states"
            number="08 · Resilience"
            title="Loading · Empty · Error · Success"
            subtitle="Every view must define these four states before development. No blank screens."
          >
            <div className="grid gap-4 md:grid-cols-2">
              <Canvas title="Loading">
                <div className="flex flex-col items-center gap-4 py-6">
                  <Spinner size="lg" />
                  <div className="w-full max-w-xs space-y-2">
                    <Skeleton className="h-4 w-2/3" />
                    <Skeleton className="h-4 w-full" />
                    <Skeleton className="h-4 w-5/6" />
                    <Skeleton className="mt-4 h-24 w-full" />
                  </div>
                </div>
              </Canvas>
              <Canvas title="Empty">
                <EmptyState
                  icon={<Zap size={28} />}
                  title="No chargers yet"
                  body="Add your first KYNETIK station to start monitoring sessions and energy."
                  actionLabel="Add charger"
                  onAction={() => undefined}
                />
              </Canvas>
              <Canvas title="Progress">
                <div className="space-y-4 py-4">
                  <div>
                    <div className="mb-2 flex justify-between text-xs">
                      <span className="text-kyn-metal">Firmware update</span>
                      <span className="text-kyn-green">64%</span>
                    </div>
                    <ProgressBar value={64} />
                  </div>
                  <div>
                    <div className="mb-2 flex justify-between text-xs">
                      <span className="text-kyn-metal">Monthly energy goal</span>
                      <span className="text-kyn-green">82%</span>
                    </div>
                    <ProgressBar value={82} />
                  </div>
                </div>
              </Canvas>
              <Canvas title="Avatar · Identity">
                <div className="flex flex-wrap items-center gap-4 py-4">
                  <Avatar name="Khalifa Ben Ali" size="lg" status="online" />
                  <Avatar name="Leila Mansour" size="md" status="busy" />
                  <Avatar name="Support Bot" size="sm" status="offline" />
                  <div>
                    <p className="font-semibold">Khalifa Ben Ali</p>
                    <p className="text-xs text-kyn-metal">Founder · Online</p>
                  </div>
                </div>
              </Canvas>
            </div>
          </Section>

          {/* DOMAIN */}
          <Section
            id="domain"
            number="09 · Domain"
            title="KYNETIK-specific components"
            subtitle="Product DNA widgets reused across App, Cloud and marketing — charge ring, energy stats, station status."
          >

        <div className="mb-10 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          <Canvas title="StatusPill">
            <div className="flex flex-wrap gap-2">
              <StatusPill status="online">Online</StatusPill>
              <StatusPill status="charging" pulse>Charging</StatusPill>
              <StatusPill status="warning">Maintenance</StatusPill>
              <StatusPill status="offline">Offline</StatusPill>
            </div>
          </Canvas>
          <Canvas title="SpecChip">
            <div className="flex flex-wrap gap-2">
              <SpecChip>OCPP 1.6J</SpecChip>
              <SpecChip accent>22 kW</SpecChip>
              <SpecChip>IP54</SpecChip>
              <SpecChip>WiFi + 4G</SpecChip>
            </div>
          </Canvas>
          <Canvas title="MetricTile">
            <MetricTile label="Uptime" value="99.2%" delta="+0.4%" />
          </Canvas>
          <Canvas title="SectionLabel" className="md:col-span-2">
            <SectionLabel>Design system extension</SectionLabel>
            <p className="text-sm text-kyn-silver">Same brand tokens — new domain building blocks for product & ops surfaces.</p>
          </Canvas>
          <Canvas title="ProductStage">
            <ProductStage src="/images/products/nova-socket.png" alt="NOVA" accent="#00e676" className="h-40" />
          </Canvas>
          <Canvas title="GlassPanel" className="md:col-span-2 lg:col-span-3">
            <GlassPanel className="p-5">
              <p className="text-sm font-semibold text-white">GlassPanel</p>
              <p className="mt-1 text-xs text-kyn-metal">Canonical glass surface with optional green glow.</p>
            </GlassPanel>
          </Canvas>
        </div>
            <div className="grid items-center gap-6 md:grid-cols-2">
              <Canvas title="ChargeRing">
                <div className="flex justify-center py-6">
                  <ChargeRing percent={75} label="Recharge en cours" />
                </div>
                <SpecRow label="Component" value="ChargeRing" />
                <SpecRow label="Props" value="percent · label" />
                <SpecRow label="Track" value="conic-gradient green → graphite" />
              </Canvas>
              <div className="grid gap-4 sm:grid-cols-2">
                <StatCard label="Puissance" value="11.2 kW" delta="Live" />
                <StatCard label="Énergie" value="18.4 kWh" delta="Session" />
                <StatCard label="CO₂ sauvé" value="−32 kg" delta="This month" />
                <StatCard label="Coût" value="56.8 DT" delta="Wallet" />
              </div>
            </div>
          </Section>

          {/* NAMING */}
          <Section
            id="naming"
            number="10 · Delivery"
            title="Naming & handoff rules"
            subtitle="Consistent names from Figma → React → API so engineering never translates design intent."
          >
            <div className="grid gap-4 lg:grid-cols-2">
              <Canvas title="Naming convention">
                <div className="space-y-3 text-sm">
                  {[
                    ['Figma component', 'Kyn / Button / Primary'],
                    ['React export', 'Button · variant="primary"'],
                    ['Token', 'colors.green · space.lg · radius.card'],
                    ['CSS variable', '--color-kyn-green'],
                    ['File path', 'src/ui/primitives/Button.tsx'],
                    ['Domain widget', 'src/ui/kynetik/ChargeRing.tsx'],
                  ].map(([k, v]) => (
                    <div key={k} className="flex flex-col gap-0.5 rounded-xl border border-white/5 bg-black/20 px-3 py-2.5 sm:flex-row sm:items-center sm:justify-between">
                      <span className="text-xs text-kyn-metal">{k}</span>
                      <code className="font-mono text-[11px] text-kyn-green">{v}</code>
                    </div>
                  ))}
                </div>
              </Canvas>
              <Canvas title="Definition of ready">
                <ul className="space-y-3 text-sm text-kyn-silver">
                  {[
                    'All interactive states designed (hover, active, focus, disabled, loading)',
                    'Empty / error / success counterparts documented',
                    'Tokens only — no hard-coded hex outside tokens.ts',
                    'Accessible name + focus visible',
                    'Responsive behavior noted (stack / scroll / collapse)',
                    'Story or live canvas example in this library',
                  ].map((item) => (
                    <li key={item} className="flex gap-2">
                      <Check size={15} className="mt-0.5 shrink-0 text-kyn-green" />
                      {item}
                    </li>
                  ))}
                </ul>
                <div className="mt-6 flex flex-wrap gap-2">
                  <Link to="/handoff">
                    <Button variant="secondary" size="sm">
                      Dev Handoff <ChevronRight size={12} />
                    </Button>
                  </Link>
                  <Link to="/design-bible">
                    <Button variant="ghost" size="sm">
                      Design Bible
                    </Button>
                  </Link>
                  <Link to="/tokens">
                    <Button variant="ghost" size="sm">
                      UI Tokens page
                    </Button>
                  </Link>
                </div>
              </Canvas>
            </div>

            <div className="mt-8 rounded-3xl border border-kyn-green/20 bg-gradient-to-br from-kyn-green/10 via-transparent to-transparent p-8 text-center md:p-12">
              <Layers className="mx-auto text-kyn-green" size={28} />
              <h3 className="mt-4 font-display text-2xl font-bold md:text-3xl">
                Master Figma + React package ready
              </h3>
              <p className="mx-auto mt-3 max-w-xl text-sm text-kyn-silver">
                Chapter 02 closes the pre-development UI contract. Implement from this library —
                do not invent parallel components.
              </p>
              <div className="mt-6 flex flex-wrap justify-center gap-3">
                <Button>
                  Start build from library <ArrowRight size={14} />
                </Button>
                <Link to="/showcase">
                  <Button variant="secondary">View product showcase</Button>
                </Link>
              </div>
            </div>
          </Section>

          <footer className="border-t border-white/5 py-10 text-center">
            <BrandLogo height={24} className="mx-auto justify-center" />
            <p className="mt-4 text-[11px] text-kyn-metal">
              KYNETIK Design System · Chapter 02 · UI Component Library v1.0 · Confidential
            </p>
          </footer>
        </main>
      </div>
    </div>
  );
}

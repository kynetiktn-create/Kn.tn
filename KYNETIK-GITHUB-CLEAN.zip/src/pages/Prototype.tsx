import { useEffect, useMemo, useState, type ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  ArrowRight, ArrowLeft, Play, Smartphone, Globe, Cloud, CheckCircle2,
  ExternalLink, Layers, MousePointer2, Accessibility, Monitor, Tablet, ChevronRight
} from 'lucide-react';
import BrandLogo from '../components/BrandLogo';
import PhoneFrame from '../components/PhoneFrame';
import LoadingState from '../components/LoadingState';
import ErrorState from '../components/ErrorState';
import MicroInteractions from '../components/prototype/MicroInteractions';
import {
  SplashScreen, OnboardingScreen, AuthScreen, DashboardScreen, ChargingScreen,
  MapScreen, PaymentsScreen, ProfileScreen,
} from '../components/mobile/screens';
import {
  QrScanScreen, ChargerDetailsScreen, ChargingSummaryScreen, HistoryScreen,
} from '../components/mobile/screensExtra';
import { apiGet, cn } from '../lib/utils';

interface FlowStep {
  id: number;
  flow: string;
  title: string;
  description: string;
  route: string;
  slug: string;
  sort_order: number;
}

type Tab = 'website' | 'mobile' | 'cloud' | 'micro' | 'a11y' | 'qa';

const mobileScreenMap: Record<string, () => ReactNode> = {
  splash: () => <SplashScreen />,
  onboarding: () => <OnboardingScreen page={1} />,
  onboarding_2: () => <OnboardingScreen page={2} />,
  onboarding_3: () => <OnboardingScreen page={3} />,
  login: () => <AuthScreen />,
  home: () => <DashboardScreen />,
  map: () => <MapScreen />,
  station: () => <ChargerDetailsScreen />,
  qr: () => <QrScanScreen />,
  charging: () => <ChargingScreen />,
  payment: () => <PaymentsScreen />,
  summary: () => <ChargingSummaryScreen />,
  history: () => <HistoryScreen />,
  profile: () => <ProfileScreen />,
};

const websiteMap = [
  { title: 'Homepage', path: '/home', desc: 'Hero, products, cloud, academy, contact' },
  { title: 'Product System', path: '/product-system', desc: 'NOVA · PRIME · GO · EDGE · PRO' },
  { title: 'GO Series', path: '/product-system?series=go', desc: 'Portable EVSE · CEE 32A · Schuko' },
  { title: 'Request Quote', path: '/product-system#cta', desc: 'Sales CTA / devis' },
  { title: 'KYNETIK Cloud', path: '/cloud', desc: 'Cloud marketing page' },
  { title: 'Cloud Console', path: '/console', desc: 'Operator SaaS dashboard' },
  { title: 'Mobile App Landing', path: '/app-landing', desc: 'App marketing + screens' },
  { title: 'Academy', path: '/academy', desc: 'Training platform' },
  { title: 'Contact / Investor', path: '/investor', desc: 'Deck & outreach' },
];

const cloudMap = [
  { title: 'Dashboard', path: '/console', desc: 'KPIs live, energy, health' },
  { title: 'Charge Points', path: '/console', desc: 'Fleet stations list' },
  { title: 'Sessions', path: '/console', desc: 'Active & historical sessions' },
  { title: 'Analytics', path: '/console', desc: 'Energy, revenue, CO₂' },
  { title: 'Reports', path: '/console', desc: 'Export & board packs' },
  { title: 'Settings', path: '/console', desc: 'Org, users, tariffs' },
];

const a11yChecks = [
  'Contrast ratio ≥ 4.5:1 on body text (white on #050505)',
  'Primary CTA green on black exceeds WCAG AA for large text',
  'Focus rings visible on all interactive controls (outline offset 2px)',
  'Keyboard: Tab order follows visual hierarchy left→right / top→bottom',
  'Icons paired with text labels in navigation',
  'Status not conveyed by color alone (chips + icons + copy)',
  'Touch targets ≥ 44px on mobile bottom nav and primary buttons',
  'Reduced-motion friendly: animations short, non-essential',
];

const qaChecks = [
  { g: 'Spacing', i: '8pt scale · cards 16–24px padding · sections 80–128px' },
  { g: 'Typography', i: 'Space Grotesk display · Inter body · tracking hierarchy' },
  { g: 'Color', i: 'Black / green / white / metal — one accent per focal region' },
  { g: 'Icons', i: 'Lucide 1.5–2px stroke · consistent 16/18/20 sizes' },
  { g: 'Components', i: 'Buttons 16px radius · glass cards · status chips' },
  { g: 'Cross-surface', i: 'Web · App · Console share tokens & brand mark' },
];

export default function Prototype() {
  const [steps, setSteps] = useState<FlowStep[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [tab, setTab] = useState<Tab>('mobile');
  const [mobileIdx, setMobileIdx] = useState(0);
  const [webIdx, setWebIdx] = useState(0);
  const [cloudIdx, setCloudIdx] = useState(0);
  const [playing, setPlaying] = useState(false);

  useEffect(() => {
    apiGet<FlowStep[]>('/api/prototype')
      .then((data) => setSteps(Array.isArray(data) ? data : []))
      .catch(() => {
        // Fallback offline demo steps so /prototype never hard-fails
        setSteps([
          { id: 1, flow: 'mobile', title: 'Splash', description: 'Brand entry', route: '/app', slug: 'splash', sort_order: 1 },
          { id: 2, flow: 'mobile', title: 'Onboarding', description: 'Value props', route: '/app', slug: 'onboarding', sort_order: 2 },
          { id: 3, flow: 'mobile', title: 'Login', description: 'Auth', route: '/app', slug: 'login', sort_order: 3 },
          { id: 4, flow: 'mobile', title: 'Home', description: 'Dashboard', route: '/app', slug: 'home', sort_order: 4 },
          { id: 5, flow: 'mobile', title: 'Map', description: 'Stations', route: '/app', slug: 'map', sort_order: 5 },
          { id: 6, flow: 'mobile', title: 'Charging', description: 'Live session', route: '/app', slug: 'charging', sort_order: 6 },
          { id: 7, flow: 'mobile', title: 'Payment', description: 'Wallet', route: '/app', slug: 'payment', sort_order: 7 },
          { id: 8, flow: 'mobile', title: 'Profile', description: 'Account', route: '/app', slug: 'profile', sort_order: 8 },
        ]);
      })
      .finally(() => setLoading(false));
  }, []);

  const mobileSteps = useMemo(
    () => steps.filter((s) => s.flow === 'mobile').sort((a, b) => a.sort_order - b.sort_order),
    [steps]
  );

  useEffect(() => {
    if (!playing || tab !== 'mobile' || mobileSteps.length === 0) return;
    const t = setInterval(() => {
      setMobileIdx((i) => (i + 1) % mobileSteps.length);
    }, 2200);
    return () => clearInterval(t);
  }, [playing, tab, mobileSteps.length]);

  if (loading) {
    return (
      <div className="min-h-screen bg-kyn-black flex items-center justify-center">
        <LoadingState label="Loading interactive prototype…" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-kyn-black flex items-center justify-center p-8">
        <ErrorState message={error} />
      </div>
    );
  }

  const currentMobile = mobileSteps[mobileIdx];
  const MobileUI = currentMobile ? mobileScreenMap[currentMobile.slug] || SplashScreen : SplashScreen;

  const tabs: { id: Tab; label: string; icon: typeof Play }[] = [
    { id: 'mobile', label: 'App Flow', icon: Smartphone },
    { id: 'website', label: 'Website', icon: Globe },
    { id: 'cloud', label: 'Cloud', icon: Cloud },
    { id: 'micro', label: 'Micro UI', icon: MousePointer2 },
    { id: 'a11y', label: 'A11y', icon: Accessibility },
    { id: 'qa', label: 'Design QA', icon: Layers },
  ];

  return (
    <div className="min-h-screen bg-kyn-black text-white">
      <header className="sticky top-0 z-50 border-b border-white/5 bg-kyn-black/90 backdrop-blur-xl">
        <div className="max-w-7xl mx-auto px-5 md:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <BrandLogo height={28} />
            <span className="text-[10px] font-semibold tracking-[0.2em] uppercase text-kyn-green border border-kyn-green/30 rounded-full px-2 py-0.5">
              Prototype
            </span>
          </div>
          <div className="flex items-center gap-3">
            <Link to="/showcase" className="hidden sm:inline text-xs text-kyn-silver hover:text-white">
              Final Showcase
            </Link>
            <Link to="/handoff" className="hidden sm:inline text-xs text-kyn-silver hover:text-white">
              Dev Handoff
            </Link>
            <Link
              to="/design-system"
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-kyn-green text-kyn-black text-xs font-bold"
            >
              System <ArrowRight size={12} />
            </Link>
          </div>
        </div>
      </header>

      <section className="max-w-7xl mx-auto px-5 md:px-8 py-12 md:py-16">
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}>
          <p className="text-kyn-green text-xs font-semibold tracking-[0.3em] uppercase mb-3">
            Phase 11–13 · Interactive Prototype
          </p>
          <h1 className="font-display text-3xl md:text-5xl font-bold leading-tight max-w-3xl">
            Clickable product experience for investors, clients & engineers
          </h1>
          <p className="mt-4 text-kyn-silver max-w-2xl leading-relaxed">
            Full flows for Website, Mobile App and Cloud Console — plus micro-interactions,
            accessibility rules and design QA before developer handoff.
          </p>
        </motion.div>

        {/* Tabs */}
        <div className="mt-10 flex flex-wrap gap-2">
          {tabs.map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              type="button"
              onClick={() => setTab(id)}
              className={cn(
                'inline-flex items-center gap-2 px-4 py-2.5 rounded-full text-xs font-semibold transition-all focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-kyn-green',
                tab === id ? 'bg-kyn-green text-kyn-black' : 'bg-kyn-steel text-kyn-silver hover:text-white'
              )}
            >
              <Icon size={14} /> {label}
            </button>
          ))}
        </div>

        {/* MOBILE FLOW */}
        {tab === 'mobile' && (
          <div className="mt-12 grid lg:grid-cols-[300px_1fr] gap-10 items-start">
            <div className="flex flex-col items-center sticky top-24">
              <AnimatePresence mode="wait">
                <motion.div
                  key={currentMobile?.slug || mobileIdx}
                  initial={{ opacity: 0, x: 12 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -12 }}
                  transition={{ duration: 0.25 }}
                >
                  <PhoneFrame label={currentMobile?.title || 'Screen'}>
                    <MobileUI />
                  </PhoneFrame>
                </motion.div>
              </AnimatePresence>
              <div className="mt-6 flex items-center gap-3">
                <button
                  type="button"
                  aria-label="Previous screen"
                  onClick={() => setMobileIdx((i) => (i - 1 + mobileSteps.length) % mobileSteps.length)}
                  className="w-10 h-10 rounded-full border border-white/15 flex items-center justify-center hover:border-kyn-green/40 focus-visible:outline focus-visible:outline-2 focus-visible:outline-kyn-green"
                >
                  <ArrowLeft size={16} />
                </button>
                <button
                  type="button"
                  onClick={() => setPlaying(!playing)}
                  className={cn(
                    'px-5 py-2.5 rounded-full text-xs font-bold inline-flex items-center gap-2',
                    playing ? 'bg-white/10 text-white' : 'bg-kyn-green text-kyn-black'
                  )}
                >
                  <Play size={14} className={playing ? 'opacity-50' : ''} />
                  {playing ? 'Pause demo' : 'Auto-play flow'}
                </button>
                <button
                  type="button"
                  aria-label="Next screen"
                  onClick={() => setMobileIdx((i) => (i + 1) % mobileSteps.length)}
                  className="w-10 h-10 rounded-full border border-white/15 flex items-center justify-center hover:border-kyn-green/40 focus-visible:outline focus-visible:outline-2 focus-visible:outline-kyn-green"
                >
                  <ArrowRight size={16} />
                </button>
              </div>
              <p className="mt-3 text-[11px] text-kyn-metal">
                {mobileIdx + 1} / {mobileSteps.length}
              </p>
            </div>

            <div>
              <div className="flex items-center justify-between mb-4">
                <h2 className="font-display text-xl font-bold">User journey</h2>
                <Link to="/app" className="text-xs text-kyn-green inline-flex items-center gap-1">
                  Full screen library <ExternalLink size={12} />
                </Link>
              </div>
              <div className="space-y-2 max-h-[640px] overflow-y-auto pr-1">
                {mobileSteps.map((s, i) => (
                  <button
                    key={s.id}
                    type="button"
                    onClick={() => {
                      setMobileIdx(i);
                      setPlaying(false);
                    }}
                    className={cn(
                      'w-full text-left rounded-2xl border p-4 transition-all flex gap-3 items-start focus-visible:outline focus-visible:outline-2 focus-visible:outline-kyn-green',
                      i === mobileIdx
                        ? 'border-kyn-green/40 bg-kyn-green/5'
                        : 'border-white/8 bg-white/[0.02] hover:border-white/20'
                    )}
                  >
                    <span
                      className={cn(
                        'w-7 h-7 rounded-lg flex items-center justify-center text-[11px] font-bold shrink-0',
                        i === mobileIdx ? 'bg-kyn-green text-kyn-black' : 'bg-kyn-steel text-kyn-metal'
                      )}
                    >
                      {i + 1}
                    </span>
                    <div className="min-w-0">
                      <p className="font-semibold text-sm">{s.title}</p>
                      <p className="text-xs text-kyn-metal mt-1 leading-relaxed">{s.description}</p>
                    </div>
                    {i === mobileIdx && <ChevronRight size={16} className="text-kyn-green shrink-0 mt-1" />}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* WEBSITE */}
        {tab === 'website' && (
          <div className="mt-12 grid lg:grid-cols-2 gap-8">
            <div className="space-y-3">
              <h2 className="font-display text-xl font-bold mb-4">Linked website IA</h2>
              {websiteMap.map((w, i) => (
                <button
                  key={w.path}
                  type="button"
                  onClick={() => setWebIdx(i)}
                  className={cn(
                    'w-full text-left rounded-2xl border p-4 flex items-center justify-between gap-3 transition-all',
                    webIdx === i ? 'border-kyn-green/40 bg-kyn-green/5' : 'border-white/8 hover:border-white/20'
                  )}
                >
                  <div>
                    <p className="font-semibold text-sm">{w.title}</p>
                    <p className="text-xs text-kyn-metal mt-1">{w.desc}</p>
                  </div>
                  <ChevronRight size={16} className="text-kyn-metal" />
                </button>
              ))}
            </div>
            <div className="rounded-3xl border border-white/10 overflow-hidden bg-kyn-void poster-shadow min-h-[420px] flex flex-col">
              <div className="flex items-center gap-2 px-4 py-3 border-b border-white/5 bg-kyn-charcoal">
                <span className="w-2.5 h-2.5 rounded-full bg-red-500/70" />
                <span className="w-2.5 h-2.5 rounded-full bg-yellow-500/70" />
                <span className="w-2.5 h-2.5 rounded-full bg-green-500/70" />
                <span className="ml-3 text-[10px] text-kyn-metal flex-1 text-center truncate">
                  kynetik.tn{websiteMap[webIdx].path}
                </span>
              </div>
              <div className="flex-1 p-8 flex flex-col justify-center">
                <p className="text-kyn-green text-xs font-semibold tracking-widest uppercase mb-2">
                  Step {webIdx + 1}
                </p>
                <h3 className="font-display text-3xl font-bold">{websiteMap[webIdx].title}</h3>
                <p className="mt-3 text-kyn-silver">{websiteMap[webIdx].desc}</p>
                <div className="mt-8 flex flex-wrap gap-3">
                  <Link
                    to={websiteMap[webIdx].path}
                    className="inline-flex items-center gap-2 px-5 py-3 rounded-full bg-kyn-green text-kyn-black text-sm font-bold"
                  >
                    Open live page <ExternalLink size={14} />
                  </Link>
                  {webIdx < websiteMap.length - 1 && (
                    <button
                      type="button"
                      onClick={() => setWebIdx(webIdx + 1)}
                      className="inline-flex items-center gap-2 px-5 py-3 rounded-full border border-white/15 text-sm font-medium"
                    >
                      Next link <ArrowRight size={14} />
                    </button>
                  )}
                </div>
                <div className="mt-10 flex flex-wrap gap-2">
                  {['Homepage→Products', 'Product→Quote', 'Home→Cloud', 'Home→Academy', 'Home→Contact'].map((f) => (
                    <span key={f} className="text-[10px] px-2.5 py-1 rounded-full border border-white/10 text-kyn-metal">
                      {f}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* CLOUD */}
        {tab === 'cloud' && (
          <div className="mt-12 grid lg:grid-cols-2 gap-8">
            <div className="space-y-3">
              <h2 className="font-display text-xl font-bold mb-4">Operator console flow</h2>
              {cloudMap.map((c, i) => (
                <button
                  key={c.title}
                  type="button"
                  onClick={() => setCloudIdx(i)}
                  className={cn(
                    'w-full text-left rounded-2xl border p-4 transition-all',
                    cloudIdx === i ? 'border-kyn-green/40 bg-kyn-green/5' : 'border-white/8 hover:border-white/20'
                  )}
                >
                  <div className="flex items-center gap-3">
                    <span className="w-7 h-7 rounded-lg bg-kyn-steel text-[11px] font-bold flex items-center justify-center">
                      {i + 1}
                    </span>
                    <div>
                      <p className="font-semibold text-sm">{c.title}</p>
                      <p className="text-xs text-kyn-metal mt-0.5">{c.desc}</p>
                    </div>
                  </div>
                </button>
              ))}
            </div>
            <div className="rounded-3xl border border-white/10 bg-gradient-to-b from-kyn-charcoal to-kyn-black p-8 flex flex-col justify-center min-h-[420px]">
              <Cloud className="text-kyn-green mb-4" size={28} />
              <h3 className="font-display text-3xl font-bold">{cloudMap[cloudIdx].title}</h3>
              <p className="mt-3 text-kyn-silver">{cloudMap[cloudIdx].desc}</p>
              <ul className="mt-6 space-y-2 text-sm text-kyn-metal">
                <li className="flex gap-2"><CheckCircle2 size={14} className="text-kyn-green mt-0.5" /> Live metrics & station health</li>
                <li className="flex gap-2"><CheckCircle2 size={14} className="text-kyn-green mt-0.5" /> Session table + remote actions</li>
                <li className="flex gap-2"><CheckCircle2 size={14} className="text-kyn-green mt-0.5" /> Alerts, reports, RBAC settings</li>
              </ul>
              <Link
                to="/console"
                className="mt-8 inline-flex items-center gap-2 self-start px-6 py-3 rounded-full bg-kyn-green text-kyn-black text-sm font-bold"
              >
                Launch Cloud Dashboard <ArrowRight size={14} />
              </Link>
            </div>
          </div>
        )}

        {/* MICRO */}
        {tab === 'micro' && (
          <div className="mt-12">
            <h2 className="font-display text-xl font-bold mb-2">Micro-interactions kit</h2>
            <p className="text-sm text-kyn-metal mb-8 max-w-xl">
              Hover, loading, success, error, skeleton, toast — the polish layer that sells enterprise craft.
            </p>
            <MicroInteractions />
          </div>
        )}

        {/* A11Y */}
        {tab === 'a11y' && (
          <div className="mt-12 grid lg:grid-cols-2 gap-8">
            <div>
              <h2 className="font-display text-xl font-bold mb-4">Accessibility checklist</h2>
              <ul className="space-y-3">
                {a11yChecks.map((c) => (
                  <li key={c} className="flex gap-3 text-sm text-kyn-silver rounded-xl border border-white/8 p-3">
                    <CheckCircle2 size={16} className="text-kyn-green shrink-0 mt-0.5" />
                    {c}
                  </li>
                ))}
              </ul>
            </div>
            <div className="space-y-4">
              <div className="rounded-2xl border border-white/10 p-6">
                <p className="text-xs text-kyn-metal uppercase tracking-wider mb-4">Responsive breakpoints</p>
                <div className="grid grid-cols-2 gap-3">
                  {[
                    { icon: Monitor, l: 'Desktop', v: '1280+' },
                    { icon: Monitor, l: 'Laptop', v: '1024' },
                    { icon: Tablet, l: 'Tablet', v: '768' },
                    { icon: Smartphone, l: 'Mobile', v: '375' },
                  ].map(({ icon: Icon, l, v }) => (
                    <div key={l} className="rounded-xl bg-white/[0.03] border border-white/8 p-4">
                      <Icon size={16} className="text-kyn-green mb-2" />
                      <p className="font-semibold text-sm">{l}</p>
                      <p className="text-xs text-kyn-metal font-mono mt-0.5">{v}px</p>
                    </div>
                  ))}
                </div>
              </div>
              <div className="rounded-2xl border border-white/10 p-6">
                <p className="text-xs text-kyn-metal uppercase tracking-wider mb-3">Focus demo</p>
                <div className="flex flex-wrap gap-2">
                  <button type="button" className="px-4 py-2 rounded-full bg-kyn-green text-kyn-black text-xs font-bold focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white">
                    Tab here
                  </button>
                  <button type="button" className="px-4 py-2 rounded-full border border-white/15 text-xs font-medium focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-kyn-green">
                    Then here
                  </button>
                  <a href="#top" className="px-4 py-2 rounded-full border border-white/15 text-xs font-medium focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-kyn-green">
                    Link focus
                  </a>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* QA */}
        {tab === 'qa' && (
          <div className="mt-12">
            <h2 className="font-display text-xl font-bold mb-6">Design QA before handoff</h2>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {qaChecks.map((q) => (
                <div key={q.g} className="rounded-2xl border border-white/8 bg-white/[0.02] p-5">
                  <div className="flex items-center gap-2 text-kyn-green mb-2">
                    <CheckCircle2 size={16} />
                    <span className="text-xs font-semibold uppercase tracking-wider">{q.g}</span>
                  </div>
                  <p className="text-sm text-kyn-silver leading-relaxed">{q.i}</p>
                </div>
              ))}
            </div>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link to="/handoff" className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-kyn-green text-kyn-black text-sm font-bold">
                Open Developer Handoff <ArrowRight size={14} />
              </Link>
              <Link to="/showcase" className="inline-flex items-center gap-2 px-6 py-3 rounded-full border border-white/15 text-sm font-medium">
                Final Showcase
              </Link>
            </div>
          </div>
        )}
      </section>
    </div>
  );
}

import { useCallback, useEffect, useMemo, useState, type ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Activity, ArrowRight, Bolt, Cable, CheckCircle2, ChevronRight, Circle,
  Command, Cpu, Database, Gauge, KeyRound, Loader2, Menu, Plus, Power,
  Radio, RefreshCw, Server, Shield, Terminal, Unlock, Wifi, WifiOff,
  X, Zap, FileWarning, ScrollText, Users, CreditCard, BarChart3,
  RotateCcw, Settings2, HardDrive, Clock, Play, Square
} from 'lucide-react';
import BrandLogo from '../components/BrandLogo';
import LoadingState from '../components/LoadingState';
import { cn } from '../lib/utils';
import ocppClient, {
  type OcppStation,
  type OcppTransaction,
  type OcppConnector,
} from '../lib/ocppClient';

type Tab = 'stations' | 'transactions' | 'energy' | 'rfid' | 'commands' | 'events' | 'audit' | 'docs';

const TABS: { id: Tab; label: string; icon: typeof Server }[] = [
  { id: 'stations', label: 'Stations', icon: Server },
  { id: 'transactions', label: 'Transactions', icon: Bolt },
  { id: 'energy', label: 'Energy', icon: BarChart3 },
  { id: 'rfid', label: 'RFID / Users', icon: CreditCard },
  { id: 'commands', label: 'Commands', icon: Command },
  { id: 'events', label: 'OCPP Events', icon: Radio },
  { id: 'audit', label: 'Audit', icon: Shield },
  { id: 'docs', label: 'Protocol', icon: ScrollText },
];

function statusColor(s?: string) {
  const v = (s || '').toLowerCase();
  if (v.includes('charg')) return 'text-emerald-400 bg-emerald-400/10 border-emerald-400/25';
  if (v.includes('online') || v.includes('available') || v.includes('accepted') || v.includes('completed'))
    return 'text-sky-300 bg-sky-400/10 border-sky-400/25';
  if (v.includes('fault') || v.includes('block') || v.includes('fail'))
    return 'text-rose-300 bg-rose-400/10 border-rose-400/25';
  if (v.includes('off') || v.includes('unavail')) return 'text-slate-400 bg-white/5 border-white/10';
  return 'text-amber-300 bg-amber-400/10 border-amber-400/25';
}

function Pill({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <span className={cn('inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold border', className)}>
      {children}
    </span>
  );
}

function Card({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <div className={cn('rounded-2xl border border-white/10 bg-gradient-to-b from-white/[0.04] to-transparent', className)}>
      {children}
    </div>
  );
}

export default function OcppCsmsConsole() {
  const [tab, setTab] = useState<Tab>('stations');
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [toast, setToast] = useState('');
  const [menuOpen, setMenuOpen] = useState(false);
  const [health, setHealth] = useState<{ stations: number; online: number; protocol: string; websocket: string } | null>(null);
  const [stations, setStations] = useState<OcppStation[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [detail, setDetail] = useState<(OcppStation & { connectors?: OcppConnector[] }) | null>(null);
  const [txs, setTxs] = useState<OcppTransaction[]>([]);
  const [energy, setEnergy] = useState<Awaited<ReturnType<typeof ocppClient.energyReport>> | null>(null);
  const [tags, setTags] = useState<Awaited<ReturnType<typeof ocppClient.listIdTags>>>([]);
  const [users, setUsers] = useState<unknown[]>([]);
  const [commands, setCommands] = useState<unknown[]>([]);
  const [events, setEvents] = useState<unknown[]>([]);
  const [audit, setAudit] = useState<unknown[]>([]);
  const [idTagInput, setIdTagInput] = useState('RFID-1001');
  const [showRegister, setShowRegister] = useState(false);
  const [regForm, setRegForm] = useState({ charge_point_id: '', model: 'NOVA', site_name: '', city: 'Tunis', auth_key: '' });

  const notify = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(''), 3200);
  };

  const refreshCore = useCallback(async () => {
    setError('');
    try {
      const [h, st] = await Promise.all([ocppClient.health(), ocppClient.listStations()]);
      setHealth(h);
      setStations(st);
      if (!selectedId && st[0]) setSelectedId(st[0].charge_point_id);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to load OCPP data');
    } finally {
      setLoading(false);
    }
  }, [selectedId]);

  useEffect(() => {
    refreshCore();
    const t = setInterval(refreshCore, 15000);
    return () => clearInterval(t);
  }, [refreshCore]);

  useEffect(() => {
    if (!selectedId) return;
    ocppClient.getStation(selectedId).then(setDetail).catch(console.error);
  }, [selectedId, stations]);

  useEffect(() => {
    (async () => {
      try {
        if (tab === 'transactions') setTxs(await ocppClient.listTransactions({ limit: 100 }));
        if (tab === 'energy') setEnergy(await ocppClient.energyReport());
        if (tab === 'rfid') {
          setTags(await ocppClient.listIdTags());
          setUsers(await ocppClient.listUsers());
        }
        if (tab === 'commands') setCommands(await ocppClient.listCommands(selectedId || undefined));
        if (tab === 'events') setEvents(await ocppClient.listEvents(selectedId || undefined, 80));
        if (tab === 'audit') setAudit(await ocppClient.listAudit(80));
      } catch (e) {
        console.error(e);
      }
    })();
  }, [tab, selectedId, stations]);

  const run = async (action: string, payload: Record<string, unknown> = {}) => {
    if (!selectedId) return;
    setBusy(true);
    setError('');
    try {
      const res = await ocppClient.command(selectedId, action, payload);
      notify(`${action} · ${String((res.result as { status?: string })?.status || res.status)}`);
      await refreshCore();
      if (tab === 'commands') setCommands(await ocppClient.listCommands(selectedId));
      if (tab === 'transactions') setTxs(await ocppClient.listTransactions({ limit: 100 }));
      setDetail(await ocppClient.getStation(selectedId));
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Command failed');
    } finally {
      setBusy(false);
    }
  };

  const register = async () => {
    if (!regForm.charge_point_id.trim()) return;
    setBusy(true);
    try {
      await ocppClient.registerStation({
        ...regForm,
        connectors: [1],
      });
      notify(`Registered ${regForm.charge_point_id}`);
      setShowRegister(false);
      setRegForm({ charge_point_id: '', model: 'NOVA', site_name: '', city: 'Tunis', auth_key: '' });
      await refreshCore();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Register failed');
    } finally {
      setBusy(false);
    }
  };

  const activeTx = useMemo(
    () => detail?.connectors?.find((c) => c.current_transaction_id)?.current_transaction_id,
    [detail]
  );

  const kpis = useMemo(() => {
    const online = stations.filter((s) => s.connected || s.status === 'online' || s.status === 'charging').length;
    const charging = stations.filter((s) => (s.status || '').toLowerCase().includes('charg')).length;
    const offline = stations.length - online;
    return [
      { label: 'Stations', value: stations.length, icon: Server, accent: 'text-sky-300' },
      { label: 'Online', value: online, icon: Wifi, accent: 'text-emerald-400' },
      { label: 'Charging', value: charging, icon: Zap, accent: 'text-kyn-green' },
      { label: 'Offline', value: offline, icon: WifiOff, accent: 'text-slate-400' },
    ];
  }, [stations]);

  if (loading) {
    return (
      <div className="min-h-screen bg-[#05070c] flex items-center justify-center">
        <LoadingState label="Loading OCPP CSMS…" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#05070c] text-slate-100">
      <header className="sticky top-0 z-50 border-b border-white/[0.06] bg-[#05070c]/90 backdrop-blur-xl">
        <div className="max-w-[1440px] mx-auto px-4 md:px-6 h-14 md:h-16 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <BrandLogo height={28} />
            <div className="hidden sm:block h-5 w-px bg-white/10" />
            <div className="hidden sm:flex items-center gap-2 min-w-0">
              <Cpu size={14} className="text-emerald-400 shrink-0" />
              <span className="text-xs font-medium text-slate-300 truncate">OCPP 1.6J CSMS</span>
              <Pill className="text-emerald-300 bg-emerald-400/10 border-emerald-400/25">JSON · WS</Pill>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => refreshCore()}
              className="p-2 rounded-lg border border-white/10 hover:bg-white/5 text-slate-400"
              title="Refresh"
            >
              <RefreshCw size={14} className={busy ? 'animate-spin' : ''} />
            </button>
            <Link
              to="/console"
              className="hidden md:inline-flex items-center gap-1.5 text-xs text-slate-400 hover:text-white px-3 py-2"
            >
              Cloud Console <ArrowRight size={12} />
            </Link>
            <button type="button" className="md:hidden p-2" onClick={() => setMenuOpen((v) => !v)}>
              {menuOpen ? <X size={18} /> : <Menu size={18} />}
            </button>
          </div>
        </div>
        {menuOpen && (
          <div className="md:hidden border-t border-white/5 px-4 py-3 flex flex-wrap gap-2">
            {TABS.map((t) => (
              <button
                key={t.id}
                type="button"
                onClick={() => {
                  setTab(t.id);
                  setMenuOpen(false);
                }}
                className={cn(
                  'px-3 py-1.5 rounded-full text-xs border',
                  tab === t.id ? 'bg-emerald-400 text-black border-emerald-400' : 'border-white/10 text-slate-400'
                )}
              >
                {t.label}
              </button>
            ))}
          </div>
        )}
      </header>

      <div className="max-w-[1440px] mx-auto px-4 md:px-6 py-6 md:py-8">
        {/* Hero */}
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 mb-8">
          <div>
            <p className="text-emerald-400 text-[11px] font-semibold tracking-[0.28em] uppercase mb-2">
              KYNETIK Cloud · Phase 28
            </p>
            <h1 className="font-display text-3xl md:text-4xl font-bold tracking-tight">
              OCPP Central System
            </h1>
            <p className="mt-2 text-sm text-slate-400 max-w-2xl leading-relaxed">
              Production CSMS package at <code className="text-emerald-300/90">ocpp-csms/</code> — WebSocket OCPP 1.6J,
              REST for Dashboard & Mobile, JWT/RBAC, audit trail. This console operates the shared data plane.
            </p>
            {health && (
              <p className="mt-3 text-[11px] text-slate-500 font-mono">
                WS path: {health.websocket} · {health.protocol}
              </p>
            )}
          </div>
          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={() => setShowRegister(true)}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-full bg-emerald-400 text-black text-xs font-bold"
            >
              <Plus size={14} /> Register charger
            </button>
            <Link
              to="/engineering-pack"
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-full border border-white/15 text-xs font-semibold"
            >
              Eng Pack
            </Link>
          </div>
        </div>

        {/* KPIs */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-6">
          {kpis.map((k) => (
            <Card key={k.label} className="p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-[11px] text-slate-500 uppercase tracking-wider">{k.label}</span>
                <k.icon size={14} className={k.accent} />
              </div>
              <p className={cn('font-display text-2xl font-bold', k.accent)}>{k.value}</p>
            </Card>
          ))}
        </div>

        {error && (
          <div className="mb-4 rounded-xl border border-rose-500/30 bg-rose-500/10 px-4 py-3 text-sm text-rose-200 flex items-start gap-2">
            <FileWarning size={16} className="mt-0.5 shrink-0" />
            <span className="break-all">{error}</span>
          </div>
        )}

        <div className="flex flex-col xl:flex-row gap-6">
          {/* Tabs + main */}
          <div className="flex-1 min-w-0">
            <div className="hidden md:flex flex-wrap gap-1.5 mb-4">
              {TABS.map((t) => (
                <button
                  key={t.id}
                  type="button"
                  onClick={() => setTab(t.id)}
                  className={cn(
                    'inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold border transition-colors',
                    tab === t.id
                      ? 'bg-white text-black border-white'
                      : 'border-white/10 text-slate-400 hover:border-white/20 hover:text-white'
                  )}
                >
                  <t.icon size={13} />
                  {t.label}
                </button>
              ))}
            </div>

            <AnimatePresence mode="wait">
              <motion.div
                key={tab}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
                transition={{ duration: 0.2 }}
              >
                {tab === 'stations' && (
                  <div className="grid lg:grid-cols-5 gap-4">
                    <Card className="lg:col-span-2 overflow-hidden">
                      <div className="px-4 py-3 border-b border-white/5 flex items-center justify-between">
                        <span className="text-xs font-semibold text-slate-300">Charge points</span>
                        <span className="text-[10px] text-slate-500">{stations.length} total</span>
                      </div>
                      <div className="max-h-[520px] overflow-y-auto divide-y divide-white/5">
                        {stations.map((s) => (
                          <button
                            key={s.charge_point_id}
                            type="button"
                            onClick={() => setSelectedId(s.charge_point_id)}
                            className={cn(
                              'w-full text-left px-4 py-3 hover:bg-white/[0.03] transition-colors',
                              selectedId === s.charge_point_id && 'bg-emerald-400/5'
                            )}
                          >
                            <div className="flex items-center justify-between gap-2">
                              <span className="font-mono text-xs font-semibold text-white">{s.charge_point_id}</span>
                              <Pill className={statusColor(s.status)}>{s.status || '—'}</Pill>
                            </div>
                            <p className="mt-1 text-[11px] text-slate-500">
                              {s.model} · {s.site_name || s.city || '—'}
                            </p>
                            <div className="mt-1.5 flex items-center gap-2 text-[10px] text-slate-600">
                              {s.connected ? (
                                <span className="inline-flex items-center gap-1 text-emerald-400/80">
                                  <Circle size={6} className="fill-current" /> live
                                </span>
                              ) : (
                                <span className="inline-flex items-center gap-1">
                                  <Circle size={6} /> stored
                                </span>
                              )}
                              <span>fw {s.firmware_version || '—'}</span>
                            </div>
                          </button>
                        ))}
                        {!stations.length && (
                          <p className="p-6 text-sm text-slate-500 text-center">No stations yet. Register one.</p>
                        )}
                      </div>
                    </Card>

                    <Card className="lg:col-span-3 p-5">
                      {detail ? (
                        <>
                          <div className="flex flex-wrap items-start justify-between gap-3 mb-5">
                            <div>
                              <h2 className="font-display text-xl font-bold font-mono">{detail.charge_point_id}</h2>
                              <p className="text-sm text-slate-400 mt-1">
                                {detail.vendor} {detail.model} · {detail.site_name} · {detail.city}
                              </p>
                            </div>
                            <Pill className={statusColor(detail.status)}>{detail.status}</Pill>
                          </div>

                          <div className="grid sm:grid-cols-3 gap-3 mb-5">
                            {[
                              ['Protocol', detail.protocol || 'ocpp1.6'],
                              ['Serial', detail.serial_number || '—'],
                              ['Heartbeat', detail.last_heartbeat ? new Date(detail.last_heartbeat).toLocaleString() : '—'],
                              ['Last boot', detail.last_boot ? new Date(detail.last_boot).toLocaleString() : '—'],
                              ['Interval', `${detail.heartbeat_interval || 60}s`],
                              ['Registration', detail.registration_status || '—'],
                            ].map(([l, v]) => (
                              <div key={l} className="rounded-xl bg-white/[0.03] border border-white/5 px-3 py-2">
                                <p className="text-[10px] text-slate-500 uppercase tracking-wider">{l}</p>
                                <p className="text-xs font-medium mt-0.5 truncate">{v}</p>
                              </div>
                            ))}
                          </div>

                          <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">Connectors</h3>
                          <div className="grid sm:grid-cols-2 gap-2 mb-5">
                            {(detail.connectors || []).map((c) => (
                              <div key={c.connector_id} className="rounded-xl border border-white/10 p-3 flex items-center gap-3">
                                <div className="w-9 h-9 rounded-lg bg-emerald-400/10 border border-emerald-400/20 flex items-center justify-center text-emerald-400">
                                  <Cable size={16} />
                                </div>
                                <div className="min-w-0 flex-1">
                                  <div className="flex items-center justify-between gap-2">
                                    <span className="text-xs font-semibold">Connector {c.connector_id}</span>
                                    <Pill className={statusColor(c.status)}>{c.status}</Pill>
                                  </div>
                                  <p className="text-[11px] text-slate-500 mt-0.5">
                                    {c.power_kw || 0} kW · {c.availability || '—'}
                                    {c.current_transaction_id ? ` · tx #${c.current_transaction_id}` : ''}
                                  </p>
                                </div>
                              </div>
                            ))}
                            {!detail.connectors?.length && (
                              <p className="text-xs text-slate-500 col-span-2">No connectors recorded yet.</p>
                            )}
                          </div>

                          <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
                            Remote commands
                          </h3>
                          <div className="flex flex-wrap gap-2">
                            <CmdBtn busy={busy} icon={Play} label="Remote Start" onClick={() => run('RemoteStartTransaction', { connectorId: 1, idTag: idTagInput })} />
                            <CmdBtn busy={busy} icon={Square} label="Remote Stop" onClick={() => run('RemoteStopTransaction', { transactionId: activeTx || txs.find((t) => t.charge_point_id === selectedId && t.status === 'active')?.transaction_id })} />
                            <CmdBtn busy={busy} icon={RotateCcw} label="Reset Soft" onClick={() => run('Reset', { type: 'Soft' })} />
                            <CmdBtn busy={busy} icon={Unlock} label="Unlock" onClick={() => run('UnlockConnector', { connectorId: 1 })} />
                            <CmdBtn busy={busy} icon={Settings2} label="Get Config" onClick={() => run('GetConfiguration', { key: [] })} />
                            <CmdBtn busy={busy} icon={Settings2} label="Set Heartbeat 60" onClick={() => run('ChangeConfiguration', { key: 'HeartbeatInterval', value: '60' })} />
                            <CmdBtn busy={busy} icon={Power} label="Inoperative" onClick={() => run('ChangeAvailability', { connectorId: 1, type: 'Inoperative' })} />
                            <CmdBtn busy={busy} icon={Power} label="Operative" onClick={() => run('ChangeAvailability', { connectorId: 1, type: 'Operative' })} />
                            <CmdBtn busy={busy} icon={Clock} label="Reserve" onClick={() => run('ReserveNow', { connectorId: 1, idTag: idTagInput, expiryDate: new Date(Date.now() + 3600000).toISOString() })} />
                            <CmdBtn busy={busy} icon={Gauge} label="Smart Profile" onClick={() => run('SetChargingProfile', { connectorId: 0, csChargingProfiles: { chargingProfileId: 1, stackLevel: 0, chargingProfilePurpose: 'TxDefaultProfile', chargingProfileKind: 'Absolute', chargingSchedule: { chargingRateUnit: 'A', chargingSchedulePeriod: [{ startPeriod: 0, limit: 16 }] } } })} />
                            <CmdBtn busy={busy} icon={HardDrive} label="Firmware" onClick={() => run('UpdateFirmware', { location: 'https://fw.kynetik.tn/nova-2.5.0.bin', retrieveDate: new Date().toISOString() })} />
                            <CmdBtn busy={busy} icon={Terminal} label="Trigger Boot" onClick={() => run('TriggerMessage', { requestedMessage: 'BootNotification' })} />
                            <CmdBtn busy={busy} icon={Radio} label="DataTransfer" onClick={() => run('DataTransfer', { vendorId: 'KYNETIK', messageId: 'ping', data: 'hello' })} />
                          </div>

                          <div className="mt-4 flex items-center gap-2">
                            <KeyRound size={14} className="text-slate-500" />
                            <input
                              value={idTagInput}
                              onChange={(e) => setIdTagInput(e.target.value)}
                              className="flex-1 bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-xs font-mono outline-none focus:border-emerald-400/40"
                              placeholder="idTag for Authorize / RemoteStart"
                            />
                          </div>
                        </>
                      ) : (
                        <p className="text-sm text-slate-500">Select a station</p>
                      )}
                    </Card>
                  </div>
                )}

                {tab === 'transactions' && (
                  <Card className="overflow-hidden">
                    <div className="px-4 py-3 border-b border-white/5 text-xs font-semibold">Transaction history</div>
                    <div className="overflow-x-auto">
                      <table className="w-full text-left text-xs">
                        <thead className="text-slate-500 border-b border-white/5">
                          <tr>
                            <th className="px-4 py-2 font-medium">Tx ID</th>
                            <th className="px-4 py-2 font-medium">Station</th>
                            <th className="px-4 py-2 font-medium">Tag</th>
                            <th className="px-4 py-2 font-medium">Status</th>
                            <th className="px-4 py-2 font-medium">Energy</th>
                            <th className="px-4 py-2 font-medium">Cost</th>
                            <th className="px-4 py-2 font-medium">Started</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-white/5">
                          {txs.map((t) => (
                            <tr key={t.transaction_id} className="hover:bg-white/[0.02]">
                              <td className="px-4 py-2.5 font-mono">{t.transaction_id}</td>
                              <td className="px-4 py-2.5 font-mono text-slate-300">{t.charge_point_id}</td>
                              <td className="px-4 py-2.5">{t.id_tag}</td>
                              <td className="px-4 py-2.5"><Pill className={statusColor(t.status)}>{t.status}</Pill></td>
                              <td className="px-4 py-2.5">{t.energy_kwh ?? '—'} kWh</td>
                              <td className="px-4 py-2.5">{t.cost != null ? `${t.cost} ${t.currency || 'TND'}` : '—'}</td>
                              <td className="px-4 py-2.5 text-slate-500">{t.start_timestamp ? new Date(t.start_timestamp).toLocaleString() : '—'}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                      {!txs.length && <p className="p-8 text-center text-slate-500 text-sm">No transactions</p>}
                    </div>
                  </Card>
                )}

                {tab === 'energy' && energy && (
                  <div className="grid md:grid-cols-3 gap-4">
                    <Card className="p-5">
                      <p className="text-[11px] text-slate-500 uppercase tracking-wider">Total energy</p>
                      <p className="font-display text-3xl font-bold text-emerald-400 mt-1">{energy.total_kwh} kWh</p>
                    </Card>
                    <Card className="p-5">
                      <p className="text-[11px] text-slate-500 uppercase tracking-wider">Sessions</p>
                      <p className="font-display text-3xl font-bold text-sky-300 mt-1">{energy.total_sessions}</p>
                    </Card>
                    <Card className="p-5">
                      <p className="text-[11px] text-slate-500 uppercase tracking-wider">Cost</p>
                      <p className="font-display text-3xl font-bold text-white mt-1">{energy.total_cost} {energy.currency}</p>
                    </Card>
                    <Card className="md:col-span-3 overflow-hidden">
                      <div className="px-4 py-3 border-b border-white/5 text-xs font-semibold">By station</div>
                      <div className="divide-y divide-white/5">
                        {energy.by_station.map((r) => (
                          <div key={r.charge_point_id} className="px-4 py-3 flex items-center justify-between text-xs gap-3">
                            <span className="font-mono font-semibold">{r.charge_point_id}</span>
                            <span className="text-slate-400">{r.sessions} sessions</span>
                            <span className="text-emerald-400">{r.energy_kwh.toFixed(2)} kWh</span>
                            <span>{r.cost.toFixed(2)} TND</span>
                          </div>
                        ))}
                        {!energy.by_station.length && <p className="p-6 text-slate-500 text-sm text-center">No energy data</p>}
                      </div>
                    </Card>
                  </div>
                )}

                {tab === 'rfid' && (
                  <div className="grid md:grid-cols-2 gap-4">
                    <Card className="overflow-hidden">
                      <div className="px-4 py-3 border-b border-white/5 text-xs font-semibold flex items-center gap-2">
                        <CreditCard size={14} /> RFID / idTags
                      </div>
                      <div className="divide-y divide-white/5 max-h-[420px] overflow-y-auto">
                        {tags.map((t) => (
                          <div key={t.id_tag} className="px-4 py-3 flex items-center justify-between gap-2 text-xs">
                            <div>
                              <p className="font-mono font-semibold">{t.id_tag}</p>
                              <p className="text-slate-500 mt-0.5">{t.label || t.user_id || '—'}</p>
                            </div>
                            <Pill className={statusColor(t.status)}>{t.status}</Pill>
                          </div>
                        ))}
                      </div>
                    </Card>
                    <Card className="overflow-hidden">
                      <div className="px-4 py-3 border-b border-white/5 text-xs font-semibold flex items-center gap-2">
                        <Users size={14} /> Users
                      </div>
                      <div className="divide-y divide-white/5 max-h-[420px] overflow-y-auto">
                        {(users as { user_id: string; email: string; role: string; full_name?: string; status?: string }[]).map((u) => (
                          <div key={u.user_id} className="px-4 py-3 text-xs">
                            <div className="flex items-center justify-between gap-2">
                              <p className="font-semibold">{u.full_name || u.email}</p>
                              <Pill className={statusColor(u.role)}>{u.role}</Pill>
                            </div>
                            <p className="text-slate-500 mt-0.5 font-mono">{u.email}</p>
                          </div>
                        ))}
                      </div>
                    </Card>
                  </div>
                )}

                {tab === 'commands' && <JsonList title="Pending / completed commands" rows={commands as Record<string, unknown>[]} fields={['command_id', 'charge_point_id', 'action', 'status', 'created_at']} />}
                {tab === 'events' && <JsonList title="OCPP event log" rows={events as Record<string, unknown>[]} fields={['created_at', 'direction', 'action', 'charge_point_id', 'message_type']} />}
                {tab === 'audit' && <JsonList title="Security audit log" rows={audit as Record<string, unknown>[]} fields={['created_at', 'actor', 'action', 'resource_id']} />}

                {tab === 'docs' && (
                  <div className="grid md:grid-cols-2 gap-4">
                    <Card className="p-5 space-y-3">
                      <h3 className="font-display text-lg font-bold flex items-center gap-2">
                        <Database size={18} className="text-emerald-400" /> Package layout
                      </h3>
                      <pre className="text-[11px] leading-relaxed text-slate-400 font-mono bg-black/40 rounded-xl p-4 overflow-x-auto border border-white/5">{`ocpp-csms/
  src/server/          bootstrap HTTP+WS
  src/websocket/       OCPP 1.6J JSON server
  src/rest/            Express routes
  src/controllers/     REST controllers
  src/services/        handlers, commands
  src/repositories/    stations, tx, meters…
  src/auth/            JWT + RBAC
  src/database/        Supabase client
  scripts/             CP simulator`}</pre>
                      <p className="text-xs text-slate-500">
                        Start CSMS: <code className="text-emerald-300">npm run ocpp</code> · Simulator:{' '}
                        <code className="text-emerald-300">npm run ocpp:sim</code>
                      </p>
                    </Card>
                    <Card className="p-5 space-y-3">
                      <h3 className="font-display text-lg font-bold flex items-center gap-2">
                        <Activity size={18} className="text-sky-400" /> Supported operations
                      </h3>
                      <div className="grid grid-cols-1 gap-2 text-[11px]">
                        <DocLine title="CP → CSMS" body="BootNotification, Heartbeat, StatusNotification, MeterValues, Authorize, Start/StopTransaction, DataTransfer, Firmware/Diagnostics status" />
                        <DocLine title="CSMS → CP" body="RemoteStart/Stop, Reset, UnlockConnector, Change/GetConfiguration, ChangeAvailability, DataTransfer, UpdateFirmware, GetDiagnostics, Reserve/Cancel, Set/ClearChargingProfile, GetCompositeSchedule, TriggerMessage" />
                        <DocLine title="Security" body="JWT Bearer, X-API-Key, RBAC roles, CP auth_key, audit + event logs, TLS at edge (WSS/HTTPS)" />
                        <DocLine title="Scale" body="Sticky WS sessions, multi-node ready, 5k stations/node default, Postgres meter ingest, command queue table" />
                      </div>
                      <Link to="/engineering-pack" className="inline-flex items-center gap-1 text-xs text-emerald-400 font-semibold">
                        Open Engineering Pack <ChevronRight size={14} />
                      </Link>
                    </Card>
                  </div>
                )}
              </motion.div>
            </AnimatePresence>
          </div>
        </div>
      </div>

      {/* Register modal */}
      <AnimatePresence>
        {showRegister && (
          <motion.div
            className="fixed inset-0 z-[80] flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <motion.div
              initial={{ scale: 0.96, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.96, opacity: 0 }}
              className="w-full max-w-md rounded-2xl border border-white/10 bg-[#0b0e14] p-5 shadow-2xl"
            >
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-display font-bold">Register charge point</h3>
                <button type="button" onClick={() => setShowRegister(false)} className="p-1 text-slate-400">
                  <X size={16} />
                </button>
              </div>
              <div className="space-y-3">
                {(
                  [
                    ['charge_point_id', 'Charge Point ID'],
                    ['model', 'Model'],
                    ['site_name', 'Site name'],
                    ['city', 'City'],
                    ['auth_key', 'Auth key (optional)'],
                  ] as const
                ).map(([k, label]) => (
                  <label key={k} className="block">
                    <span className="text-[10px] uppercase tracking-wider text-slate-500">{label}</span>
                    <input
                      value={regForm[k]}
                      onChange={(e) => setRegForm((f) => ({ ...f, [k]: e.target.value }))}
                      className="mt-1 w-full rounded-lg bg-white/5 border border-white/10 px-3 py-2 text-sm outline-none focus:border-emerald-400/40 font-mono"
                    />
                  </label>
                ))}
              </div>
              <button
                type="button"
                disabled={busy}
                onClick={register}
                className="mt-5 w-full rounded-full bg-emerald-400 text-black text-sm font-bold py-2.5 disabled:opacity-50"
              >
                {busy ? 'Saving…' : 'Create station'}
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {toast && (
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 12 }}
            className="fixed bottom-6 left-1/2 -translate-x-1/2 z-[90] px-4 py-2.5 rounded-full bg-emerald-400 text-black text-xs font-bold shadow-lg shadow-emerald-400/20 flex items-center gap-2"
          >
            <CheckCircle2 size={14} /> {toast}
          </motion.div>
        )}
      </AnimatePresence>

      <footer className="border-t border-white/5 mt-12">
        <div className="max-w-[1440px] mx-auto px-4 md:px-6 py-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-[11px] text-slate-500">
          <p>KYNETIK OCPP 1.6J CSMS · Dashboard integration layer + Node WebSocket server</p>
          <div className="flex gap-3">
            <Link to="/console" className="hover:text-white">Console</Link>
            <Link to="/prd" className="hover:text-white">PRD</Link>
            <Link to="/architecture" className="hover:text-white">Architecture</Link>
          </div>
        </div>
      </footer>
    </div>
  );
}

function CmdBtn({
  label, onClick, busy, icon: Icon,
}: {
  label: string;
  onClick: () => void;
  busy: boolean;
  icon: typeof Play;
}) {
  return (
    <button
      type="button"
      disabled={busy}
      onClick={onClick}
      className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-white/10 bg-white/[0.03] hover:border-emerald-400/30 hover:bg-emerald-400/5 text-[11px] font-semibold disabled:opacity-40 transition-colors"
    >
      {busy ? <Loader2 size={12} className="animate-spin" /> : <Icon size={12} className="text-emerald-400" />}
      {label}
    </button>
  );
}

function JsonList({
  title, rows, fields,
}: {
  title: string;
  rows: Record<string, unknown>[];
  fields: string[];
}) {
  return (
    <Card className="overflow-hidden">
      <div className="px-4 py-3 border-b border-white/5 text-xs font-semibold">{title}</div>
      <div className="overflow-x-auto">
        <table className="w-full text-left text-[11px]">
          <thead className="text-slate-500 border-b border-white/5">
            <tr>
              {fields.map((f) => (
                <th key={f} className="px-3 py-2 font-medium whitespace-nowrap">{f}</th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-white/5">
            {rows.map((r, i) => (
              <tr key={i} className="hover:bg-white/[0.02]">
                {fields.map((f) => (
                  <td key={f} className="px-3 py-2 font-mono text-slate-300 whitespace-nowrap max-w-[220px] truncate">
                    {r[f] == null ? '—' : typeof r[f] === 'object' ? JSON.stringify(r[f]) : String(r[f])}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
        {!rows.length && <p className="p-8 text-center text-slate-500 text-sm">No rows</p>}
      </div>
    </Card>
  );
}

function DocLine({ title, body }: { title: string; body: string }) {
  return (
    <div className="rounded-xl border border-white/10 p-3">
      <p className="text-emerald-300/90 font-semibold mb-1">{title}</p>
      <p className="text-slate-400 leading-relaxed">{body}</p>
    </div>
  );
}

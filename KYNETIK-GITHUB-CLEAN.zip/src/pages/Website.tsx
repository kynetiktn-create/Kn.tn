import { useEffect, useState } from 'react';
import {
  ArrowRight, Cloud, GraduationCap, Zap, Home, Building2, Hotel,
  Landmark, Car, Check, Monitor, Activity, FileBarChart
} from 'lucide-react';
import SectionHeader from '../components/SectionHeader';
import LoadingState from '../components/LoadingState';
import ErrorState from '../components/ErrorState';
import Logo from '../components/Logo';
import { apiGet, cn } from '../lib/utils';

interface Product {
  id: number;
  name: string;
  tagline: string;
  power: string;
  category: string;
  image_url: string;
  accent: string;
}

interface Section {
  id: number;
  page: string;
  title: string;
  subtitle: string;
  body: string;
  cta_primary: string;
  cta_secondary: string;
  section_key: string;
  sort_order: number;
}

export default function Website() {
  const [products, setProducts] = useState<Product[]>([]);
  const [sections, setSections] = useState<Section[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [activeSection, setActiveSection] = useState('hero');

  useEffect(() => {
    Promise.all([
      apiGet<Product[]>('/api/products'),
      apiGet<Section[]>('/api/website-sections?page=home'),
    ])
      .then(([p, s]) => {
        setProducts(p);
        setSections(s);
        if (s[0]) setActiveSection(s[0].section_key);
      })
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <div className="p-10"><LoadingState label="Loading website UX…" /></div>;
  if (error) return <div className="p-10"><ErrorState message={error} /></div>;

  const industries = [
    { icon: Home, label: 'Residential' },
    { icon: Building2, label: 'Companies' },
    { icon: Hotel, label: 'Hotels' },
    { icon: Landmark, label: 'Public sector' },
    { icon: Car, label: 'Fleets' },
  ];

  return (
    <div className="max-w-6xl mx-auto px-6 md:px-10 py-12 md:py-16">
      <SectionHeader
        eyebrow="UI/UX · Website"
        title="Homepage architecture"
        description="Seven-section marketing system — cinematic hero, ecosystem story, products, Cloud, Academy, industries and premium contact CTA."
      />

      {/* IA map */}
      <div className="flex flex-wrap gap-2 mb-8">
        {sections.map((s) => (
          <button
            key={s.id}
            type="button"
            onClick={() => {
              setActiveSection(s.section_key);
              document.getElementById(`ws-${s.section_key}`)?.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }}
            className={cn(
              'px-3 py-1.5 rounded-full text-xs font-semibold',
              activeSection === s.section_key ? 'bg-kyn-green text-kyn-black' : 'bg-kyn-steel text-kyn-silver'
            )}
          >
            {s.sort_order}. {s.title}
          </button>
        ))}
      </div>

      {/* Browser mock full site */}
      <div className="rounded-2xl border border-white/10 overflow-hidden poster-shadow bg-kyn-void">
        <div className="flex items-center gap-2 px-4 py-3 bg-kyn-charcoal border-b border-white/5 sticky top-0 z-30">
          <div className="flex gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-red-500/70" />
            <span className="w-2.5 h-2.5 rounded-full bg-yellow-500/70" />
            <span className="w-2.5 h-2.5 rounded-full bg-green-500/70" />
          </div>
          <div className="flex-1 mx-4 rounded-md bg-kyn-black/60 text-[10px] text-kyn-metal px-3 py-1 text-center">
            www.kynetik.tn
          </div>
        </div>

        {/* Nav */}
        <div className="flex items-center justify-between px-6 md:px-10 py-4 border-b border-white/5 bg-kyn-black/80 backdrop-blur">
          <Logo size="sm" glowing />
          <div className="hidden md:flex items-center gap-6 text-xs text-kyn-silver">
            {['Solutions', 'Produits', 'Cloud', 'Academy', 'Industries'].map((l) => (
              <span key={l} className="hover:text-kyn-green cursor-default">{l}</span>
            ))}
          </div>
          <button type="button" className="px-4 py-2 rounded-full bg-kyn-green text-kyn-black text-[11px] font-bold">
            Contact
          </button>
        </div>

        {/* 1 Hero */}
        <section id="ws-hero" className="relative min-h-[460px] md:min-h-[560px] flex items-center">
          <img src="/images/hero-city.jpg" alt="Hero" className="absolute inset-0 w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-r from-black via-black/85 to-black/25" />
          <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-black/40" />
          <div className="relative z-10 px-8 md:px-14 py-16 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-kyn-green/30 bg-kyn-green/10 text-kyn-green text-[10px] font-semibold mb-6">
              <Zap size={11} /> Tunisie · EV Technology
            </div>
            <h2 className="font-display text-4xl md:text-6xl font-bold leading-[1.05]">
              L'énergie<br /><span className="text-kyn-green text-glow">en mouvement</span>
            </h2>
            <p className="mt-5 text-sm md:text-base text-kyn-silver max-w-md leading-relaxed">
              La solution intelligente de recharge électrique pour la mobilité de demain.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <button type="button" className="px-5 py-3 rounded-full bg-kyn-green text-kyn-black text-xs font-bold inline-flex items-center gap-2 glow-green">
                Découvrir KYNETIK <ArrowRight size={14} />
              </button>
              <button type="button" className="px-5 py-3 rounded-full border border-white/20 text-xs font-medium">
                Installer une borne
              </button>
            </div>
          </div>
        </section>

        {/* 2 Ecosystem */}
        <section id="ws-ecosystem" className="px-8 md:px-14 py-16 border-t border-white/5 bg-kyn-black/40">
          <p className="text-kyn-green text-[10px] tracking-[0.25em] uppercase font-semibold">Écosystème</p>
          <h3 className="font-display text-2xl md:text-3xl font-bold mt-2 max-w-lg">
            Un écosystème complet pour gérer votre énergie
          </h3>
          <div className="mt-10 flex flex-col md:flex-row items-stretch md:items-center gap-3 md:gap-2">
            {['Vehicle', 'KYNETIK Charger', 'KYNETIK Cloud', 'Mobile App'].map((node, i, arr) => (
              <div key={node} className="flex md:flex-1 items-center gap-2">
                <div className="flex-1 rounded-2xl border border-kyn-green/25 bg-gradient-to-b from-kyn-steel to-kyn-void p-5 text-center">
                  <p className="font-display font-semibold text-sm">{node}</p>
                </div>
                {i < arr.length - 1 && (
                  <span className="hidden md:block text-kyn-green font-bold">→</span>
                )}
                {i < arr.length - 1 && (
                  <span className="md:hidden text-kyn-green text-center w-full text-xs">↓</span>
                )}
              </div>
            ))}
          </div>
        </section>

        {/* 3 Products */}
        <section id="ws-products" className="px-8 md:px-14 py-16 border-t border-white/5">
          <p className="text-kyn-green text-[10px] tracking-[0.25em] uppercase font-semibold">Produits</p>
          <h3 className="font-display text-2xl md:text-3xl font-bold mt-2 mb-8">Gamme de bornes</h3>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {products.map((p) => (
              <div key={p.id} className="rounded-2xl border border-white/8 bg-kyn-charcoal overflow-hidden group">
                <div className="h-36 relative">
                  <img src={p.image_url} alt={p.name} className="w-full h-full object-cover opacity-70 group-hover:opacity-95 transition-opacity" />
                  <div className="absolute inset-0 bg-gradient-to-t from-kyn-charcoal to-transparent" />
                </div>
                <div className="p-4 -mt-4 relative">
                  <p className="font-display font-bold text-lg" style={{ color: p.accent }}>{p.name}</p>
                  <p className="text-[10px] text-kyn-metal mt-0.5 uppercase tracking-wider">{p.category}</p>
                  <p className="text-xs text-kyn-silver mt-2 line-clamp-2">{p.tagline}</p>
                  <p className="text-xs font-semibold text-white mt-2">{p.power}</p>
                  <button type="button" className="mt-4 text-[11px] text-kyn-green font-semibold inline-flex items-center gap-1">
                    Voir détails <ArrowRight size={12} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* 4 Cloud */}
        <section id="ws-cloud" className="px-8 md:px-14 py-16 bg-kyn-black/50 border-t border-white/5">
          <div className="grid md:grid-cols-2 gap-10 items-center">
            <div>
              <div className="inline-flex items-center gap-2 text-kyn-green text-xs font-semibold mb-3">
                <Cloud size={14} /> KYNETIK Cloud
              </div>
              <h3 className="font-display text-2xl font-bold">Supervision & energy management</h3>
              <p className="mt-3 text-sm text-kyn-metal leading-relaxed">
                Plateforme OCPP pour monitoring distant, smart charging, reporting et exploitation multi-sites.
              </p>
              <ul className="mt-6 space-y-3">
                {[
                  { icon: Monitor, t: 'Remote monitoring' },
                  { icon: Activity, t: 'OCPP 1.6J / 2.0.1' },
                  { icon: Zap, t: 'Energy management' },
                  { icon: FileBarChart, t: 'Reports & billing' },
                ].map(({ icon: Icon, t }) => (
                  <li key={t} className="flex items-center gap-3 text-sm text-kyn-silver">
                    <span className="w-8 h-8 rounded-lg bg-kyn-green/10 border border-kyn-green/20 flex items-center justify-center">
                      <Icon size={14} className="text-kyn-green" />
                    </span>
                    {t}
                  </li>
                ))}
              </ul>
            </div>
            <div className="rounded-2xl border border-kyn-green/20 overflow-hidden bg-kyn-charcoal">
              <div className="px-4 py-3 border-b border-white/5 flex items-center justify-between">
                <span className="text-xs font-semibold">Cloud Dashboard</span>
                <span className="text-[9px] text-kyn-green">● Live</span>
              </div>
              <div className="p-4 grid grid-cols-2 gap-2">
                {[
                  { l: 'Bornes online', v: '118' },
                  { l: 'Sessions', v: '1 284' },
                  { l: 'Uptime', v: '99.4%' },
                  { l: 'kWh today', v: '8.2k' },
                ].map((m) => (
                  <div key={m.l} className="rounded-xl bg-black/40 border border-white/5 p-3">
                    <p className="text-[9px] text-kyn-metal">{m.l}</p>
                    <p className="font-display font-bold text-lg text-kyn-green">{m.v}</p>
                  </div>
                ))}
              </div>
              <div className="px-4 pb-4">
                <div className="h-20 rounded-xl bg-black/30 border border-white/5 flex items-end gap-1 p-3">
                  {[40, 55, 35, 70, 50, 85, 60, 75, 45, 90, 65, 80].map((h, i) => (
                    <div key={i} className="flex-1 rounded-sm bg-kyn-green/70" style={{ height: `${h}%` }} />
                  ))}
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* 5 Academy */}
        <section id="ws-academy" className="relative px-8 md:px-14 py-16 border-t border-white/5 overflow-hidden">
          <img src="/images/academy.jpg" alt="" className="absolute inset-0 w-full h-full object-cover opacity-25" />
          <div className="absolute inset-0 bg-gradient-to-r from-kyn-void via-kyn-void/90 to-transparent" />
          <div className="relative z-10 max-w-md">
            <div className="inline-flex items-center gap-2 text-kyn-green text-xs font-semibold mb-3">
              <GraduationCap size={14} /> KYNETIK Academy
            </div>
            <h3 className="font-display text-2xl font-bold">Former les experts de la mobilité électrique</h3>
            <p className="mt-3 text-sm text-kyn-metal">
              Parcours certifiants pour installateurs, techniciens et partenaires — présentiel + digital.
            </p>
            <button type="button" className="mt-6 px-5 py-2.5 rounded-full border border-kyn-green/40 text-kyn-green text-xs font-semibold">
              Découvrir l'Academy
            </button>
          </div>
        </section>

        {/* 6 Industries */}
        <section id="ws-industries" className="px-8 md:px-14 py-16 border-t border-white/5">
          <p className="text-kyn-green text-[10px] tracking-[0.25em] uppercase font-semibold">Industries</p>
          <h3 className="font-display text-2xl md:text-3xl font-bold mt-2 mb-8">Solutions par secteur</h3>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
            {industries.map(({ icon: Icon, label }) => (
              <div key={label} className="rounded-2xl border border-white/8 bg-kyn-charcoal p-5 text-center hover:border-kyn-green/30 transition-colors">
                <div className="w-10 h-10 mx-auto rounded-xl bg-kyn-green/10 border border-kyn-green/20 flex items-center justify-center text-kyn-green mb-3">
                  <Icon size={18} />
                </div>
                <p className="text-sm font-semibold">{label}</p>
              </div>
            ))}
          </div>
        </section>

        {/* 7 Contact */}
        <section id="ws-contact" className="px-8 md:px-14 py-16 border-t border-white/5 relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-kyn-green/10 via-transparent to-transparent" />
          <div className="relative z-10 max-w-2xl mx-auto text-center">
            <h3 className="font-display text-2xl md:text-4xl font-bold leading-tight">
              Construisons ensemble la mobilité électrique de demain
            </h3>
            <p className="mt-4 text-sm text-kyn-metal">
              Équipes commerciales & techniques à Tunis — devis, déploiement et support premium.
            </p>
            <div className="mt-8 flex flex-wrap justify-center gap-3">
              <button type="button" className="px-6 py-3 rounded-full bg-kyn-green text-kyn-black text-xs font-bold glow-green">
                Parler à un expert
              </button>
              <button type="button" className="px-6 py-3 rounded-full border border-white/15 text-xs font-medium">
                Télécharger la brochure
              </button>
            </div>
            <div className="mt-8 flex flex-wrap justify-center gap-4 text-[11px] text-kyn-metal">
              {['Réponse < 24h', 'Installateurs certifiés', 'SLA entreprise'].map((t) => (
                <span key={t} className="inline-flex items-center gap-1.5">
                  <Check size={12} className="text-kyn-green" />
                  {t}
                </span>
              ))}
            </div>
          </div>
        </section>

        <footer className="px-8 md:px-14 py-8 border-t border-white/5 flex flex-wrap justify-between gap-4 items-center bg-kyn-black">
          <Logo size="sm" />
          <p className="text-[10px] text-kyn-metal">© KYNETIK — Tunisie · EV Charging Technology</p>
        </footer>
      </div>

      {/* Section specs from DB */}
      <div className="mt-12 grid md:grid-cols-2 gap-4">
        {sections.map((s) => (
          <div key={s.id} className="glass-card rounded-2xl p-5">
            <p className="text-[10px] text-kyn-green font-semibold uppercase tracking-wider">Section 0{s.sort_order}</p>
            <h4 className="font-display font-semibold mt-1">{s.title}</h4>
            <p className="text-xs text-kyn-metal mt-2">{s.body}</p>
            {(s.cta_primary || s.cta_secondary) && (
              <div className="mt-3 flex flex-wrap gap-2">
                {s.cta_primary && <span className="text-[10px] px-2 py-1 rounded-md bg-kyn-green/10 text-kyn-green">{s.cta_primary}</span>}
                {s.cta_secondary && <span className="text-[10px] px-2 py-1 rounded-md bg-white/5 text-kyn-silver">{s.cta_secondary}</span>}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

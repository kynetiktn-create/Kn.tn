import { useEffect, useMemo, useState, type ComponentType, type ReactNode } from 'react';
import { motion } from 'framer-motion';
import {
  Activity, AlertTriangle, ArrowUpRight, BatteryCharging, Bell,
  Brain, CheckCircle2, ChevronRight, Cpu, Gauge, Leaf, Radio,
  RefreshCw, Shield, Sparkles, TrendingUp, Truck, Wrench, Zap,
  Clock, Target, BarChart3,
} from 'lucide-react';
import BrandLogo from '../components/BrandLogo';
import LoadingState from '../components/LoadingState';
import { apiGet, cn } from '../lib/utils';

interface Insight {
  id: number;
  title: string;
  category: string;
  severity: string;
  body: string;
  impact: string;
  action_label: string;
  sort_order: number;
}

interface Metric {
  id: number;
  label: string;
  value: string;
  delta: string;
  category: string;
  sort_order: number;
}

function severityStyles(sev: string) {
  const s = (sev || '').toLowerCase();
  if (s === 'critical') return 'text-red-400 bg-red-500/10 border-red-500/25';
  if (s === 'warning') return 'text-amber-300 bg-amber-500/10 border-amber-500/25';
  if (s === 'success') return 'text-kyn-green bg-kyn-green/10 border-kyn-green/25';
  return 'text-sky-300 bg-sky-500/10 border-sky-500/25';
}

function HealthRing({ score }: { score: number }) {
  const r = 70;
  const c = 2 * Math.PI * r;
  const offset = c - (score / 100) * c;
  return (
    <div className="relative w-44 h-44 mx-auto">
      <svg className="w-full h-full -rotate-90" viewBox="0 0 160 160">
        <circle cx="80" cy="80" r={r} fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth="10" />
        <circle
          cx="80"
          cy="80"
          r={r}
          fill="none"
          stroke="url(#healthGrad)"
          strokeWidth="10"
          strokeLinecap="round"
          strokeDasharray={c}
          strokeDashoffset={offset}
          className="drop-shadow-[0_0_12px_rgba(0,230,118,0.55)]"
        />
        <defs>
          <linearGradient id="healthGrad" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#00c853" />
            <stop offset="100%" stopColor="#39ff14" />
          </linearGradient>
        </defs>
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="font-display text-4xl font-bold text-kyn-green text-glow">{score}</span>
        <span className="text-[10px] uppercase tracking-[0.2em] text-kyn-metal mt-1">Health</span>
      </div>
    </div>
  );
}

function GlassCard({
  children,
  className,
}: {
  children: ReactNode;
  className?: string;
}) {
  return (
    <div
      className={cn(
        'rounded-2xl border border-white/8 bg-gradient-to-b from-white/[0.05] to-white/[0.015] backdrop-blur-xl',
        className
      )}
    >
      {children}
    </div>
  );
}

function SectionTitle({
  icon: Icon,
  title,
  badge,
}: {
  icon: ComponentType<{ size?: number; className?: string }>;
  title: string;
  badge?: string;
}) {
  return (
    <div className="flex items-center justify-between gap-3 mb-4">
      <div className="flex items-center gap-2.5">
        <div className="w-8 h-8 rounded-xl bg-kyn-green/10 border border-kyn-green/20 flex items-center justify-center text-kyn-green">
          <Icon size={15} />
        </div>
        <h2 className="font-display font-semibold text-sm md:text-base tracking-tight">{title}</h2>
      </div>
      {badge && (
        <span className="text-[10px] font-semibold uppercase tracking-wider text-kyn-green bg-kyn-green/10 border border-kyn-green/20 px-2 py-0.5 rounded-full">
          {badge}
        </span>
      )}
    </div>
  );
}

const energyBars = [42, 55, 48, 62, 58, 70, 66, 78, 72, 85, 80, 92, 88, 76, 82, 90, 84, 95, 88, 79, 86, 91, 87, 74];

export default function AIDashboard() {
  const [insights, setInsights] = useState<Insight[]>([]);
  const [metrics, setMetrics] = useState<Metric[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [now, setNow] = useState(() => new Date());
  const [refreshing, setRefreshing] = useState(false);

  const load = async () => {
    try {
      const [ins, met] = await Promise.all([
        apiGet<Insight[]>('/api/ai-insights'),
        apiGet<Metric[]>('/api/cloud-metrics'),
      ]);
      setInsights(ins || []);
      setMetrics(met || []);
      setError('');
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to load AI dashboard');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    load();
    const t = setInterval(() => setNow(new Date()), 30000);
    return () => clearInterval(t);
  }, []);

  const byCat = useMemo(() => {
    const map: Record<string, Insight[]> = {};
    for (const i of insights) {
      const k = (i.category || 'other').toLowerCase();
      (map[k] ||= []).push(i);
    }
    return map;
  }, [insights]);

  const maintenance = useMemo(
    () =>
      insights.filter((i) =>
        ['maintenance', 'anomaly'].includes((i.category || '').toLowerCase())
      ),
    [insights]
  );

  const liveInsights = useMemo(
    () =>
      insights.filter((i) =>
        ['optimisation', 'recommendation', 'info', 'energy', 'fleet', 'health'].includes(
          (i.category || '').toLowerCase()
        ) || ['info', 'success'].includes((i.severity || '').toLowerCase())
      ).slice(0, 6),
    [insights]
  );

  const recommendations = useMemo(
    () =>
      insights
        .filter(
          (i) =>
            (i.category || '').toLowerCase() === 'recommendation' ||
            Boolean(i.action_label)
        )
        .slice(0, 6),
    [insights]
  );

  const healthScore = 94;
  const healthBreakdown = [
    { label: 'Model confidence', value: '96%', tone: 'good' },
    { label: 'Anomaly rate', value: '0.8%', tone: 'good' },
    { label: 'Data freshness', value: '1.2s', tone: 'good' },
    { label: 'Coverage', value: '118 CP', tone: 'info' },
  ];

  const fleetCards = [
    { label: 'Vehicles online', value: '86', sub: 'of 92 fleet units', icon: Truck },
    { label: 'Charging now', value: '24', sub: 'avg 48 kW', icon: BatteryCharging },
    { label: 'Depot utilization', value: '71%', sub: 'Sfax + Tunis', icon: Gauge },
    { label: 'Morning SoC ready', value: '88%', sub: 'SLA met', icon: Target },
  ];

  const energyKpis = [
    { label: 'Optimized energy', value: '1.84 MWh', delta: '+14%' },
    { label: 'Peak shave', value: '18%', delta: 'on target' },
    { label: 'Cost avoided', value: '12.4k DT', delta: '+9% MTD' },
    { label: 'Solar-aware jobs', value: '312', delta: '+41' },
  ];

  if (loading) {
    return (
      <div className="min-h-screen bg-kyn-black flex items-center justify-center">
        <LoadingState label="Initializing KYNETIK AI…" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-kyn-black text-white">
      {/* Ambient */}
      <div className="pointer-events-none fixed inset-0">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(0,230,118,0.08),transparent_50%)]" />
        <div className="absolute inset-0 grid-bg opacity-25" />
      </div>

      <div className="relative z-10 max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-6 lg:py-8">
        {/* Top bar */}
        <header className="flex flex-wrap items-center justify-between gap-4 mb-8">
          <div className="flex items-center gap-4">
            <BrandLogo height={28} />
            <div className="h-8 w-px bg-white/10 hidden sm:block" />
            <div>
              <div className="flex items-center gap-2">
                <Brain size={16} className="text-kyn-green" />
                <h1 className="font-display font-bold text-lg tracking-tight">AI Dashboard</h1>
              </div>
              <p className="text-[11px] text-kyn-metal mt-0.5">
                Intelligent control plane · {now.toLocaleString('fr-TN', { dateStyle: 'medium', timeStyle: 'short' })}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 sm:gap-3">
            <span className="hidden md:inline-flex items-center gap-1.5 text-[10px] font-semibold text-kyn-green bg-kyn-green/10 border border-kyn-green/25 px-2.5 py-1 rounded-full">
              <span className="w-1.5 h-1.5 rounded-full bg-kyn-green animate-pulse" />
              LIVE INTELLIGENCE
            </span>
            <button
              type="button"
              onClick={() => {
                setRefreshing(true);
                load();
              }}
              className="inline-flex items-center gap-2 px-3 py-2 rounded-xl border border-white/10 bg-white/[0.03] text-xs text-kyn-silver hover:border-kyn-green/30 hover:text-white transition-colors"
            >
              <RefreshCw size={13} className={cn(refreshing && 'animate-spin')} />
              Refresh
            </button>
          </div>
        </header>

        {error && (
          <div className="mb-6 rounded-xl border border-red-500/30 bg-red-500/10 px-4 py-3 text-sm text-red-300">
            {error}
          </div>
        )}

        {/* KPI strip */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-6">
          {(metrics.length
            ? metrics.slice(0, 4)
            : [
                { id: 1, label: 'Sessions 24h', value: '1 284', delta: '+12%' },
                { id: 2, label: 'Uptime', value: '99.4%', delta: 'SLA OK' },
                { id: 3, label: 'AI actions', value: '147', delta: '+23' },
                { id: 4, label: 'Savings 24h', value: '860 DT', delta: '+6%' },
              ]
          ).map((m, i) => (
            <motion.div
              key={m.id || m.label}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
            >
              <GlassCard className="p-4">
                <p className="text-[10px] uppercase tracking-wider text-kyn-metal">{m.label}</p>
                <p className="font-display text-2xl font-bold mt-1">{m.value}</p>
                <p className="text-[11px] text-kyn-green mt-1 flex items-center gap-1">
                  <TrendingUp size={11} /> {m.delta}
                </p>
              </GlassCard>
            </motion.div>
          ))}
        </div>

        {/* Main grid */}
        <div className="grid lg:grid-cols-12 gap-4 lg:gap-5">
          {/* LEFT COLUMN */}
          <div className="lg:col-span-4 space-y-4 lg:space-y-5">
            {/* 1. AI Health Score */}
            <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.05 }}>
              <GlassCard className="p-5 md:p-6 relative overflow-hidden">
                <div className="absolute -right-10 -top-10 w-40 h-40 rounded-full bg-kyn-green/10 blur-3xl" />
                <SectionTitle icon={Shield} title="AI Health Score" badge="Excellent" />
                <HealthRing score={healthScore} />
                <p className="text-center text-xs text-kyn-metal mt-2 mb-5">
                  Network intelligence index · Ensemble v2.4
                </p>
                <div className="grid grid-cols-2 gap-2">
                  {healthBreakdown.map((h) => (
                    <div key={h.label} className="rounded-xl border border-white/6 bg-black/30 px-3 py-2.5">
                      <p className="text-[10px] text-kyn-metal">{h.label}</p>
                      <p className="text-sm font-semibold mt-0.5 text-kyn-green">{h.value}</p>
                    </div>
                  ))}
                </div>
                {byCat.health?.[0] && (
                  <p className="mt-4 text-[11px] text-kyn-silver leading-relaxed border-t border-white/5 pt-3">
                    {byCat.health[0].body}
                  </p>
                )}
              </GlassCard>
            </motion.div>

            {/* 4. Predictive Maintenance */}
            <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.12 }}>
              <GlassCard className="p-5 md:p-6">
                <SectionTitle icon={Wrench} title="Predictive Maintenance" badge={`${maintenance.length} signals`} />
                <div className="space-y-2.5">
                  {(maintenance.length
                    ? maintenance
                    : [
                        {
                          id: 1,
                          title: 'Depot Sfax · P2',
                          body: 'Cooling fan degradation predicted',
                          impact: '12–18 days',
                          severity: 'warning',
                          action_label: 'Schedule',
                          category: 'maintenance',
                          sort_order: 1,
                        },
                      ]
                  ).map((m) => (
                    <div
                      key={m.id}
                      className="rounded-xl border border-white/6 bg-black/25 p-3.5 hover:border-white/12 transition-colors"
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="min-w-0">
                          <p className="text-sm font-medium truncate">{m.title}</p>
                          <p className="text-[11px] text-kyn-metal mt-1 line-clamp-2">{m.body}</p>
                        </div>
                        <span className={cn('shrink-0 text-[9px] font-bold uppercase tracking-wide px-2 py-0.5 rounded-full border', severityStyles(m.severity))}>
                          {m.severity}
                        </span>
                      </div>
                      <div className="mt-2.5 flex items-center justify-between">
                        <span className="text-[11px] text-kyn-green font-medium flex items-center gap-1">
                          <Clock size={11} /> {m.impact}
                        </span>
                        <button type="button" className="text-[11px] font-semibold text-kyn-silver hover:text-kyn-green inline-flex items-center gap-0.5">
                          {m.action_label || 'Action'} <ChevronRight size={12} />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </GlassCard>
            </motion.div>
          </div>

          {/* CENTER + RIGHT */}
          <div className="lg:col-span-8 space-y-4 lg:space-y-5">
            {/* 2. Energy Optimization */}
            <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.08 }}>
              <GlassCard className="p-5 md:p-6">
                <SectionTitle icon={Leaf} title="Energy Optimization" badge="Smart load" />
                <div className="grid sm:grid-cols-4 gap-2.5 mb-5">
                  {energyKpis.map((k) => (
                    <div key={k.label} className="rounded-xl border border-white/6 bg-black/30 p-3">
                      <p className="text-[10px] text-kyn-metal uppercase tracking-wider">{k.label}</p>
                      <p className="font-display text-lg font-bold mt-1">{k.value}</p>
                      <p className="text-[10px] text-kyn-green mt-0.5">{k.delta}</p>
                    </div>
                  ))}
                </div>
                <div className="rounded-xl border border-white/6 bg-black/35 p-4">
                  <div className="flex items-center justify-between mb-3">
                    <p className="text-xs font-semibold text-kyn-silver">AI load curve · 24h</p>
                    <BarChart3 size={14} className="text-kyn-green" />
                  </div>
                  <div className="h-28 flex items-end gap-1">
                    {energyBars.map((h, i) => (
                      <div
                        key={i}
                        className="flex-1 rounded-t-sm bg-gradient-to-t from-kyn-green/25 via-kyn-green/70 to-kyn-green-glow"
                        style={{ height: `${h}%`, opacity: 0.45 + (i / energyBars.length) * 0.55 }}
                      />
                    ))}
                  </div>
                  <div className="mt-3 flex flex-wrap gap-3 text-[10px] text-kyn-metal">
                    <span className="inline-flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-sm bg-kyn-green" /> Optimized dispatch
                    </span>
                    <span className="inline-flex items-center gap-1.5">
                      <Zap size={10} className="text-amber-300" /> Peak window avoided 17:30–19:30
                    </span>
                  </div>
                </div>
              </GlassCard>
            </motion.div>

            {/* 3. Fleet Overview */}
            <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
              <GlassCard className="p-5 md:p-6">
                <SectionTitle icon={Truck} title="Fleet Overview" badge="Live" />
                <div className="grid sm:grid-cols-2 xl:grid-cols-4 gap-3 mb-4">
                  {fleetCards.map(({ label, value, sub, icon: Icon }) => (
                    <div key={label} className="rounded-xl border border-white/6 bg-black/30 p-3.5">
                      <div className="flex items-center justify-between mb-2">
                        <Icon size={14} className="text-kyn-green" />
                        <Activity size={12} className="text-kyn-metal" />
                      </div>
                      <p className="text-[10px] text-kyn-metal uppercase tracking-wider">{label}</p>
                      <p className="font-display text-2xl font-bold mt-0.5">{value}</p>
                      <p className="text-[10px] text-kyn-metal mt-1">{sub}</p>
                    </div>
                  ))}
                </div>
                <div className="rounded-xl border border-white/6 bg-black/25 overflow-hidden">
                  <div className="grid grid-cols-4 text-[9px] uppercase tracking-wider text-kyn-metal px-3 py-2 border-b border-white/5">
                    <span>Unit</span>
                    <span>Status</span>
                    <span>SoC</span>
                    <span>Site</span>
                  </div>
                  {[
                    ['VAN-12', 'Charging', '64%', 'Depot Sfax'],
                    ['BUS-04', 'Ready', '94%', 'Tunis Hub'],
                    ['VAN-07', 'Route', '71%', 'Lac corridor'],
                    ['SUV-02', 'Charging', '38%', 'Hotel Palm'],
                  ].map((row) => (
                    <div key={row[0]} className="grid grid-cols-4 text-[11px] px-3 py-2.5 border-b border-white/[0.03] text-kyn-silver">
                      <span className="font-medium text-white">{row[0]}</span>
                      <span className={row[1] === 'Charging' ? 'text-kyn-green' : row[1] === 'Ready' ? 'text-emerald-300' : 'text-sky-300'}>
                        {row[1]}
                      </span>
                      <span>{row[2]}</span>
                      <span className="truncate">{row[3]}</span>
                    </div>
                  ))}
                </div>
              </GlassCard>
            </motion.div>

            {/* 5 + 6 Insights & Recommendations */}
            <div className="grid md:grid-cols-2 gap-4 lg:gap-5">
              {/* Live AI Insights */}
              <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.14 }}>
                <GlassCard className="p-5 md:p-6 h-full">
                  <SectionTitle icon={Sparkles} title="Live AI Insights" badge="Streaming" />
                  <div className="space-y-2.5">
                    {(liveInsights.length ? liveInsights : insights).slice(0, 5).map((ins, idx) => (
                      <div
                        key={ins.id}
                        className="rounded-xl border border-white/6 bg-black/25 p-3.5 group hover:border-kyn-green/25 transition-colors"
                      >
                        <div className="flex items-start gap-2.5">
                          <div className="mt-0.5 w-6 h-6 rounded-lg bg-kyn-green/10 border border-kyn-green/20 flex items-center justify-center text-kyn-green shrink-0">
                            {idx % 2 === 0 ? <Cpu size={12} /> : <Radio size={12} />}
                          </div>
                          <div className="min-w-0">
                            <p className="text-sm font-medium leading-snug">{ins.title}</p>
                            <p className="text-[11px] text-kyn-metal mt-1 line-clamp-2">{ins.body}</p>
                            <div className="mt-2 flex items-center gap-2">
                              <span className={cn('text-[9px] font-bold uppercase px-1.5 py-0.5 rounded border', severityStyles(ins.severity))}>
                                {ins.severity}
                              </span>
                              <span className="text-[10px] text-kyn-green font-medium">{ins.impact}</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </GlassCard>
              </motion.div>

              {/* Recent Recommendations */}
              <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.16 }}>
                <GlassCard className="p-5 md:p-6 h-full">
                  <SectionTitle icon={Bell} title="Recent Recommendations" badge="Actionable" />
                  <div className="space-y-2.5">
                    {(recommendations.length ? recommendations : insights).slice(0, 5).map((rec) => (
                      <div
                        key={rec.id}
                        className="rounded-xl border border-white/6 bg-black/25 p-3.5 hover:bg-white/[0.03] transition-colors"
                      >
                        <div className="flex items-start justify-between gap-2">
                          <div className="min-w-0">
                            <p className="text-sm font-medium leading-snug">{rec.title}</p>
                            <p className="text-[11px] text-kyn-metal mt-1 line-clamp-2">{rec.body}</p>
                          </div>
                          {rec.severity === 'critical' ? (
                            <AlertTriangle size={14} className="text-red-400 shrink-0" />
                          ) : rec.severity === 'warning' ? (
                            <AlertTriangle size={14} className="text-amber-300 shrink-0" />
                          ) : (
                            <CheckCircle2 size={14} className="text-kyn-green shrink-0" />
                          )}
                        </div>
                        <div className="mt-3 flex items-center justify-between gap-2">
                          <span className="text-[10px] text-kyn-green font-medium flex items-center gap-1">
                            <ArrowUpRight size={11} /> {rec.impact}
                          </span>
                          <button
                            type="button"
                            className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-kyn-green text-kyn-black text-[10px] font-bold hover:bg-kyn-green-glow transition-colors"
                          >
                            {rec.action_label || 'Apply'}
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </GlassCard>
              </motion.div>
            </div>
          </div>
        </div>

        {/* Footer strip */}
        <footer className="mt-8 pt-5 border-t border-white/5 flex flex-wrap items-center justify-between gap-3 text-[10px] text-kyn-metal">
          <div className="flex items-center gap-2">
            <Brain size={12} className="text-kyn-green" />
            <span>KYNETIK AI · Predictive · Optimization · Fleet intelligence</span>
          </div>
          <span>Design System · Premium Dark · Electric Green</span>
        </footer>
      </div>
    </div>
  );
}

import { useCallback, useEffect, useMemo, useState, type ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Activity, AlertTriangle, BarChart3, Bell, Bolt, CheckCircle2, ChevronRight,
  Circle, Command, CreditCard, Gauge, Layers, Loader2, Map as MapIcon, Menu,
  Moon, Power, Radio, RefreshCw, RotateCcw, Server, Settings2, Shield,
  Sun, Terminal, Unlock, Users, Wifi, WifiOff, X, Zap, FileWarning,
  ScrollText, TrendingUp, Cpu, KeyRound, Plus
} from 'lucide-react';
import BrandLogo from '../components/BrandLogo';
import LoadingState from '../components/LoadingState';
import { cn } from '../lib/utils';
import ocppClient from '../lib/ocppClient';

type Tab =
  | 'overview' | 'live' | 'map' | 'sessions' | 'transactions' | 'revenue'
  | 'energy' | 'alerts' | 'faults' | 'firmware' | 'diagnostics' | 'reports'
  | 'users' | 'roles' | 'rfid' | 'commands' | 'events' | 'mobile' | 'docs';

const NAV: { id: Tab; label: string; icon: typeof Zap; group: string }[] = [
  { id: 'overview', label: 'Overview', icon: Gauge, group: 'Monitor' },
  { id: 'live', label: 'Live chargers', icon: Radio, group: 'Monitor' },
  { id: 'map', label: 'Map', icon: MapIcon, group: 'Monitor' },
  { id: 'sessions', label: 'Sessions', icon: Activity, group: 'Energy' },
  { id: 'transactions', label: 'Transactions', icon: Bolt, group: 'Energy' },
  { id: 'energy', label: 'Energy', icon: Zap, group: 'Energy' },
  { id: 'revenue', label: 'Revenue', icon: TrendingUp, group: 'Energy' },
  { id: 'alerts', label: 'Alerts', icon: Bell, group: 'Ops' },
  { id: 'faults', label: 'Faults', icon: AlertTriangle, group: 'Ops' },
  { id: 'firmware', label: 'Firmware', icon: Cpu, group: 'Ops' },
  { id: 'diagnostics', label: 'Diagnostics', icon: FileWarning, group: 'Ops' },
  { id: 'commands', label: 'Commands', icon: Command, group: 'Ops' },
  { id: 'reports', label: 'Reports', icon: BarChart3, group: 'Insights' },
  { id: 'events', label: 'Event log', icon: ScrollText, group: 'Insights' },
  { id: 'users', label: 'Users', icon: Users, group: 'Access' },
  { id: 'roles', label: 'Roles', icon: Shield, group: 'Access' },
  { id: 'rfid', label: 'RFID cards', icon: CreditCard, group: 'Access' },
  { id: 'mobile', label: 'Mobile API', icon: Layers, group: 'Platform' },
  { id: 'docs', label: 'Architecture', icon: Server, group: 'Platform' },
];

export default function CsmsDashboard() {
  const [tab, setTab] = useState<Tab>('overview');
  const [theme, setTheme] = useState<'dark' | 'light'>('dark');
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [analytics, setAnalytics] = useState<any>(null);
  const [stations, setStations] = useState<any[]>([]);
  const [connectors, setConnectors] = useState<Record<string, any[]>>({});
  const [sessions, setSessions] = useState<any[]>([]);
  const [transactions, setTransactions] = useState<any[]>([]);
  const [alerts, setAlerts] = useState<any[]>([]);
  const [users, setUsers] = useState<any[]>([]);
  const [roles, setRoles] = useState<any[]>([]);
  const [idTags, setIdTags] = useState<any[]>([]);
  const [events, setEvents] = useState<any[]>([]);
  const [commands, setCommands] = useState<any[]>([]);
  const [notifications, setNotifications] = useState<any[]>([]);
  const [selected, setSelected] = useState<string | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [toast, setToast] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [reg, setReg] = useState({ charge_point_id: '', site_name: '', city: 'Tunis', model: 'NOVA', vendor: 'KYNETIK' });

  const dark = theme === 'dark';

  const load = useCallback(async (soft = false) => {
    if (soft) setRefreshing(true);
    else setLoading(true);
    setError(null);
    try {
      const a = await ocppClient.analyticsOverview();
      setAnalytics(a);
      setStations(a.stations || []);
      setTransactions(a.transactions || []);
      setAlerts(a.alerts || []);
      const [sess, us, ro, tags, ev, cmd, ntf] = await Promise.all([
        ocppClient.listSessionsCsms({ limit: 100 }),
        ocppClient.listUsers(),
        ocppClient.listRoles(),
        ocppClient.listIdTags(),
        ocppClient.listEvents({ limit: 80 }),
        ocppClient.listCommands({ limit: 40 }),
        ocppClient.listNotifications(),
      ]);
      setSessions(sess as any[]);
      setUsers(us as any[]);
      setRoles(ro as any[]);
      setIdTags(tags as any[]);
      setEvents(ev as any[]);
      setCommands(cmd as any[]);
      setNotifications(ntf as any[]);
      if (!selected && a.stations?.[0]) setSelected(a.stations[0].charge_point_id);
    } catch (e: any) {
      setError(e.message || 'Failed to load CSMS data');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [selected]);

  useEffect(() => { load(); }, [load]);

  useEffect(() => {
    if (!selected) return;
    ocppClient.listConnectors(selected).then((c) => setConnectors((prev) => ({ ...prev, [selected]: c as any[] }))).catch(() => {});
  }, [selected]);

  useEffect(() => {
    const t = setInterval(() => load(true), 20000);
    return () => clearInterval(t);
  }, [load]);

  const flash = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 3200);
  };

  const runCmd = async (label: string, fn: () => Promise<any>) => {
    setBusy(label);
    setError(null);
    try {
      const r = await fn();
      flash(`${label} → ${r?.result?.status || r?.status || 'ok'}`);
      await load(true);
    } catch (e: any) {
      setError(e.message || `${label} failed`);
    } finally {
      setBusy(null);
    }
  };

  const selectedStation = useMemo(() => stations.find((s) => s.charge_point_id === selected), [stations, selected]);
  const openAlerts = alerts.filter((a) => a.status === 'open');
  const faultStations = stations.filter((s) => /fault|error|offline/i.test(String(s.status || '')));

  const energySeries = useMemo(() => {
    const days: Record<string, number> = {};
    for (const t of transactions) {
      if (!t.start_timestamp) continue;
      const d = String(t.start_timestamp).slice(0, 10);
      days[d] = (days[d] || 0) + Number(t.energy_kwh || 0);
    }
    return Object.entries(days).sort(([a], [b]) => a.localeCompare(b)).slice(-14);
  }, [transactions]);

  const maxEnergy = Math.max(...energySeries.map(([, v]) => v), 1);

  const mapStations = stations.filter((s) => s.latitude != null && s.longitude != null);
  const bounds = useMemo(() => {
    if (!mapStations.length) return { minLat: 36.7, maxLat: 36.95, minLng: 10.1, maxLng: 10.4 };
    const lats = mapStations.map((s) => Number(s.latitude));
    const lngs = mapStations.map((s) => Number(s.longitude));
    return {
      minLat: Math.min(...lats) - 0.05,
      maxLat: Math.max(...lats) + 0.05,
      minLng: Math.min(...lngs) - 0.05,
      maxLng: Math.max(...lngs) + 0.05,
    };
  }, [mapStations]);

  const project = (lat: number, lng: number) => {
    const x = ((lng - bounds.minLng) / (bounds.maxLng - bounds.minLng || 1)) * 100;
    const y = (1 - (lat - bounds.minLat) / (bounds.maxLat - bounds.minLat || 1)) * 100;
    return { x: Math.min(98, Math.max(2, x)), y: Math.min(98, Math.max(2, y)) };
  };

  if (loading) {
    return (
      <div className={cn('min-h-screen flex items-center justify-center', dark ? 'bg-[#05080f]' : 'bg-slate-100')}>
        <LoadingState label="Starting KYNETIK CSMS…" />
      </div>
    );
  }

  const shell = dark
    ? 'bg-[#05080f] text-slate-100'
    : 'bg-slate-100 text-slate-900';
  const panel = dark
    ? 'bg-[#0b1220]/90 border-white/10'
    : 'bg-white border-slate-200 shadow-sm';
  const muted = dark ? 'text-slate-400' : 'text-slate-500';
  const subtle = dark ? 'border-white/10' : 'border-slate-200';

  const groups = [...new Set(NAV.map((n) => n.group))];

  return (
    <div className={cn('min-h-screen', shell)}>
      {/* Top bar */}
      <header className={cn('sticky top-0 z-40 border-b backdrop-blur-xl', dark ? 'bg-[#05080f]/85 border-white/10' : 'bg-white/90 border-slate-200')}>
        <div className="max-w-[1600px] mx-auto px-3 md:px-5 h-14 flex items-center gap-3">
          <button type="button" className="lg:hidden p-2 rounded-lg border border-current/10" onClick={() => setMenuOpen(true)}>
            <Menu size={18} />
          </button>
          <Link to="/" className="flex items-center gap-2 min-w-0">
            <BrandLogo height={26} />
            <div className="hidden sm:block leading-tight">
              <p className="text-[11px] font-semibold tracking-wide">CSMS Control Plane</p>
              <p className={cn('text-[10px]', muted)}>OCPP 1.6J JSON · multi-vendor</p>
            </div>
          </Link>
          <div className="flex-1" />
          <div className={cn('hidden md:flex items-center gap-2 text-[11px] px-2.5 py-1 rounded-full border', subtle, muted)}>
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            Live · {analytics?.stations_online ?? 0} WS peers · auto-refresh 20s
          </div>
          <button
            type="button"
            onClick={() => setTheme((t) => (t === 'dark' ? 'light' : 'dark'))}
            className={cn('p-2 rounded-lg border', subtle)}
            title="Toggle theme"
          >
            {dark ? <Sun size={16} /> : <Moon size={16} />}
          </button>
          <button
            type="button"
            onClick={() => load(true)}
            className={cn('inline-flex items-center gap-1.5 text-xs font-semibold px-3 py-2 rounded-lg border', subtle)}
          >
            <RefreshCw size={14} className={refreshing ? 'animate-spin' : ''} /> Refresh
          </button>
          <Link to="/ocpp" className={cn('hidden sm:inline-flex text-xs font-semibold px-3 py-2 rounded-lg', dark ? 'bg-emerald-400 text-black' : 'bg-emerald-500 text-white')}>
            OCPP console
          </Link>
        </div>
      </header>

      <div className="max-w-[1600px] mx-auto flex">
        {/* Sidebar */}
        <aside className={cn('hidden lg:flex w-60 shrink-0 flex-col border-r min-h-[calc(100vh-3.5rem)] sticky top-14', subtle, dark ? 'bg-[#070b14]/50' : 'bg-white/60')}>
          <nav className="p-3 space-y-4 overflow-y-auto flex-1">
            {groups.map((g) => (
              <div key={g}>
                <p className={cn('text-[10px] uppercase tracking-[0.2em] font-semibold px-2 mb-1.5', muted)}>{g}</p>
                <div className="space-y-0.5">
                  {NAV.filter((n) => n.group === g).map((n) => {
                    const Icon = n.icon;
                    const active = tab === n.id;
                    return (
                      <button
                        key={n.id}
                        type="button"
                        onClick={() => setTab(n.id)}
                        className={cn(
                          'w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg text-left text-[13px] transition-colors',
                          active
                            ? dark ? 'bg-emerald-400/15 text-emerald-300' : 'bg-emerald-50 text-emerald-800'
                            : dark ? 'text-slate-400 hover:bg-white/5 hover:text-white' : 'text-slate-600 hover:bg-slate-100'
                        )}
                      >
                        <Icon size={15} />
                        <span className="flex-1">{n.label}</span>
                        {n.id === 'alerts' && openAlerts.length > 0 && (
                          <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-full bg-rose-500/20 text-rose-300">{openAlerts.length}</span>
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>
            ))}
          </nav>
          <div className={cn('p-3 border-t text-[10px]', subtle, muted)}>
            Horizontal scale · sticky WS · shared Postgres · OCPP 2.0.1-ready
          </div>
        </aside>

        {/* Mobile drawer */}
        <AnimatePresence>
          {menuOpen && (
            <motion.div className="fixed inset-0 z-50 lg:hidden" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <div className="absolute inset-0 bg-black/60" onClick={() => setMenuOpen(false)} />
              <motion.div
                initial={{ x: -280 }} animate={{ x: 0 }} exit={{ x: -280 }}
                className={cn('absolute left-0 top-0 bottom-0 w-72 border-r p-3 overflow-y-auto', dark ? 'bg-[#0b1220] border-white/10' : 'bg-white')}
              >
                <div className="flex justify-between items-center mb-4">
                  <span className="font-semibold text-sm">CSMS menu</span>
                  <button type="button" onClick={() => setMenuOpen(false)}><X size={18} /></button>
                </div>
                {NAV.map((n) => (
                  <button
                    key={n.id}
                    type="button"
                    onClick={() => { setTab(n.id); setMenuOpen(false); }}
                    className={cn('w-full text-left px-3 py-2.5 rounded-lg text-sm mb-0.5', tab === n.id ? 'bg-emerald-400/15 text-emerald-300' : '')}
                  >
                    {n.label}
                  </button>
                ))}
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Main */}
        <main className="flex-1 min-w-0 p-3 md:p-5 space-y-4">
          {error && (
            <div className="rounded-xl border border-rose-500/30 bg-rose-500/10 text-rose-200 px-4 py-3 text-sm flex justify-between gap-3">
              <span>{error}</span>
              <button type="button" onClick={() => setError(null)}><X size={16} /></button>
            </div>
          )}
          <AnimatePresence>
            {toast && (
              <motion.div
                initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
                className="fixed top-16 right-4 z-50 px-4 py-2.5 rounded-xl bg-emerald-400 text-black text-sm font-semibold shadow-lg"
              >
                {toast}
              </motion.div>
            )}
          </AnimatePresence>

          {tab === 'overview' && (
            <>
              <div className="grid grid-cols-2 md:grid-cols-4 xl:grid-cols-8 gap-2.5">
                <Kpi dark={dark} label="Stations" value={analytics?.stations_total} icon={Server} />
                <Kpi dark={dark} label="Online" value={analytics?.stations_online} icon={Wifi} accent="emerald" />
                <Kpi dark={dark} label="Charging" value={analytics?.stations_charging} icon={Zap} accent="amber" />
                <Kpi dark={dark} label="Active TX" value={analytics?.active_sessions} icon={Activity} />
                <Kpi dark={dark} label="Energy MWh" value={(Number(analytics?.energy_kwh || 0) / 1000).toFixed(2)} icon={Bolt} />
                <Kpi dark={dark} label="Revenue" value={`${Number(analytics?.revenue || 0).toFixed(0)}`} suffix="TND" icon={TrendingUp} accent="emerald" />
                <Kpi dark={dark} label="Open alerts" value={analytics?.open_alerts} icon={Bell} accent="rose" />
                <Kpi dark={dark} label="Utilization" value={`${analytics?.utilization ?? 0}%`} icon={Gauge} />
              </div>

              <div className="grid lg:grid-cols-3 gap-4">
                <Card dark={dark} className="lg:col-span-2" title="Energy (14 days)" subtitle="kWh delivered from completed sessions">
                  <div className="h-44 flex items-end gap-1.5 pt-4">
                    {energySeries.length === 0 && <p className={cn('text-sm', muted)}>No energy data yet</p>}
                    {energySeries.map(([day, val]) => (
                      <div key={day} className="flex-1 flex flex-col items-center gap-1 min-w-0">
                        <div
                          className={cn('w-full rounded-t-md', dark ? 'bg-gradient-to-t from-emerald-600 to-emerald-300' : 'bg-gradient-to-t from-emerald-600 to-emerald-400')}
                          style={{ height: `${Math.max(6, (val / maxEnergy) * 100)}%` }}
                          title={`${val.toFixed(1)} kWh`}
                        />
                        <span className={cn('text-[9px] truncate w-full text-center', muted)}>{day.slice(5)}</span>
                      </div>
                    ))}
                  </div>
                </Card>
                <Card dark={dark} title="Notifications" subtitle={`${notifications.length} recent`}>
                  <div className="space-y-2 max-h-44 overflow-y-auto">
                    {notifications.slice(0, 6).map((n) => (
                      <div key={n.id} className={cn('rounded-lg border px-3 py-2', subtle)}>
                        <div className="flex items-center gap-2">
                          <SeverityDot s={n.severity} />
                          <p className="text-xs font-semibold truncate flex-1">{n.title}</p>
                        </div>
                        <p className={cn('text-[11px] mt-0.5 line-clamp-2', muted)}>{n.body}</p>
                      </div>
                    ))}
                    {!notifications.length && <p className={cn('text-sm', muted)}>No notifications</p>}
                  </div>
                </Card>
              </div>

              <div className="grid lg:grid-cols-2 gap-4">
                <Card dark={dark} title="Live fleet snapshot" action={<button type="button" className="text-xs text-emerald-400" onClick={() => setTab('live')}>Open</button>}>
                  <div className="space-y-2">
                    {stations.slice(0, 5).map((s) => (
                      <button
                        key={s.charge_point_id}
                        type="button"
                        onClick={() => { setSelected(s.charge_point_id); setTab('live'); }}
                        className={cn('w-full flex items-center gap-3 rounded-xl border px-3 py-2.5 text-left', subtle, dark ? 'hover:bg-white/5' : 'hover:bg-slate-50')}
                      >
                        {s.connected ? <Wifi size={14} className="text-emerald-400" /> : <WifiOff size={14} className="text-slate-500" />}
                        <div className="min-w-0 flex-1">
                          <p className="text-sm font-semibold truncate">{s.charge_point_id}</p>
                          <p className={cn('text-[11px] truncate', muted)}>{s.site_name} · {s.model}</p>
                        </div>
                        <StatusPill status={s.status} dark={dark} />
                      </button>
                    ))}
                  </div>
                </Card>
                <Card dark={dark} title="Open alerts" action={<button type="button" className="text-xs text-emerald-400" onClick={() => setTab('alerts')}>Manage</button>}>
                  <div className="space-y-2">
                    {openAlerts.slice(0, 5).map((a) => (
                      <div key={a.alert_id} className={cn('rounded-xl border px-3 py-2.5', subtle)}>
                        <div className="flex items-center gap-2">
                          <SeverityDot s={a.severity} />
                          <p className="text-sm font-semibold flex-1 truncate">{a.title}</p>
                          <button
                            type="button"
                            className="text-[11px] text-emerald-400 font-semibold"
                            onClick={() => ocppClient.resolveAlert(a.alert_id).then(() => load(true))}
                          >
                            Resolve
                          </button>
                        </div>
                        <p className={cn('text-[11px] mt-1', muted)}>{a.charge_point_id} · {a.code}</p>
                      </div>
                    ))}
                    {!openAlerts.length && (
                      <div className="flex items-center gap-2 text-sm text-emerald-400">
                        <CheckCircle2 size={16} /> All clear
                      </div>
                    )}
                  </div>
                </Card>
              </div>
            </>
          )}

          {tab === 'live' && (
            <div className="grid lg:grid-cols-5 gap-4">
              <Card dark={dark} className="lg:col-span-2" title="Charging stations" subtitle={`${stations.length} registered`}>
                <div className="space-y-2 max-h-[70vh] overflow-y-auto pr-1">
                  {stations.map((s) => (
                    <button
                      key={s.charge_point_id}
                      type="button"
                      onClick={() => setSelected(s.charge_point_id)}
                      className={cn(
                        'w-full text-left rounded-xl border px-3 py-3 transition-all',
                        selected === s.charge_point_id
                          ? dark ? 'border-emerald-400/40 bg-emerald-400/10' : 'border-emerald-500 bg-emerald-50'
                          : cn(subtle, dark ? 'hover:bg-white/5' : 'hover:bg-slate-50')
                      )}
                    >
                      <div className="flex items-center gap-2">
                        <Circle size={8} className={s.connected ? 'fill-emerald-400 text-emerald-400' : 'fill-slate-500 text-slate-500'} />
                        <span className="font-mono text-sm font-semibold">{s.charge_point_id}</span>
                        <StatusPill status={s.status} dark={dark} />
                      </div>
                      <p className={cn('text-[11px] mt-1', muted)}>{s.site_name} · {s.city} · {s.vendor} {s.model}</p>
                    </button>
                  ))}
                </div>
                <form
                  className={cn('mt-4 pt-4 border-t space-y-2', subtle)}
                  onSubmit={(e) => {
                    e.preventDefault();
                    runCmd('Register', () => ocppClient.registerStation({ ...reg, connectors: [1, 2] }));
                  }}
                >
                  <p className="text-xs font-semibold">Register station</p>
                  <input className={inputCls(dark)} placeholder="Charge Point ID" value={reg.charge_point_id} onChange={(e) => setReg({ ...reg, charge_point_id: e.target.value })} required />
                  <div className="grid grid-cols-2 gap-2">
                    <input className={inputCls(dark)} placeholder="Site" value={reg.site_name} onChange={(e) => setReg({ ...reg, site_name: e.target.value })} />
                    <input className={inputCls(dark)} placeholder="City" value={reg.city} onChange={(e) => setReg({ ...reg, city: e.target.value })} />
                  </div>
                  <button type="submit" className={btnPrimary(dark)} disabled={!!busy}>
                    <Plus size={14} /> Add station
                  </button>
                </form>
              </Card>

              <Card dark={dark} className="lg:col-span-3" title={selectedStation?.charge_point_id || 'Select a station'} subtitle={selectedStation ? `${selectedStation.site_name} · fw ${selectedStation.firmware_version || '—'}` : '—'}>
                {!selectedStation ? (
                  <p className={muted}>Select a charger</p>
                ) : (
                  <div className="space-y-4">
                    <div className="grid sm:grid-cols-3 gap-2">
                      <Meta dark={dark} k="Protocol" v={selectedStation.protocol || 'ocpp1.6'} />
                      <Meta dark={dark} k="Heartbeat" v={selectedStation.last_heartbeat ? new Date(selectedStation.last_heartbeat).toLocaleString() : '—'} />
                      <Meta dark={dark} k="Auth" v={selectedStation.auth_key ? '••••' : 'open'} />
                    </div>
                    <div>
                      <p className={cn('text-xs font-semibold mb-2', muted)}>Connectors</p>
                      <div className="grid sm:grid-cols-2 gap-2">
                        {(connectors[selected!] || []).map((c) => (
                          <div key={c.connector_id} className={cn('rounded-xl border p-3', subtle)}>
                            <div className="flex justify-between items-center">
                              <span className="font-semibold text-sm">Connector {c.connector_id}</span>
                              <StatusPill status={c.status} dark={dark} />
                            </div>
                            <p className={cn('text-[11px] mt-1', muted)}>
                              {c.power_kw != null ? `${c.power_kw} kW` : '—'} · {c.error_code || 'NoError'}
                            </p>
                          </div>
                        ))}
                        {!(connectors[selected!] || []).length && <p className={cn('text-sm', muted)}>No connector rows yet</p>}
                      </div>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      <CmdBtn dark={dark} busy={busy} label="Remote Start" onClick={() => runCmd('RemoteStart', () => ocppClient.command(selected!, 'RemoteStartTransaction', { connectorId: 1, idTag: 'RFID-1001' }))} icon={Power} />
                      <CmdBtn dark={dark} busy={busy} label="Remote Stop" onClick={() => runCmd('RemoteStop', () => ocppClient.command(selected!, 'RemoteStopTransaction', {}))} icon={Power} />
                      <CmdBtn dark={dark} busy={busy} label="Unlock" onClick={() => runCmd('Unlock', () => ocppClient.command(selected!, 'UnlockConnector', { connectorId: 1 }))} icon={Unlock} />
                      <CmdBtn dark={dark} busy={busy} label="Soft Reset" onClick={() => runCmd('Reset', () => ocppClient.command(selected!, 'Reset', { type: 'Soft' }))} icon={RotateCcw} />
                      <CmdBtn dark={dark} busy={busy} label="Get Config" onClick={() => runCmd('GetConfiguration', () => ocppClient.command(selected!, 'GetConfiguration', {}))} icon={Settings2} />
                      <CmdBtn dark={dark} busy={busy} label="Trigger Status" onClick={() => runCmd('TriggerMessage', () => ocppClient.command(selected!, 'TriggerMessage', { requestedMessage: 'StatusNotification' }))} icon={Radio} />
                    </div>
                    <p className={cn('text-[11px]', muted)}>
                      Commands queue to the CSMS. When the charge point is online on WSS, they are delivered as OCPP CALL frames; offline stations store a completed local audit trail for demo ops.
                    </p>
                  </div>
                )}
              </Card>
            </div>
          )}

          {tab === 'map' && (
            <Card dark={dark} title="Charger map" subtitle="Geo positions from station registry">
              <div className={cn('relative h-[480px] rounded-2xl overflow-hidden border', subtle, dark ? 'bg-[#071018]' : 'bg-slate-200')}>
                <div className={cn('absolute inset-0 opacity-40', dark ? 'bg-[radial-gradient(circle_at_30%_40%,#064e3b,transparent_50%),radial-gradient(circle_at_70%_60%,#1e3a5f,transparent_45%)]' : 'bg-[radial-gradient(circle_at_30%_40%,#a7f3d0,transparent_50%),radial-gradient(circle_at_70%_60%,#bfdbfe,transparent_45%)]')} />
                <div className="absolute inset-0 opacity-20" style={{ backgroundImage: 'linear-gradient(to right, currentColor 1px, transparent 1px), linear-gradient(to bottom, currentColor 1px, transparent 1px)', backgroundSize: '40px 40px' }} />
                {mapStations.map((s) => {
                  const { x, y } = project(Number(s.latitude), Number(s.longitude));
                  return (
                    <button
                      key={s.charge_point_id}
                      type="button"
                      title={s.charge_point_id}
                      onClick={() => { setSelected(s.charge_point_id); setTab('live'); }}
                      className="absolute -translate-x-1/2 -translate-y-1/2 group"
                      style={{ left: `${x}%`, top: `${y}%` }}
                    >
                      <span className={cn(
                        'block w-3.5 h-3.5 rounded-full ring-4',
                        s.connected ? 'bg-emerald-400 ring-emerald-400/30' : 'bg-slate-400 ring-slate-400/20',
                        s.status === 'charging' && 'animate-pulse'
                      )} />
                      <span className={cn(
                        'absolute left-4 top-1/2 -translate-y-1/2 whitespace-nowrap text-[10px] font-semibold px-2 py-1 rounded-md opacity-0 group-hover:opacity-100 transition-opacity',
                        dark ? 'bg-black/80 text-white' : 'bg-white shadow text-slate-800'
                      )}>
                        {s.charge_point_id} · {s.city}
                      </span>
                    </button>
                  );
                })}
                {!mapStations.length && (
                  <div className="absolute inset-0 flex items-center justify-center text-sm text-slate-500">No geo-tagged stations</div>
                )}
              </div>
            </Card>
          )}

          {tab === 'sessions' && (
            <DataTable
              dark={dark}
              title="Charging sessions"
              columns={['Session', 'Station', 'User / Tag', 'Status', 'Energy', 'Started']}
              rows={sessions.map((s) => [
                s.session_id,
                s.charge_point_id,
                s.user_id || s.id_tag || '—',
                s.status,
                s.energy_kwh != null ? `${s.energy_kwh} kWh` : '—',
                s.started_at ? new Date(s.started_at).toLocaleString() : '—',
              ])}
            />
          )}

          {tab === 'transactions' && (
            <DataTable
              dark={dark}
              title="OCPP transactions"
              columns={['TX', 'Station', 'Connector', 'IdTag', 'Status', 'kWh', 'Cost', 'Start']}
              rows={transactions.map((t) => [
                t.transaction_id,
                t.charge_point_id,
                t.connector_id,
                t.id_tag,
                t.status,
                t.energy_kwh ?? '—',
                t.cost != null ? `${t.cost} ${t.currency || ''}` : '—',
                t.start_timestamp ? new Date(t.start_timestamp).toLocaleString() : '—',
              ])}
            />
          )}

          {tab === 'energy' && (
            <div className="grid md:grid-cols-2 gap-4">
              <Card dark={dark} title="Energy summary">
                <div className="grid grid-cols-2 gap-3">
                  <Meta dark={dark} k="Total delivered" v={`${analytics?.energy_kwh ?? 0} kWh`} />
                  <Meta dark={dark} k="Completed sessions" v={String(analytics?.completed_sessions ?? 0)} />
                  <Meta dark={dark} k="Active sessions" v={String(analytics?.active_sessions ?? 0)} />
                  <Meta dark={dark} k="Avg / session" v={`${analytics?.completed_sessions ? (Number(analytics.energy_kwh) / analytics.completed_sessions).toFixed(2) : 0} kWh`} />
                </div>
              </Card>
              <Card dark={dark} title="By station">
                <StationEnergy dark={dark} transactions={transactions} />
              </Card>
            </div>
          )}

          {tab === 'revenue' && (
            <Card dark={dark} title="Revenue" subtitle="From completed transactions with cost">
              <div className="grid sm:grid-cols-3 gap-3 mb-4">
                <Kpi dark={dark} label="Total revenue" value={Number(analytics?.revenue || 0).toFixed(2)} suffix={analytics?.currency || 'TND'} icon={TrendingUp} accent="emerald" />
                <Kpi dark={dark} label="Paying sessions" value={transactions.filter((t) => t.cost != null).length} icon={CreditCard} />
                <Kpi dark={dark} label="ARPU (session)" value={
                  transactions.filter((t) => t.cost != null).length
                    ? (Number(analytics?.revenue || 0) / transactions.filter((t) => t.cost != null).length).toFixed(2)
                    : '0'
                } icon={BarChart3} />
              </div>
              <DataTable
                dark={dark}
                title=""
                embedded
                columns={['TX', 'Station', 'kWh', 'Cost', 'Currency']}
                rows={transactions.filter((t) => t.cost != null).map((t) => [
                  t.transaction_id, t.charge_point_id, t.energy_kwh, t.cost, t.currency || 'TND',
                ])}
              />
            </Card>
          )}

          {(tab === 'alerts' || tab === 'faults') && (
            <Card dark={dark} title={tab === 'faults' ? 'Fault management' : 'Alerts'} subtitle="NOC queue">
              <div className="space-y-2">
                {(tab === 'faults' ? alerts.filter((a) => a.severity === 'critical' || /fault|offline|error/i.test(a.code || '')) : alerts).map((a) => (
                  <div key={a.alert_id} className={cn('rounded-xl border p-3 flex flex-col sm:flex-row sm:items-center gap-2', subtle)}>
                    <SeverityDot s={a.severity} />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold">{a.title} <span className={cn('font-normal', muted)}>({a.alert_id})</span></p>
                      <p className={cn('text-[11px]', muted)}>{a.charge_point_id} · {a.code} · {a.status}</p>
                      <p className={cn('text-xs mt-1', muted)}>{a.body}</p>
                    </div>
                    {a.status === 'open' && (
                      <button
                        type="button"
                        className={btnPrimary(dark)}
                        onClick={() => ocppClient.resolveAlert(a.alert_id).then(() => load(true))}
                      >
                        Resolve
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </Card>
          )}

          {tab === 'firmware' && (
            <Card dark={dark} title="Firmware status" subtitle="Per-station firmware inventory">
              <DataTable
                dark={dark}
                embedded
                title=""
                columns={['Station', 'Model', 'Firmware', 'Connected', 'Last boot']}
                rows={stations.map((s) => [
                  s.charge_point_id,
                  s.model,
                  s.firmware_version || '—',
                  s.connected ? 'yes' : 'no',
                  s.last_boot ? new Date(s.last_boot).toLocaleString() : '—',
                ])}
              />
              <p className={cn('text-xs mt-3', muted)}>
                Push UpdateFirmware via Live view or REST <code className="text-emerald-400">POST /stations/:id/firmware</code>. Jobs persist in <code>ocpp_firmware_jobs</code>.
              </p>
            </Card>
          )}

          {tab === 'diagnostics' && (
            <Card dark={dark} title="Diagnostics" subtitle="GetDiagnostics + status notifications">
              <p className={cn('text-sm mb-3', muted)}>
                Request diagnostics packages from online charge points. Results stream back via DiagnosticsStatusNotification and are stored in <code>ocpp_diagnostics</code>.
              </p>
              <div className="flex flex-wrap gap-2">
                {stations.slice(0, 6).map((s) => (
                  <CmdBtn
                    key={s.charge_point_id}
                    dark={dark}
                    busy={busy}
                    label={`Diag ${s.charge_point_id}`}
                    onClick={() => runCmd('GetDiagnostics', () => ocppClient.command(s.charge_point_id, 'GetDiagnostics', { location: 'https://csms.kynetik.tn/diag/' }))}
                    icon={FileWarning}
                  />
                ))}
              </div>
              <div className="mt-4">
                <p className={cn('text-xs font-semibold mb-2', muted)}>Faulted / offline stations</p>
                <div className="flex flex-wrap gap-2">
                  {faultStations.map((s) => (
                    <span key={s.charge_point_id} className={cn('text-xs px-2 py-1 rounded-lg border', subtle)}>{s.charge_point_id} · {s.status}</span>
                  ))}
                  {!faultStations.length && <span className="text-emerald-400 text-sm">No faulted stations</span>}
                </div>
              </div>
            </Card>
          )}

          {tab === 'reports' && (
            <div className="grid md:grid-cols-2 gap-4">
              <Card dark={dark} title="Operational report">
                <ul className={cn('text-sm space-y-2', muted)}>
                  <li>• Fleet size: {analytics?.stations_total}</li>
                  <li>• Online ratio: {analytics?.stations_total ? ((analytics.stations_online / analytics.stations_total) * 100).toFixed(0) : 0}%</li>
                  <li>• Session success pool: {analytics?.completed_sessions} completed / {analytics?.active_sessions} active</li>
                  <li>• Open alerts: {analytics?.open_alerts} ({analytics?.critical_alerts} critical)</li>
                </ul>
              </Card>
              <Card dark={dark} title="Export hooks">
                <p className={cn('text-sm', muted)}>
                  REST: <code className="text-emerald-400">GET /reports/energy</code>, <code className="text-emerald-400">GET /analytics/overview</code>, <code className="text-emerald-400">GET /transactions</code>.
                  Wire BI tools to the same Postgres views for warehouse sync.
                </p>
              </Card>
            </div>
          )}

          {tab === 'users' && (
            <DataTable
              dark={dark}
              title="Users"
              columns={['User ID', 'Email', 'Name', 'Role', 'Org', 'Status']}
              rows={users.map((u) => [u.user_id, u.email, u.full_name, u.role, u.organization, u.status])}
            />
          )}

          {tab === 'roles' && (
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {roles.map((r) => (
                <Card key={r.id || r.code} dark={dark} title={r.name || r.code} subtitle={r.code}>
                  <p className={cn('text-xs mb-2', muted)}>{r.description}</p>
                  <div className="flex flex-wrap gap-1">
                    {(Array.isArray(r.permissions) ? r.permissions : []).map((p: string) => (
                      <span key={p} className={cn('text-[10px] px-2 py-0.5 rounded-full border font-mono', subtle)}>{p}</span>
                    ))}
                  </div>
                </Card>
              ))}
              {!roles.length && <p className={muted}>No roles seeded</p>}
            </div>
          )}

          {tab === 'rfid' && (
            <DataTable
              dark={dark}
              title="RFID / IdTags"
              columns={['IdTag', 'User', 'Status', 'Label']}
              rows={idTags.map((t) => [t.id_tag, t.user_id || '—', t.status, t.label || '—'])}
            />
          )}

          {tab === 'commands' && (
            <DataTable
              dark={dark}
              title="Pending / recent commands"
              columns={['Command', 'Station', 'Action', 'Status', 'By', 'Created']}
              rows={commands.map((c) => [
                c.command_id,
                c.charge_point_id,
                c.action,
                c.status,
                c.requested_by,
                c.created_at ? new Date(c.created_at).toLocaleString() : '—',
              ])}
            />
          )}

          {tab === 'events' && (
            <DataTable
              dark={dark}
              title="OCPP event log"
              columns={['Time', 'Dir', 'Action', 'Station', 'Msg']}
              rows={events.map((e) => [
                e.created_at ? new Date(e.created_at).toLocaleString() : '—',
                e.direction,
                e.action,
                e.charge_point_id,
                e.message_id,
              ])}
            />
          )}

          {tab === 'mobile' && (
            <Card dark={dark} title="Mobile API" subtitle="/api/ocpp/v1/mobile/* on CSMS process">
              <div className="grid md:grid-cols-2 gap-3 text-sm">
                {[
                  ['POST /mobile/auth/login', 'JWT for drivers'],
                  ['GET /mobile/chargers', 'Discovery + filters'],
                  ['GET /mobile/chargers/:id', 'Details + connectors'],
                  ['POST .../start|stop', 'Remote start/stop'],
                  ['GET /mobile/sessions', 'History'],
                  ['GET|POST /mobile/favorites', 'Favorites'],
                  ['GET /mobile/profile', 'Profile'],
                  ['GET /mobile/notifications', 'Inbox'],
                ].map(([p, d]) => (
                  <div key={p} className={cn('rounded-xl border p-3', subtle)}>
                    <p className="font-mono text-xs text-emerald-400">{p}</p>
                    <p className={cn('text-xs mt-1', muted)}>{d}</p>
                  </div>
                ))}
              </div>
            </Card>
          )}

          {tab === 'docs' && (
            <div className="grid md:grid-cols-2 gap-4">
              <Card dark={dark} title="Architecture">
                <ul className={cn('text-sm space-y-2 list-disc pl-4', muted)}>
                  <li>OCPP 1.6J JSON WebSocket central system (`ocpp-csms`)</li>
                  <li>REST for dashboard + mobile with JWT / API key RBAC</li>
                  <li>Postgres domain tables (stations, TX, meters, RFID, profiles…)</li>
                  <li>Event queue + background jobs (offline reconcile, notify)</li>
                  <li>Smart charging profile builder + composite schedule</li>
                  <li>OpenAPI at <code className="text-emerald-400">/api/docs</code></li>
                  <li>Docker Compose for single-node deploy; LB sticky WS for HA</li>
                </ul>
              </Card>
              <Card dark={dark} title="OCPP coverage">
                <p className={cn('text-xs leading-relaxed', muted)}>
                  Authorize, BootNotification, ChangeAvailability, ChangeConfiguration, ClearCache, DataTransfer,
                  GetConfiguration, Heartbeat, MeterValues, RemoteStart/Stop, Reset, Start/StopTransaction,
                  StatusNotification, UnlockConnector, GetDiagnostics, DiagnosticsStatusNotification,
                  FirmwareStatusNotification, UpdateFirmware, GetLocalListVersion, SendLocalList, ReserveNow,
                  CancelReservation, Set/ClearChargingProfile, GetCompositeSchedule, TriggerMessage.
                </p>
                <div className="mt-4 flex flex-wrap gap-2">
                  <Link to="/ocpp" className={btnPrimary(dark)}>OCPP lab console <ChevronRight size={14} /></Link>
                  <Link to="/engineering-pack" className={cn('inline-flex items-center gap-1 text-xs font-semibold px-3 py-2 rounded-lg border', subtle)}>Engineering pack</Link>
                </div>
              </Card>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}

/* ── UI atoms ───────────────────────────────────────────────────────── */

function inputCls(dark: boolean) {
  return cn(
    'w-full rounded-lg border px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-emerald-400/40',
    dark ? 'bg-black/30 border-white/10' : 'bg-white border-slate-200'
  );
}
function btnPrimary(dark: boolean) {
  return cn(
    'inline-flex items-center justify-center gap-1.5 rounded-lg px-3 py-2 text-xs font-bold',
    dark ? 'bg-emerald-400 text-black hover:bg-emerald-300' : 'bg-emerald-600 text-white hover:bg-emerald-500'
  );
}

function Card({ dark, title, subtitle, children, className, action, embedded }: {
  dark: boolean; title: string; subtitle?: string; children: ReactNode; className?: string; action?: ReactNode; embedded?: boolean;
}) {
  return (
    <section className={cn(
      !embedded && 'rounded-2xl border p-4 md:p-5',
      !embedded && (dark ? 'bg-[#0b1220]/90 border-white/10' : 'bg-white border-slate-200 shadow-sm'),
      className
    )}>
      {(title || action) && (
        <div className="flex items-start justify-between gap-3 mb-3">
          <div>
            {title && <h2 className="text-sm font-semibold tracking-tight">{title}</h2>}
            {subtitle && <p className={cn('text-[11px] mt-0.5', dark ? 'text-slate-500' : 'text-slate-500')}>{subtitle}</p>}
          </div>
          {action}
        </div>
      )}
      {children}
    </section>
  );
}

function Kpi({ dark, label, value, icon: Icon, accent, suffix }: {
  dark: boolean; label: string; value: any; icon: typeof Zap; accent?: 'emerald' | 'amber' | 'rose'; suffix?: string;
}) {
  const color =
    accent === 'emerald' ? 'text-emerald-400' :
    accent === 'amber' ? 'text-amber-400' :
    accent === 'rose' ? 'text-rose-400' : (dark ? 'text-slate-200' : 'text-slate-800');
  return (
    <div className={cn('rounded-2xl border p-3', dark ? 'bg-[#0b1220]/90 border-white/10' : 'bg-white border-slate-200')}>
      <div className="flex items-center justify-between mb-2">
        <span className={cn('text-[10px] uppercase tracking-wider font-semibold', dark ? 'text-slate-500' : 'text-slate-500')}>{label}</span>
        <Icon size={14} className={color} />
      </div>
      <p className={cn('text-xl font-bold tabular-nums', color)}>
        {value ?? '—'}
        {suffix && <span className="text-xs font-semibold ml-1 opacity-70">{suffix}</span>}
      </p>
    </div>
  );
}

function StatusPill({ status, dark }: { status?: string; dark: boolean }) {
  const s = String(status || 'unknown').toLowerCase();
  let cls = dark ? 'bg-slate-500/20 text-slate-300' : 'bg-slate-100 text-slate-600';
  if (s.includes('online') || s === 'available' || s === 'accepted') cls = 'bg-emerald-500/15 text-emerald-400';
  if (s.includes('charg') || s === 'occupied' || s === 'active') cls = 'bg-amber-500/15 text-amber-400';
  if (s.includes('fault') || s.includes('offline') || s.includes('error')) cls = 'bg-rose-500/15 text-rose-400';
  return <span className={cn('text-[10px] font-bold uppercase tracking-wide px-2 py-0.5 rounded-full', cls)}>{status || '—'}</span>;
}

function SeverityDot({ s }: { s?: string }) {
  const c = s === 'critical' ? 'bg-rose-500' : s === 'warning' ? 'bg-amber-400' : 'bg-sky-400';
  return <span className={cn('w-2 h-2 rounded-full shrink-0', c)} />;
}

function Meta({ dark, k, v }: { dark: boolean; k: string; v: string }) {
  return (
    <div className={cn('rounded-xl border px-3 py-2', dark ? 'border-white/10 bg-black/20' : 'border-slate-200 bg-slate-50')}>
      <p className={cn('text-[10px] uppercase tracking-wider', dark ? 'text-slate-500' : 'text-slate-500')}>{k}</p>
      <p className="text-xs font-semibold mt-0.5 break-all">{v}</p>
    </div>
  );
}

function CmdBtn({ dark, label, onClick, busy, icon: Icon }: {
  dark: boolean; label: string; onClick: () => void; busy: string | null; icon: typeof Zap;
}) {
  const isBusy = busy === label;
  return (
    <button
      type="button"
      disabled={!!busy}
      onClick={onClick}
      className={cn(
        'inline-flex items-center gap-1.5 rounded-lg border px-3 py-2 text-xs font-semibold disabled:opacity-50',
        dark ? 'border-white/10 hover:bg-white/5' : 'border-slate-200 hover:bg-slate-50'
      )}
    >
      {isBusy ? <Loader2 size={14} className="animate-spin" /> : <Icon size={14} />}
      {label}
    </button>
  );
}

function DataTable({ dark, title, columns, rows, embedded }: {
  dark: boolean; title: string; columns: string[]; rows: any[][]; embedded?: boolean;
}) {
  const table = (
    <div className="overflow-x-auto -mx-1">
      <table className="w-full text-left text-xs">
        <thead>
          <tr className={cn('border-b', dark ? 'border-white/10 text-slate-500' : 'border-slate-200 text-slate-500')}>
            {columns.map((c) => (
              <th key={c} className="px-2 py-2 font-semibold whitespace-nowrap">{c}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((r, i) => (
            <tr key={i} className={cn('border-b', dark ? 'border-white/5' : 'border-slate-100')}>
              {r.map((cell, j) => (
                <td key={j} className="px-2 py-2 whitespace-nowrap max-w-[200px] truncate">{cell ?? '—'}</td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
      {!rows.length && <p className={cn('text-sm p-4 text-center', dark ? 'text-slate-500' : 'text-slate-500')}>No rows</p>}
    </div>
  );
  if (embedded) return table;
  return <Card dark={dark} title={title}>{table}</Card>;
}

function StationEnergy({ dark, transactions }: { dark: boolean; transactions: any[] }) {
  const map: Record<string, number> = {};
  for (const t of transactions) {
    map[t.charge_point_id] = (map[t.charge_point_id] || 0) + Number(t.energy_kwh || 0);
  }
  const entries = Object.entries(map).sort((a, b) => b[1] - a[1]);
  const max = Math.max(...entries.map(([, v]) => v), 1);
  return (
    <div className="space-y-2">
      {entries.map(([id, kwh]) => (
        <div key={id}>
          <div className="flex justify-between text-[11px] mb-1">
            <span className="font-mono">{id}</span>
            <span>{kwh.toFixed(1)} kWh</span>
          </div>
          <div className={cn('h-1.5 rounded-full overflow-hidden', dark ? 'bg-white/10' : 'bg-slate-200')}>
            <div className="h-full rounded-full bg-emerald-400" style={{ width: `${(kwh / max) * 100}%` }} />
          </div>
        </div>
      ))}
      {!entries.length && <p className="text-sm text-slate-500">No data</p>}
    </div>
  );
}

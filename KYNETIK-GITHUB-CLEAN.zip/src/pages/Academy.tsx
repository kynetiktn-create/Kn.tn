import { useEffect, useState } from 'react';
import { BookOpen, Award, Clock, Play, Users, CheckCircle2 } from 'lucide-react';
import SectionHeader from '../components/SectionHeader';
import LoadingState from '../components/LoadingState';
import ErrorState from '../components/ErrorState';
import Logo from '../components/Logo';
import { apiGet, cn } from '../lib/utils';

interface Course {
  id: number;
  title: string;
  level: string;
  duration: string;
  modules: number;
  description: string;
  sort_order: number;
}

interface Asset {
  id: number;
  title: string;
  category: string;
  description: string;
  meta: string | null;
}

export default function Academy() {
  const [courses, setCourses] = useState<Course[]>([]);
  const [assets, setAssets] = useState<Asset[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [active, setActive] = useState<Course | null>(null);

  useEffect(() => {
    Promise.all([
      apiGet<Course[]>('/api/academy-courses'),
      apiGet<Asset[]>('/api/design-assets?category=academy'),
    ])
      .then(([c, a]) => {
        setCourses(c);
        setAssets(a);
        setActive(c[0] || null);
      })
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <div className="p-10"><LoadingState label="Loading Academy platform…" /></div>;
  if (error) return <div className="p-10"><ErrorState message={error} /></div>;

  return (
    <div className="max-w-6xl mx-auto px-6 md:px-10 py-12 md:py-16">
      <SectionHeader
        eyebrow="UI/UX · KYNETIK Academy"
        title="Learning platform"
        description="Certified training product UI — course catalog, learning path, progress and installer badge system nested in the master brand."
      />

      {/* Platform shell */}
      <div className="rounded-2xl border border-white/10 overflow-hidden poster-shadow bg-kyn-void mb-10">
        <div className="relative min-h-[220px] flex items-end">
          <img src="/images/academy.jpg" alt="" className="absolute inset-0 w-full h-full object-cover opacity-40" />
          <div className="absolute inset-0 bg-gradient-to-t from-kyn-void via-kyn-void/70 to-transparent" />
          <div className="relative z-10 p-8 w-full flex flex-wrap items-end justify-between gap-4">
            <div>
              <div className="inline-flex items-center gap-2 mb-3">
                <Logo size="sm" showWordmark={false} glowing />
                <span className="font-display font-bold tracking-[0.18em] text-sm">
                  KYNETIK <span className="text-kyn-green">ACADEMY</span>
                </span>
              </div>
              <h2 className="font-display text-2xl md:text-3xl font-bold max-w-md">
                Former les experts de la mobilité électrique
              </h2>
            </div>
            <div className="flex gap-4 text-center">
              {[
                { v: courses.length.toString(), l: 'Cours' },
                { v: '1.2k', l: 'Apprenants' },
                { v: '94%', l: 'Réussite' },
              ].map((s) => (
                <div key={s.l} className="px-3">
                  <p className="font-display text-xl font-bold text-kyn-green">{s.v}</p>
                  <p className="text-[10px] text-kyn-metal">{s.l}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="p-6 md:p-8 grid lg:grid-cols-[1fr_320px] gap-6">
          <div>
            <p className="text-xs text-kyn-metal uppercase tracking-wider mb-3">Catalogue</p>
            <div className="space-y-3">
              {courses.map((c) => (
                <button
                  key={c.id}
                  type="button"
                  onClick={() => setActive(c)}
                  className={cn(
                    'w-full text-left rounded-2xl border p-4 transition-all',
                    active?.id === c.id
                      ? 'border-kyn-green/40 bg-kyn-green/5'
                      : 'border-white/8 bg-kyn-steel/30 hover:border-white/15'
                  )}
                >
                  <div className="flex flex-wrap items-start justify-between gap-2">
                    <div>
                      <p className="font-display font-semibold">{c.title}</p>
                      <p className="text-xs text-kyn-metal mt-1 line-clamp-2">{c.description}</p>
                    </div>
                    <span className="text-[10px] px-2 py-1 rounded-full bg-white/5 text-kyn-green border border-kyn-green/20">
                      {c.level}
                    </span>
                  </div>
                  <div className="mt-3 flex gap-4 text-[10px] text-kyn-metal">
                    <span className="inline-flex items-center gap-1"><Clock size={11} />{c.duration}</span>
                    <span className="inline-flex items-center gap-1"><BookOpen size={11} />{c.modules} modules</span>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {active && (
            <div className="rounded-2xl border border-white/10 bg-kyn-charcoal p-5 h-fit">
              <div className="aspect-video rounded-xl bg-kyn-black border border-white/8 flex items-center justify-center relative overflow-hidden mb-4">
                <img src="/images/tech-abstract.jpg" alt="" className="absolute inset-0 w-full h-full object-cover opacity-40" />
                <button type="button" className="relative z-10 w-12 h-12 rounded-full bg-kyn-green text-kyn-black flex items-center justify-center glow-green">
                  <Play size={18} fill="currentColor" />
                </button>
              </div>
              <h3 className="font-display font-bold">{active.title}</h3>
              <p className="text-xs text-kyn-metal mt-2">{active.description}</p>
              <div className="mt-4 space-y-2">
                {Array.from({ length: Math.min(active.modules, 5) }).map((_, i) => (
                  <div key={i} className="flex items-center gap-2 text-xs">
                    <CheckCircle2 size={12} className={i < 2 ? 'text-kyn-green' : 'text-kyn-metal'} />
                    <span className={i < 2 ? 'text-kyn-silver' : 'text-kyn-metal'}>Module 0{i + 1}</span>
                  </div>
                ))}
              </div>
              <button type="button" className="mt-5 w-full rounded-xl bg-kyn-green text-kyn-black text-xs font-bold py-3">
                Continuer le parcours
              </button>
              <div className="mt-3 flex items-center gap-2 text-[10px] text-kyn-metal">
                <Award size={12} className="text-kyn-green" /> Certification KYNETIK à la fin du parcours
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Light education templates */}
      <div className="grid md:grid-cols-2 gap-6 mb-10">
        <div className="rounded-2xl bg-white text-kyn-black p-8 poster-shadow">
          <div className="flex items-center gap-2 mb-6">
            <div className="w-8 h-8 rounded-lg bg-kyn-green flex items-center justify-center">
              <BookOpen size={16} className="text-kyn-black" />
            </div>
            <span className="font-display font-bold text-sm tracking-wide">KYNETIK ACADEMY</span>
          </div>
          <p className="text-xs font-semibold text-kyn-green uppercase tracking-widest mb-2">Social learning</p>
          <h3 className="font-display text-2xl font-bold">Comment fonctionne une borne AC ?</h3>
          <div className="mt-6 space-y-3">
            {['Réseau électrique', 'Chargeur embarqué', 'Contrôle de session', 'Sécurité différentielle'].map((s, i) => (
              <div key={s} className="flex items-center gap-3">
                <span className="w-6 h-6 rounded-full bg-kyn-green/15 text-kyn-green text-xs font-bold flex items-center justify-center">{i + 1}</span>
                <span className="text-sm font-medium">{s}</span>
              </div>
            ))}
          </div>
        </div>
        <div className="rounded-2xl border border-white/10 bg-kyn-charcoal p-8">
          <Users className="text-kyn-green mb-4" size={22} />
          <h3 className="font-display text-xl font-bold">Audience & format</h3>
          <ul className="mt-4 space-y-3 text-sm text-kyn-silver">
            <li>Techniciens & installateurs certifiés</li>
            <li>Ateliers terrain + e-learning</li>
            <li>Badge digital + foil print partner kit</li>
            <li>Tone: clair, pédagogique, premium</li>
          </ul>
        </div>
      </div>

      <div className="grid md:grid-cols-3 gap-4">
        {assets.map((a) => (
          <div key={a.id} className="glass-card rounded-2xl p-6">
            <h3 className="font-display font-semibold">{a.title}</h3>
            <p className="text-sm text-kyn-metal mt-2">{a.description}</p>
            {a.meta && <p className="mt-3 text-xs text-kyn-green font-mono">{a.meta}</p>}
          </div>
        ))}
      </div>
    </div>
  );
}

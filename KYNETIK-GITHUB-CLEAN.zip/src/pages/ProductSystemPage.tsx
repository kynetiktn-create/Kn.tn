import { useEffect, useMemo, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  ArrowRight, Check, Zap, Wifi, Shield, Cpu, Radio, Cable,
  Plug, Cloud, Smartphone, ChevronRight, Menu, X, Gauge, Leaf,
  Building2, Home, Hotel, Briefcase, MapPin, Landmark, Factory
} from 'lucide-react';
import BrandLogo from '../components/BrandLogo';
import AppDownloadCTA from '../components/AppDownloadCTA';
import LoadingState from '../components/LoadingState';
import ErrorState from '../components/ErrorState';
import { apiGet, cn } from '../lib/utils';

interface Product {
  id: number;
  name: string;
  tagline: string;
  power: string;
  specs: string;
  features: string;
  category: string;
  image_url: string;
  accent: string;
  sort_order: number;
}

type Series = 'flex' | 'nova' | 'prime' | 'go' | 'edge' | 'pro' | 'family';
type Config = string;

function parseList(s: string | null | undefined): string[] {
  if (!s) return [];
  try {
    const v = JSON.parse(s);
    return Array.isArray(v) ? v : [];
  } catch {
    return s.split(',').map((x) => x.trim()).filter(Boolean);
  }
}

const seriesMeta: Record<
  Series,
  {
    label: string;
    title: string;
    subtitle: string;
    finish: string;
    accent: string;
    glow: string;
    stage: string;
    audience: string;
    configs: { id: string; label: string; match: string }[];
  }
> = {
  flex: {
    label: 'FLEX',
    title: 'FLEX Series',
    subtitle: 'Simple smart wallbox for premium homes & light business',
    finish: 'Matte Black + Soft Violet accent',
    accent: '#a78bfa',
    glow: 'rgba(167,139,250,0.18)',
    stage: 'rgba(167,139,250,0.12)',
    audience: 'Residential premium · Villas · PME',
    configs: [
      { id: 'socket', label: 'Socket', match: 'socket' },
      { id: 'tethered', label: 'Tethered', match: 'tethered' },
    ],
  },
  nova: {
    label: 'NOVA',
    title: 'NOVA Series',
    subtitle: 'Matte black signature wall charger for home & SME',
    finish: 'Matte Black + Electric Green',
    accent: '#00e676',
    glow: 'rgba(0,230,118,0.16)',
    stage: 'rgba(0,230,118,0.12)',
    audience: 'Residential · SME',
    configs: [
      { id: 'socket', label: 'Socket', match: 'socket' },
      { id: 'tethered', label: 'Tethered', match: 'tethered' },
    ],
  },
  prime: {
    label: 'PRIME',
    title: 'PRIME Series',
    subtitle: 'Pearl white premium line for workplace & hospitality',
    finish: 'Pearl White + Teal LED',
    accent: '#2dd4bf',
    glow: 'rgba(45,212,191,0.18)',
    stage: 'rgba(45,212,191,0.14)',
    audience: 'Workplace · Hotels · Parking',
    configs: [
      { id: 'socket', label: 'Socket', match: 'socket' },
      { id: 'tethered', label: 'Tethered', match: 'tethered' },
    ],
  },
  go: {
    label: 'GO',
    title: 'GO Series',
    subtitle: 'Portable EVSE with LCD control box — Type 2 to CEE 32A or Schuko, charge anywhere',
    finish: 'Matte Black Portable + LCD',
    accent: '#60a5fa',
    glow: 'rgba(96,165,250,0.22)',
    stage: 'rgba(96,165,250,0.16)',
    audience: 'Travel · Fleets · Sites · Events',
    configs: [
      { id: 'cee', label: 'CEE 32A', match: 'cee' },
      { id: 'schuko', label: 'Schuko', match: 'schuko' },
    ],
  },
  edge: {
    label: 'EDGE',
    title: 'EDGE Series',
    subtitle: 'Compact urban chargers — wall graphite or pedestal white for shared parking',
    finish: 'Graphite Wall · White Pedestal',
    accent: '#a3e635',
    glow: 'rgba(163,230,53,0.18)',
    stage: 'rgba(163,230,53,0.14)',
    audience: 'Urban · Shared parking · Campus',
    configs: [
      { id: 'wall', label: 'Wall', match: 'wall' },
      { id: 'pedestal', label: 'Pedestal', match: 'pedestal' },
    ],
  },
  pro: {
    label: 'PRO',
    title: 'PRO Series',
    subtitle: 'Commercial pedestal chargers — dual-cable or socket for fleets and public parking',
    finish: 'Matte Black Pedestal + Green Frame',
    accent: '#4ade80',
    glow: 'rgba(74,222,128,0.2)',
    stage: 'rgba(74,222,128,0.14)',
    audience: 'Commercial · Fleet · Public parking',
    configs: [
      { id: 'tethered', label: 'Dual Cable', match: 'tethered' },
      { id: 'socket', label: 'Socket', match: 'socket' },
    ],
  },
  family: {
    label: 'FAMILY',
    title: 'Full Hardware Family',
    subtitle: 'Wall, portable and depot — one KYNETIK ecosystem',
    finish: 'System architecture',
    accent: '#00e676',
    glow: 'rgba(0,230,118,0.12)',
    stage: 'rgba(0,230,118,0.1)',
    audience: 'All segments',
    configs: [],
  },
};

function seriesOf(name: string): Series | null {
  const n = name.toUpperCase();
  if (n.includes('FLEX')) return 'flex';
  if (n.includes('NOVA')) return 'nova';
  if (n.includes('PRIME')) return 'prime';
  if (n.includes('GO')) return 'go';
  if (n.includes('EDGE')) return 'edge';
  if (n.includes('PRO')) return 'pro';
  return null;
}

export default function ProductSystemPage() {
  const [searchParams] = useSearchParams();
  const initialSeries = (['flex', 'nova', 'prime', 'go', 'edge', 'pro', 'family'] as Series[]).includes(
    (searchParams.get('series') || '').toLowerCase() as Series
  )
    ? ((searchParams.get('series') || 'go').toLowerCase() as Series)
    : 'go';

  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [series, setSeries] = useState<Series>(initialSeries);
  const [config, setConfig] = useState<Config>(initialSeries === 'go' ? 'cee' : 'socket');
  const [activeId, setActiveId] = useState<number | null>(null);
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const s = (searchParams.get('series') || '').toLowerCase() as Series;
    if ((['flex', 'nova', 'prime', 'go', 'edge', 'pro', 'family'] as Series[]).includes(s)) {
      setSeries(s);
      if (s === 'go') setConfig('cee');
      else if (s === 'edge') setConfig('wall');
      else if (s !== 'family') setConfig('socket');
    }
  }, [searchParams]);

  useEffect(() => {
    apiGet<Product[]>('/api/products')
      .then((data) => {
        const clean = data
          .filter((p) => p.name && !p.name.startsWith('_') && !p.name.includes('Archive'))
          .sort((a, b) => (a.sort_order ?? 0) - (b.sort_order ?? 0));
        setProducts(clean);
        const preferred =
          clean.find((p) => p.name.toUpperCase().includes(initialSeries.toUpperCase())) ||
          clean.find((p) => p.name.toLowerCase().includes('go') && p.name.toLowerCase().includes('cee')) ||
          clean.find((p) => p.name.toLowerCase().includes('go')) ||
          clean[0];
        if (preferred) setActiveId(preferred.id);
      })
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const novaLine = useMemo(() => products.filter((p) => p.name.toUpperCase().includes('NOVA')), [products]);
  const primeLine = useMemo(() => products.filter((p) => p.name.toUpperCase().includes('PRIME')), [products]);
  const goLine = useMemo(() => products.filter((p) => p.name.toUpperCase().includes('GO')), [products]);
  const edgeLine = useMemo(() => products.filter((p) => p.name.toUpperCase().includes('EDGE')), [products]);
  const proLine = useMemo(() => products.filter((p) => p.name.toUpperCase().includes('PRO')), [products]);
  const family = useMemo(() => products, [products]);

  const lineFor = (s: Series) => {
    if (s === 'nova') return novaLine;
    if (s === 'prime') return primeLine;
    if (s === 'go') return goLine;
    if (s === 'edge') return edgeLine;
    if (s === 'pro') return proLine;
    return family;
  };

  const activeLine = lineFor(series);
  const meta = seriesMeta[series];

  const heroProduct = useMemo(() => {
    if (series === 'family') {
      return products.find((p) => p.id === activeId) || products[0] || null;
    }
    const line = lineFor(series);
    const cfg = seriesMeta[series].configs.find((c) => c.id === config);
    const match = line.find((p) => p.name.toLowerCase().includes(cfg?.match || config));
    return match || line[0] || null;
  }, [series, config, novaLine, primeLine, goLine, edgeLine, proLine, products, activeId]);

  useEffect(() => {
    if (heroProduct) setActiveId(heroProduct.id);
  }, [heroProduct?.id]);

  const active = products.find((p) => p.id === activeId) || heroProduct;

  const heroImage = useMemo(() => {
    if (series === 'pro') {
      return config === 'socket' ? '/images/products/pro-socket.png' : '/images/products/pro-tethered.png';
    }
    if (series === 'edge') {
      return config === 'pedestal' ? '/images/products/edge-pedestal.png' : '/images/products/edge-wall.png';
    }
    if (series === 'go') {
      // Official transparent product renders (Type2→CEE / Type2→Schuko)
      return config === 'schuko'
        ? '/images/products/go-schuko.png'
        : '/images/products/go-cee.png';
    }
    if (series === 'prime') {
      // Official cutouts + lifestyle hero for tethered
      return config === 'socket'
        ? '/images/products/prime-socket.png'
        : '/images/products/prime-hero.png';
    }
    if (series === 'flex') {
      return config === 'socket' ? '/images/products/flex-socket.png' : '/images/products/flex-tethered.png';
    }
    if (series === 'nova') {
      return config === 'socket' ? '/images/products/nova-socket.png' : '/images/products/nova-tethered.png';
    }
    return active?.image_url || '/images/products/pro-tethered.png';
  }, [series, config, active]);

  if (loading) {
    return (
      <div className="min-h-screen bg-kyn-black flex items-center justify-center">
        <LoadingState label="Loading GO Series…" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-kyn-black flex items-center justify-center p-8">
        <ErrorState message={error} />
      </div>
    );
  }

  const callouts =
    series === 'pro'
      ? [
          { icon: Factory, title: 'Commercial pedestal', body: 'Full-height column for public & fleet parking' },
          { icon: Zap, title: 'Up to 2× 22 kW', body: 'Dual-cable simultaneous sessions on tethered model' },
          { icon: Radio, title: 'OCPP + RFID', body: 'Screen, contactless auth, Cloud command' },
          { icon: Shield, title: 'IP54 outdoor', body: 'Industrial matte black enclosure' },
          { icon: Cable, title: 'Cable or socket', body: 'Dual Type 2 cables or lateral socket config' },
          { icon: Leaf, title: 'Green LED frame', body: 'Illuminated screen bezel signature KYNETIK' },
        ]
      : series === 'edge'
      ? [
          { icon: Landmark, title: 'Urban footprint', body: 'Compact wall or pedestal for dense shared parking' },
          { icon: Zap, title: '7–22 kW AC', body: 'Workplace and residential shared charging' },
          { icon: Radio, title: 'OCPP + RFID', body: 'Secure access and Cloud supervision' },
          { icon: Shield, title: 'IP54 outdoor', body: 'Graphite wall & pedestal-ready builds' },
          { icon: Cable, title: 'Wall or pedestal', body: 'Socket wall unit or tethered pedestal column' },
          { icon: Leaf, title: 'LED signature', body: 'Electric green ring on every EDGE face' },
        ]
      : series === 'go'
      ? [
          { icon: MapPin, title: 'Charge anywhere', body: 'Portable control box for travel, sites and visits' },
          { icon: Zap, title: 'Adjustable power', body: 'From domestic Schuko to industrial CEE 32A' },
          { icon: Gauge, title: 'LCD status', body: 'Live session feedback on the control unit' },
          { icon: Shield, title: 'Built-in safety', body: 'Protection electronics in a sealed portable body' },
          { icon: Briefcase, title: 'Trunk-ready', body: 'Coiled cable form factor for fleets & road trips' },
          { icon: Leaf, title: 'KYNETIK DNA', body: 'Same brand language as wall NOVA / PRIME lines' },
        ]
      : series === 'prime'
        ? [
            { icon: Zap, title: '7–22 kW AC', body: 'Puissance workplace monophasé / triphasé' },
            { icon: Radio, title: 'OCPP 1.6J', body: 'Cloud, roaming et supervision multi-sites' },
            { icon: Wifi, title: 'WiFi + 4G', body: 'Connectivité redondante hôtels & parkings' },
            { icon: Shield, title: 'IP54 · Safety', body: 'Outdoor-ready, protections électriques' },
            { icon: Building2, title: 'Hospitality finish', body: 'Pearl white pour workplaces premium' },
            { icon: Leaf, title: 'Teal status LED', body: 'Anneau lumineux signature PRIME' },
          ]
        : [
            { icon: Zap, title: '7–22 kW AC', body: 'Charge monophasée ou triphasée' },
            { icon: Radio, title: 'OCPP 1.6J', body: 'Cloud, roaming et supervision' },
            { icon: Wifi, title: 'WiFi + 4G', body: 'Connectivité redondante' },
            { icon: Shield, title: 'IP54 · Safety', body: 'Outdoor-ready' },
            { icon: Cpu, title: 'Smart charging', body: 'Load balancing KYNETIK Cloud' },
            { icon: Leaf, title: 'Green status LED', body: 'Signature electric green' },
          ];

  const configIcon = (id: string) => {
    if (id === 'wall') return Landmark;
    if (id === 'pedestal') return Building2;
    if (id === 'socket' || id === 'schuko') return Plug;
    if (id === 'cee') return Zap;
    if (id === 'tethered') return Cable;
    return Cable;
  };

  return (
    <div className="min-h-screen bg-kyn-black text-white overflow-x-hidden">
      <header
        className={cn(
          'fixed top-0 inset-x-0 z-50 transition-all duration-300',
          scrolled ? 'bg-kyn-black/85 backdrop-blur-xl border-b border-white/5' : 'bg-transparent'
        )}
      >
        <div className="max-w-7xl mx-auto px-5 md:px-8 h-16 md:h-20 flex items-center justify-between">
          <a href="#top" className="flex items-center gap-3">
            <BrandLogo height={30} />
            <span
              className="hidden sm:inline text-[10px] font-semibold tracking-[0.22em] uppercase border rounded-full px-2 py-0.5"
              style={{ color: meta.accent, borderColor: `${meta.accent}55` }}
            >
              Products
            </span>
          </a>
          <nav className="hidden lg:flex items-center gap-7 text-xs font-medium text-kyn-silver">
            {[
              ['#series', 'Series'],
              ['#configs', 'Configs'],
              ['#compare', 'Compare'],
              ['#anatomy', 'Anatomy'],
              ['#family', 'Family'],
              ['#download-app', 'Get the App'],
            ].map(([href, label]) => (
              <a key={href} href={href} className="hover:text-white transition-colors">
                {label}
              </a>
            ))}
          </nav>
          <div className="flex items-center gap-3">
            <Link to="/cloud-platform" className="hidden md:inline text-xs text-kyn-metal hover:text-white">
              Cloud Platform
            </Link>
            <a
              href="#cta"
              className="hidden sm:inline-flex items-center gap-2 px-4 py-2 rounded-full text-xs font-bold text-kyn-black"
              style={{ background: meta.accent }}
            >
              Demander un devis <ArrowRight size={13} />
            </a>
            <button type="button" className="lg:hidden p-2 text-kyn-silver" onClick={() => setMenuOpen(!menuOpen)}>
              {menuOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </div>
        {menuOpen && (
          <div className="lg:hidden border-t border-white/5 bg-kyn-void/95 px-5 py-4 space-y-2">
            {['#series', '#configs', '#compare', '#family', '#download-app', '#cta'].map((href) => (
              <a key={href} href={href} onClick={() => setMenuOpen(false)} className="block py-2 text-sm text-kyn-silver capitalize">
                {href.replace('#', '').replace('-', ' ')}
              </a>
            ))}
          </div>
        )}
      </header>

      {/* HERO */}
      <section id="top" className="relative min-h-screen flex items-center pt-20 pb-16 overflow-hidden">
        <div className="absolute inset-0">
          <div
            className="absolute inset-0"
            style={{
              background: `
                radial-gradient(ellipse 70% 55% at 72% 42%, ${meta.glow}, transparent 58%),
                radial-gradient(ellipse 45% 40% at 18% 30%, ${meta.stage}, transparent 55%),
                radial-gradient(ellipse 50% 30% at 50% 100%, rgba(255,255,255,0.04), transparent 55%)
              `,
            }}
          />
          <div className="absolute inset-0 grid-bg opacity-[0.22]" />
          <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white/10 to-transparent" />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-5 md:px-8 w-full">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-10 items-center">
            <div>
              <motion.p
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
                className="text-[11px] font-semibold tracking-[0.34em] uppercase mb-6"
                style={{ color: meta.accent }}
              >
                Product System · {meta.label}
              </motion.p>

              <motion.h1
                initial={{ opacity: 0, y: 22 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.65, delay: 0.06, ease: [0.22, 1, 0.36, 1] }}
                className="font-display font-bold tracking-[-0.03em] leading-[0.98]"
              >
                <span className="block text-[2.55rem] sm:text-5xl md:text-[3.65rem] text-white">
                  KYNETIK{' '}
                  <span className="text-glow" style={{ color: meta.accent }}>
                    {series === 'family' ? 'HARDWARE' : meta.label}
                  </span>
                </span>
                <span className="mt-3 block text-[1.35rem] sm:text-2xl md:text-[1.85rem] font-medium tracking-[-0.02em] text-kyn-silver/90 leading-snug max-w-xl">
                  {series === 'pro'
                    ? 'Commercial Pedestal Line'
                    : series === 'edge'
                    ? 'Urban Compact Line'
                    : series === 'go'
                    ? 'Portable AC Chargers'
                    : series === 'prime'
                      ? 'Pearl White AC Line'
                      : series === 'nova'
                        ? 'Matte Black AC Line'
                        : 'Complete Range'}
                </span>
              </motion.h1>

              <motion.p
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.55, delay: 0.14, ease: [0.22, 1, 0.36, 1] }}
                className="mt-7 text-[15px] md:text-lg text-kyn-silver/85 max-w-md leading-[1.7] font-normal"
              >
                {meta.subtitle}
              </motion.p>

              {/* Series switcher */}
              <motion.div
                id="series"
                initial={{ opacity: 0, y: 14 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.2 }}
                className="mt-9 inline-flex p-1.5 rounded-full bg-kyn-steel/50 border border-white/[0.09] flex-wrap gap-1 shadow-[inset_0_1px_0_rgba(255,255,255,0.04)]"
              >
                {([
                  ['flex', 'FLEX', Home],
                  ['nova', 'NOVA', Home],
                  ['prime', 'PRIME', Hotel],
                  ['go', 'GO', MapPin],
                  ['edge', 'EDGE', Landmark],
                  ['pro', 'PRO', Factory],
                  ['family', 'FAMILY', Building2],
                ] as const).map(([id, label, Icon]) => (
                  <button
                    key={id}
                    type="button"
                    onClick={() => {
                      setSeries(id);
                      const next = seriesMeta[id];
                      if (next.configs[0]) setConfig(next.configs[0].id);
                      const line = lineFor(id);
                      const p =
                        line.find((x) =>
                          next.configs[0] ? x.name.toLowerCase().includes(next.configs[0].match) : true
                        ) || line[0];
                      if (p) setActiveId(p.id);
                    }}
                    className={cn(
                      'inline-flex items-center gap-2 px-3.5 py-2.5 rounded-full text-xs font-semibold transition-all duration-300',
                      series === id
                        ? 'text-kyn-black shadow-[0_8px_24px_rgba(0,0,0,0.35)]'
                        : 'text-kyn-silver hover:text-white hover:bg-white/[0.04]'
                    )}
                    style={series === id ? { background: seriesMeta[id].accent } : undefined}
                  >
                    <Icon size={14} /> {label}
                  </button>
                ))}
              </motion.div>

              {/* Config toggle */}
              {series !== 'family' && meta.configs.length > 0 && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.45, delay: 0.26 }}
                  className="mt-5 inline-flex p-1.5 rounded-full bg-black/45 border border-white/[0.08] shadow-[inset_0_1px_0_rgba(255,255,255,0.03)]"
                >
                  {meta.configs.map((c) => {
                    const Icon = configIcon(c.id);
                    return (
                      <button
                        key={c.id}
                        type="button"
                        onClick={() => setConfig(c.id)}
                        className={cn(
                          'inline-flex items-center gap-2 px-5 py-2.5 rounded-full text-xs font-semibold transition-all duration-300',
                          config === c.id
                            ? 'text-kyn-black shadow-[0_6px_18px_rgba(0,0,0,0.3)]'
                            : 'text-kyn-silver hover:text-white'
                        )}
                        style={config === c.id ? { background: meta.accent } : undefined}
                      >
                        <Icon size={14} /> {c.label}
                      </button>
                    );
                  })}
                </motion.div>
              )}

              {heroProduct && (
                <motion.div
                  key={heroProduct.id}
                  initial={{ opacity: 0, y: 12 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.45, delay: 0.3 }}
                  className="mt-9"
                >
                  <p className="font-display text-[1.35rem] md:text-2xl font-semibold tracking-tight text-white">
                    {heroProduct.name}
                  </p>
                  <p className="text-sm md:text-[15px] text-kyn-metal mt-2 max-w-md leading-relaxed">
                    {heroProduct.tagline}
                  </p>
                  <div className="mt-5 flex flex-wrap gap-2.5">
                    {parseList(heroProduct.specs).slice(0, 5).map((s) => (
                      <span
                        key={s}
                        className="px-3 py-1.5 rounded-lg border text-[11px] font-medium tracking-wide backdrop-blur-sm"
                        style={{
                          borderColor: `${meta.accent}35`,
                          background: `${meta.accent}10`,
                          color: meta.accent,
                          boxShadow: `0 0 0 1px rgba(0,0,0,0.2), 0 8px 20px ${meta.glow}`,
                        }}
                      >
                        {s}
                      </span>
                    ))}
                  </div>
                </motion.div>
              )}

              <motion.div
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.45, delay: 0.36 }}
                className="mt-11 flex flex-wrap items-center gap-4"
              >
                <a
                  href="#cta"
                  className="group inline-flex items-center gap-2.5 px-7 py-3.5 rounded-full text-sm font-bold text-kyn-black transition-transform duration-300 hover:-translate-y-0.5 active:translate-y-0"
                  style={{
                    background: meta.accent,
                    boxShadow: `0 0 0 1px rgba(255,255,255,0.12), 0 12px 40px ${meta.glow}, 0 4px 14px rgba(0,0,0,0.45)`,
                  }}
                >
                  Commander {meta.label}
                  <ArrowRight size={16} className="transition-transform duration-300 group-hover:translate-x-0.5" />
                </a>
                <a
                  href="#anatomy"
                  className="inline-flex items-center gap-2.5 px-7 py-3.5 rounded-full border border-white/15 bg-white/[0.02] text-sm font-medium text-kyn-silver hover:text-white hover:border-white/30 hover:bg-white/[0.04] transition-all duration-300 shadow-[0_8px_30px_rgba(0,0,0,0.25)]"
                >
                  Voir les détails
                </a>
              </motion.div>
            </div>

            {/* Product stage */}
            <div className="relative flex items-center justify-center min-h-[440px] md:min-h-[600px]">
              {/* Layered studio lighting */}
              <motion.div
                aria-hidden
                className="absolute w-[340px] h-[340px] md:w-[500px] md:h-[500px] rounded-full blur-[100px]"
                style={{ background: meta.stage }}
                animate={{ opacity: [0.55, 0.85, 0.55], scale: [0.96, 1.04, 0.96] }}
                transition={{ duration: 6.5, repeat: Infinity, ease: 'easeInOut' }}
              />
              <div
                aria-hidden
                className="absolute w-[220px] h-[220px] md:w-[300px] md:h-[300px] rounded-full blur-[40px] opacity-40"
                style={{
                  background: `radial-gradient(circle, ${meta.accent}55 0%, transparent 70%)`,
                  top: '18%',
                }}
              />
              <div
                aria-hidden
                className="absolute w-[78%] h-[28%] bottom-[10%] rounded-[100%] blur-2xl"
                style={{
                  background: `radial-gradient(ellipse, ${meta.glow} 0%, rgba(0,0,0,0.75) 70%)`,
                }}
              />
              {/* Soft rim rings */}
              <div
                aria-hidden
                className="absolute w-[260px] h-[260px] md:w-[380px] md:h-[380px] rounded-full border opacity-[0.12]"
                style={{ borderColor: meta.accent }}
              />
              <div
                aria-hidden
                className="absolute w-[320px] h-[320px] md:w-[460px] md:h-[460px] rounded-full border opacity-[0.06]"
                style={{ borderColor: meta.accent }}
              />

              <AnimatePresence mode="wait">
                {series === 'prime' ? (
                  <motion.div
                    key={`${series}-${config}-${heroImage}`}
                    initial={{ opacity: 0, scale: 0.94, y: 20 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.97, y: -12 }}
                    transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
                    className="relative z-10 flex flex-col items-center"
                  >
                    <motion.img
                      src={heroImage}
                      alt={heroProduct?.name || 'KYNETIK PRIME'}
                      className="w-full max-w-[400px] md:max-w-[480px] object-contain select-none"
                      style={{
                        filter: `
                          drop-shadow(0 40px 60px rgba(0,0,0,0.55))
                          drop-shadow(0 18px 50px ${meta.glow})
                          drop-shadow(0 0 40px ${meta.stage})
                        `,
                      }}
                      animate={{ y: [0, -8, 0] }}
                      transition={{ duration: 5.5, repeat: Infinity, ease: 'easeInOut' }}
                    />
                    <div className="mt-5 text-center">
                      <p className="text-[10px] tracking-[0.28em] uppercase text-teal-300/90">PRIME Series · Studio</p>
                      <p className="text-sm font-semibold mt-1.5 text-kyn-silver tracking-tight">
                        {config === 'socket' ? 'Type 2 Socket' : 'Type 2 Tethered'}
                      </p>
                    </div>
                  </motion.div>
                ) : series === 'go' ? (
                  <motion.div
                    key={`${series}-${config}-${heroImage}`}
                    initial={{ opacity: 0, scale: 0.94, y: 20 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.97, y: -12 }}
                    transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
                    className="relative z-10 flex flex-col items-center"
                  >
                    <motion.img
                      src={heroImage}
                      alt={heroProduct?.name || 'KYNETIK GO'}
                      className="max-h-[500px] md:max-h-[580px] w-auto max-w-[260px] md:max-w-[300px] object-contain select-none"
                      style={{
                        filter: `
                          drop-shadow(0 42px 64px rgba(0,0,0,0.6))
                          drop-shadow(0 16px 48px ${meta.glow})
                          drop-shadow(0 0 36px ${meta.stage})
                        `,
                      }}
                      animate={{ y: [0, -10, 0] }}
                      transition={{ duration: 5.8, repeat: Infinity, ease: 'easeInOut' }}
                    />
                    <div className="mt-5 text-center">
                      <p className="text-[10px] tracking-[0.28em] uppercase text-sky-300/90">GO Series · Portable EVSE</p>
                      <p className="text-sm font-semibold mt-1.5 text-kyn-silver tracking-tight">
                        {config === 'schuko' ? 'Type 2 → Schuko' : 'Type 2 → CEE 32A'}
                      </p>
                    </div>
                  </motion.div>
                ) : (
                  <motion.div
                    key={`${series}-${config}-${heroImage}`}
                    initial={{ opacity: 0, scale: 0.94, y: 20 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.97, y: -12 }}
                    transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
                    className="relative z-10 flex flex-col items-center"
                  >
                    <motion.img
                      src={heroImage}
                      alt={heroProduct?.name || 'KYNETIK product'}
                      className={cn(
                        'w-full object-contain select-none',
                        series === 'pro' ? 'max-w-[320px] md:max-w-[380px]' : 'max-w-[440px] md:max-w-[540px]'
                      )}
                      style={{
                        filter: `
                          drop-shadow(0 40px 60px rgba(0,0,0,0.55))
                          drop-shadow(0 18px 50px ${meta.glow})
                          drop-shadow(0 0 40px ${meta.stage})
                        `,
                      }}
                      animate={{ y: [0, -8, 0] }}
                      transition={{ duration: 5.5, repeat: Infinity, ease: 'easeInOut' }}
                    />
                  </motion.div>
                )}
              </AnimatePresence>

              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.5, duration: 0.6 }}
                className="absolute bottom-5 left-1/2 -translate-x-1/2 text-center"
              >
                <p className="text-[10px] tracking-[0.3em] uppercase text-kyn-metal/90">
                  {series === 'prime'
                    ? 'Lifestyle studio · Pearl white'
                    : series === 'go'
                      ? 'Portable EVSE · CEE 32A / Schuko'
                      : `Official 3D · ${meta.finish}`}
                </p>
              </motion.div>
            </div>
          </div>
        </div>
      </section>

      {/* Specs strip */}
      <section className="border-y border-white/5 bg-kyn-void/80">
        <div className="max-w-7xl mx-auto px-5 md:px-8 py-8 grid grid-cols-2 md:grid-cols-4 gap-6">
          {[
            {
              l: 'Power range',
              v:
                series === 'go'
                  ? config === 'schuko'
                    ? '1.8–3.7 kW'
                    : '7–22 kW'
                  : series === 'pro'
                    ? config === 'tethered'
                      ? '2× 7–22 kW'
                      : '7–22 kW'
                  : series === 'family'
                    ? '1.8–44 kW AC'
                    : '7–22 kW',
            },
            {
              l: 'Form factor',
              v:
                series === 'pro'
                  ? 'Commercial pedestal'
                  : series === 'edge'
                    ? 'Wall · Pedestal'
                    : series === 'go'
                      ? 'Portable EVSE'
                      : series === 'family'
                        ? 'Wall · Portable · Pedestal'
                        : 'Wall-mounted',
            },
            {
              l: 'Inlet / plug',
              v:
                series === 'go'
                  ? config === 'schuko'
                    ? 'Type 2 → Schuko'
                    : 'Type 2 → CEE 32A'
                  : series === 'pro'
                    ? config === 'socket'
                      ? 'Type 2 Socket'
                      : 'Dual Type 2 Cable'
                  : config === 'socket'
                    ? 'Type 2 Socket'
                    : 'Type 2 Cable',
            },
            { l: 'Segment', v: meta.audience },
          ].map((s) => (
            <div key={s.l}>
              <p className="text-[10px] uppercase tracking-widest text-kyn-metal">{s.l}</p>
              <p className="font-display text-lg md:text-xl font-semibold mt-1">{s.v}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Dual configs */}
      {series !== 'family' && (
        <section id="configs" className="py-24 md:py-28">
          <div className="max-w-7xl mx-auto px-5 md:px-8">
            <div className="max-w-2xl mb-12">
              <p className="text-xs font-semibold tracking-[0.3em] uppercase mb-3" style={{ color: meta.accent }}>
                {meta.label} line
              </p>
              <h2 className="font-display text-3xl md:text-4xl font-bold">
                {series === 'pro'
                  ? 'Dual cable or socket. Built to serve.'
                  : series === 'edge'
                    ? 'Wall or pedestal. City-ready.'
                    : series === 'go'
                      ? 'Two plugs. Total freedom.'
                      : 'Two configurations. One design language.'}
              </h2>
              <p className="mt-4 text-kyn-silver leading-relaxed">
                {series === 'pro'
                  ? 'PRO Tethered offre deux câbles pour deux véhicules. PRO Socket garde la flexibilité multi-câbles sur une colonne commerciale.'
                  : series === 'go'
                  ? 'GO CEE pour les prises industrielles 32A. GO Schuko pour le réseau domestique — le même boîtier intelligent KYNETIK.'
                  : 'Socket pour flexibilité multi-câbles. Tethered pour le quotidien plug-and-charge.'}
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-5">
              {activeLine.map((p, i) => {
                const isActive = activeId === p.id;
                return (
                  <motion.button
                    key={p.id}
                    type="button"
                    onClick={() => {
                      setActiveId(p.id);
                      const cfg = meta.configs.find((c) => p.name.toLowerCase().includes(c.match));
                      if (cfg) setConfig(cfg.id);
                    }}
                    initial={{ opacity: 0, y: 16 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: i * 0.08 }}
                    className={cn(
                      'text-left rounded-3xl border overflow-hidden transition-all group',
                      isActive ? 'bg-gradient-to-b to-kyn-void' : 'border-white/8 bg-kyn-void hover:border-white/20'
                    )}
                    style={
                      isActive
                        ? {
                            borderColor: `${meta.accent}66`,
                            backgroundImage: `linear-gradient(to bottom, ${meta.accent}18, transparent)`,
                          }
                        : undefined
                    }
                  >
                    <div
                      className={cn(
                        'relative h-64 md:h-72 flex items-center justify-center overflow-hidden',
                        p.image_url.includes('lifestyle') ? '' : ''
                      )}
                      style={{ background: `radial-gradient(circle at center, ${meta.stage}, transparent 60%)` }}
                    >
                      <img
                        src={
                          series === 'go'
                            ? p.name.toLowerCase().includes('schuko')
                              ? '/images/products/go-schuko.png'
                              : '/images/products/go-cee.png'
                            : p.image_url
                        }
                        alt={p.name}
                        className={cn(
                          'transition-transform duration-500 group-hover:scale-105',
                          p.image_url.includes('lifestyle') && series !== 'go'
                            ? 'h-full w-full object-cover'
                            : series === 'go'
                              ? 'h-[92%] w-auto object-contain'
                              : 'h-[85%] w-auto object-contain'
                        )}
                      />
                    </div>
                    <div className="p-6 md:p-7 border-t border-white/5">
                      <div className="flex items-start justify-between gap-3">
                        <div>
                          <p className="text-[10px] uppercase tracking-wider text-kyn-metal">{p.category}</p>
                          <h3 className="font-display text-2xl font-bold mt-1">{p.name}</h3>
                        </div>
                        <span className="font-display font-semibold text-sm" style={{ color: meta.accent }}>
                          {p.power}
                        </span>
                      </div>
                      <p className="mt-3 text-sm text-kyn-silver leading-relaxed">{p.tagline}</p>
                      <div className="mt-5 flex flex-wrap gap-2">
                        {parseList(p.specs).slice(0, 3).map((s) => (
                          <span key={s} className="text-[10px] px-2.5 py-1 rounded-md bg-white/5 border border-white/8 text-kyn-metal">
                            {s}
                          </span>
                        ))}
                      </div>
                    </div>
                  </motion.button>
                );
              })}
            </div>
          </div>
        </section>
      )}

      {/* GO use cases */}
      {series === 'go' && (
        <section className="py-16 md:py-20 border-t border-white/5">
          <div className="max-w-7xl mx-auto px-5 md:px-8">
            <div className="mb-10 max-w-2xl">
              <p className="text-xs font-semibold tracking-[0.3em] uppercase mb-3 text-blue-400">GO Series · Use cases</p>
              <h2 className="font-display text-3xl md:text-4xl font-bold">Portable power for every grid</h2>
              <p className="mt-4 text-kyn-silver leading-relaxed">
                Same Type 2 vehicle gun and LCD control brain — choose CEE 32A for industrial sites or Schuko for any household outlet.
              </p>
            </div>
            <div className="grid md:grid-cols-2 gap-5 mb-8">
              <div className="rounded-3xl border border-blue-400/25 bg-gradient-to-b from-blue-500/10 to-transparent p-6 md:p-8">
                <div className="h-52 flex items-center justify-center mb-5 rounded-2xl bg-[radial-gradient(circle,rgba(96,165,250,0.15),transparent_65%)]">
                  <img src="/images/products/go-cee.png" alt="GO CEE" className="max-h-full w-auto object-contain drop-shadow-[0_20px_50px_rgba(96,165,250,0.25)]" />
                </div>
                <p className="text-blue-400 text-[10px] font-semibold tracking-[0.2em] uppercase">Industrial grid</p>
                <h3 className="font-display text-2xl font-bold mt-1">GO CEE 32A</h3>
                <p className="text-sm text-kyn-silver mt-2">Blue industrial plug for workshops, depots, events and temporary sites — up to 22 kW depending on installation.</p>
                <div className="mt-4 flex flex-wrap gap-2">
                  {['CEE 32A', '7–22 kW', 'LCD box', 'Fleet & site'].map((t) => (
                    <span key={t} className="text-[10px] px-2.5 py-1 rounded-md border border-blue-400/30 text-blue-300 bg-blue-500/10">{t}</span>
                  ))}
                </div>
              </div>
              <div className="rounded-3xl border border-sky-300/20 bg-gradient-to-b from-sky-400/10 to-transparent p-6 md:p-8">
                <div className="h-52 flex items-center justify-center mb-5 rounded-2xl bg-[radial-gradient(circle,rgba(147,197,253,0.14),transparent_65%)]">
                  <img src="/images/products/go-schuko.png" alt="GO Schuko" className="max-h-full w-auto object-contain drop-shadow-[0_20px_50px_rgba(147,197,253,0.22)]" />
                </div>
                <p className="text-sky-300 text-[10px] font-semibold tracking-[0.2em] uppercase">Domestic grid</p>
                <h3 className="font-display text-2xl font-bold mt-1">GO Schuko</h3>
                <p className="text-sm text-kyn-silver mt-2">Universal household plug for apartments, hotels and visitor charging — compact enough for every trunk.</p>
                <div className="mt-4 flex flex-wrap gap-2">
                  {['Schuko', '1.8–3.7 kW', 'Travel ready', 'Plug & charge'].map((t) => (
                    <span key={t} className="text-[10px] px-2.5 py-1 rounded-md border border-sky-300/30 text-sky-200 bg-sky-400/10">{t}</span>
                  ))}
                </div>
              </div>
            </div>
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
              {[
                { t: 'Road trips', d: 'Charge at hotels, Airbnbs and family homes' },
                { t: 'Fleets', d: 'Backup EVSE when fixed chargers are busy' },
                { t: 'Construction', d: 'Temporary power on CEE industrial sites' },
                { t: 'Events', d: 'Pop-up charging for showrooms & demos' },
              ].map((u) => (
                <div key={u.t} className="rounded-2xl border border-white/8 bg-white/[0.02] p-4">
                  <p className="font-display font-semibold text-blue-300">{u.t}</p>
                  <p className="text-xs text-kyn-metal mt-1 leading-relaxed">{u.d}</p>
                </div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Compare matrix */}
      <section id="compare" className="py-20 md:py-24 bg-kyn-void border-y border-white/5">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <h2 className="font-display text-2xl md:text-3xl font-bold mb-3">Series matrix</h2>
          <p className="text-kyn-metal text-sm mb-8 max-w-xl">
            Wall, portable, urban and commercial pedestal — one KYNETIK Cloud ecosystem.
          </p>
          <div className="overflow-x-auto rounded-2xl border border-white/10">
            <table className="w-full text-left text-sm min-w-[980px]">
              <thead className="bg-white/[0.03] text-kyn-metal text-xs uppercase tracking-wider">
                <tr>
                  <th className="px-5 py-4 font-medium">Attribute</th>
                  <th className="px-5 py-4 font-medium text-kyn-green">NOVA</th>
                  <th className="px-5 py-4 font-medium text-teal-300">PRIME</th>
                  <th className="px-5 py-4 font-medium text-blue-400">GO</th>
                  <th className="px-5 py-4 font-medium text-lime-300">EDGE</th>
                  <th className="px-5 py-4 font-medium text-green-400">PRO</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {[
                  ['Form', 'Wall AC', 'Wall AC', 'Portable EVSE', 'Wall · Pedestal AC', 'Commercial pedestal'],
                  ['Finish', 'Matte black + green LED', 'Pearl white + teal LED', 'Matte black + LCD', 'Graphite · White pedestal', 'Matte black + green frame'],
                  ['Configs', 'Socket · Tethered', 'Socket · Tethered', 'CEE 32A · Schuko', 'Wall · Pedestal', 'Dual Cable · Socket'],
                  ['Power', '7–22 kW', '7–22 kW', '1.8–22 kW', '7–22 kW', '7–22 kW / 2×22 kW'],
                  ['Best for', 'Home & SME', 'Workplace & hotels', 'Travel, fleets, events', 'Urban shared parking', 'Fleet & public parking'],
                  ['Cloud', 'Full', 'Full', 'Session / app ready', 'Full OCPP + RFID', 'Full OCPP + dual session'],
                ].map((row) => (
                  <tr key={row[0]} className="text-kyn-silver">
                    <td className="px-5 py-3.5 text-kyn-metal font-medium">{row[0]}</td>
                    <td className="px-5 py-3.5">{row[1]}</td>
                    <td className="px-5 py-3.5">{row[2]}</td>
                    <td className="px-5 py-3.5">{row[3]}</td>
                    <td className="px-5 py-3.5">{row[4]}</td>
                    <td className="px-5 py-3.5">{row[5]}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="mt-10 grid sm:grid-cols-2 lg:grid-cols-5 gap-4">
            <div className="rounded-2xl border border-kyn-green/20 bg-black/40 p-6 flex items-center gap-4">
              <img src="/images/products/nova-tethered.png" alt="NOVA" className="h-24 w-auto object-contain" />
              <div>
                <p className="text-kyn-green text-xs font-semibold tracking-wider uppercase">NOVA</p>
                <p className="font-display font-bold">Dark signature wall</p>
              </div>
            </div>
            <div className="rounded-2xl border border-teal-400/25 bg-black/40 p-4 flex items-center gap-4 overflow-hidden">
              <img src="/images/products/prime-hero.png" alt="PRIME" className="h-24 w-20 object-cover rounded-lg shrink-0" />
              <div>
                <p className="text-teal-300 text-xs font-semibold tracking-wider uppercase">PRIME</p>
                <p className="font-display font-bold">Pearl hospitality</p>
              </div>
            </div>
            <div className="rounded-2xl border border-blue-400/25 bg-black/40 p-6 flex items-center gap-3">
              <div className="flex items-center -space-x-3">
                <img src="/images/products/go-cee.png" alt="GO CEE" className="h-20 w-auto object-contain relative z-10" />
                <img src="/images/products/go-schuko.png" alt="GO Schuko" className="h-20 w-auto object-contain opacity-90" />
              </div>
              <div>
                <p className="text-blue-400 text-xs font-semibold tracking-wider uppercase">GO</p>
                <p className="font-display font-bold">CEE · Schuko portable</p>
              </div>
            </div>
            <div className="rounded-2xl border border-lime-400/25 bg-black/40 p-6 flex items-center gap-4">
              <img src="/images/products/edge-wall.png" alt="EDGE" className="h-24 w-auto object-contain" />
              <div>
                <p className="text-lime-300 text-xs font-semibold tracking-wider uppercase">EDGE</p>
                <p className="font-display font-bold">Urban compact</p>
              </div>
            </div>
            <div className="rounded-2xl border border-green-400/25 bg-black/40 p-6 flex items-center gap-4">
              <img src="/images/products/pro-tethered.png" alt="PRO" className="h-24 w-auto object-contain" />
              <div>
                <p className="text-green-400 text-xs font-semibold tracking-wider uppercase">PRO</p>
                <p className="font-display font-bold">Commercial pedestal</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Anatomy */}
      <section id="anatomy" className="py-24 md:py-32">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="relative flex items-center justify-center min-h-[400px]">
              <div className="absolute inset-0" style={{ background: `radial-gradient(circle at center, ${meta.stage}, transparent 55%)` }} />
              <img
                src={
                  series === 'pro'
                    ? config === 'socket'
                      ? '/images/products/pro-socket.png'
                      : '/images/products/pro-tethered.png'
                    : series === 'edge'
                    ? config === 'pedestal'
                      ? '/images/products/edge-pedestal.png'
                      : '/images/products/edge-wall.png'
                    : series === 'go'
                    ? config === 'schuko'
                      ? '/images/products/go-schuko.png'
                      : '/images/products/go-cee.png'
                    : series === 'prime'
                      ? config === 'socket'
                        ? '/images/products/prime-socket.png'
                        : '/images/products/prime-hero.png'
                      : '/images/products/nova-tethered.png'
                }
                alt="Product anatomy"
                className={cn(
                  'relative z-10 w-auto object-contain',
                  series === 'pro' ? 'max-h-[520px]' : 'max-h-[480px]'
                )}
              />
              {series === 'go' ? (
                <>
                  <div className="absolute top-[22%] right-[6%] glass-card rounded-xl px-3 py-2 text-[10px] max-w-[130px]">
                    <span className="font-semibold text-blue-400">Type 2 gun</span>
                    <p className="text-kyn-metal mt-0.5">Vehicle connector</p>
                  </div>
                  <div className="absolute top-[48%] left-[4%] glass-card rounded-xl px-3 py-2 text-[10px] max-w-[130px]">
                    <span className="font-semibold text-blue-400">LCD box</span>
                    <p className="text-kyn-metal mt-0.5">Control + safety</p>
                  </div>
                  <div className="absolute bottom-[24%] right-[10%] glass-card rounded-xl px-3 py-2 text-[10px] max-w-[130px]">
                    <span className="font-semibold text-blue-400">Grid plug</span>
                    <p className="text-kyn-metal mt-0.5">CEE or Schuko</p>
                  </div>
                </>
              ) : series === 'pro' ? (
                <>
                  <div className="absolute top-[16%] right-[10%] glass-card rounded-xl px-3 py-2 text-[10px] max-w-[130px]">
                    <span className="font-semibold" style={{ color: meta.accent }}>LED frame</span>
                    <p className="text-kyn-metal mt-0.5">Screen bezel glow</p>
                  </div>
                  <div className="absolute top-[38%] left-[6%] glass-card rounded-xl px-3 py-2 text-[10px] max-w-[130px]">
                    <span className="font-semibold" style={{ color: meta.accent }}>HMI + RFID</span>
                    <p className="text-kyn-metal mt-0.5">Auth & session UI</p>
                  </div>
                  <div className="absolute bottom-[20%] right-[8%] glass-card rounded-xl px-3 py-2 text-[10px] max-w-[140px]">
                    <span className="font-semibold" style={{ color: meta.accent }}>Type 2 access</span>
                    <p className="text-kyn-metal mt-0.5">Dual cable or socket</p>
                  </div>
                </>
              ) : (
                <>
                  <div className="absolute top-[18%] right-[8%] glass-card rounded-xl px-3 py-2 text-[10px] max-w-[120px]">
                    <span className="font-semibold" style={{ color: meta.accent }}>LED ring</span>
                    <p className="text-kyn-metal mt-0.5">Status ambient</p>
                  </div>
                  <div className="absolute bottom-[22%] right-[6%] glass-card rounded-xl px-3 py-2 text-[10px] max-w-[130px]">
                    <span className="font-semibold" style={{ color: meta.accent }}>Type 2</span>
                    <p className="text-kyn-metal mt-0.5">Cable or socket</p>
                  </div>
                </>
              )}
            </div>

            <div>
              <p className="text-xs font-semibold tracking-[0.3em] uppercase mb-3" style={{ color: meta.accent }}>
                Product anatomy
              </p>
              <h2 className="font-display text-3xl md:text-4xl font-bold">
                {series === 'pro'
                  ? 'Built for commercial throughput'
                  : series === 'edge'
                    ? 'Built for the city edge'
                    : series === 'go'
                      ? 'Engineered for the road'
                      : 'Designed as a system, not a gadget'}
              </h2>
              <p className="mt-4 text-kyn-silver leading-relaxed">
                {series === 'pro'
                  ? 'PRO est la colonne commerciale KYNETIK : écran, RFID, cadre LED vert et architecture pedestal pour parkings flottes ou publics — en dual cable ou socket.'
                  : series === 'edge'
                  ? 'EDGE est la ligne urbaine compacte : face graphite murale ou tête blanche sur pedestal — RFID, LED ring et Cloud pour les parkings partagés.'
                  : series === 'go'
                  ? 'GO étend la famille KYNETIK hors du mur : un EVSE portable avec écran, sécurité embarquée et deux interfaces réseau pour ne plus dépendre d’une borne fixe.'
                  : 'Chaque détail suit le langage industriel KYNETIK — finition premium, signature lumineuse, Cloud-native.'}
              </p>
              <ul className="mt-8 space-y-4">
                {(active ? parseList(active.features) : callouts.map((c) => c.title)).slice(0, 6).map((f) => (
                  <li key={f} className="flex items-start gap-3 text-sm text-kyn-silver">
                    <Check size={16} className="mt-0.5 shrink-0" style={{ color: meta.accent }} />
                    {f}
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div className="mt-16 grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {callouts.map((c, i) => {
              const Icon = c.icon;
              return (
                <motion.div
                  key={c.title}
                  initial={{ opacity: 0, y: 12 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.05 }}
                  className="rounded-2xl border border-white/8 bg-white/[0.02] p-5"
                >
                  <Icon size={18} className="mb-3" style={{ color: meta.accent }} />
                  <p className="font-display font-semibold">{c.title}</p>
                  <p className="text-sm text-kyn-metal mt-1">{c.body}</p>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Family */}
      <section id="family" className="py-24 md:py-28 bg-kyn-void border-y border-white/5">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <div className="flex flex-wrap items-end justify-between gap-4 mb-10">
            <div>
              <p className="text-kyn-green text-xs font-semibold tracking-[0.3em] uppercase mb-3">Hardware family</p>
              <h2 className="font-display text-3xl md:text-4xl font-bold">NOVA · PRIME · GO · EDGE · PRO</h2>
            </div>
            <p className="text-sm text-kyn-metal max-w-sm">Wall, portable, urban and commercial pedestal — unified under KYNETIK Cloud.</p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {family.map((p) => {
              const s = seriesOf(p.name);
              const accent = p.accent || (s ? seriesMeta[s].accent : '#00e676');
              return (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => {
                    setActiveId(p.id);
                    if (s) {
                      setSeries(s);
                      const cfg = seriesMeta[s].configs.find((c) => p.name.toLowerCase().includes(c.match));
                      if (cfg) setConfig(cfg.id);
                    } else {
                      setSeries('family');
                    }
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className={cn(
                    'text-left rounded-2xl border p-4 transition-all hover:-translate-y-0.5',
                    activeId === p.id ? 'bg-white/[0.03]' : 'border-white/8 bg-black/30 hover:border-white/20'
                  )}
                  style={activeId === p.id ? { borderColor: `${accent}66` } : undefined}
                >
                  <div
                    className="h-36 flex items-center justify-center mb-3 rounded-xl"
                    style={{ background: `radial-gradient(circle, ${accent}22, transparent 70%)` }}
                  >
                    <img src={p.image_url} alt={p.name} className="h-full w-auto object-contain p-2" />
                  </div>
                  <p className="font-display font-bold text-sm">{p.name}</p>
                  <p className="text-[11px] mt-0.5" style={{ color: accent }}>
                    {p.power}
                  </p>
                  <p className="text-xs text-kyn-metal mt-2 line-clamp-2">{p.tagline}</p>
                </button>
              );
            })}
          </div>
        </div>
      </section>

      {/* Detail */}
      {active && (
        <section id="detail" className="py-20 md:py-24">
          <div className="max-w-7xl mx-auto px-5 md:px-8">
            <div className="rounded-3xl border border-white/10 overflow-hidden bg-gradient-to-br from-kyn-charcoal to-kyn-black">
              <div className="grid lg:grid-cols-2">
                <div className="flex items-center justify-center p-10 md:p-14 relative min-h-[360px]">
                  <div
                    className="absolute inset-0"
                    style={{
                      background: `radial-gradient(circle at center, ${active.accent || meta.accent}33, transparent 55%)`,
                    }}
                  />
                  <img
                    src={active.image_url}
                    alt={active.name}
                    className={cn(
                      'relative z-10 w-auto object-contain',
                      active.name.toUpperCase().includes('PRO') ? 'max-h-[460px]' : 'max-h-[400px]'
                    )}
                  />
                </div>
                <div className="p-8 md:p-12 flex flex-col justify-center border-t lg:border-t-0 lg:border-l border-white/5">
                  <p className="text-xs font-semibold tracking-[0.2em] uppercase" style={{ color: active.accent || meta.accent }}>
                    {active.category}
                  </p>
                  <h3 className="font-display text-3xl md:text-4xl font-bold mt-2">{active.name}</h3>
                  <p className="mt-3 text-kyn-silver">{active.tagline}</p>
                  <p className="mt-4 font-display text-xl" style={{ color: active.accent || meta.accent }}>
                    {active.power}
                  </p>
                  <div className="mt-6 flex flex-wrap gap-2">
                    {parseList(active.specs).map((s) => (
                      <span key={s} className="px-3 py-1.5 rounded-lg bg-kyn-steel border border-white/8 text-xs">
                        {s}
                      </span>
                    ))}
                  </div>
                  <ul className="mt-8 space-y-2.5">
                    {parseList(active.features).map((f) => (
                      <li key={f} className="flex gap-2 text-sm text-kyn-silver">
                        <ChevronRight size={15} className="shrink-0 mt-0.5" style={{ color: active.accent || meta.accent }} />
                        {f}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </section>
      )}

      <section className="py-20 md:py-24 bg-kyn-void border-y border-white/5">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <div className="grid md:grid-cols-3 gap-4">
            {[
              { icon: Cloud, t: 'KYNETIK Cloud', d: 'Supervision, smart charging, billing', to: '/cloud-platform' },
              { icon: Smartphone, t: 'Mobile App', d: 'Sessions, map, wallet, analytics', to: '/app' },
              { icon: Gauge, t: 'Operator Console', d: 'Multi-site real-time ops', to: '/cloud' },
            ].map(({ icon: Icon, t, d, to }) => (
              <Link key={t} to={to} className="group rounded-2xl border border-white/8 bg-black/30 p-6 hover:border-blue-400/30 transition-all">
                <Icon className="text-blue-400 mb-4" size={22} />
                <p className="font-display font-semibold text-lg group-hover:text-blue-300 transition-colors">{t}</p>
                <p className="text-sm text-kyn-metal mt-2">{d}</p>
                <span className="mt-4 inline-flex items-center gap-1 text-xs text-blue-400">
                  Ouvrir <ArrowRight size={12} />
                </span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <AppDownloadCTA accent={meta.accent} />

      <section id="cta" className="py-24 md:py-32 relative">
        <div className="absolute inset-0" style={{ background: `radial-gradient(ellipse at center, ${meta.glow}, transparent 55%)` }} />
        <div className="relative z-10 max-w-3xl mx-auto px-5 text-center">
          <BrandLogo height={36} className="mx-auto justify-center" />
          <h2 className="mt-8 font-display text-3xl md:text-5xl font-bold">
            NOVA. PRIME. GO. EDGE. PRO.
            <br />
            <span className="text-glow" style={{ color: meta.accent }}>
              Fixed, portable or urban. Always KYNETIK.
            </span>
          </h2>
          <p className="mt-5 text-kyn-silver max-w-xl mx-auto">
            Mur, hospitality, portable ou pedestal urbain — une seule marque, un Cloud, une expérience.
          </p>
          <div className="mt-10 flex flex-wrap justify-center gap-3">
            <a
              href="mailto:sales@kynetik.tn"
              className="inline-flex items-center gap-2 px-8 py-4 rounded-full text-sm font-bold text-kyn-black"
              style={{ background: meta.accent, boxShadow: `0 0 40px ${meta.glow}` }}
            >
              Contacter les ventes <ArrowRight size={16} />
            </a>
            <Link to="/" className="inline-flex items-center gap-2 px-8 py-4 rounded-full border border-white/15 text-sm font-medium">
              Design System
            </Link>
          </div>
        </div>
      </section>

      <footer className="border-t border-white/5 py-8">
        <div className="max-w-7xl mx-auto px-5 md:px-8 flex flex-wrap justify-between gap-4 items-center">
          <BrandLogo height={26} />
          <p className="text-[11px] text-kyn-metal">© KYNETIK Product System · NOVA · PRIME · GO · EDGE · PRO</p>
        </div>
      </footer>
    </div>
  );
}

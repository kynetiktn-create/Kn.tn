import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import SectionHeader from '../components/SectionHeader';
import LoadingState from '../components/LoadingState';
import ErrorState from '../components/ErrorState';
import Logo from '../components/Logo';
import { apiGet } from '../lib/utils';

interface Asset {
  id: number;
  title: string;
  category: string;
  description: string;
  meta: string | null;
}

const slides = [
  {
    type: 'cover',
    title: 'KYNETIK',
    subtitle: "L'énergie en mouvement",
    footer: 'Investor Presentation 2026 · Confidential',
  },
  {
    type: 'stat',
    title: 'Market Opportunity',
    stats: [
      { v: '€4.2B', l: 'MENA EV infra by 2030' },
      { v: '35%', l: 'CAGR charging assets' },
      { v: 'TN', l: 'Gateway to North Africa' },
    ],
  },
  {
    type: 'product',
    title: 'Hardware + Software',
    points: ['AC & DC product family', 'KYNETIK Cloud OCPP stack', 'Driver app & roaming', 'Academy certified installers'],
  },
  {
    type: 'traction',
    title: 'Traction Snapshot',
    stats: [
      { v: '120+', l: 'Chargers deployed' },
      { v: '48k', l: 'Sessions / year' },
      { v: '99.2%', l: 'Uptime target' },
    ],
  },
  {
    type: 'ask',
    title: 'The Ask',
    subtitle: 'Scale manufacturing, cloud & national coverage',
    points: ['Expand DC fast corridor', 'Enterprise fleet contracts', 'Regional partnerships'],
  },
];

export default function Investor() {
  const [assets, setAssets] = useState<Asset[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [active, setActive] = useState(0);

  useEffect(() => {
    apiGet<Asset[]>('/api/design-assets?category=investor')
      .then(setAssets)
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <div className="p-10"><LoadingState /></div>;
  if (error) return <div className="p-10"><ErrorState message={error} /></div>;

  const slide = slides[active];

  return (
    <div className="max-w-6xl mx-auto px-6 md:px-10 py-12 md:py-16">
      <SectionHeader
        eyebrow="08 · Investor Deck"
        title="Presentation template"
        description="Dark cinematic slides with large numbers, minimal copy and electric energy lines — built for fundraising and boardrooms."
      />

      {/* Slide stage */}
      <div className="rounded-2xl overflow-hidden border border-white/10 poster-shadow mb-6 aspect-[16/9] relative bg-kyn-black">
        <img src="/images/presentation.jpg" alt="" className="absolute inset-0 w-full h-full object-cover opacity-15" />
        <div className="absolute inset-0 grid-bg" />
        <div className="absolute top-0 inset-x-0 h-px bg-gradient-to-r from-transparent via-kyn-green to-transparent" />

        <div className="relative z-10 h-full p-8 md:p-12 flex flex-col">
          <div className="flex justify-between items-start">
            <Logo size="sm" glowing />
            <span className="text-[10px] text-kyn-metal tracking-widest">0{active + 1} / 0{slides.length}</span>
          </div>

          <div className="flex-1 flex flex-col justify-center">
            {slide.type === 'cover' && (
              <motion.div key={active} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}>
                <h2 className="font-display text-4xl md:text-6xl font-bold tracking-tight">{slide.title}</h2>
                <p className="mt-4 text-xl md:text-2xl text-kyn-green text-glow">{slide.subtitle}</p>
                <p className="mt-10 text-xs text-kyn-metal tracking-wide">{slide.footer}</p>
              </motion.div>
            )}

            {(slide.type === 'stat' || slide.type === 'traction') && (
              <motion.div key={active} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}>
                <h2 className="font-display text-2xl md:text-3xl font-bold mb-10">{slide.title}</h2>
                <div className="grid grid-cols-3 gap-6">
                  {slide.stats?.map((s) => (
                    <div key={s.l}>
                      <p className="font-display text-3xl md:text-5xl font-bold text-kyn-green text-glow">{s.v}</p>
                      <p className="mt-2 text-xs md:text-sm text-kyn-metal">{s.l}</p>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}

            {(slide.type === 'product' || slide.type === 'ask') && (
              <motion.div key={active} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}>
                <h2 className="font-display text-2xl md:text-3xl font-bold">{slide.title}</h2>
                {slide.subtitle && <p className="mt-2 text-kyn-silver">{slide.subtitle}</p>}
                <ul className="mt-8 space-y-3">
                  {slide.points?.map((p) => (
                    <li key={p} className="flex items-center gap-3 text-sm md:text-base">
                      <span className="w-1.5 h-1.5 rounded-full bg-kyn-green" />
                      {p}
                    </li>
                  ))}
                </ul>
              </motion.div>
            )}
          </div>

          <div className="energy-line" />
        </div>
      </div>

      {/* Slide nav */}
      <div className="flex flex-wrap gap-2 mb-12">
        {slides.map((s, i) => (
          <button
            key={s.title}
            type="button"
            onClick={() => setActive(i)}
            className={`px-4 py-2 rounded-lg text-xs font-medium transition-colors ${
              active === i
                ? 'bg-kyn-green text-kyn-black'
                : 'bg-kyn-steel text-kyn-silver hover:text-white'
            }`}
          >
            {i + 1}. {s.title}
          </button>
        ))}
      </div>

      <div className="grid md:grid-cols-3 gap-4">
        {assets.map((a) => (
          <div key={a.id} className="glass-card rounded-2xl p-6">
            <h3 className="font-display font-semibold">{a.title}</h3>
            <p className="text-sm text-kyn-metal mt-2">{a.description}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
